// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#define WIN32_LEAN_AND_MEAN
#define _WIN32_WINNT 0x0400

#include "core.h"
#include "scene.h"
#include "lightbvh.h"
#include "photonmap.h"
#include "common.h"
#include "windows.h"
#include "winbase.h"
#include "bvh.h"
#include "bvhthreaded.h"
#include "bvhstatic.h"
#include "bvhagglom.h"
#include "memory.h"
#include "freeimage.h"
#include "math.h"
#include "stdio.h"
#include "string.h"
#include "sthread.h"
#include "jobmanager.h"
#include <d3d9.h>
#include <d3dx9.h>
#include <dxerr9.h>
#include "surface.h"
#include "scenegraph.h"
#include <stdio.h>
#include <fcntl.h>
#include <iostream>
#include <fstream>
#include <io.h>
#include <vector>
#include <limits>