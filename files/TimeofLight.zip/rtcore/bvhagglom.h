// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#pragma once

#include "common_math.h"
#include "sthread.h"

namespace Raytracer {

struct BinTri;
struct BVHNode;
class Node;

class Cluster
{
public:
	bool IsLeaf() { return (prims > 0); }
	// data members
	__m128 cmin, cmax, vmin, vmax;			// 64
	BinTri* prim[8];						// 32
	Cluster* left, *right, *next, *prev;	// 16
	int prims, d1, d2, d3;					// 16
};

class AgglomerativeBuilder : public BVHBuilder
{
public:
	AgglomerativeBuilder( Node* a_Node );
	~AgglomerativeBuilder();
	void CalculateUnion( Cluster* a_First, Cluster* a_Second, __m128& a_Min, __m128& a_Max );
	float CalculateArea( __m128& a_Min, __m128& a_Max );
	Cluster* FindBestMatch( Cluster* m_Cluster, Cluster* a_List );
	void ClusterTreeStats( Cluster* a_Node, int& a_Nodes, int& a_Leafs, int& a_MaxDepth, int a_Depth );
	void CreateBVH( Cluster* a_Node, BVHNode* a_Root );
	void OptimizeClusters( Cluster* a_Node );
	void Build();
private:
	BinTri** m_Tri;
	BinTri* m_BTPool;
	int m_PIdx;
};

}; // namespace Raytracer