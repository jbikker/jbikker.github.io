// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#include "precomp.h"
#include "windows.h"
#include "bvh.h"

namespace Raytracer {

void StaticBuilder::BuildThread::Init( int a_Thread, int a_PCount, StaticBuilder* a_Builder )
{
	m_Thread = a_Thread;
	m_Builder = a_Builder;
	SetThreadIdealProcessor( handle(), m_Thread );
	m_TTri = new BinTri*[a_PCount];
	box = (__m128*)MALLOC64( 4 * sizeof( __m128 ) );
}

void StaticBuilder::BuildThread::SetData( int firstprim, BinTri** trilist, BVHNode* root, int first, int last, BVHNode* pool, int pidx )
{
	m_FirstPrim = firstprim;
	m_Tri = trilist; 
	m_Root = root; 
	m_First = first; 
	m_Last = last; 
	m_Pool = pool; 
	m_PIdx = pidx; 
}

void StaticBuilder::BuildThread::run()
{
	while (1)
	{
		WaitForSingleObject( m_Builder->m_Wait[m_Thread], INFINITE );
		Build();
		SetEvent( m_Builder->m_Done[m_Thread] );
	}
}

void StaticBuilder::BuildThread::Build()
{
	BinStack stack[128];
	int stackptr = 0;
	int first = m_First, last = m_Last;
	__m128 vmin4 = box[2], vmax4 = box[3], cmin4 = box[0], cmax4 = box[1];
	const __m128 plarge = _mm_set_ps1( 100000 ), nlarge = _mm_set_ps1( -100000 ), half4 = _mm_set_ps1( 0.5f );
	BVHNode* node = m_Root;
	while (1)
	{
		while (1)
		{
			// store node extends
			const float* vmin = (float*)&vmin4, *vmax = (float*)&vmax4;
			node->min = vector3( vmin[3], vmin[2], vmin[1] );
			node->max = vector3( vmax[3], vmax[2], vmax[1] );
			// check termination criterium: minimal primitive count
			if ((last - first) < 2) break;
			// loop over axii
			int bestaxis = -1;
			__m128 bestlmin4c, bestlmin4v, bestlmax4c, bestlmax4v;
			__m128 bestrmin4c, bestrmin4v, bestrmax4c, bestrmax4v;
			const float* cmin = (float*)&cmin4, *cmax = (float*)&cmax4;
			const float k1[3] = { 15.9999f / (cmax[3] - cmin[3]), 15.9999f / (cmax[2] - cmin[2]), 15.9999f / (cmax[1] - cmin[1]) };
			union { __m128 extends4; float extends[4]; };
			extends4 = _mm_sub_ps( vmax4, vmin4 );
			float bestcost = (extends[1] * extends[2] + extends[2] * extends[3] + extends[1] * extends[3]) * ((last - first) + 1);
			int bestpos = -1;
			for ( int axis = 0; axis < 3; axis++ )
			{
				const float extend = cmax[3 - axis] - cmin[3 - axis];
				if (extend < 0.8f) continue; // skip this axis, too small
				// calculate counts and boxes for the bins
				__m128 bcmin[16], bcmax[16], bvmin[16], bvmax[16], lmin4c[16], lmax4c[16];
				__m128 lmin4v[16], lmax4v[16], rmin4v[16], rmax4v[16], rmin4c[16], rmax4c[16];
				for ( int i = 0; i < 16; i++ )
				{
					bcmin[i] = bvmin[i] = lmin4c[i] = rmin4c[i] = lmin4v[i] = rmin4v[i] = plarge;
					bcmax[i] = bvmax[i] = lmax4c[i] = rmax4c[i] = lmax4v[i] = rmax4v[i] = nlarge;
				}
				union { __m128 kNl4[4]; float kNl[16]; };
				union { __m128 kNr4[4]; float kNr[16]; };
				union { __m128 kAl4[4]; float kAl[16]; };
				union { __m128 kAr4[4]; float kAr[16]; };
				union { __m128 Ck4[4]; float Ck[16]; };
				float binN[16] = { 0, 0, 0, 0, 0, 0, 0, 0 };
				for ( int r = first; r <= last; r++ )
				{
					float* centroid = (float*)&m_Tri[r]->centroid;
					const int bin = (int)(k1[axis] * (centroid[3 - axis] - cmin[3 - axis]));
					binN[bin] += 1.0f;
					bcmin[bin] = _mm_min_ps( bcmin[bin], m_Tri[r]->centroid );								// update centroid box of a bin (min)
					bcmax[bin] = _mm_max_ps( bcmax[bin], m_Tri[r]->centroid );								// update centroid box of a bin (max)
					bvmin[bin] = _mm_min_ps( bvmin[bin], m_Tri[r]->boxp1 );									// update voxel box of a bin (min)
					bvmax[bin] = _mm_max_ps( bvmax[bin], m_Tri[r]->boxp2 );									// update voxel box of a bin (min)
				}
				// calculate cost per split candidate
				float Nl = 0, Nr = 0;
				__m128 min4cl = plarge, max4cl = nlarge;													// final left and right centroid box
				__m128 min4vl = plarge, max4vl = nlarge;													// final left and right voxel box
				__m128 min4cr = plarge, max4cr = nlarge;													// final left and right centroid box
				__m128 min4vr = plarge, max4vr = nlarge;													// final left and right voxel box
				for ( int k = 0; k < 16; k++ )
				{
					const unsigned int k2 = 15 - k;
					kNr[k2] = Nr;
					union { __m128 extends4; float extends[4]; };
					extends4 = _mm_sub_ps( max4vr, min4vr );
					rmin4c[k2] = min4cr, rmax4c[k2] = max4cr;
					rmin4v[k2] = min4vr, rmax4v[k2] = max4vr;
					kAr[k2] = extends[1] * extends[2] + extends[2] * extends[3] + extends[1] * extends[3];
					min4cl = lmin4c[k] = _mm_min_ps( min4cl, bcmin[k] ), max4cl = lmax4c[k] = _mm_max_ps( max4cl, bcmax[k] );
					min4vl = lmin4v[k] = _mm_min_ps( min4vl, bvmin[k] ), max4vl = lmax4v[k] = _mm_max_ps( max4vl, bvmax[k] );
					min4cr = _mm_min_ps( min4cr, bcmin[k2] ), max4cr = _mm_max_ps( max4cr, bcmax[k2] );
					min4vr = _mm_min_ps( min4vr, bvmin[k2] ), max4vr = _mm_max_ps( max4vr, bvmax[k2] );
					Nl += binN[k], Nr += binN[k2];
					kNl[k] = Nl;
					extends4 = _mm_sub_ps( max4vl, min4vl );
					kAl[k] = extends[1] * extends[2] + extends[2] * extends[3] + extends[1] * extends[3];
				}
				// determine best position
				Ck4[0] = _mm_add_ps( _mm_mul_ps( kAl4[0], kNl4[0] ), _mm_mul_ps( kAr4[0], kNr4[0] ) );
				Ck4[1] = _mm_add_ps( _mm_mul_ps( kAl4[1], kNl4[1] ), _mm_mul_ps( kAr4[1], kNr4[1] ) );
				Ck4[2] = _mm_add_ps( _mm_mul_ps( kAl4[2], kNl4[2] ), _mm_mul_ps( kAr4[2], kNr4[2] ) );
				Ck4[3] = _mm_add_ps( _mm_mul_ps( kAl4[3], kNl4[3] ), _mm_mul_ps( kAr4[3], kNr4[3] ) );
				for ( int k = 0; k < 15; k++ ) if ((kNl[k] > 0) && (kNr[k] > 0) && (Ck[k] < bestcost)) 
				{
					bestpos = k;
					bestcost = Ck[k];
					bestaxis = axis;
					bestlmin4c = lmin4c[k], bestlmin4v = lmin4v[k], bestlmax4c = lmax4c[k], bestlmax4v = lmax4v[k];
					bestrmin4c = rmin4c[k], bestrmin4v = rmin4v[k], bestrmax4c = rmax4c[k], bestrmax4v = rmax4v[k];
				}
			}
			// split at best position
			if (bestaxis == -1) break;
			int lcount = 0, rcount = 0;
			const int count = (last - first) + 1;
			for ( int r = first; r <= last; r++ )
			{
				const float* centroid = (float*)&m_Tri[r]->centroid;
				const int bin = (int)(k1[bestaxis] * (centroid[3 - bestaxis] - cmin[3 - bestaxis]));
				if (bin <= bestpos) m_TTri[lcount++] = m_Tri[r]; else m_TTri[count - ++rcount] = m_Tri[r];
			}
			// recurse
			node->SetLeft( m_PIdx );
			node->SetAxis( bestaxis );
			node->SetTCount( 0 );
			const __m128 lcentre4 = _mm_mul_ps( half4, _mm_add_ps( bestlmin4v, bestlmax4v ) );
			const __m128 rcentre4 = _mm_mul_ps( half4, _mm_add_ps( bestrmin4v, bestrmax4v ) );
			const float* lcentre = (float*)&lcentre4, *rcentre = (float*)&rcentre4;
			node->SetFirst( lcentre[bestaxis] > rcentre[bestaxis]?1:0 );
			memcpy( m_Tri + first, m_TTri, ((last - first) + 1) * 4 );
			// push right side on stack
			node = &m_Pool[m_PIdx++];
			stack[stackptr].node = &m_Pool[m_PIdx++];
			stack[stackptr].first = first + lcount;
			stack[stackptr].last = last;
			stack[stackptr].cmin4 = bestrmin4c;
			stack[stackptr].cmax4 = bestrmax4c;
			stack[stackptr].vmin4 = bestrmin4v;
			stack[stackptr].vmax4 = bestrmax4v;
			stackptr++;
			last = (first + lcount) - 1;	
			cmin4 = bestlmin4c;
			cmax4 = bestlmax4c;
			vmin4 = bestlmin4v;
			vmax4 = bestlmax4v;
			BVHNode* tnode = stack[stackptr - 1].node;
		}
		// generate leaf
		node->SetStart( first + m_FirstPrim );
		node->SetTCount( (last - first) + 1 );
		// pop from stack and continue
		if (!stackptr) break;
		first = stack[--stackptr].first;
		node = stack[stackptr].node;
		last = stack[stackptr].last;
		vmin4 = stack[stackptr].vmin4;
		vmax4 = stack[stackptr].vmax4;
		cmin4 = stack[stackptr].cmin4;
		cmax4 = stack[stackptr].cmax4;
	}
}

// --------------------------------------------------------------------------
// StaticBuilder class
// --------------------------------------------------------------------------

StaticBuilder::StaticBuilder( Node* a_Node )
{
	m_Node = a_Node;												// this builder will always build a_Node
	m_PCount = a_Node->GetPrimCount();								// store polygon count (supposed to remain constant)
	int allocsize = m_PCount;
#ifdef BVHPRESPLIT
	allocsize = m_PCount + (m_PCount >> 1);
#endif
	m_FirstNode = MManager::AllocBVHNodes( allocsize * 2 );			// reserve some extra room for split triangles
	m_LastNode = (m_FirstNode + allocsize * 2) - 1;
	m_FirstPrim = MManager::AllocBVHPrims( allocsize );
	m_LastPrim = (m_FirstPrim + allocsize) - 1;
	m_Pool = MManager::GetBVHPool();
	m_Root = &m_Pool[m_FirstNode];									// this will always be the root
	m_Prim = &MManager::GetBVHPrims()[m_FirstPrim];					// for easier building, create a pointer to the first primitive pointer we own
	for ( int i = 0; i < 2; i++ )
	{
		m_Wait[i] = CreateEvent( NULL, FALSE, FALSE, NULL );		// create the 'wait for build command' signal
		m_Done[i] = CreateEvent( NULL, FALSE, FALSE, NULL );		// create the 'building done' signal
	}
	m_TBuilder[0].Init( 0, allocsize, this );						// initialize building thread 0
	m_TBuilder[1].Init( 1, allocsize, this );						// initialize building thread 1
	m_TBuilder[0].start();											// start building thread 0 (it will start waiting for a build command)
	m_TBuilder[1].start();											// start building thraed 1
}

StaticBuilder::~StaticBuilder()
{
	FREE64( m_BTPool );
	delete m_TTri;
	delete m_Tri;
}

void StaticBuilder::Build()
{
	// allocate temporary bintree nodes
	int allocsize = m_PCount;
#ifdef BVHPRESPLIT
	allocsize = m_PCount + (m_PCount >> 1);
#endif
	m_BTPool = (BinTri*)MALLOC64( sizeof( BinTri ) * allocsize );
	m_Tri = new BinTri*[allocsize];								
	m_TTri = new BinTri*[allocsize];							
	for ( int i = 0; i < allocsize; i++ ) m_Tri[i] = &m_BTPool[i];
	// implementation of Wald's paper, 'On fast Construction of SAH-based Bounding Volume Hierarchies'
	memcpy( m_Prim, m_Node->GetPrimArray(), m_PCount * 4 );
	BVHNode* node = &m_Pool[m_FirstNode];
	// determine centroids and aabbs for all triangles
	const __m128 plarge = _mm_set_ps1( 100000 ), nlarge = _mm_set_ps1( -100000 ), half4 = _mm_set_ps1( 0.5f );
	__m128 cmin4 = plarge, cmax4 = nlarge;  // box around centroids
	__m128 vmin4 = plarge, vmax4 = nlarge;	// voxel size; initially full scene extend
	int pidx = 0;
	int splitroom = m_PCount >> 1;
	for ( unsigned int r = 0; r < m_PCount; r++ )
	{
		__m128 emin4 = plarge, emax4 = nlarge;
		for ( int j = 0; j < 3; j++ )
		{
			const vector3 pos = m_Prim[r]->GetVertex( j )->GetPos();
			const __m128 pos4 = _mm_set_ps( pos.x, pos.y, pos.z, 0 );
			emin4 = _mm_min_ps( emin4, pos4 ), emax4 = _mm_max_ps( emax4, pos4 );
		}
		m_Tri[pidx]->prim = m_Prim[r];
		m_Tri[pidx]->boxp1 = emin4;
		m_Tri[pidx]->boxp2 = emax4;
		m_Tri[pidx]->centroid = _mm_mul_ps( _mm_add_ps( emin4, emax4 ), half4 );
		cmin4 = _mm_min_ps( cmin4, m_Tri[pidx]->centroid ), cmax4 = _mm_max_ps( cmax4, m_Tri[pidx]->centroid );
		vmin4 = _mm_min_ps( vmin4, emin4 ), vmax4 = _mm_max_ps( vmax4, emax4 );
		pidx++;
	#ifdef BVHPRESPLIT
		// pre-split triangles
		BinTri* bstack[64]; int bsidx[64];
		bstack[0] = m_Tri[pidx - 1]; bsidx[0] = pidx - 1;
		int bsptr = 1;
		while (bsptr > 0)
		{
			BinTri* tri1 = bstack[--bsptr];
			BinTri* tri2 = m_Tri[pidx];
			float* emin = (float*)&tri1->boxp1;
			float* emax = (float*)&tri1->boxp2;
			vector3 p1( emin[3], emin[2], emin[1] ), p2( emax[3] - emin[3], emax[2] - emin[2], emax[1] - emin[1] );
			aabb box = aabb::FromPosSize( p1, p2 );
			float sarea = box.area();
			if ((sarea > 90) && (splitroom > 0))
			{
				// split and push both halves on the stack
				int axis = box.LongestSide();
				float centre = (box.GetP1().cell[axis] + box.GetP2().cell[axis]) * 0.5f;
				// emit boxes
				*tri2 = *tri1;
				float* temax = (float*)&tri1->boxp2;
				float* temin = (float*)&tri2->boxp1;
				temax[3 - axis] = temin[3 - axis] = centre;
				tri1->centroid = _mm_mul_ps( _mm_add_ps( tri1->boxp1, tri1->boxp2 ), half4 );
				tri2->centroid = _mm_mul_ps( _mm_add_ps( tri2->boxp1, tri2->boxp2 ), half4 );
				cmin4 = _mm_min_ps( cmin4, tri1->centroid ), cmax4 = _mm_max_ps( cmax4, tri1->centroid );
				vmin4 = _mm_min_ps( vmin4, emin4 ), vmax4 = _mm_max_ps( vmax4, emax4 );
				cmin4 = _mm_min_ps( cmin4, tri2->centroid ), cmax4 = _mm_max_ps( cmax4, tri2->centroid );
				vmin4 = _mm_min_ps( vmin4, emin4 ), vmax4 = _mm_max_ps( vmax4, emax4 );
				bsptr++;
				bstack[bsptr] = tri2; 
				bsidx[bsptr++] = pidx++;
				splitroom--;
			}
			else m_Tri[bsidx[bsptr]] = tri1;
		}
	#endif
	}
	m_PCount = pidx;
	// first split
	int first = 0, last = m_PCount -1, stackptr = 0;
	const float* vmin = (float*)&vmin4, *vmax = (float*)&vmax4;
	node->min = vector3( vmin[3], vmin[2], vmin[1] );
	node->max = vector3( vmax[3], vmax[2], vmax[1] );
	// determine longest axis (for first split, this should be fine)
	int axis = 0;
	const float* cmin = (float*)&cmin4, *cmax = (float*)&cmax4;
	float largest = cmax[SSE_X] - cmin[SSE_X];
	if ((cmax[SSE_Y] - cmin[SSE_Y]) > largest) axis = 1, largest = cmax[SSE_Y] - cmin[SSE_Y];
	if ((cmax[SSE_Z] - cmin[SSE_Z]) > largest) axis = 2, largest = cmax[SSE_Z] - cmin[SSE_Z];
	union { __m128 extends4; float extends[4]; };
	extends4 = _mm_sub_ps( vmax4, vmin4 );
	float Cn = (extends[1] * extends[2] + extends[2] * extends[3] + extends[1] * extends[3]) * ((last - first) + 1);
	// calculate counts and boxes for the bins
	__m128 bcmin[16], bcmax[16], bvmin[16], bvmax[16], lmin4c[16], lmax4c[16];
	__m128 lmin4v[16], lmax4v[16], rmin4v[16], rmax4v[16], rmin4c[16], rmax4c[16];
	for ( int i = 0; i < 16; i++ )
	{
		bcmin[i] = bvmin[i] = lmin4c[i] = rmin4c[i] = lmin4v[i] = rmin4v[i] = plarge;
		bcmax[i] = bvmax[i] = lmax4c[i] = rmax4c[i] = lmax4v[i] = rmax4v[i] = nlarge;
	}
	union { __m128 kNl4[4]; float kNl[16]; };
	union { __m128 kNr4[4]; float kNr[16]; };
	union { __m128 kAl4[4]; float kAl[16]; };
	union { __m128 kAr4[4]; float kAr[16]; };
	union { __m128 Ck4[4]; float Ck[16]; };
	float binN[16] = { 0, 0, 0, 0, 0, 0, 0, 0 };
	const float k1 = 15.9999f / (cmax[3 - axis] - cmin[3 - axis]);
	for ( int r = first; r <= last; r++ )
	{
		float* centroid = (float*)&m_Tri[r]->centroid;
		const int bin = (int)(k1 * (centroid[3 - axis] - cmin[3 - axis]));
		binN[bin] += 1.0f;
		bcmin[bin] = _mm_min_ps( bcmin[bin], m_Tri[r]->centroid );								// update centroid box of a bin (min)
		bcmax[bin] = _mm_max_ps( bcmax[bin], m_Tri[r]->centroid );								// update centroid box of a bin (max)
		bvmin[bin] = _mm_min_ps( bvmin[bin], m_Tri[r]->boxp1 );									// update voxel box of a bin (min)
		bvmax[bin] = _mm_max_ps( bvmax[bin], m_Tri[r]->boxp2 );									// update voxel box of a bin (min)
	}
	// calculate cost per split candidate
	float Nl = 0, Nr = 0;
	__m128 min4cl = plarge, max4cl = nlarge;													// final left and right centroid box
	__m128 min4vl = plarge, max4vl = nlarge;													// final left and right voxel box
	__m128 min4cr = plarge, max4cr = nlarge;													// final left and right centroid box
	__m128 min4vr = plarge, max4vr = nlarge;													// final left and right voxel box
	for ( int k = 0; k < 16; k++ )
	{
		const unsigned int k2 = 15 - k;
		kNr[k2] = Nr;
		union { __m128 extends4; float extends[4]; };
		extends4 = _mm_sub_ps( max4vr, min4vr );
		rmin4c[k2] = min4cr, rmax4c[k2] = max4cr;
		rmin4v[k2] = min4vr, rmax4v[k2] = max4vr;
		kAr[k2] = extends[1] * extends[2] + extends[2] * extends[3] + extends[1] * extends[3];
		min4cl = lmin4c[k] = _mm_min_ps( min4cl, bcmin[k] ), max4cl = lmax4c[k] = _mm_max_ps( max4cl, bcmax[k] );
		min4vl = lmin4v[k] = _mm_min_ps( min4vl, bvmin[k] ), max4vl = lmax4v[k] = _mm_max_ps( max4vl, bvmax[k] );
		min4cr = _mm_min_ps( min4cr, bcmin[k2] ), max4cr = _mm_max_ps( max4cr, bcmax[k2] );
		min4vr = _mm_min_ps( min4vr, bvmin[k2] ), max4vr = _mm_max_ps( max4vr, bvmax[k2] );
		Nl += binN[k], Nr += binN[k2];
		kNl[k] = Nl;
		extends4 = _mm_sub_ps( max4vl, min4vl );
		kAl[k] = extends[1] * extends[2] + extends[2] * extends[3] + extends[1] * extends[3];
	}
	// determine best position
	float bestcost = Cn;
	int bestpos = -1;
	Ck4[0] = _mm_add_ps( _mm_mul_ps( kAl4[0], kNl4[0] ), _mm_mul_ps( kAr4[0], kNr4[0] ) );
	Ck4[1] = _mm_add_ps( _mm_mul_ps( kAl4[1], kNl4[1] ), _mm_mul_ps( kAr4[1], kNr4[1] ) );
	Ck4[2] = _mm_add_ps( _mm_mul_ps( kAl4[2], kNl4[2] ), _mm_mul_ps( kAr4[2], kNr4[2] ) );
	Ck4[3] = _mm_add_ps( _mm_mul_ps( kAl4[3], kNl4[3] ), _mm_mul_ps( kAr4[3], kNr4[3] ) );
	for ( int k = 0; k < 15; k++ ) if ((kNl[k] > 0) && (kNr[k] > 0) && (Ck[k] < bestcost)) bestpos = k, bestcost = Ck[k];
	// split at best position
	if (bestpos == -1) 
	{
		m_Root = 0; // that's bad, as we haven't even subdivided yet.
		return;
	}
	int lcount = 0, rcount = 0;
	const int count = (last - first) + 1;
	for ( int r = first; r <= last; r++ )
	{
		const float* centroid = (float*)&m_Tri[r]->centroid;
		const int bin = (int)(k1 * (centroid[3 - axis] - cmin[3 - axis]));
		if (bin <= bestpos) m_TTri[lcount++] = m_Tri[r]; else m_TTri[count - ++rcount] = m_Tri[r];
	}
	// launch threads
	node->SetLeft( m_FirstNode + 1 );
	node->SetAxis( axis );
	node->SetTCount( 0 );
	const __m128 lcentre4 = _mm_mul_ps( half4, _mm_add_ps( lmin4v[bestpos], lmax4v[bestpos] ) );
	const __m128 rcentre4 = _mm_mul_ps( half4, _mm_add_ps( rmin4v[bestpos], rmax4v[bestpos] ) );
	const float* lcentre = (float*)&lcentre4, *rcentre = (float*)&rcentre4;
	node->SetFirst( lcentre[axis] > rcentre[axis]?1:0 );
	memcpy( m_Tri + first, m_TTri, ((last - first) + 1) * 4 );
	BVHNode* lnode = &m_Pool[m_FirstNode + 1];
	BVHNode* rnode = &m_Pool[m_FirstNode + 2];
	m_TBuilder[0].SetData( m_FirstPrim, m_Tri, lnode, first, (first + lcount) - 1, m_Pool, m_FirstNode + 3 );
	m_TBuilder[0].SetCBox( lmin4c[bestpos], lmax4c[bestpos] );
	m_TBuilder[0].SetVBox( lmin4v[bestpos], lmax4v[bestpos] );
	m_TBuilder[1].SetData( m_FirstPrim, m_Tri, rnode, first + lcount, last, m_Pool, m_FirstNode + 3 + 2 * lcount );
	m_TBuilder[1].SetCBox( rmin4c[bestpos], rmax4c[bestpos] );
	m_TBuilder[1].SetVBox( rmin4v[bestpos], rmax4v[bestpos] );
	SetEvent( m_Wait[0] );
	SetEvent( m_Wait[1] );
	// wait for threads to complete
	WaitForMultipleObjects( 2, m_Done, true, INFINITE );
	for ( unsigned int i = 0; i < m_PCount; i++ ) m_Prim[i] = m_Tri[i]->prim;
	// clean up
	FREE64( m_BTPool );
	delete m_Tri;
	delete m_TTri;
}

}; // namespace Raytracer