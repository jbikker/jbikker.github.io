// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#include "precomp.h"

using namespace Raytracer;

_declspec(align(16)) 

Texture* MManager::m_TPtr;
Light* MManager::m_LgtPtr;
unsigned int MManager::m_CurPrim, MManager::m_CurLight;
unsigned int MManager::m_CurText, MManager::m_CurMat;
Primitive* MManager::m_PrimPtr;
Material* MManager::m_MPtr;
LightList* MManager::m_LLPtr;
LNode* MManager::m_LNPtr;
LBVHNode* LBVHMManager::m_LBVHNPtr;

MManager::MManager()
{
	m_MPtr = (Material*)MALLOC64( MAXMATERIAL * sizeof( Material ) );
	m_CurMat = 0;
	m_TPtr = (Texture*)MALLOC64( 512 * sizeof( Texture ) );
	m_CurText = 0;
}

void MManager::Init( unsigned int a_Size )
{
	a_Size += 20; // take care of some boundaries & stuff
	m_LgtPtr = (Light*)MALLOC64( MAXLIGHTS * sizeof( Light ) );
	m_CurLight = 0;
	m_PrimPtr = (Primitive*)MALLOC64( a_Size * sizeof( Primitive ) );
	m_CurPrim = 0;
	m_LLPtr = (LightList*)MALLOC64( 2048 * sizeof( LightList ) );
	for ( unsigned int i = 0; i < 2048; i++ ) m_LLPtr[i].SetNext( &m_LLPtr[i + 1] );
	m_LNPtr = (LNode*)MALLOC64( 2048 * sizeof( LNode ) );
	for ( unsigned int i = 0; i < 2048; i++ ) m_LNPtr[i].SetLeft( &m_LNPtr[i + 1] );
}

Texture* MManager::FindTexture( char* a_Name )
{
	for ( unsigned int i = 0; i < m_CurText; i++ ) if (m_TPtr[i].m_Name)
		if (!strcmp( m_TPtr[i].m_Name, a_Name )) return &m_TPtr[i];
	return 0;
}

Primitive* MManager::NewPrimitive() { return &m_PrimPtr[m_CurPrim++]; }
Light* MManager::NewLight() { return &m_LgtPtr[m_CurLight++]; }
Texture* MManager::NewTexture() { return &m_TPtr[m_CurText++]; }
Material* MManager::NewMaterial() { m_MPtr[m_CurMat].Init(); return &m_MPtr[m_CurMat++]; }