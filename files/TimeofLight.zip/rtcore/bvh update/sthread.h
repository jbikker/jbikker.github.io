// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#pragma once

// original code by Vijay Mathew Pandyalakal

namespace Raytracer {

class Thread 
{
private:
	unsigned long* m_hThread;
public:
	Thread() { m_hThread = NULL; }
	~Thread() { if (m_hThread != NULL) stop(); }
	unsigned long* handle() { return m_hThread; }
	void start();
	virtual void run() {};
	void sleep(long ms);
	void suspend();
	void resume();
	void kill();
	void stop();
	void setPriority(int p);
	static const int P_ABOVE_NORMAL;
	static const int P_BELOW_NORMAL;
	static const int P_HIGHEST;
	static const int P_IDLE;
	static const int P_LOWEST;
	static const int P_NORMAL;
	static const int P_CRITICAL;
};

}

extern "C" { unsigned int sthread_proc(void* param); }				
