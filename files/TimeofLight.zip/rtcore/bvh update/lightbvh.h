// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#pragma once

#include "common_math.h"

namespace Raytracer {

class LBVHNode
{
public:
	LBVHNode() {}
	// data access
	void Init( LBVHNode* a_Left, LBVHNode* a_Right, float a_Radius );
	void SetLeft( LBVHNode* a_Left) { m_Left = a_Left; }
	LBVHNode* GetLeft() const { return m_Left; }
	LBVHNode* GetRight() const { return m_Right; }
	Light* GetLight() { return m_Light; }
	void SetLight( Light* a_Light ) { m_Light = a_Light; m_Leaf = 1; }
	int IsLeaf() { return m_Leaf; }
	void SetRadius( float a_Radius ) { m_Radius = a_Radius; m_Radius4 = _mm_set_ps1( a_Radius ); m_SqRadius = a_Radius * a_Radius; }
	float GetRadius() { return m_Radius; }
	float GetSqRadius() { return m_SqRadius; }
	__m128 GetRadius4() { return m_Radius4; }
	void SetPos( vector3& a_Pos ) 
	{ 
		m_Pos = a_Pos; 
		m_PosX4 = _mm_set_ps1( a_Pos.x );
		m_PosY4 = _mm_set_ps1( a_Pos.y );
		m_PosZ4 = _mm_set_ps1( a_Pos.z );
	}
	vector3 GetPos() { return m_Pos; }
	__m128 GetX4() { return m_PosX4; }
	__m128 GetY4() { return m_PosY4; }
	__m128 GetZ4() { return m_PosZ4; }
	float RadiusCalc( LBVHNode* a_Node);
protected:
	// data members
	__m128 m_Radius4, m_PosX4, m_PosY4, m_PosZ4; // 64
	float m_Radius, m_SqRadius;					 // 8
	vector3 m_Pos;								 // 12
	union
	{
		struct { LBVHNode* m_Left, *m_Right; };
		struct { int dummy1; Light* m_Light; };  // 8
	};
	unsigned int m_Leaf;						 // 4, total 96
};

class LBVHMManager
{
public:
	LBVHMManager();
	static LBVHNode* NewLBVHNode() { LBVHNode* r = m_LBVHNPtr; m_LBVHNPtr = r->GetLeft(); return r; }
	static void FreeLBVHNode( LBVHNode* l ) { l->SetLeft( m_LBVHNPtr ); m_LBVHNPtr = l; }
protected:
	static LBVHNode* m_LBVHNPtr;
};

class LBVH
{
public:
	LBVH(): m_Root(0) {}
	~LBVH() { Recycle( m_Root ); }
	void Build( Light** a_Array, int a_Length );
	const unsigned int Traverse( Light** a_Array, const vector3& _min, const vector3& _max) const;
	int Traverse( Light** a_Array, vector3& aPos );
	int Traverse( Light** a_Array, __m128& x4, __m128& y4, __m128& z4 );
protected:
	void Recycle( LBVHNode* a_Root );
	LBVHNode* m_Root;
	static LBVHMManager m_MManager;
};

}; // namespace Raytracer