// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#pragma once

#include "common_math.h"

#pragma warning (disable : 4311)
#pragma warning (disable : 4312)

namespace Raytracer {

class Primitive;
class MManager;
class Scene;

// -----------------------------------------------------------
// Object list helper class
// -----------------------------------------------------------

class ObjectList
{
public:
	ObjectList() : m_Primitive( 0 ), m_Next( 0 ) {}
	~ObjectList() { delete m_Next; }
	void SetPrimitive( const Primitive* a_Prim ) { m_Primitive = a_Prim; }
	const Primitive* GetPrimitive() { return m_Primitive; }
	void SetNext( ObjectList* a_Next ) { m_Next = a_Next; }
	ObjectList* GetNext() { return m_Next; }
	int GetSize() { if (m_Next) return 1 + m_Next->GetSize(); else return 1; }
private:
	const Primitive* m_Primitive;
	ObjectList* m_Next;
};

// -----------------------------------------------------------
// KdTree class definition
// -----------------------------------------------------------

class KdTreeNode
{
public:
	KdTreeNode() : m_Data( 6 ) {};
	void SetAxis( int a_Axis ) { m_Data = (m_Data & 0xfffffffc) + a_Axis; }
	const int GetAxis() const { return m_Data & 3; }
	void SetSplitPos( float a_Pos ) { m_Split = a_Pos; }
	const float GetSplitPos() const { return m_Split; }
	void SetLeft( KdTreeNode* a_Left ) { m_Data = (unsigned long)a_Left + (m_Data & 7); }
	const KdTreeNode* GetLeft() const { return (KdTreeNode*)(m_Data&0xfffffff8); }
	const KdTreeNode* GetRight() const { return ((KdTreeNode*)(m_Data&0xfffffff8)) + 1; }
	void Add( Primitive* a_Prim );
	const int IsLeaf() const { return (m_Data & 4); }
	void SetLeaf( bool a_Leaf ) { m_Data = (a_Leaf)?(m_Data|4):(m_Data&0xfffffffb); }
	ObjectList* GetList() const { return (ObjectList*)(m_Data&0xfffffff8); }
	void SetList( ObjectList* a_List ) { m_Data = (unsigned long)a_List + (m_Data & 7); }
	void SetObjList( int a_Offs, int a_Count ) { m_Data = (a_Offs << 8) + (a_Count << 3) + (m_Data & 7); }
	const int GetObjOffset() const { return (m_Data >> 8); }
	const int GetObjCount() const { return (m_Data & 248) >> 3; }
	float m_Split;
	unsigned long m_Data;
};

class KdTree
{
public:
	KdTree();
	~KdTree();
	void Load( char* a_File );
	KdTreeNode* GetRoot() const { return m_Root; }
	void SetRoot( KdTreeNode* a_Root ) { m_Root = a_Root; }
	Primitive** GetObjectList() const { return m_ObjList; }
// private:
	KdTreeNode* m_Root;
	Primitive** m_ObjList;
	ObjectList* m_OList;
};

}; // namespace Raytracer