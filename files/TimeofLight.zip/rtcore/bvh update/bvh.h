// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#pragma once

#include "common_math.h"
#include "sthread.h"

#pragma warning (disable : 4311)
#pragma warning (disable : 4312)

namespace Raytracer {

class Primitive;
class MManager;
class Scene;

// -----------------------------------------------------------
// BVH node class
// -----------------------------------------------------------

struct BVHNode
{
	// member data access methods
	unsigned int GetAxis() const { return (data >> 29) & 3; }
	unsigned int GetFirst() const { return (data >> 31); }
	unsigned int GetTCount() const { return (data & 0x1fffffff); }
	unsigned int GetLeft() const { return left & 0x00ffffff; }
	unsigned int GetRight() const { return (left & 0x00ffffff) + 1; }
	void SetFirst( unsigned int f ) { data = (data & 0x7FFFFFFF) + (f << 31); }
	void SetAxis( unsigned int a ) { data = (data & 0x9FFFFFFF ) + (a << 29); }
	void SetTCount( unsigned int c ) { data = c + (data & 0xE0000000); };
	void SetLeft( unsigned int idx ) { left = (left & 0xff000000)|idx; }
	bool IsLeaf() const { return ((data & 0x1fffffff) != 0); }
	void SetDirMask( unsigned int mask ) { left = (left & 0x00ffffff) + (mask << 24); }
	unsigned int GetDirMask() const { return left >> 24; }
	// data members
	vector3 min;
	union
	{
		unsigned int left;  // first child node (inner)
		unsigned int start; // first triangle ID (leaf)
	};
	vector3 max;
	unsigned int data;		// total 32 bytes
};

// -----------------------------------------------------------
// BVH node class
// -----------------------------------------------------------

struct BinTri
{
	__m128 boxp1, boxp2, centroid;	// 32
	Primitive* prim;				// 4
	int dummy1, dummy2, dummy3;		// 12
};

struct BinStack
{
	__m128 vmin4, vmax4, cmin4, cmax4;
	int first, last, dummy;
	BVHNode* node;
};

#define SSE_X	 3
#define SSE_Y	 2
#define SSE_Z    1

class ThreadedBVHBuilder : public Thread
{
public:
	void Init( uint thread, BVHierarchy* bvh, int maxsize );
	void SetData( BinTri** trilist, BVHNode* root, int first, int last, BVHNode* pool, int pidx ) { m_Tri = trilist; m_Root = root; m_First = first; m_Last = last; m_Pool = pool; m_PIdx = pidx; }
	void SetCBox( __m128 min4, __m128 max4 ) { box[0] = min4; box[1] = max4; }
	void SetVBox( __m128 min4, __m128 max4 ) { box[2] = min4; box[3] = max4; }
	void Build();
	void run();
private:
	__m128* box; // m_Min4c, m_Max4c, m_Min4v, m_Max4v;
	int m_Thread, m_First, m_Last, m_PIdx;
	BinTri** m_Tri, **m_LTri;
	BVHierarchy* m_BVH;
	BVHNode* m_Root, *m_Pool;
};

class BVHierarchy
{
public:
	// constructor / destructor
	BVHierarchy();
	~BVHierarchy();
	void Recurse( BVHNode* a_Root, unsigned int a_Start, unsigned int a_End, aabb& a_Box );
	void CalcBBox( SubPrim** a_Prim, unsigned int a_Start, unsigned int a_End, aabb& a_Box );
	void CountLeafs( BVHNode* a_Node, int& a_Leafs, int& a_Prims, int& a_MaxPrims, int& a_MaxDepth, float& a_Area, float& a_TArea, int& a_Nodes, int a_Depth );
	void PreBuild( Primitive** a_Prim, unsigned int a_PCount, SubPrim** a_SPrim, unsigned int& a_NCount );
	void FinalizeLeaf( BVHNode* a_Node, SubPrim** a_Prim, int start, int end );
	void Build( SubPrim** a_Prim, unsigned int a_PCount );
	void Refit( BVHNode* a_Node, __m128& a_Min4, __m128& a_Max4 );
	void PrepThreadedBuild();
	void PrepDynamicBuilds( unsigned int a_PCount );
	void BinnedBuild( Primitive** a_Prim, unsigned int a_PCount );
	void ThreadedBuild( Primitive** a_Prim, unsigned int a_PCount );
	void UpdateDirMasks( BVHNode* a_Node );
	unsigned int CalculateDirMask( BVHNode* a_LNode, BVHNode* a_RNode );
	BVHNode* GetRoot() { return m_Root; }
	// data members
	aabb m_Extends;
	__m128* m_Box, *m_Centroid;
	BVHNode* m_Root;
	BVHNode* m_Pool;
	Primitive** m_Prim;
	BinTri** m_Tri, **m_LTri, **m_RTri;
	SubPrim** m_SPrim;
	unsigned int m_PIdx;
};

// -----------------------------------------------------------
// PrimData class
// -----------------------------------------------------------

class PrimData
{
	struct _aabb { vector3 p1; vector3 p2; };
public:
	PrimData();
	PrimData( Primitive* a_Prim );
	PrimData( PrimData* a_PD );
	void Init( const Primitive* a_Prim );
	bool Clip( float a_Pos, float a_Dir, int a_Axis );
	// void Clip( float a_Pos, float a_Dir, int a_Axis );
	void UpdateBBox();
	bool RebuildAndClip( aabb& a_Box );
	// data members
	static vector3* s_TVert;
	int m_Verts;
	Primitive* m_Prim;
	vector3* m_Vertex;
	_aabb bbox;
};

}; // namespace Raytracer