// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#include "precomp.h"

namespace Raytracer {

void LBVHNode::Init( LBVHNode* a_Left, LBVHNode* a_Right, float a_Radius )
{
	m_Left = a_Left;
	m_Right = a_Right;
	m_Leaf = 0;
	SetRadius( a_Radius );
	if (a_Radius <= a_Left->GetRadius()) 
	{
		vector3 pos = a_Left->GetPos();
		SetPos( pos );
	}
	else if (a_Radius <= a_Right->GetRadius()) 
	{
		vector3 pos = a_Right->GetPos();
		SetPos( pos );
	}
	else 
	{
		vector3 diff = (a_Left->GetPos() - a_Right->GetPos());
		diff.Normalize();
		vector3 newpos = a_Right->GetPos() + (a_Radius - a_Right->GetRadius()) * diff;
		SetPos( newpos );
	}
}

float LBVHNode::RadiusCalc( LBVHNode* a_Node )
{
	float distance = (GetPos() - a_Node->GetPos()).Length();
	float radius = (distance + GetRadius() + a_Node->GetRadius()) * 0.5f;
	if (radius < GetRadius()) radius = GetRadius();
	else if (radius < a_Node->GetRadius()) radius = a_Node->GetRadius();
	return radius;
}

LBVHMManager::LBVHMManager()
{
	m_LBVHNPtr = (LBVHNode*)MALLOC64( 1024 * sizeof( LBVHNode ) );
	for ( unsigned int i = 0; i < 1024; i++ ) m_LBVHNPtr[i].SetLeft( &m_LBVHNPtr[i + 1] );
}

void LBVH::Build( Light** a_Array, int a_Length )
{
	if (m_Root) Recycle( m_Root );
	if (!a_Length) { m_Root = 0; return; }
	LBVHNode** NodeArray = new LBVHNode*[a_Length];
	int* IndexArray = new int[a_Length];
	int nractive = 0;
	float* RadiusArray = new float[a_Length];
	for ( int i = 0; i < a_Length; i++ )
	{
		Light* l = a_Array[i];
		if (!l->IsActive()) continue;
		LBVHNode* tNode = m_MManager.NewLBVHNode();
		tNode->SetLight( l );
		if ((l->GetWidth() == -2) || (l->IsMultiBeam()))
		{
			// omnilight
			float radius = l->GetRadius();
			if (l->IsMultiBeam()) radius *= 200;
			tNode->SetRadius( radius );
			vector3 pos = l->GetPos();
			tNode->SetPos( pos );
		}
		else
		{
			// spotlight
			tNode->SetRadius( l->GetRadius() * 0.53f );
			vector3 pos = l->GetPos() + 0.55f * l->GetRadius() * l->GetDirection();
			tNode->SetPos( pos );
		}
		NodeArray[nractive++] = tNode;
	}
	if (!nractive) { m_Root = 0; return; }
	float SmallestRadius = 1000000.0f;
	int Index = -1;
	for ( int i = nractive - 1; i > 0; i--)
	{
		float SmallRadius = NodeArray[i]->RadiusCalc( NodeArray[i-1] );
		IndexArray[i] = i - 1;
		for ( int j = i - 2; j >= 0; j--)
		{
			float radius = NodeArray[i]->RadiusCalc( NodeArray[j] );
			if (radius < SmallRadius )
			{
				IndexArray[i] = j;
				SmallRadius = radius;
			}
		}
		RadiusArray[i] = SmallRadius;
		if (SmallRadius < SmallestRadius)
		{
			Index = i;
			SmallestRadius = SmallRadius;
		}
	}
	for ( int k = nractive - 1; k > 0; k--)
	{
		int NewIndex = IndexArray[Index];
		LBVHNode* OldNode = NodeArray[NewIndex];
		NodeArray[NewIndex] = m_MManager.NewLBVHNode();
		NodeArray[NewIndex]->Init( OldNode, NodeArray[Index], RadiusArray[Index] );
		if (NewIndex)
		{
			float SmallRadius = NodeArray[NewIndex]->RadiusCalc( NodeArray[NewIndex - 1] );
			IndexArray[NewIndex] = NewIndex - 1;
			for ( int j = NewIndex - 2; j >= 0; j--)
			{
				float radius = NodeArray[NewIndex]->RadiusCalc( NodeArray[j] );
				if (radius < SmallRadius)
				{
					IndexArray[NewIndex] = j;
					SmallRadius = radius;
				}
			}
			RadiusArray[NewIndex] = SmallRadius;
		}
		float SmallestRadius = 1000000.0f;
		int OldIndex = Index;
		if (Index != k)
		{
			NodeArray[Index] = NodeArray[k];
			if (Index <= IndexArray[k]) IndexArray[Index] = NewIndex;
			else
			{
				IndexArray[Index] = IndexArray[k];
				RadiusArray[Index] = RadiusArray[k];
			}
			for ( int i = k - 1; i > OldIndex; i--)
			{	
				if (IndexArray[i] == NewIndex || IndexArray[i] == OldIndex)
				{
					float SmallRadius=NodeArray[i]->RadiusCalc( NodeArray[i - 1] );
					IndexArray[i] = i - 1;
					for ( int j = i - 2; j >= 0; j--)
					{
						float radius = NodeArray[i]->RadiusCalc( NodeArray[j] );
						if (radius < SmallRadius)
						{
							IndexArray[i] = j;
							SmallRadius = radius;
						}
					}
					RadiusArray[i] = SmallRadius;
					if (SmallRadius < SmallestRadius)
					{
						Index = i;
						SmallestRadius = SmallRadius;
					}
				}
				else if (RadiusArray[i] < SmallestRadius)
				{
					Index = i;
					SmallestRadius = RadiusArray[i];
				}
			}
			OldIndex++;
		}
		for (int i = OldIndex - 1; i > NewIndex; i-- )
		{
			if (IndexArray[i] == NewIndex)
			{
				float SmallRadius = NodeArray[i]->RadiusCalc( NodeArray[i - 1] );
				IndexArray[i] = i - 1;
				for ( int j = i - 2; j >= 0; j--)
				{
					float radius = NodeArray[i]->RadiusCalc( NodeArray[j] );
					if (radius < SmallRadius)
					{
						IndexArray[i] = j;
						SmallRadius = radius;
					}
				}
				RadiusArray[i] = SmallRadius;
				if (SmallRadius < SmallestRadius)
				{
					Index = i;
					SmallestRadius = SmallRadius;
				}
			}
			else if (RadiusArray[i] < SmallestRadius)
			{
				Index = i;
				SmallestRadius = RadiusArray[i];
			}						
		}
		for ( int i = NewIndex; i > 0; i-- )
		{
			if (RadiusArray[i] < SmallestRadius)
			{
				Index = i;
				SmallestRadius = RadiusArray[i];
			}
		}
	}
	m_Root = NodeArray[0];
	// CleanUp
	delete[] IndexArray;
	delete[] NodeArray;
	delete[] RadiusArray;
}

void LBVH::Recycle( LBVHNode* a_Root ) 
{
	if (!a_Root) return;
	if (!a_Root->IsLeaf())
	{
		Recycle( a_Root->GetLeft() );
		Recycle( a_Root->GetRight() );
	}
	m_MManager.FreeLBVHNode( a_Root );
}

const unsigned int LBVH::Traverse( Light** a_Array, const vector3& a_Min, const vector3& a_Max) const
{
	if (!m_Root) return 0;
	LBVHNode* lroot = m_Root;
	float dmin = 0;
	for( int i = 0; i < 3; i++ ) 
	{
		if (lroot->GetPos()[i] < a_Min.cell[i]) 
		{
			const float dist = lroot->GetPos()[i] - a_Min.cell[i];
			dmin += dist * dist;
		}
		else if (lroot->GetPos()[i] > a_Max.cell[i]) 
		{	
			const float dist = lroot->GetPos()[i] - a_Max.cell[i];
			dmin += dist * dist;
		}
	}
	if (dmin > lroot->GetSqRadius()) return 0;
	unsigned int count = 0;
	LBVHNode* stack[32];
	unsigned int stackptr = 0;
	while (1)
	{
		if (lroot->IsLeaf())
		{
			a_Array[count++] = lroot->GetLight();
			if (!stackptr) break;
			lroot = stack[--stackptr];
			continue;
		}
		dmin = 0;
		for( int i = 0; i < 3; i++ )
		{
			const float lpos = lroot->GetLeft()->GetPos()[i];
			if (lpos < a_Min.cell[i]) { const float dist = lpos - a_Min.cell[i]; dmin += dist * dist; }
			else if (lpos > a_Max.cell[i]) { const float dist = lpos - a_Max.cell[i]; dmin += dist * dist; }
		}
		if (dmin > lroot->GetLeft()->GetSqRadius())
		{
			dmin = 0;
			for( int i = 0; i < 3; i++ )
			{
				const float rpos = lroot->GetRight()->GetPos()[i];
				if (rpos < a_Min.cell[i] ) { const float dist = rpos - a_Min.cell[i]; dmin += dist * dist; }
				else if (rpos > a_Max.cell[i]) { const float dist = rpos - a_Max.cell[i]; dmin += dist * dist; }
			}
			if (dmin > lroot->GetRight()->GetSqRadius()) 
			{
				if (!stackptr) break;
				lroot = stack[--stackptr];
				continue;
			}
			lroot = lroot->GetRight();
		}
		else
		{
			dmin = 0;
			for( int i = 0; i < 3; i++ )
			{
				const float rpos = lroot->GetRight()->GetPos()[i];
				if (rpos < a_Min.cell[i]) { const float dist = rpos - a_Min.cell[i]; dmin += dist * dist; }
				else if (rpos > a_Max.cell[i]) { const float dist = rpos - a_Max.cell[i]; dmin += dist * dist; }
			}
			if (dmin <= lroot->GetRight()->GetSqRadius()) stack[stackptr++] = lroot->GetRight();
			lroot = lroot->GetLeft();
		}
	}
	return count;
}

int LBVH::Traverse( Light** a_Array, vector3& a_Pos ) 
{
	if (!m_Root) return 0;
	unsigned int stackptr = 0;
	LBVHNode* stack[32];
	LBVHNode* lroot = m_Root;
	float dmin = 0;
	int Counter = 0;
	if ((a_Pos - lroot->GetPos()).SqrLength() > lroot->GetRadius() * lroot->GetRadius()) return 0;
	while (1)
	{
		while (1)
		{
			if (lroot->IsLeaf())
			{
				a_Array[Counter++] = lroot->GetLight();
				break;
			}
			if ((a_Pos-lroot->GetLeft()->GetPos()).SqrLength() > lroot->GetLeft()->GetRadius() * lroot->GetLeft()->GetRadius())
			{
				if ((a_Pos-lroot->GetRight()->GetPos()).SqrLength() > lroot->GetRight()->GetRadius() * lroot->GetRight()->GetRadius()) break;
				else lroot = lroot->GetRight();
			}
			else
			{
				if ((a_Pos-lroot->GetRight()->GetPos()).SqrLength() <= lroot->GetRight()->GetRadius() * lroot->GetRight()->GetRadius())
				{
					stack[stackptr++]=lroot->GetRight();
				}
				lroot = lroot->GetLeft();
			}
		}
		if (!stackptr) break;
		lroot = stack[--stackptr];
	}
	return Counter;
}

int LBVH::Traverse( Light** a_Array, __m128& x4, __m128& y4, __m128& z4 ) 
{
	if (!m_Root) return 0;
	unsigned int stackptr = 0;
	LBVHNode* stack[12];
	LBVHNode* lroot = m_Root;
	float dmin = 0;
	int Counter = 0;
	__m128 dx4 = _mm_sub_ps( x4, lroot->GetX4() );
	dx4 = _mm_mul_ps( dx4, dx4 );
	__m128 dy4 = _mm_sub_ps( y4, lroot->GetY4() );
	dy4 = _mm_mul_ps( dy4, dy4 );
	__m128 dz4 = _mm_sub_ps( z4, lroot->GetZ4() );
	dz4 = _mm_mul_ps( dz4, dz4 );
	__m128 length4 = _mm_add_ps( _mm_add_ps( dx4, dy4 ), dz4 );
	if (!_mm_movemask_ps( _mm_cmple_ps( length4, _mm_mul_ps( lroot->GetRadius4(), lroot->GetRadius4() ) ) )) return 0;
	while (1)
	{
		while (1)
		{
			if (lroot->IsLeaf())
			{
				a_Array[Counter++] = lroot->GetLight();
				break;
			}
			dx4 = _mm_sub_ps( x4, lroot->GetLeft()->GetX4() );
			dx4 = _mm_mul_ps( dx4, dx4 );
			dy4 = _mm_sub_ps( y4, lroot->GetLeft()->GetY4() );
			dy4 = _mm_mul_ps( dy4, dy4 );
			dz4 = _mm_sub_ps( z4, lroot->GetLeft()->GetZ4() );
			dz4 = _mm_mul_ps( dz4, dz4 );
			length4 = _mm_add_ps( _mm_add_ps( dx4, dy4 ), dz4 );
			if (_mm_movemask_ps( _mm_cmple_ps( length4, _mm_mul_ps( lroot->GetLeft()->GetRadius4(), lroot->GetLeft()->GetRadius4() ) ) ))
			{
				dx4 = _mm_sub_ps( x4, lroot->GetRight()->GetX4() );
				dx4 = _mm_mul_ps( dx4, dx4 );
				dy4 = _mm_sub_ps( y4,lroot->GetRight()->GetY4() );
				dy4 = _mm_mul_ps( dy4, dy4 );
				dz4 = _mm_sub_ps( z4,lroot->GetRight()->GetZ4() );
				dz4 = _mm_mul_ps( dz4, dz4 );
				length4 = _mm_add_ps( _mm_add_ps( dx4, dy4 ), dz4 );
				if (_mm_movemask_ps( _mm_cmple_ps( length4, _mm_mul_ps( lroot->GetRight()->GetRadius4(), lroot->GetRight()->GetRadius4() ) ) ))
				{
					stack[stackptr++] = lroot->GetRight();
				}
				lroot = lroot->GetLeft();
			}
			else
			{
				dx4 = _mm_sub_ps( x4, lroot->GetRight()->GetX4() );
				dx4 = _mm_mul_ps( dx4, dx4 );
				dy4 = _mm_sub_ps( y4, lroot->GetRight()->GetY4() );
				dy4 = _mm_mul_ps( dy4, dy4 );
				dz4 = _mm_sub_ps( z4, lroot->GetRight()->GetZ4() );
				dz4 = _mm_mul_ps( dz4, dz4 );
				length4 = _mm_add_ps( _mm_add_ps( dx4, dy4 ), dz4 );
				if ( _mm_movemask_ps( _mm_cmple_ps( length4, _mm_mul_ps( lroot->GetRight()->GetRadius4(), lroot->GetRight()->GetRadius4() ) ) )) 
				{
					lroot = lroot->GetRight();
				}
				else break;
			}
		}
		if (!stackptr) break;
		lroot = stack[--stackptr];
	}
	return Counter;
}

}; // namespace Raytracer