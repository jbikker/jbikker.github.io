// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#pragma once

namespace Raytracer {

static const vector3 gVector(0,-0.2f,0);
class Primitive;
class Material;
class Node
{
public:
	Node();
	Node( int a_PCount );
	Node( char* a_Obj, vector3 a_Pos, float a_Scale );
	~Node();
	void Add( Primitive* a_Prim );
	Primitive* Get( unsigned int a_Idx ) { return m_Prim[a_Idx]; }
	void Set( unsigned int a_Idx, Primitive* a_Prim ) { m_Prim[a_Idx] = a_Prim; }
	virtual void Load( char* a_Obj, float a_Scale = 1.0f );
	void SetTransform( matrix& a_Mat ) { m_Mat = a_Mat; }
	matrix& GetTransform() { return m_Mat; }
	Primitive* GetOPrim( int a_Idx ) { return m_OPrim[a_Idx]; }
	Primitive* GetPrim( int a_Idx ) { return m_Prim[a_Idx]; }
	int GetPrimCount() { return m_PCount; }
	virtual void Transform();
	void SetMaterial( Material* a_Mat );
	virtual void Break();
	virtual void Break(vector3 a_Direction);
	virtual void SetGravity(bool a_Bool, vector3 a_Vector=gVector);
protected:
	Primitive** m_Prim, **m_OPrim;
	int m_PCount;
	matrix m_Mat;
};

/* md2 header */
typedef struct
{
	int ident;          // magic number: "IDP2"
	int version;        // version: must be 8
	int skinwidth;      // texture width
	int skinheight;     // texture height
	int framesize;      // size in bytes of a frame
	int num_skins;      // number of skins
	int num_vertices;   // number of vertices per frame
	int num_st;         // number of texture coordinates
	int num_tris;       // number of triangles
	int num_glcmds;     // number of opengl commands
	int num_frames;     // number of frames
	int offset_skins;   // offset skin data
	int offset_st;      // offset texture coordinate data
	int offset_tris;    // offset triangle data
	int offset_frames;  // offset frame data
	int offset_glcmds;  // offset OpenGL command data
	int offset_end;     // offset end of file
} MD2Header;

typedef struct
{
	char name[64];		// texture file name
} MD2Skin;

typedef struct
{
	short u, v;
} MD2UV;

typedef struct
{
	unsigned short vertex[3];	// vertex indices of the triangle
	unsigned short uv[3];		// tcoord indices
} MD2Tri;

typedef struct
{
	unsigned char v[3];			// position
	unsigned char normalIndex;	// normal vector index
} MD2Vert;

typedef struct
{
	vector3 scale;			// scale factor
	vector3 translate;		// translation vector
	char name[16];			// frame name
	vector3* verts;			// list of frame's vertices
} MD2Frame;

class Vertex;
class MD2Node : public Node
{
public:
	MD2Node();
	MD2Node( char* a_Obj, vector3 a_Pos, float a_Scale );
	~MD2Node();
	virtual void Load( char* a_Obj, float a_Scale = 1.0f );
	virtual void Transform();
	void SetAnim( char* a_Name );
	void SetAnimPos( float a_Pos ) { m_APos = a_Pos; }
	int FindFirstFrame( char* a_Name );
	int FindLastFrame( char* a_Name );
private:
	MD2Header m_Header;
	MD2Skin* m_Skins;
	MD2UV* m_TCoords;
	MD2Tri* m_Tris;
	MD2Frame* m_Frames;
	Vertex* m_VArray;
	int* m_GLCmds;
	float m_APos;
	int m_First, m_Last;
};

class Breakable : public Node
{
public:
	Breakable();
	Breakable( char* a_Obj, vector3 a_Pos, float a_Scale );
	Breakable( char* a_Obj, vector3 a_Pos, float a_Scale, vector3 a_Direction);
	~Breakable();
	virtual void Load( char* a_Obj, float a_Scale = 1.0f );
	virtual void Transform();
	void Break();
	void Explode();
	void Reset();
	void Break( vector3 a_Direction );
	void SetGravity( bool a_Bool, vector3 a_Vector = gVector );
private:
	vector3* m_Pos, *m_DPos;	// position and speed (per polygon)
	vector3* m_Rot, *m_DRot;	// rotations and angular velocity (16)
	matrix* m_Trans;			// matrices representing rotation (16)
	bool m_Broken;				// object is broken or not
	vector3 m_BlastDirection;	// where do the polygons move to
	vector3 m_VGravity;			// gravity vector
	bool m_BGravity;			// gravity boolean
};

#ifdef MULTIBEAM
class MultiBeam
{
public:
	MultiBeam( Light* a_Light ) { m_Light = a_Light; }
	void SetDirection( int a_Idx, vector3& a_Dir ) { a_Dir.Normalize(); m_Dir[a_Idx] = a_Dir; }
	vector3& GetDirection( int a_Idx ) { return m_Dir[a_Idx]; }
	void Transform( matrix& a_Mat );
	inline Light* GetLight() { return m_Light; }
private:
	Light* m_Light;
	vector3 m_Dir[MULTIBEAMDIRS];
};
#endif

class SceneGraph
{
public:
	SceneGraph();
	~SceneGraph();
	static void Update();
	static void UpdatePrimList();
	static void AddNode( Node* a_Node ) { m_Node[m_NCount++] = a_Node; }
	static void Reset() { m_NCount = 0; }
	static Node* GetNode( unsigned int a_Idx ) { return m_Node[a_Idx]; }
	static void Break();
	static void Break(vector3 a_Direction);
	virtual void SetGravity(bool a_Bool, vector3 a_Vector=gVector);
private:
	static Node** m_Node;
	static unsigned int m_NCount;
};

} // namespace Raytracer