// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#include "precomp.h"

using namespace Raytracer;

int filesize( FILE* f )
{
	int cp = ftell( f );
	fseek( f, 0, SEEK_END );
	int l = ftell( f );
	fseek( f, cp, SEEK_SET );
	return l;
}

bool isnewer( char* fname1, char* fname2 )
{
	HANDLE f = CreateFile( fname1, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL );
	if (f == INVALID_HANDLE_VALUE) return true;
	BY_HANDLE_FILE_INFORMATION fi1, fi2;
	GetFileInformationByHandle( f, &fi1 );
	CloseHandle( f );
	f = CreateFile( fname2, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL );
	if (f == INVALID_HANDLE_VALUE) return true;
	GetFileInformationByHandle( f, &fi2 );
	CloseHandle( f );
	long result = CompareFileTime( &fi1.ftLastWriteTime, &fi2.ftLastWriteTime );
	return (result == 1);
}

// -----------------------------------------------------------
// Log class implementation
// Store system messages
// -----------------------------------------------------------
Log::Log( char* a_File )
{
	m_File = new char[strlen( a_File ) + 1];
	strcpy( m_File, a_File );
	FILE* f = fopen( a_File, "w" ); // clear the file
	fprintf( f, "Logging started.\n" );
	if (f) fclose( f );
}

void Log::Write( char* a_Txt, char* a_Data )
{
	FILE* f = fopen( m_File, "a" );
	if (f)
	{
		fprintf( f, "MSG:  %s\nDATA: %s\n", a_Txt, a_Data );
		fflush( f );
		fclose( f );
	}
}

void Log::Message( char* a_Txt )
{
	FILE* f = fopen( m_File, "a" );
	if (f)
	{
		fprintf( f, "%s\n", a_Txt );
		fflush( f );
		fclose( f );
	}
}

void Log::Message( char* a_Txt, char* a_Txt2 )
{
	FILE* f = fopen( m_File, "a" );
	if (f)
	{
		fprintf( f, "%s%s\n", a_Txt, a_Txt2 );
		fflush( f );
		fclose( f );
	}
}

void Log::IntValue( char* a_Txt, int a_Data )
{
	FILE* f = fopen( m_File, "a" );
	if (f)
	{
		char t[64];
		sprintf( t, "%i", a_Data );
		fprintf( f, "%s %s\n", a_Txt, t );
		fflush( f );
		fclose( f );
	}
}

void Log::FloatValue( char* a_Txt, float a_Data )
{
	FILE* f = fopen( m_File, "a" );
	if (f)
	{
		char t[64];
		sprintf( t, "%f", a_Data );
		fprintf( f, "%s %s\n", a_Txt, t );
		fflush( f );
		fclose( f );
	}
}

void Log::CharValue( char* a_Txt, char* a_Data )
{
	FILE* f = fopen( m_File, "a" );
	if (f)
	{
		fprintf( f, "%s %s\n", a_Txt, a_Data );
		fflush( f );
		fclose( f );
	}
}

void Log::Error( char* a_Error, char* a_Param )
{
	Message( "halted for a catastrophic error:" );
	Message( a_Error, a_Param );
	MessageBox( NULL, a_Param, a_Error, MB_OK | MB_ICONINFORMATION );
	_exit( 0 );
}

// -----------------------------------------------------------
// Engine::FinalizeImage
// Finalizing the image with or without a box filter
// -----------------------------------------------------------
extern Pixel* m_Final, *m_Surf;
extern Color64* m_BDest, *m_Dest;
void Engine::FinalizeImage()
{
/*	if (m_HDRBlur)
	{
		__m128i* src = (__m128i*)m_BDest, *dst = (__m128i*)m_TDest;
		union { __m128i mask4; unsigned int mask[4]; };
		mask[0] = mask[1] = mask[2] = mask[3] = 2047 + (2047 << 16);
		for ( uint x = 0; x < m_Width / 16; x++ )
		{
			__m128i t[8];
			for ( uint i = 0; i < 8; i++ ) t[i] = _mm_setzero_si128();
			for ( uint v = 0; v < 15; v++ ) for ( uint i = 0; i < 8; i++ )
				t[i] = _mm_add_epi16( t[i], _mm_and_si128( _mm_srli_epi16( src[v * m_Pitch / 2 + i], 5 ), mask4 ) );
			for ( uint y = 0; y < 17; y++ ) for ( uint i = 0; i < 8; i++ )
			{
				t[i] = _mm_add_epi16( t[i], _mm_and_si128( _mm_srli_epi16( src[(y + 15) * (m_Pitch / 2) + i], 5 ), mask4 ) );
				dst[y * (m_Pitch / 2) + i] = t[i];
			}
			uint delta = m_Pitch / 2;
			__m128i* dst2 = dst + 17 * delta, *src2 = src + 32 * delta, *src3 = src;
			for ( uint y = 17; y < m_Height - 16; y++, src2 += delta, src3 += delta, dst2 += delta ) for ( int i = 0; i < 8; i++ )
			{
				t[i] = _mm_add_epi16( t[i], _mm_and_si128( _mm_srli_epi16( src2[i], 5 ), mask4 ) );
				t[i] = _mm_sub_epi16( t[i], _mm_and_si128( _mm_srli_epi16( src3[i], 5 ), mask4 ) );
				dst2[i] = t[i];
			}
			for ( uint y = m_Height - 16; y < m_Height; y++ ) for ( uint i = 0; i < 8; i++ )
			{
				t[i] = _mm_sub_epi16( t[i], _mm_and_si128( _mm_srli_epi16( src[(y - 17) * (m_Pitch / 2) + i], 5 ), mask4 ) );
				dst[y * (m_Pitch / 2) + i] = t[i];
			}
			src += 8, dst += 8;
		}
		Color64* src1 = m_TDest;
		Color64* src2 = m_BDest;
		Pixel* final = m_Final;
		// PASS 2: Horizontal blur + final image
		for ( uint y = 0; y < m_Height; y++ )
		{
			uint red = 0, green = 0, blue = 0;
			for ( uint v = 0; v < 15; v++ )
			{
				const Color64 s = src1[v];
				red += (s.ra >> 4) & 2047;
				green += (s.bg >> 20) & 2047;
				blue += (s.bg >> 4) & 2047;
			}
			for ( uint x = 0; x < 17; x++ )
			{
				const Color64 s2 = src1[x + 15];
				red += (s2.ra >> 4) & 2047, green += (s2.bg >> 20) & 2047, blue += (s2.bg >> 4) & 2047;
				const Color64 d = src2[x];
				const unsigned int lred = (red >> 3) + (d.ra & 65535);
				const unsigned int lgreen = (green >> 3) + ((d.bg >> 16) & 65535);
				const unsigned int lblue = (blue >> 3) + (d.bg & 65535);
				const unsigned int fred = (lred > 255)?255:lred;
				const unsigned int fgreen = (lgreen > 255)?255:lgreen;
				const unsigned int fblue = (lblue > 255)?255:lblue;
				final[x] = (fred << 16) + (fgreen << 8) + fblue;
			}
			for ( uint x = 17; x < m_Width - 16; x++ )
			{
				const Color64 s1 = src1[x - 17];
				red -= (s1.ra >> 4) & 2047, green -= (s1.bg >> 20) & 2047, blue -= (s1.bg >> 4) & 2047;
				const Color64 s2 = src1[x + 15];
				red += (s2.ra >> 4) & 2047, green += (s2.bg >> 20) & 2047, blue += (s2.bg >> 4) & 2047;
				const Color64 d = src2[x];
				const unsigned int lred = (red >> 3) + (d.ra & 65535);
				const unsigned int lgreen = (green >> 3) + ((d.bg >> 16) & 65535);
				const unsigned int lblue = (blue >> 3) + (d.bg & 65535);
				const unsigned int fred = (lred > 255)?255:lred;
				const unsigned int fgreen = (lgreen > 255)?255:lgreen;
				const unsigned int fblue = (lblue > 255)?255:lblue;
				final[x] = (fred << 16) + (fgreen << 8) + fblue;
			}
			for ( uint x = m_Width - 16; x < m_Width; x++ )
			{
				const Color64 s1 = src1[x - 17];
				red -= (s1.ra >> 4) & 2047, green -= (s1.bg >> 20) & 2047, blue -= (s1.bg >> 4) & 2047;
				const Color64 d = src2[x];
				const unsigned int lred = (red >> 3) + (d.ra & 65535);
				const unsigned int lgreen = (green >> 3) + ((d.bg >> 16) & 65535);
				const unsigned int lblue = (blue >> 3) + (d.bg & 65535);
				const unsigned int fred = (lred > 255)?255:lred;
				const unsigned int fgreen = (lgreen > 255)?255:lgreen;
				const unsigned int fblue = (lblue > 255)?255:lblue;
				final[x] = (fred << 16) + (fgreen << 8) + fblue;
			}
			src1 += m_Pitch;
			src2 += m_Pitch;
			final += m_Pitch;
		}
	}
	else
	{
	#if 0
		memcpy( m_Final, m_BDest, m_Width * m_Height * 4 );
	#else
		Color64* src = m_BDest;
		Pixel* dst = m_Final;
		for ( uint y = 0; y < m_Height; y++ )
		{
			__m128i* src2 = (__m128i*)src;
			for ( uint x = 0; x < m_Width / 2; x++ )
			{
				const __m128i p = src2[x];
				union { __m128i f4; unsigned int f[4]; };
				f4 = _mm_packus_epi16( p, p );
				dst[x * 2 + 0] = f[0];
				dst[x * 2 + 1] = f[1];
			}
			src += m_Pitch;
			dst += m_Pitch;
		}
	#endif
	} */
}

// -----------------------------------------------------------
// Engine::IsVisible
// Checks if a 3D position is visible from the current camera
// -----------------------------------------------------------
bool Engine::IsVisible( const vector3& a_Pos, sint& a_X, sint& a_Y )
{
	const vector3 O = Scene::GetCamera()->GetPosition();
	const vector3 V = Scene::GetCamera()->GetTarget() - O;
	return IsVisible( a_Pos, O, V, a_X, a_Y );
}

// -----------------------------------------------------------
// Engine::IsVisible
// Checks if a 3D position is visible from the current camera
// -----------------------------------------------------------
bool Engine::IsVisible( const vector3& a_Pos, const vector3& a_Campos, const vector3& a_Camdir, sint& a_X, sint& a_Y )
{
	vector3 L = a_Pos - a_Campos;
	const float sqdist = L.x * L.x + L.y * L.y + L.z * L.z;
	NORMALIZE( L );
	Primitive* prim = 0;
	const float odist = Engine::Trace( a_Campos, L, prim );
	bool retval = (sqdist < (odist * odist));
	float d = DOT( a_Camdir, L );
	if (d > 0)
	{
		vector3 xaxis = Engine::GetP1() - Engine::GetP2();
		vector3 yaxis = Engine::GetP1() - Engine::GetP4();
		const float len1 = LENGTH( xaxis ), len2 = LENGTH( yaxis );
		xaxis *= 1.0f / (len1 * len1), yaxis *= 1.0f / (len2 * len2);
		const vector3 i = a_Campos + ((DOT( a_Camdir, a_Campos ) - DOT( a_Camdir, Engine::GetP1() )) / d) * L;
		a_X = (int)((float)m_Width * (DOT( i, xaxis ) - DOT( Engine::GetP2(), xaxis )));
		a_Y = (int)((float)m_Height * (DOT( i, yaxis ) - DOT( Engine::GetP4(), yaxis )));
		if ((a_X < 0) && (a_Y < 0) && (a_X >= m_Width) && (a_Y >= m_Height)) retval = false;
	}
	return retval;
}

// -----------------------------------------------------------
// Engine::Trace
// Sends a single ray through the kd-tree
// -----------------------------------------------------------
float Engine::Trace( const vector3& a_O, const vector3& a_D, Primitive*& a_Prim, bool a_Dyn )
{
	BVHStack stack[128];
	float dist = 10000;
	vector3 R( 1.0f / a_D.x, 1.0f / a_D.y, 1.0f / a_D.z );
	unsigned int nrt = (a_Dyn)?2:1;
	for ( uint t = 0; t < nrt; t++ )
	{
		unsigned int stackptr = 0;
		BVHierarchy* bvh = (BVHierarchy*)Scene::GetBVH( t );
		BVHNode* node = bvh->GetRoot();
		if (!node) break;
		while (1)
		{
			// see if ray intersects current node
			float tmin = 0.00001f, tmax = dist;
			for ( uint axis = 0; axis < 3; ++axis ) 
			{
				const float t0 = (node->min.cell[axis] - a_O.cell[axis]) * R.cell[axis];
				const float t1 = (node->max.cell[axis] - a_O.cell[axis]) * R.cell[axis];
				const float nr = (t0 < t1) ? t0 : t1, fr = (t0 < t1) ? t1 : t0;
				tmin = (tmin < nr) ? nr : tmin, tmax = (fr <  tmax) ? fr : tmax;
			}
			if (tmin <= tmax)
			{
				// walk tree
				if (!node->IsLeaf())
				{
					stack[stackptr++].node = &bvh->m_Pool[node->GetLeft() + 1];
					node = &bvh->m_Pool[node->GetLeft()];
					continue;
				}
				else
				{
					// intersect
					const uint start = node->start, count = node->GetTCount();
					for ( uint i = 0; i < count; ++i ) 
					{
						const Primitive* restrict pr = bvh->m_Prim[start + i];
						const vector3 ao = pr->m_Vertex[0]->m_Pos - a_O;
						if ((ao.x * pr->m_N.x + ao.y * pr->m_N.y + ao.z * pr->m_N.z) < 0) continue;
						const vector3 bo = pr->m_Vertex[1]->m_Pos - a_O;
						const vector3 co = pr->m_Vertex[2]->m_Pos - a_O;
						const vector3 v1c = bo^ao, v2c = ao^co, v0c = co^bo;
						const float nominator = DOT( ao, pr->m_N );
						// intersection test
						const float v0d = DOT( v0c, a_D ), v1d = DOT( v1c, a_D ), v2d = DOT( v2c, a_D );
						if ((v0d > 0) && (v1d > 0) && (v2d > 0))
						{
							const float t = nominator * (1.0f / DOT( a_D, pr->m_N ));
							if ((t < dist) && (t >= 0)) 
							{
								a_Prim = (Primitive*)pr;
								dist = t;
							}
						}
					}
				}
			}
			if (!stackptr) break;
			node = stack[--stackptr].node;
		}
	}
	return dist;
}

// -----------------------------------------------------------
// Engine::TracePixel
// Trace a ray through a screen pixel
// -----------------------------------------------------------
float Engine::TracePixel( int x, int y, Primitive*& p, bool dyn )
{
	const vector3 I = m_P1 + ((m_P2 - m_P1) * ((float)x / (float)m_Width)) + ((m_P4 - m_P1) * ((float)y / (float)m_Height));
	const vector3 O = m_Origin, D = (I - O).Normalized();
	return Trace( O, D, p, dyn );
}

// -----------------------------------------------------------
// Engine::TraceEx
// Returns additional intersection data for a single ray
// -----------------------------------------------------------
void Engine::TraceEx( const vector3& a_O, const vector3& a_D, IData1& a_IData, bool a_Dyn )
{
	BVHStack stack[128];
	a_IData.dist = 10000;
	a_IData.prim = 0;
	vector3 R( 1.0f / a_D.x, 1.0f / a_D.y, 1.0f / a_D.z );
	unsigned int nrt = (a_Dyn)?2:1;
	for ( unsigned int t = 0; t < nrt; t++ )
	{
		unsigned int stackptr = 0;
		BVHierarchy* bvh = (BVHierarchy*)Scene::GetBVH( t );
		if (!bvh) break;
		BVHNode* node = bvh->GetRoot();
		while (1)
		{
			// see if ray intersects current node
			float tmin = 0.00001f, tmax = a_IData.dist;
			for ( uint axis = 0; axis < 3; ++axis ) 
			{
				const float t0 = (node->min.cell[axis] - a_O.cell[axis]) * R.cell[axis];
				const float t1 = (node->max.cell[axis] - a_O.cell[axis]) * R.cell[axis];
				const float nr = (t0 < t1) ? t0 : t1, fr = (t0 < t1) ? t1 : t0;
				tmin = (tmin < nr) ? nr : tmin, tmax = (fr <  tmax) ? fr : tmax;
			}
			if (tmin <= tmax)
			{
				// walk tree
				if (!node->IsLeaf())
				{
					stack[stackptr++].node = &bvh->m_Pool[node->GetLeft() + 1];
					node = &bvh->m_Pool[node->GetLeft()];
					continue;
				}
				else
				{
					// intersect
					const uint start = node->start, count = node->GetTCount();
					for ( uint i = 0; i < count; ++i ) 
					{
						const Primitive* restrict pr = bvh->m_Prim[start + i];
						const vector3 ao = pr->m_Vertex[0]->m_Pos - a_O;
						if ((ao.x * pr->m_N.x + ao.y * pr->m_N.y + ao.z * pr->m_N.z) < 0) continue;
						const vector3 bo = pr->m_Vertex[1]->m_Pos - a_O;
						const vector3 co = pr->m_Vertex[2]->m_Pos - a_O;
						const vector3 v1c = bo^ao, v2c = ao^co, v0c = co^bo;
						const float nominator = DOT( ao, pr->m_N );
						// intersection test
						const float v0d = DOT( v0c, a_D ), v1d = DOT( v1c, a_D ), v2d = DOT( v2c, a_D );
						if ((v0d > 0) && (v1d > 0) && (v2d > 0))
						{
							const float t = nominator * (1.0f / DOT( a_D, pr->m_N ));
							if ((t < a_IData.dist) && (t >= 0)) 
							{
								a_IData.prim = (Primitive*)pr;
								a_IData.dist = t;
								const float div = 1.0f / (v0d + v1d + v2d);
								a_IData.u = v2d * div;
								a_IData.v = v1d * div;
							}
						}
					}
				}
			}
			if (!stackptr) break;
			node = stack[--stackptr].node;
		}
	}
	if (a_IData.prim) a_IData.N = a_IData.prim->GetNormal( a_IData.u, a_IData.v );
}