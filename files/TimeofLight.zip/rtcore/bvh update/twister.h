// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2007 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#pragma once

namespace Raytracer {

#define MT_N 624
#define MT_M 397
#define MT_MATRIX_A   0x9908b0dfUL
#define MT_UPPER_MASK 0x80000000UL
#define MT_LOWER_MASK 0x7fffffffUL

class MTStore 
{
public:
	MTStore ();
	~MTStore ();
	void mtInit( MTStore* st );
	void mtInitScale( MTStore* st, float scale );
	void mtRandomInit( MTStore* st, unsigned int s, float scale );
	void mtNewRandomState( unsigned int* state, float* output );
	unsigned int* mtStateBase, *mtState;
	float* mtFloatBase, *mtFloat;
	unsigned short mtFloatCounter;
};

inline static float TRand( MTStore* st )
{
	float* rn = (float*)st->mtFloat;
	unsigned short c = st->mtFloatCounter;
	if (++c >= MT_N)  
	{
		st->mtNewRandomState (st->mtState, rn);
		st->mtFloatCounter = 0;
		return rn[0];
	}  
	else  
	{
		st->mtFloatCounter = c;
		return rn[c];
	}
}

}; // namespace Raytracer