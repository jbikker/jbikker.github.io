// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#include "precomp.h"
#include "bvh.h"

namespace Raytracer {

static const float flt_plus_inf = -logf(0);
vector3* PrimData::s_TVert = new vector3[16];
static wallclock_t BTimer;

static HANDLE waitbuild[2];
static HANDLE builddone[2];
_declspec(align(16)) 
ThreadedBVHBuilder TBuilder[2];

void ThreadedBVHBuilder::Init( uint thread, BVHierarchy* bvh, int maxsize )
{
	m_Thread = thread;
	SetThreadIdealProcessor( handle(), m_Thread );
	m_BVH = bvh;
	m_LTri = new BinTri*[maxsize];
	box = (__m128*)MALLOC64( 4 * sizeof( __m128 ) );
}

void ThreadedBVHBuilder::run()
{
	while (1)
	{
		WaitForSingleObject( waitbuild[m_Thread], INFINITE );
		Build();
		SetEvent( builddone[m_Thread] );
	}
}

void ThreadedBVHBuilder::Build()
{
	BinStack stack[128];
	int stackptr = 0;
	int first = m_First, last = m_Last;
	__m128 vmin4 = box[2], vmax4 = box[3], cmin4 = box[0], cmax4 = box[1];
	const __m128 plarge = _mm_set_ps1( 100000 ), nlarge = _mm_set_ps1( -100000 ), half4 = _mm_set_ps1( 0.5f );
	BVHNode* node = m_Root;
	while (1)
	{
		while (1)
		{
			// store node extends
			const float* vmin = (float*)&vmin4, *vmax = (float*)&vmax4;
			node->min = vector3( vmin[3], vmin[2], vmin[1] );
			node->max = vector3( vmax[3], vmax[2], vmax[1] );
			// check termination criterium: minimal primitive count
			if ((last - first) < 2) break;
			// determine longest axis
			int axis = 0;
			const float* cmin = (float*)&cmin4, *cmax = (float*)&cmax4;
			float largest = cmax[SSE_X] - cmin[SSE_X];
			if ((cmax[SSE_Y] - cmin[SSE_Y]) > largest) axis = 1, largest = cmax[SSE_Y] - cmin[SSE_Y];
			if ((cmax[SSE_Z] - cmin[SSE_Z]) > largest) axis = 2, largest = cmax[SSE_Z] - cmin[SSE_Z];
			// check termination criterium: minimal centroid box size
			if (largest < 0.0001f) break;
			union { __m128 extends4; float extends[4]; };
			extends4 = _mm_sub_ps( vmax4, vmin4 );
			float Cn = (extends[1] * extends[2] + extends[2] * extends[3] + extends[1] * extends[3]) * ((last - first) + 1);
			// calculate counts and boxes for the bins
			__m128 bcmin[8] = { plarge, plarge, plarge, plarge, plarge, plarge, plarge, plarge };		// centroid box min per bin
			__m128 bcmax[8] = { nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge };		// centroid box max per bin
			__m128 bvmin[8] = { plarge, plarge, plarge, plarge, plarge, plarge, plarge, plarge };		// voxel box min per bin
			__m128 bvmax[8] = { nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge };		// voxel box max per bin 
			__m128 lmin4c[8] = { plarge, plarge, plarge, plarge, plarge, plarge, plarge, plarge };
			__m128 lmax4c[8] = { nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge };		// final left centroid box
			__m128 lmin4v[8] = { plarge, plarge, plarge, plarge, plarge, plarge, plarge, plarge };
			__m128 lmax4v[8] = { nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge };		// final left voxel box
			__m128 rmin4v[8] = { plarge, plarge, plarge, plarge, plarge, plarge, plarge, plarge };
			__m128 rmax4v[8] = { nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge };		// final right centroid box
			__m128 rmin4c[8] = { plarge, plarge, plarge, plarge, plarge, plarge, plarge, plarge };
			__m128 rmax4c[8] = { nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge };		// final right voxel box
			union { __m128 kNl4[2]; float kNl[8]; };
			union { __m128 kNr4[2]; float kNr[8]; };
			union { __m128 kAl4[2]; float kAl[8]; };
			union { __m128 kAr4[2]; float kAr[8]; };
			union { __m128 Ck4[2]; float Ck[8]; };
			float binN[8] = { 0, 0, 0, 0, 0, 0, 0, 0 };
			const float k1 = 7.9999f / (cmax[3 - axis] - cmin[3 - axis]);
			for ( int r = first; r <= last; r++ )
			{
				float* centroid = (float*)&m_Tri[r]->centroid;
				const int bin = (int)(k1 * (centroid[3 - axis] - cmin[3 - axis]));
				binN[bin] += 1.0f;
				bcmin[bin] = _mm_min_ps( bcmin[bin], m_Tri[r]->centroid );								// update centroid box of a bin (min)
				bcmax[bin] = _mm_max_ps( bcmax[bin], m_Tri[r]->centroid );								// update centroid box of a bin (max)
				bvmin[bin] = _mm_min_ps( bvmin[bin], m_Tri[r]->boxp1 );									// update voxel box of a bin (min)
				bvmax[bin] = _mm_max_ps( bvmax[bin], m_Tri[r]->boxp2 );									// update voxel box of a bin (min)
			}
			// calculate cost per split candidate
			float Nl = 0, Nr = 0;
			__m128 min4cl = plarge, max4cl = nlarge;													// final left and right centroid box
			__m128 min4vl = plarge, max4vl = nlarge;													// final left and right voxel box
			__m128 min4cr = plarge, max4cr = nlarge;													// final left and right centroid box
			__m128 min4vr = plarge, max4vr = nlarge;													// final left and right voxel box
			for ( int k = 0; k < 8; k++ )
			{
				const unsigned int k2 = 7 - k;
				kNr[k2] = Nr;
				union { __m128 extends4; float extends[4]; };
				extends4 = _mm_sub_ps( max4vr, min4vr );
				rmin4c[k2] = min4cr, rmax4c[k2] = max4cr;
				rmin4v[k2] = min4vr, rmax4v[k2] = max4vr;
				kAr[k2] = extends[1] * extends[2] + extends[2] * extends[3] + extends[1] * extends[3];
				min4cl = lmin4c[k] = _mm_min_ps( min4cl, bcmin[k] ), max4cl = lmax4c[k] = _mm_max_ps( max4cl, bcmax[k] );
				min4vl = lmin4v[k] = _mm_min_ps( min4vl, bvmin[k] ), max4vl = lmax4v[k] = _mm_max_ps( max4vl, bvmax[k] );
				min4cr = _mm_min_ps( min4cr, bcmin[k2] ), max4cr = _mm_max_ps( max4cr, bcmax[k2] );
				min4vr = _mm_min_ps( min4vr, bvmin[k2] ), max4vr = _mm_max_ps( max4vr, bvmax[k2] );
				Nl += binN[k], Nr += binN[k2];
				kNl[k] = Nl;
				extends4 = _mm_sub_ps( max4vl, min4vl );
				kAl[k] = extends[1] * extends[2] + extends[2] * extends[3] + extends[1] * extends[3];
			}
			// determine best position
			float bestcost = Cn;
			int bestpos = -1;
			Ck4[0] = _mm_add_ps( _mm_mul_ps( kAl4[0], kNl4[0] ), _mm_mul_ps( kAr4[0], kNr4[0] ) );
			Ck4[1] = _mm_add_ps( _mm_mul_ps( kAl4[1], kNl4[1] ), _mm_mul_ps( kAr4[1], kNr4[1] ) );
			for ( int k = 0; k < 7; k++ ) if ((kNl[k] > 0) && (kNr[k] > 0) && (Ck[k] < bestcost)) bestpos = k, bestcost = Ck[k];
			// split at best position
			if (bestpos == -1) break;
			int lcount = 0, rcount = 0;
			const int count = (last - first) + 1;
			for ( int r = first; r <= last; r++ )
			{
				const float* centroid = (float*)&m_Tri[r]->centroid;
				const int bin = (int)(k1 * (centroid[3 - axis] - cmin[3 - axis]));
				if (bin <= bestpos) m_LTri[lcount++] = m_Tri[r]; else m_LTri[count - ++rcount] = m_Tri[r];
			}
			// recurse
			node->SetLeft( m_PIdx );
			node->SetAxis( axis );
			node->SetTCount( 0 );
			const __m128 lcentre4 = _mm_mul_ps( half4, _mm_add_ps( lmin4v[bestpos], lmax4v[bestpos] ) );
			const __m128 rcentre4 = _mm_mul_ps( half4, _mm_add_ps( rmin4v[bestpos], rmax4v[bestpos] ) );
			const float* lcentre = (float*)&lcentre4, *rcentre = (float*)&rcentre4;
			node->SetFirst( lcentre[axis] > rcentre[axis]?1:0 );
			memcpy( m_Tri + first, m_LTri, ((last - first) + 1) * 4 );
			// push right side on stack
			node = &m_Pool[m_PIdx++];
			stack[stackptr].node = &m_Pool[m_PIdx++];
			stack[stackptr].first = first + lcount;
			stack[stackptr].last = last;
			stack[stackptr].cmin4 = rmin4c[bestpos];
			stack[stackptr].cmax4 = rmax4c[bestpos];
			stack[stackptr].vmin4 = rmin4v[bestpos];
			stack[stackptr].vmax4 = rmax4v[bestpos];
			stackptr++;
			last = (first + lcount) - 1;	
			cmin4 = lmin4c[bestpos];
			cmax4 = lmax4c[bestpos];
			vmin4 = lmin4v[bestpos];
			vmax4 = lmax4v[bestpos];
		}
		// generate leaf
		node->start = first;
		node->SetTCount( (last - first) + 1 );
		for ( int i = first; i <= last; i++ ) m_Tri[i]->prim->m_BVHNode = node;
		// pop from stack and continue
		if (!stackptr) break;
		first = stack[--stackptr].first;
		node = stack[stackptr].node;
		last = stack[stackptr].last;
		vmin4 = stack[stackptr].vmin4;
		vmax4 = stack[stackptr].vmax4;
		cmin4 = stack[stackptr].cmin4;
		cmax4 = stack[stackptr].cmax4;
	}
	// done
	int w = 0;
}

BVHierarchy::BVHierarchy()
{
	m_Pool = 0;
	m_SPrim = 0;
	m_Prim = 0;
	m_Root = 0;
}

BVHierarchy::~BVHierarchy()
{
}

void BVHierarchy::PrepThreadedBuild()
{
	for ( int i = 0; i < 2; i++ )
	{
		waitbuild[i] = CreateEvent( NULL, FALSE, FALSE, NULL );
		builddone[i] = CreateEvent( NULL, FALSE, FALSE, NULL );
	}
	TBuilder[0].Init( 0, this, 20000 );
	TBuilder[1].Init( 1, this, 20000 );
	TBuilder[0].start();
	TBuilder[1].start();
}

void BVHierarchy::Refit( BVHNode* a_Node, __m128& a_Min4, __m128& a_Max4 )
{
	if (!a_Node->IsLeaf())
	{
		__m128 lmin4, lmax4, rmin4, rmax4;
		Refit( &m_Pool[a_Node->GetLeft()], lmin4, lmax4 );
		Refit( &m_Pool[a_Node->GetRight()], rmin4, rmax4 );
		a_Min4 = _mm_min_ps( lmin4, rmin4 ), a_Max4 = _mm_max_ps( lmax4, rmax4 );
	}
	else
	{
		int start = a_Node->start, count = a_Node->GetTCount();
		a_Min4 = _mm_set_ps1( 10000 ), a_Max4 = _mm_set_ps1( -10000 );
		for ( int i = 0; i < count; i++ )
		{
			Primitive* p = m_Prim[start + i]; // may want to do this only if we already know the node has changed
			for ( int j = 0; j < 3; j++ )
			{
				const vector3 pos = p->GetVertex( j )->GetPos();
				const __m128 pos4 = _mm_set_ps( pos.x, pos.y, pos.z, 0 );
				a_Min4 = _mm_min_ps( a_Min4, pos4 ), a_Max4 = _mm_max_ps( a_Max4, pos4 );
			}
		}
	}
}

void BVHierarchy::PrepDynamicBuilds( unsigned int a_PCount )
{
	m_Pool = (BVHNode*)MALLOC64( sizeof( BVHNode ) * a_PCount * 2 );
	m_Prim = new Primitive*[a_PCount];
	m_SPrim = new SubPrim*[a_PCount];
	SubPrim* sprims = (SubPrim*)MALLOC64( sizeof( SubPrim ) * a_PCount );
	for ( unsigned int r = 0; r < a_PCount; r++ ) m_SPrim[r] = &sprims[r];
	m_Tri = new BinTri*[a_PCount];
	m_LTri = new BinTri*[a_PCount];
	m_RTri = new BinTri*[a_PCount];
	BinTri* bt = (BinTri*)MALLOC64( sizeof( BinTri ) * a_PCount );
	for ( unsigned int i = 0; i < a_PCount; i++ ) 
	{
		m_Tri[i] = &bt[i];
		m_Tri[i]->prim = m_Prim[i];
	}
}

void BVHierarchy::ThreadedBuild( Primitive** a_Prim, unsigned int a_PCount )
{
	// implementation of Wald's paper, 'On fast Construction of SAH-based Bounding Volume Hierarchies'
	if (a_PCount == 0) { m_Root = 0; return; }
	BTimer.reset();
	if (!m_Pool) 
	{
		m_Pool = (BVHNode*)MALLOC64( sizeof( BVHNode ) * a_PCount * 2 );
		m_Prim = new Primitive*[a_PCount];
		m_Tri = new BinTri*[a_PCount];
		m_LTri = new BinTri*[a_PCount];
		m_RTri = new BinTri*[a_PCount];
		BinTri* bt = (BinTri*)MALLOC64( sizeof( BinTri ) * a_PCount );
		for ( unsigned int i = 0; i < a_PCount; i++ ) 
		{
			m_Tri[i] = &bt[i];
			m_Tri[i]->prim = m_Prim[i];
		}
	}
	memcpy( m_Prim, a_Prim, a_PCount * 4 );
	for ( unsigned int i = 0; i < a_PCount; i++ ) m_Tri[i]->prim = m_Prim[i];
	BVHNode* node = m_Root = &m_Pool[0];
	m_PIdx = 1;
	// determine centroids and aabbs for all triangles
	const __m128 plarge = _mm_set_ps1( 100000 ), nlarge = _mm_set_ps1( -100000 ), half4 = _mm_set_ps1( 0.5f );
	__m128 cmin4 = plarge, cmax4 = nlarge;  // box around centroids
	__m128 vmin4 = plarge, vmax4 = nlarge;	// voxel size; initially full scene extend
	for ( unsigned int r = 0; r < a_PCount; r++ )
	{
		__m128 emin4 = plarge, emax4 = nlarge;
		for ( int j = 0; j < 3; j++ )
		{
			const vector3 pos = m_Prim[r]->GetVertex( j )->GetPos();
			const __m128 pos4 = _mm_set_ps( pos.x, pos.y, pos.z, 0 );
			emin4 = _mm_min_ps( emin4, pos4 ), emax4 = _mm_max_ps( emax4, pos4 );
		}
		m_Tri[r]->boxp1 = emin4;
		m_Tri[r]->boxp2 = emax4;
		m_Tri[r]->centroid = _mm_mul_ps( _mm_add_ps( emin4, emax4 ), half4 );
		cmin4 = _mm_min_ps( cmin4, m_Tri[r]->centroid ), cmax4 = _mm_max_ps( cmax4, m_Tri[r]->centroid );
		vmin4 = _mm_min_ps( vmin4, emin4 ), vmax4 = _mm_max_ps( vmax4, emax4 );
	}
	// first split
	int first = 0, last = a_PCount -1, stackptr = 0;
	const float* vmin = (float*)&vmin4, *vmax = (float*)&vmax4;
	node->min = vector3( vmin[3], vmin[2], vmin[1] );
	node->max = vector3( vmax[3], vmax[2], vmax[1] );
	// determine longest axis
	int axis = 0;
	const float* cmin = (float*)&cmin4, *cmax = (float*)&cmax4;
	float largest = cmax[SSE_X] - cmin[SSE_X];
	if ((cmax[SSE_Y] - cmin[SSE_Y]) > largest) axis = 1, largest = cmax[SSE_Y] - cmin[SSE_Y];
	if ((cmax[SSE_Z] - cmin[SSE_Z]) > largest) axis = 2, largest = cmax[SSE_Z] - cmin[SSE_Z];
	union { __m128 extends4; float extends[4]; };
	extends4 = _mm_sub_ps( vmax4, vmin4 );
	float Cn = (extends[1] * extends[2] + extends[2] * extends[3] + extends[1] * extends[3]) * ((last - first) + 1);
	// calculate counts and boxes for the bins
	__m128 bcmin[8] = { plarge, plarge, plarge, plarge, plarge, plarge, plarge, plarge };		// centroid box min per bin
	__m128 bcmax[8] = { nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge };		// centroid box max per bin
	__m128 bvmin[8] = { plarge, plarge, plarge, plarge, plarge, plarge, plarge, plarge };		// voxel box min per bin
	__m128 bvmax[8] = { nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge };		// voxel box max per bin 
	__m128 lmin4c[8] = { plarge, plarge, plarge, plarge, plarge, plarge, plarge, plarge };
	__m128 lmax4c[8] = { nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge };		// final left centroid box
	__m128 lmin4v[8] = { plarge, plarge, plarge, plarge, plarge, plarge, plarge, plarge };
	__m128 lmax4v[8] = { nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge };		// final left voxel box
	__m128 rmin4v[8] = { plarge, plarge, plarge, plarge, plarge, plarge, plarge, plarge };
	__m128 rmax4v[8] = { nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge };		// final right centroid box
	__m128 rmin4c[8] = { plarge, plarge, plarge, plarge, plarge, plarge, plarge, plarge };
	__m128 rmax4c[8] = { nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge };		// final right voxel box
	union { __m128 kNl4[2]; float kNl[8]; };
	union { __m128 kNr4[2]; float kNr[8]; };
	union { __m128 kAl4[2]; float kAl[8]; };
	union { __m128 kAr4[2]; float kAr[8]; };
	union { __m128 Ck4[2]; float Ck[8]; };
	float binN[8] = { 0, 0, 0, 0, 0, 0, 0, 0 };
	const float k1 = 7.9999f / (cmax[3 - axis] - cmin[3 - axis]);
	for ( int r = first; r <= last; r++ )
	{
		float* centroid = (float*)&m_Tri[r]->centroid;
		const int bin = (int)(k1 * (centroid[3 - axis] - cmin[3 - axis]));
		binN[bin] += 1.0f;
		bcmin[bin] = _mm_min_ps( bcmin[bin], m_Tri[r]->centroid );								// update centroid box of a bin (min)
		bcmax[bin] = _mm_max_ps( bcmax[bin], m_Tri[r]->centroid );								// update centroid box of a bin (max)
		bvmin[bin] = _mm_min_ps( bvmin[bin], m_Tri[r]->boxp1 );									// update voxel box of a bin (min)
		bvmax[bin] = _mm_max_ps( bvmax[bin], m_Tri[r]->boxp2 );									// update voxel box of a bin (min)
	}
	// calculate cost per split candidate
	float Nl = 0, Nr = 0;
	__m128 min4cl = plarge, max4cl = nlarge;													// final left and right centroid box
	__m128 min4vl = plarge, max4vl = nlarge;													// final left and right voxel box
	__m128 min4cr = plarge, max4cr = nlarge;													// final left and right centroid box
	__m128 min4vr = plarge, max4vr = nlarge;													// final left and right voxel box
	for ( int k = 0; k < 8; k++ )
	{
		const unsigned int k2 = 7 - k;
		kNr[k2] = Nr;
		union { __m128 extends4; float extends[4]; };
		extends4 = _mm_sub_ps( max4vr, min4vr );
		rmin4c[k2] = min4cr, rmax4c[k2] = max4cr;
		rmin4v[k2] = min4vr, rmax4v[k2] = max4vr;
		kAr[k2] = extends[1] * extends[2] + extends[2] * extends[3] + extends[1] * extends[3];
		min4cl = lmin4c[k] = _mm_min_ps( min4cl, bcmin[k] ), max4cl = lmax4c[k] = _mm_max_ps( max4cl, bcmax[k] );
		min4vl = lmin4v[k] = _mm_min_ps( min4vl, bvmin[k] ), max4vl = lmax4v[k] = _mm_max_ps( max4vl, bvmax[k] );
		min4cr = _mm_min_ps( min4cr, bcmin[k2] ), max4cr = _mm_max_ps( max4cr, bcmax[k2] );
		min4vr = _mm_min_ps( min4vr, bvmin[k2] ), max4vr = _mm_max_ps( max4vr, bvmax[k2] );
		Nl += binN[k], Nr += binN[k2];
		kNl[k] = Nl;
		extends4 = _mm_sub_ps( max4vl, min4vl );
		kAl[k] = extends[1] * extends[2] + extends[2] * extends[3] + extends[1] * extends[3];
	}
	// determine best position
	float bestcost = Cn;
	int bestpos = -1;
	Ck4[0] = _mm_add_ps( _mm_mul_ps( kAl4[0], kNl4[0] ), _mm_mul_ps( kAr4[0], kNr4[0] ) );
	Ck4[1] = _mm_add_ps( _mm_mul_ps( kAl4[1], kNl4[1] ), _mm_mul_ps( kAr4[1], kNr4[1] ) );
	for ( int k = 0; k < 7; k++ ) if ((kNl[k] > 0) && (kNr[k] > 0) && (Ck[k] < bestcost)) bestpos = k, bestcost = Ck[k];
	// split at best position
	if (bestpos == -1) return; // that's bad
	int lcount = 0, rcount = 0;
	const int count = (last - first) + 1;
	for ( int r = first; r <= last; r++ )
	{
		const float* centroid = (float*)&m_Tri[r]->centroid;
		const int bin = (int)(k1 * (centroid[3 - axis] - cmin[3 - axis]));
		if (bin <= bestpos) m_LTri[lcount++] = m_Tri[r]; else m_LTri[count - ++rcount] = m_Tri[r];
	}
	// launch threads
	node->SetLeft( m_PIdx );
	node->SetAxis( axis );
	node->SetTCount( 0 );
	const __m128 lcentre4 = _mm_mul_ps( half4, _mm_add_ps( lmin4v[bestpos], lmax4v[bestpos] ) );
	const __m128 rcentre4 = _mm_mul_ps( half4, _mm_add_ps( rmin4v[bestpos], rmax4v[bestpos] ) );
	const float* lcentre = (float*)&lcentre4, *rcentre = (float*)&rcentre4;
	node->SetFirst( lcentre[axis] > rcentre[axis]?1:0 );
	memcpy( m_Tri + first, m_LTri, ((last - first) + 1) * 4 );
	BVHNode* lnode = &m_Pool[1];
	BVHNode* rnode = &m_Pool[2];
	TBuilder[0].SetData( m_Tri, lnode, first, (first + lcount) - 1, m_Pool, 3 );
	TBuilder[0].SetCBox( lmin4c[bestpos], lmax4c[bestpos] );
	TBuilder[0].SetVBox( lmin4v[bestpos], lmax4v[bestpos] );
	TBuilder[1].SetData( m_Tri, rnode, first + lcount, last, m_Pool, 3 + 2 * lcount );
	TBuilder[1].SetCBox( rmin4c[bestpos], rmax4c[bestpos] );
	TBuilder[1].SetVBox( rmin4v[bestpos], rmax4v[bestpos] );
	SetEvent( waitbuild[0] );
	SetEvent( waitbuild[1] );
	// wait for threads to complete
	WaitForMultipleObjects( 2, builddone, true, INFINITE );
	for ( unsigned int i = 0; i < a_PCount; i++ ) m_Prim[i] = m_Tri[i]->prim;
	Engine::m_BuildTime = (float)BTimer.elapsed();
}

void BVHierarchy::BinnedBuild( Primitive** a_Prim, unsigned int a_PCount )
{
	// implementation of Wald's paper, 'On fast Construction of SAH-based Bounding Volume Hierarchies'
	if (a_PCount == 0) { m_Root = 0; return; }
	BTimer.reset();
	if (!m_Pool) 
	{
		m_Pool = (BVHNode*)MALLOC64( sizeof( BVHNode ) * a_PCount * 2 );
		m_Prim = new Primitive*[a_PCount];
		m_Tri = new BinTri*[a_PCount];
		m_LTri = new BinTri*[a_PCount];
		m_RTri = new BinTri*[a_PCount];
		BinTri* bt = (BinTri*)MALLOC64( sizeof( BinTri ) * a_PCount );
		for ( unsigned int i = 0; i < a_PCount; i++ ) 
		{
			m_Tri[i] = &bt[i];
			m_Tri[i]->prim = m_Prim[i];
		}
	}
	memcpy( m_Prim, a_Prim, a_PCount * 4 );
	for ( unsigned int i = 0; i < a_PCount; i++ ) m_Tri[i]->prim = m_Prim[i];
	BVHNode* node = m_Root = &m_Pool[0];
	m_PIdx = 1;
	// determine centroids and aabbs for all triangles
	const __m128 plarge = _mm_set_ps1( 100000 ), nlarge = _mm_set_ps1( -100000 ), half4 = _mm_set_ps1( 0.5f );
	__m128 cmin4 = plarge, cmax4 = nlarge;  // box around centroids
	__m128 vmin4 = plarge, vmax4 = nlarge;	// voxel size; initially full scene extend
	for ( unsigned int r = 0; r < a_PCount; r++ )
	{
		__m128 emin4 = plarge, emax4 = nlarge;
		for ( int j = 0; j < 3; j++ )
		{
			const vector3 pos = m_Prim[r]->GetVertex( j )->GetPos();
			const __m128 pos4 = _mm_set_ps( pos.x, pos.y, pos.z, 0 );
			emin4 = _mm_min_ps( emin4, pos4 ), emax4 = _mm_max_ps( emax4, pos4 );
		}
		m_Tri[r]->boxp1 = emin4;
		m_Tri[r]->boxp2 = emax4;
		m_Tri[r]->centroid = _mm_mul_ps( _mm_add_ps( emin4, emax4 ), half4 );
		cmin4 = _mm_min_ps( cmin4, m_Tri[r]->centroid ), cmax4 = _mm_max_ps( cmax4, m_Tri[r]->centroid );
		vmin4 = _mm_min_ps( vmin4, emin4 ), vmax4 = _mm_max_ps( vmax4, emax4 );
	}
	// start of recursive code
	int first = 0, last = a_PCount -1, stackptr = 0;
	BinStack stack[128];
	while (1)
	{
		while (1)
		{
			// store node extends
			const float* vmin = (float*)&vmin4, *vmax = (float*)&vmax4;
			node->min = vector3( vmin[3], vmin[2], vmin[1] );
			node->max = vector3( vmax[3], vmax[2], vmax[1] );
			// check termination criterium: minimal primitive count
			if ((last - first) < 2) break;
			// determine longest axis
			int axis = 0;
			const float* cmin = (float*)&cmin4, *cmax = (float*)&cmax4;
			float largest = cmax[SSE_X] - cmin[SSE_X];
			if ((cmax[SSE_Y] - cmin[SSE_Y]) > largest) axis = 1, largest = cmax[SSE_Y] - cmin[SSE_Y];
			if ((cmax[SSE_Z] - cmin[SSE_Z]) > largest) axis = 2, largest = cmax[SSE_Z] - cmin[SSE_Z];
			// check termination criterium: minimal centroid box size
			if (largest < 0.0001f) break;
			union { __m128 extends4; float extends[4]; };
			extends4 = _mm_sub_ps( vmax4, vmin4 );
			float Cn = (extends[1] * extends[2] + extends[2] * extends[3] + extends[1] * extends[3]) * ((last - first) + 1);
			// calculate counts and boxes for the bins
			__m128 bcmin[8] = { plarge, plarge, plarge, plarge, plarge, plarge, plarge, plarge };		// centroid box min per bin
			__m128 bcmax[8] = { nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge };		// centroid box max per bin
			__m128 bvmin[8] = { plarge, plarge, plarge, plarge, plarge, plarge, plarge, plarge };		// voxel box min per bin
			__m128 bvmax[8] = { nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge };		// voxel box max per bin 
			__m128 lmin4c[8] = { plarge, plarge, plarge, plarge, plarge, plarge, plarge, plarge };
			__m128 lmax4c[8] = { nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge };		// final left centroid box
			__m128 lmin4v[8] = { plarge, plarge, plarge, plarge, plarge, plarge, plarge, plarge };
			__m128 lmax4v[8] = { nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge };		// final left voxel box
			__m128 rmin4v[8] = { plarge, plarge, plarge, plarge, plarge, plarge, plarge, plarge };
			__m128 rmax4v[8] = { nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge };		// final right centroid box
			__m128 rmin4c[8] = { plarge, plarge, plarge, plarge, plarge, plarge, plarge, plarge };
			__m128 rmax4c[8] = { nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge, nlarge };		// final right voxel box
			union { __m128 kNl4[2]; float kNl[8]; };
			union { __m128 kNr4[2]; float kNr[8]; };
			union { __m128 kAl4[2]; float kAl[8]; };
			union { __m128 kAr4[2]; float kAr[8]; };
			union { __m128 Ck4[2]; float Ck[8]; };
			float binN[8] = { 0, 0, 0, 0, 0, 0, 0, 0 };
			const float k1 = 7.9999f / (cmax[3 - axis] - cmin[3 - axis]);
			for ( int r = first; r <= last; r++ )
			{
				float* centroid = (float*)&m_Tri[r]->centroid;
				const int bin = (int)(k1 * (centroid[3 - axis] - cmin[3 - axis]));
				binN[bin] += 1.0f;
				bcmin[bin] = _mm_min_ps( bcmin[bin], m_Tri[r]->centroid );								// update centroid box of a bin (min)
				bcmax[bin] = _mm_max_ps( bcmax[bin], m_Tri[r]->centroid );								// update centroid box of a bin (max)
				bvmin[bin] = _mm_min_ps( bvmin[bin], m_Tri[r]->boxp1 );									// update voxel box of a bin (min)
				bvmax[bin] = _mm_max_ps( bvmax[bin], m_Tri[r]->boxp2 );									// update voxel box of a bin (min)
			}
			// calculate cost per split candidate
			float Nl = 0, Nr = 0;
			__m128 min4cl = plarge, max4cl = nlarge;													// final left and right centroid box
			__m128 min4vl = plarge, max4vl = nlarge;													// final left and right voxel box
			__m128 min4cr = plarge, max4cr = nlarge;													// final left and right centroid box
			__m128 min4vr = plarge, max4vr = nlarge;													// final left and right voxel box
			for ( int k = 0; k < 8; k++ )
			{
				const unsigned int k2 = 7 - k;
				kNr[k2] = Nr;
				union { __m128 extends4; float extends[4]; };
				extends4 = _mm_sub_ps( max4vr, min4vr );
				rmin4c[k2] = min4cr, rmax4c[k2] = max4cr;
				rmin4v[k2] = min4vr, rmax4v[k2] = max4vr;
				kAr[k2] = extends[1] * extends[2] + extends[2] * extends[3] + extends[1] * extends[3];
				min4cl = lmin4c[k] = _mm_min_ps( min4cl, bcmin[k] ), max4cl = lmax4c[k] = _mm_max_ps( max4cl, bcmax[k] );
				min4vl = lmin4v[k] = _mm_min_ps( min4vl, bvmin[k] ), max4vl = lmax4v[k] = _mm_max_ps( max4vl, bvmax[k] );
				min4cr = _mm_min_ps( min4cr, bcmin[k2] ), max4cr = _mm_max_ps( max4cr, bcmax[k2] );
				min4vr = _mm_min_ps( min4vr, bvmin[k2] ), max4vr = _mm_max_ps( max4vr, bvmax[k2] );
				Nl += binN[k], Nr += binN[k2];
				kNl[k] = Nl;
				extends4 = _mm_sub_ps( max4vl, min4vl );
				kAl[k] = extends[1] * extends[2] + extends[2] * extends[3] + extends[1] * extends[3];
			}
			// determine best position
			float bestcost = Cn;
			int bestpos = -1;
			Ck4[0] = _mm_add_ps( _mm_mul_ps( kAl4[0], kNl4[0] ), _mm_mul_ps( kAr4[0], kNr4[0] ) );
			Ck4[1] = _mm_add_ps( _mm_mul_ps( kAl4[1], kNl4[1] ), _mm_mul_ps( kAr4[1], kNr4[1] ) );
			for ( int k = 0; k < 7; k++ ) if ((kNl[k] > 0) && (kNr[k] > 0) && (Ck[k] < bestcost)) bestpos = k, bestcost = Ck[k];
			// split at best position
			if (bestpos == -1) break;
			int lcount = 0, rcount = 0;
			const int count = (last - first) + 1;
			for ( int r = first; r <= last; r++ )
			{
				const float* centroid = (float*)&m_Tri[r]->centroid;
				const int bin = (int)(k1 * (centroid[3 - axis] - cmin[3 - axis]));
				if (bin <= bestpos) m_LTri[lcount++] = m_Tri[r]; else m_LTri[count - ++rcount] = m_Tri[r];
			}
			// recurse
			node->SetLeft( m_PIdx );
			node->SetAxis( axis );
			node->SetTCount( 0 );
			const __m128 lcentre4 = _mm_mul_ps( half4, _mm_add_ps( lmin4v[bestpos], lmax4v[bestpos] ) );
			const __m128 rcentre4 = _mm_mul_ps( half4, _mm_add_ps( rmin4v[bestpos], rmax4v[bestpos] ) );
			const float* lcentre = (float*)&lcentre4, *rcentre = (float*)&rcentre4;
			node->SetFirst( lcentre[axis] > rcentre[axis]?1:0 );
			memcpy( m_Tri + first, m_LTri, ((last - first) + 1) * 4 );
			// push right side on stack
			node = &m_Pool[m_PIdx++];
			stack[stackptr].node = &m_Pool[m_PIdx++];
			stack[stackptr].first = first + lcount;
			stack[stackptr].last = last;
			stack[stackptr].cmin4 = rmin4c[bestpos];
			stack[stackptr].cmax4 = rmax4c[bestpos];
			stack[stackptr].vmin4 = rmin4v[bestpos];
			stack[stackptr].vmax4 = rmax4v[bestpos];
			stackptr++;
			last = (first + lcount) - 1;	
			cmin4 = lmin4c[bestpos];
			cmax4 = lmax4c[bestpos];
			vmin4 = lmin4v[bestpos];
			vmax4 = lmax4v[bestpos];
		}
		// generate leaf
		node->start = first;
		node->SetTCount( (last - first) + 1 );
		// pop from stack and continue
		if (!stackptr) break;
		first = stack[--stackptr].first;
		node = stack[stackptr].node;
		last = stack[stackptr].last;
		vmin4 = stack[stackptr].vmin4;
		vmax4 = stack[stackptr].vmax4;
		cmin4 = stack[stackptr].cmin4;
		cmax4 = stack[stackptr].cmax4;
	}
	// done
	for ( unsigned int i = 0; i < a_PCount; i++ ) m_Prim[i] = m_Tri[i]->prim;
	Engine::m_BuildTime = (float)BTimer.elapsed();
}

void BVHierarchy::CalcBBox( SubPrim** a_Prim, unsigned int a_Start, unsigned int a_End, aabb& a_Box )
{
	float large = 100000;
	vector3 emin( large, large, large );
	vector3 emax( -large, -large, -large );
	for ( unsigned int i = a_Start; i <= a_End; i++ )
	{
		aabb box = a_Prim[i]->bbox;
		for ( int a = 0; a < 3; a++ )
		{
			if (box.GetP1().cell[a] < emin.cell[a]) emin.cell[a] = box.GetP1().cell[a];
			if (box.GetP2().cell[a] > emax.cell[a]) emax.cell[a] = box.GetP2().cell[a];
		}
	}
	a_Box.SetP1( emin );
	a_Box.SetP2( emax );
}

void BVHierarchy::CountLeafs( BVHNode* a_Node, int& a_Leafs, int& a_Prims, int& a_MaxPrims, int& a_MaxDepth, float& a_Area, float& a_TArea, int& a_Nodes, int a_Depth )
{
	a_Nodes++;
	vector3 size = a_Node->max - a_Node->min;
	aabb bbox( a_Node->min, size );
	a_Area += bbox.area();
	if (a_Depth < 10) a_TArea += bbox.area();
	if (a_Depth > a_MaxDepth) a_MaxDepth = a_Depth;
	if (a_Node->IsLeaf())
	{
		a_Leafs++;
		a_Prims += a_Node->GetTCount();
		if ((int)a_Node->GetTCount() > a_MaxPrims) a_MaxPrims = a_Node->GetTCount();
	}
	else
	{
		BVHNode* lnode = &m_Pool[a_Node->GetLeft()];
		BVHNode* rnode = &m_Pool[a_Node->GetRight()];
		CountLeafs( lnode, a_Leafs, a_Prims, a_MaxPrims, a_MaxDepth, a_Area, a_TArea, a_Nodes, a_Depth + 1 );
		CountLeafs( rnode, a_Leafs, a_Prims, a_MaxPrims, a_MaxDepth, a_Area, a_TArea, a_Nodes, a_Depth + 1 );
	}
}

struct BuildStack
{
	BVHNode* node;
	unsigned int start, end;
	aabb box;
};

void BVHierarchy::FinalizeLeaf( BVHNode* a_Node, SubPrim** a_Prim, int start, int end )
{
	a_Node->start = start;
	int count = 0;
	for(int i = start; i <= end; i++)
	{
		// Testing if the primitive is already in the leaf
		bool found = false;
		for( int j = 0; ! found && j < count ; j++ )
		{
			if (a_Prim[i]->prim == m_Prim[start + j]) found = true;
		}
		if (!found)
		{
			// The leaf was not found, add it
			m_Prim[start + count] = a_Prim[i]->prim;
			count ++;
		}
	}
	a_Node->SetTCount( count );
}

void BVHierarchy::PreBuild( Primitive** a_Prim, unsigned int a_PCount, SubPrim** a_SPrim, unsigned int& a_NCount )
{
	Log::Message( "entering BVHierarchy::PreBuild()" );
	unsigned int idx = 0;
	unsigned int maxsp = Scene::GetSubPrimArraySize();
	for ( unsigned int i = 0; i < a_PCount; i++ )
	{
		aabb pbox;
		float large = 100000;
		vector3 emin( large, large, large );
		vector3 emax( -large, -large, -large );
		for ( int j = 0; j < 3; j++ )
		{
			vector3 pos = a_Prim[i]->GetVertex( j )->GetPos();
			if (pos.x < emin.x) emin.x = pos.x;
			if (pos.x > emax.x) emax.x = pos.x;
			if (pos.y < emin.y) emin.y = pos.y;
			if (pos.y > emax.y) emax.y = pos.y;
			if (pos.z < emin.z) emin.z = pos.z;
			if (pos.z > emax.z) emax.z = pos.z;
		}
		pbox.SetP1( emin );
		pbox.SetP2( emax );
		aabb bstack[64];
		bool bclipped[64];
		int bsptr = 1;
		bstack[0] = pbox;
		bclipped[0] = false;
		while (bsptr > 0)
		{
			aabb box = bstack[--bsptr];
			float sarea = box.area();
		#ifdef BVHPRESPLIT
			if (sarea > 53.65f) // 28, 53
			{
				// split and push both halves on the stack
				aabb newbox = box;
				int axis = box.LongestSide();
				float centre = (box.GetP1().cell[axis] + box.GetP2().cell[axis]) * 0.5f;
				newbox.GetP1().cell[axis] = box.GetP2().cell[axis] = centre;
				bclipped[bsptr] = true; bstack[bsptr++] = newbox;
				bclipped[bsptr] = true; bstack[bsptr++] = box;
				continue;
			}
		#endif
			// clip triangle to box and emit
			aabb clipbox = box;
		#ifdef BVHPRESPLIT
			if (bclipped[bsptr])
			{
				PrimData pd( a_Prim[i] );
				pd.Clip( box.GetP1().x, 1, 0 );
				pd.Clip( box.GetP2().x, -1, 0 );
				pd.Clip( box.GetP1().y, 1, 1 );
				pd.Clip( box.GetP2().y, -1, 1 );
				pd.Clip( box.GetP1().z, 1, 2 );
				pd.Clip( box.GetP2().z, -1, 2 );
				if (pd.m_Verts == 0) continue;
				pd.UpdateBBox();
				clipbox.SetP1( pd.bbox.p1 );
				clipbox.SetP2( pd.bbox.p2 );
			}
		#endif
			a_SPrim[idx]->bbox = clipbox;
			a_SPrim[idx++]->prim = a_Prim[i];
			if (idx == maxsp) Log::Error( "ERROR: Exceeded SubPrim array", "use allocate to fix this" );
		}
	}
	a_NCount = idx;
	Log::Message( "leaving BVHierarchy::PreBuild()" );
}

void BVHierarchy::UpdateDirMasks( BVHNode* a_Node )
{
	BVHNode* stack[128];
	int stackptr = 1;
	stack[0] = a_Node;
	while (stackptr)
	{
		BVHNode* node = stack[--stackptr];
		if (!node->IsLeaf())
		{
			BVHNode* lnode = &m_Pool[node->GetLeft()];
			BVHNode* rnode = &m_Pool[node->GetRight()];
			int mask = 0;
			for( int signmask = 0; signmask < 8; ++signmask )
			{
				// compute bounding box describing the volume of interest
				int front = 0; 
				vector3 intL, intU;
				for( int axis = 0; axis < 3; ++axis )
				{
					if (signmask & (1 << axis))
					{
						intL[axis] = max( lnode->min[axis], rnode->min[axis] );
						intU[axis] = max( lnode->max[axis], rnode->max[axis] );
						front |= (lnode->max[axis] >= rnode->max[axis]) ? 0 : (1 << axis);
					}
					else
					{
						intL[axis] = min( lnode->min[axis], rnode->min[axis] );
						intU[axis] = min( lnode->max[axis], rnode->max[axis] );
						front |= (lnode->min[axis] <= rnode->min[axis]) ? 0 : (1 << axis);
					}
				}
				// intersect the bounding boxes with the volume of interest
				const vector3 leftL( max( lnode->min.x, intL.x ), max( lnode->min.y, intL.y ), max( lnode->min.z, intL.z ) );
				const vector3 leftU( min( lnode->max.x, intU.x ), min( lnode->max.y, intU.y ), min( lnode->max.z, intU.z ) );
				const vector3 rightL( max( rnode->min.x, intL.x ), max( rnode->min.y, intL.y ), max( rnode->min.z, intL.z ) );
				const vector3 rightU( min( rnode->max.x, intU.x ), min( rnode->max.y, intU.y ), min( rnode->max.z, intU.z ) );
				bool lvalid = (leftL.x <= leftU.x && leftL.y <= leftU.y && leftL.z <= leftU.z);
				bool rvalid = (rightL.x <= rightU.x && rightL.y <= rightU.y && rightL.z <= rightU.z);
				// calculate the surface areas of the visible sides
				vector3 dl = leftU - leftL, dr = rightU - rightL;
				float larea = lvalid ? 0 : (dl.x * (dl.y + dl.z) + dl.y * dl.z);
				float rarea = rvalid ? 0 : (dr.x * (dr.y + dr.z) + dr.y * dr.z);
				if (lvalid && rvalid)
				{
					// subtract the occluded surface areas
					const vector3 dimin( min( leftU.x, rightU.x ), min( leftU.y, rightU.y ), min( leftU.z, rightU.z ) );
					const vector3 dimax( max( leftL.x, rightL.x ), max( leftL.y, rightL.y ), max( leftL.z, rightL.z ) );
					const vector3 di = dimin - dimax;
					((front & 0x1) ? larea : rarea) -= max( 0.0f, di.y * di.z );
					((front & 0x2) ? larea : rarea) -= max( 0.0f, di.x * di.z );
					((front & 0x4) ? larea : rarea) -= max( 0.0f, di.x * di.y );
				}
				// pick the node with the larger visible area as the near node
				mask |= (larea >= rarea) ? 0 : (1 << signmask);
			}
			node->SetDirMask( mask );
			stack[stackptr++] = rnode;
			stack[stackptr++] = lnode;
		}
	}
}

void BVHierarchy::Build( SubPrim** a_Prim, unsigned int a_PCount )
{
	Log::Message( "entering BVHierarchy::Build()" );
	if (!m_Pool) m_Pool = new BVHNode[a_PCount * 2];
	m_PIdx = 1;
	m_Prim = new Primitive*[a_PCount];
	m_Root = &m_Pool[0];
	aabb box;
	CalcBBox( a_Prim, 0, a_PCount - 1, box );
	// recursive build
	BVHNode* node = m_Root;
	BuildStack stack[256];
	unsigned int stackptr = 0;
	unsigned int start = 0;
	unsigned int end = a_PCount - 1;
	while (1)
	{
		while (1)
		{
			node->min = box.GetP1(), node->max = box.GetP2();
			// see if this is a leaf
			if (start == end)
			{
				// generate a leaf
				node->start = start;
				node->SetTCount( (end - start) + 1 );
				break;
			}
			// determine best split pos
			const float NA = box.w() * box.d() + box.w() * box.h() + box.d() * box.h();
			const float iNA = 1 / NA;
			float bestcost = 10000000; // (float)((end - start) + 1);
			float bestpos = 0;
			int bestaxis = -1;
			for ( unsigned int axis = 0; axis < 3; axis++ )
			{
				float delta = node->max.cell[axis] - node->min.cell[axis];
				for ( float pos = BVHSTEP; pos < 1.0f; pos += BVHSTEP )
				{
					float split = node->min.cell[axis] + pos * delta;
					// count prims and determine bounding boxes
					int lcount = 0, rcount = 0;
					vector3 bmax( 1000, 1000, 1000 ), bsize( -2000, -2000, -2000 );
					aabb lbox( bmax, bsize ), rbox( bmax, bsize );
					for ( unsigned int prim = start; prim <= end; prim++ )
					{
						SubPrim* p = a_Prim[prim];
						aabb cbox = p->bbox;
						Primitive* pr = p->prim;
						float centre = (cbox.GetP1().cell[axis] + cbox.GetP2().cell[axis]) * 0.5f;
						if (centre < split) 
						{
							for ( int a = 0; a < 3; a++ )
							{
								if (cbox.GetP1().cell[a] < lbox.GetP1().cell[a]) lbox.GetP1().cell[a] = cbox.GetP1().cell[a];
								if (cbox.GetP2().cell[a] > lbox.GetP2().cell[a]) lbox.GetP2().cell[a] = cbox.GetP2().cell[a];
							}
							lcount++;
						}
						else 
						{
							for ( int a = 0; a < 3; a++ )
							{
								if (cbox.GetP1().cell[a] < rbox.GetP1().cell[a]) rbox.GetP1().cell[a] = cbox.GetP1().cell[a];
								if (cbox.GetP2().cell[a] > rbox.GetP2().cell[a]) rbox.GetP2().cell[a] = cbox.GetP2().cell[a];
							}
							rcount++;
						}
					}
					// calculate cost
					float LA = lbox.w() * lbox.d() + lbox.w() * lbox.h() + lbox.d() * lbox.h();
					float RA = rbox.w() * rbox.d() + rbox.w() * rbox.h() + rbox.d() * rbox.h();
					float cost = iNA * (LA * (float)lcount + RA * (float)rcount);
					if ((cost < bestcost) && (lcount > 1) && (rcount > 1))
					{
						bestcost = cost;
						bestaxis = axis;
						bestpos = split;
					}
				}
			}
			// split
			if (bestaxis > -1)
			{
				node->SetLeft( m_PIdx );
				node->SetAxis( bestaxis );
				node->SetTCount( 0 );
				node->SetFirst( 0 );
				unsigned int rlist = end + 1, curr = start;
				{
					while (curr < rlist)
					{
						SubPrim* p = a_Prim[curr];
						Primitive* pr = p->prim;
						aabb cbox = p->bbox;
						float centre = (cbox.GetP1().cell[bestaxis] + cbox.GetP2().cell[bestaxis]) * 0.5f;
						if (centre >= bestpos)
						{
							a_Prim[curr] = a_Prim[--rlist];
							a_Prim[rlist] = p;
						}
						else curr++;
					}
				}
				// recurse
				aabb lbox, rbox;
				CalcBBox( a_Prim, start, rlist - 1, lbox );
				CalcBBox( a_Prim, rlist, end, rbox );
				vector3 lcentre = (lbox.GetP1() + lbox.GetP2()) * 0.5f;
				vector3 rcentre = (rbox.GetP1() + rbox.GetP2()) * 0.5f;
				vector3 delta = rcentre - lcentre;
				unsigned int axis = 0;
				if ((fabs( delta.y ) > fabs( delta.x )) && (fabs( delta.y ) > fabs( delta.z ))) axis = 1;
				if ((fabs( delta.z ) > fabs( delta.x )) && (fabs( delta.z ) > fabs( delta.y ))) axis = 2;
				node->SetAxis( axis );
				node->SetFirst( lcentre.cell[axis] > rcentre.cell[axis]?1:0 );
				BVHNode* lnode = &m_Pool[m_PIdx++], *rnode = &m_Pool[m_PIdx++];
				// push right node
				stack[stackptr].node = rnode;
				stack[stackptr].start = rlist;
				stack[stackptr].end = end;
				stack[stackptr++].box = rbox;
				// traverse left node
				node = lnode;
				end = rlist - 1;
				box = lbox;
				continue;
			}
			else
			{
				// couldn't split, create leaf
				node->start = start;
				node->SetTCount( (end - start) + 1 );
				for ( int i = start; i <= end; i++ ) a_Prim[i]->prim->m_BVHNode = node;
				FinalizeLeaf( node, a_Prim, start, end );
				break;
			}
		}
		// pop node
		if (stackptr == 0) break;
		node = stack[--stackptr].node;
		start = stack[stackptr].start;
		end = stack[stackptr].end;
		box = stack[stackptr].box;
	}
	// done
	// for ( unsigned int i = 0; i < a_PCount; i++ ) m_Prim[i] = a_Prim[i]->prim;
	int leafs = 0, prims = 0, depth = 0, maxprim = 0, nodes = 0;
	float area = 0, tarea = 0;
	UpdateDirMasks( m_Root );
	CountLeafs( m_Root, leafs, prims, maxprim, depth, area, tarea, nodes, 0 );
	float pperleaf = (float)prims / (float)leafs;
	char output[1024];
	sprintf( output, "nodes: %i\nleafs: %i\nprims: %i\npperleaf: %f\nmaxprims: %i\narea: %f\ntop area: %f\ndepth: %i", nodes, leafs, prims, pperleaf, maxprim, area, tarea, depth );
	Log::Message( "---------------------------------------" );
	Log::Message( "results of BVH building stage:" );
	Log::Message( output );
	Log::Message( "---------------------------------------" );
	Log::Message( "leaving BVHierarchy::Build()" );
}

PrimData::PrimData( PrimData* a_PD )
{
	m_Vertex = new vector3[10];
	m_Prim = a_PD->m_Prim;
	m_Verts = a_PD->m_Verts;
	bbox.p1 = a_PD->bbox.p1;
	bbox.p2 = a_PD->bbox.p2;
	for ( int i = 0; i < m_Verts; i++ ) m_Vertex[i] = a_PD->m_Vertex[i];
}

PrimData::PrimData( Primitive* a_Prim )
{
	m_Vertex = new vector3[10];
	Init( a_Prim );
}

void PrimData::Init( const Primitive* a_Prim )
{
	m_Prim = (Primitive*)a_Prim;
	m_Verts = 3;
	bbox.p1 = vector3( 999,999,999 );
	bbox.p2 = vector3( -999, -999, -999 );
	if (a_Prim)
	{
		for ( int i = 0; i < 3; i++ ) m_Vertex[i] = a_Prim->GetVertex( i )->GetPos();
		UpdateBBox();
	}
}

void PrimData::UpdateBBox()
{
	bbox.p1 = vector3( 9999,9999,9999 );
	bbox.p2 = vector3( -9999, -9999, -9999 );
	for ( int i = 0; i < m_Verts; i++ ) 
	{
		vector3 v = m_Vertex[i];
		for ( int a = 0; a < 3; a++ )
		{
			if (v.cell[a] < bbox.p1.cell[a]) bbox.p1.cell[a] = v.cell[a];
			if (v.cell[a] > bbox.p2.cell[a]) bbox.p2.cell[a] = v.cell[a];
		}
	}
}

bool PrimData::RebuildAndClip( aabb& a_Box )
{
	m_Verts = 3;
	for ( int i = 0; i < 3; i++ ) m_Vertex[i] = m_Prim->GetVertex( i )->GetPos();
	bool retval = false;
	retval |= Clip( a_Box.GetP1().x, 1, 0 );
	retval |= Clip( a_Box.GetP2().x, -1, 0 );
	retval |= Clip( a_Box.GetP1().y, 1, 1 );
	retval |= Clip( a_Box.GetP2().y, -1, 1 );
	retval |= Clip( a_Box.GetP1().z, 1, 2 );
	retval |= Clip( a_Box.GetP2().z, -1, 2 );
	if (retval) UpdateBBox();
	return retval;
}

bool PrimData::Clip( float a_Pos, float a_Dir, int a_Axis )
{
	int i, ncount = 0;
	vector3 v1 = m_Vertex[0];
	float d1 = a_Dir * (v1.cell[a_Axis] - a_Pos);
	bool allin = true, allout = true, inside = (d1 >= 0);
	for ( i = 0; i < m_Verts; i++ ) 
	{
		float dist = a_Dir * (m_Vertex[i].cell[a_Axis] - a_Pos);
		if (dist < 0) allin = false; else allout = false;
	}
	if (allin) return false;
	if (allout) { m_Verts = 0; return true; }
	for ( i = 0; i < m_Verts; i++ )
	{
		vector3 v2 = m_Vertex[(i + 1) % m_Verts];
		float d2 = a_Dir * (v2.cell[a_Axis] - a_Pos);
		if (inside && (d2 >= 0)) s_TVert[ncount++] = v2;
		else if ((!inside) && (d2 >= 0))
		{
			float d = d1 / (d1 - d2);
			vector3 vc = v1 + d * (v2 - v1);
			vc.cell[a_Axis] = a_Pos;
			s_TVert[ncount++] = vc;
			s_TVert[ncount++] = v2;
			inside = true;
		}
		else if (inside && (d2 < 0))
		{
			float d = d2 / (d2 - d1);
			vector3 vc = v2 + d * (v1 - v2);
			vc.cell[a_Axis] = a_Pos;
			s_TVert[ncount++] = vc;
			inside = false;
		}
		v1 = v2, d1 = d2;
	}
	int nout = 0;
	for ( i = 0; i < ncount; i++ ) 
	{
		vector3 dist = s_TVert[i] - s_TVert[(i + ncount - 1) % ncount];
		if (dist.Length() > 0.00001f) m_Vertex[nout++] = s_TVert[i];
	}
	m_Verts = nout;
	return true;
}

}; // namespace Raytracer