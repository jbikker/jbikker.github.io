// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#pragma once

namespace Raytracer {

// ray tracer feature toggles
#define REFLECTIONS				// enable reflections
#define REFRACTIONS				// enable refractions
#define INTERPNORMALS			// enable interpolation of normals
#define MAXRECURSION	3		// maximum reflection / refraction recursion
#define SHADOWS					// enable shadows
#define BUMPMAPPING				// enable normal mapping
#define FLOORFOG				// enable floor fog
// #define OUTSIDELIGHTS		// enable if lights can be outside scene bbox
#define SPOTLIGHTS				// support spotlights
// #define MINIMALSHADING		// for performance testing
#define BVHSTEP			0.05f	// good result in little time, 0.025 also good
#define DBVHSTEP		0.2f	// for the dynamic bvh
// #define SINGLEPLANE			// leaf optimization uses only one plane
// #define TILETIMING			// visualize timing
// #define ANTIALIASING			// adaptive anti-aliasing
// #define DIRECTIONALAMBIENT	// wussies directional ambient hack
// #define PHOTONMAPPING		// discrete grid based photon mapping
#define VPLSHADOWS				// spawn shadow rays for the gi calculations
#define BVHPRESPLIT				// subdivide large polygons for better BVH
#define NOSOUND					// disable FMOD
#define MULTIBEAM				// use the special multibeam light source
#define ALTFIRST				// alternative algorithm for first box
// #define SHOWNORMALS			// visualize all surface normals in RGB
// #define GATHERSTATS			// gather ye statistics

// photon mapping parameters
#define PHOTONGRIDX		128		// photon grid x-size
#define PHOTONGRIDY		128		// photon grid y-size
#define PHOTONGRIDZ		128		// photon grid z-size
#define PHOTONYSHIFT	  7		// bits for x
#define PHOTONZSHIFT	 14		// bits for x + y
#define SEARCHRADIUS	1.2f	// overlap of sample nodes
#define MAXPOINTANGLE	0.7f	// dot between two neighbouring points

// multi-threading parameters
#define MAXTHREADS		8		// max number of rendering threads

// array sizes for various objects
#define MAXLIGHTS		512		// maximum lights count
#define MAXMATERIAL		1024

// internals
// #define USESHADERS
#define BRIGHTNESS		1.0f
#define MULTIBEAMDIRS	10

}; // namespace Raytracer

#include "math.h"
#include "stdlib.h"
#include "emmintrin.h"
#include "stdio.h"
#include "fmod.hpp"
#include "fmod_errors.h"
#include "common_math.h"

#define intcast(x) *(int*)&x

inline float Rand( float a_Range ) { return ((float)rand() / RAND_MAX) * a_Range; }
int filesize( FILE* f );
bool isnewer( char* fname1, char* fname2 );

#define MALLOC64(x) _aligned_malloc(x,64) // ((void*)(((unsigned long)(new char[(x) + 64]) + 64) & (0xffffffff - 63)))
#define FREE64(x) _aligned_free(x)
// #define INLINE __forceinline
#define INLINE inline

typedef unsigned long Pixel;
#ifdef _WIN64
typedef unsigned __int64 uint;
typedef __int64 sint;
#else
typedef unsigned int uint;
typedef int sint;
#endif
typedef int int32;
typedef unsigned int uint32;

// ----------------------------------------------------------------
//				  DERIVED DEFINES - DO NOT MODIFY
// ----------------------------------------------------------------

namespace Raytracer {

#ifdef MLRTA
#define TRACEFUNCTION(q)	TraceMLRTA(q)
#else
#define TRACEFUNCTION(q)	TracePacket(q)
#endif
#define PPERTILE		(TILESIZE/4)

#ifndef __INTEL_COMPILER
#define restrict
inline float _mm_cvtss_f32(__m128 v) { float r; _mm_store_ss(&r, v); return r; }
#endif

}; // namespace Raytracer

namespace Raytracer {

#define MIN(a,b) (((a)>(b))?(b):(a))
#define MAX(a,b) (((a)>(b))?(a):(b))
#define EPSILON			0.0001f
#define INFINITY		1000000000
#define _abs(x) abs((int)(x))
#define _fabs	fabsf
#define _cos	cosf
#define _sin	sinf
#define _acos	acosf
#define _floor	floorf
#define _ceil	ceilf
#define _sqrt	sqrtf
#define _pow	powf
#define _exp	expf

#define CROSS(A,B)		vector3(A.y*B.z-A.z*B.y,A.z*B.x-A.x*B.z,A.x*B.y-A.y*B.x)
#define DOT(A,B)		(A.x*B.x+A.y*B.y+A.z*B.z)
#define NORMALIZE(A)	{float l=1/_sqrt(A.x*A.x+A.y*A.y+A.z*A.z);A.x*=l;A.y*=l;A.z*=l;}
#define CNORMALIZE(A)	{float l=1/_sqrt(A.r*A.r+A.g*A.g+A.b*A.b);A.r*=l;A.g*=l;A.b*=l;}
#define LENGTH(A)		(_sqrt(A.x*A.x+A.y*A.y+A.z*A.z))
#define SQRLENGTH(A)	(A.x*A.x+A.y*A.y+A.z*A.z)
#define SQRDISTANCE(A,B) ((A.x-B.x)*(A.x-B.x)+(A.y-B.y)*(A.y-B.y)+(A.z-B.z)*(A.z-B.z))

#define PI				3.141592653589793238462f

#define PREFETCH(x) _mm_prefetch((const char*)(x),_MM_HINT_T0)
#define PREFETCH_ONCE(x) _mm_prefetch((const char*)(x),_MM_HINT_NTA)
#define PREFETCH_WRITE(x) _m_prefetchw((const char*)(x))

#define loadss(mem)			_mm_load_ss((const float*const)(mem))
#define broadcastps(ps)		_mm_shuffle_ps((ps),(ps), 0)
#define broadcastss(ss)		broadcastps(loadss((ss)))
#define swaphalves(a)		_mm_shuffle_ps((a),(a),_MM_SHUFFLE(1,0,3,2))
#define reverse(a)			_mm_shuffle_ps((a),(a),_MM_SHUFFLE(0,1,2,3))
#define spread0(a)			_mm_shuffle_ps(a,a,_MM_SHUFFLE(0,0,0,0))
#define spread1(a)			_mm_shuffle_ps(a,a,_MM_SHUFFLE(1,1,1,1))
#define spread2(a)			_mm_shuffle_ps(a,a,_MM_SHUFFLE(2,2,2,2))
#define spread3(a)			_mm_shuffle_ps(a,a,_MM_SHUFFLE(3,3,3,3))

class Color64
{
public:
	union 
	{
		struct { unsigned short b, g, r, a; };
		struct { unsigned int bg, ra; };
	};
};

class Color
{
public:
	Color() : r( 0.0f ), g( 0.0f ), b( 0.0f ), a( 0.0f ) {};
	Color( float a_R, float a_G, float a_B ) : r( a_R ), g( a_G ), b( a_B ), a( 0.0f ) {};
	void Set( float a_R, float a_G, float a_B ) { r = a_R; g = a_G; b = a_B; a = 0; }
	void operator += ( const Color& a_V ) { r += a_V.r; g += a_V.g; b += a_V.b; }
	void operator += ( Color* a_V ) { r += a_V->r; g += a_V->g; b += a_V->b; }
	void operator -= ( const Color& a_V ) { r -= a_V.r; g -= a_V.g; b -= a_V.b; }
	void operator -= ( Color* a_V ) { r -= a_V->r; g -= a_V->g; b -= a_V->b; }
	void operator *= ( const float f ) { r *= f; g *= f; b *= f; }
	void operator *= ( const Color& a_V ) { r *= a_V.r; g *= a_V.g; b *= a_V.b; }
	void operator *= ( Color* a_V ) { r *= a_V->r; g *= a_V->g; b *= a_V->b; }
	Color operator- () const { return Color( -r, -g, -b ); }
	friend Color operator + ( const Color& v1, const Color& v2 ) { return Color( v1.r + v2.r, v1.g + v2.g, v1.b + v2.b ); }
	friend Color operator - ( const Color& v1, const Color& v2 ) { return Color( v1.r - v2.r, v1.g - v2.g, v1.b - v2.b ); }
	friend Color operator + ( const Color& v1, Color* v2 ) { return Color( v1.r + v2->r, v1.g + v2->g, v1.b + v2->b ); }
	friend Color operator - ( const Color& v1, Color* v2 ) { return Color( v1.r - v2->r, v1.g - v2->g, v1.b - v2->b ); }
	friend Color operator * ( const Color& v, const float f ) { return Color( v.r * f, v.g * f, v.b * f ); }
	friend Color operator * ( const Color& v1, const Color& v2 ) { return Color( v1.r * v2.r, v1.g * v2.g, v1.b * v2.b ); }
	friend Color operator * ( const float f, const Color& v ) { return Color( v.r * f, v.g * f, v.b * f ); }
	friend Color operator / ( const Color& v, const float f ) { float r = 1.0f / f; return Color( v.r * r, v.g * r, v.b * r ); }
	union
	{
		struct { float b, g, r, a; };
		float cell[4];
		__m128 rgba;
		__m128i irgba;
	};
};

}; // namespace Raytracer
