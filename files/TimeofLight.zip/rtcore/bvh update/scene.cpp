// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#include "precomp.h"

using namespace Raytracer;

extern HANDLE waitpmreq[MAXTHREADS];
extern HANDLE gidone[MAXTHREADS];

// -----------------------------------------------------------
// Camera class implementation
// -----------------------------------------------------------

Camera::Camera()
{
	m_Mat.Identity();
}

vector3 Camera::GetPosition() 
{ 
	return m_Pos;
}

vector3 Camera::GetTarget() 
{ 
	return m_Target;
}

void Camera::SetPosition( const vector3& a_Pos ) 
{ 
	m_Pos = a_Pos;
	m_Mat.SetTranslation( a_Pos ); 
}

void Camera::SetTarget( const vector3& a_Target ) 
{ 
	m_Target = a_Target; 
}

void Camera::Forward( float a_Dist )
{
	vector3 zaxis( m_Mat.cell[8], m_Mat.cell[9], m_Mat.cell[10] );
	vector3 pos = GetPosition() + zaxis * a_Dist;
	SetPosition( pos );
}

void Camera::Reverse( float a_Dist )
{
	vector3 zaxis( m_Mat.cell[8], m_Mat.cell[9], m_Mat.cell[10] );
	vector3 pos = GetPosition() - zaxis * a_Dist;
	SetPosition( pos );
}

void Camera::MoveUp( float a_Dist )
{
	vector3 yaxis( m_Mat.cell[4], m_Mat.cell[5], m_Mat.cell[6] );
	vector3 pos = GetPosition() + yaxis * a_Dist;
	SetPosition( pos );
}

void Camera::MoveDown( float a_Dist )
{
	vector3 yaxis( m_Mat.cell[4], m_Mat.cell[5], m_Mat.cell[6] );
	vector3 pos = GetPosition() - yaxis * a_Dist;
	SetPosition( pos );
}

void Camera::MoveLeft( float a_Dist )
{
	vector3 xaxis( m_Mat.cell[0], m_Mat.cell[1], m_Mat.cell[2] );
	vector3 pos = GetPosition() + xaxis * a_Dist;
	SetPosition( pos );
}

void Camera::MoveRight( float a_Dist )
{
	vector3 xaxis( m_Mat.cell[0], m_Mat.cell[1], m_Mat.cell[2] );
	vector3 pos = GetPosition() - xaxis * a_Dist;
	SetPosition( pos );
}

void Camera::ForceUpVector( vector3& a_Vec )
{
	vector3 zaxis( m_Mat.cell[8], m_Mat.cell[9], m_Mat.cell[10] );
	vector3 newx = zaxis.Cross( a_Vec );
	vector3 newy = zaxis.Cross( newx );
	m_Mat.cell[0] = newx.x, m_Mat.cell[1] = newx.y, m_Mat.cell[2] = newx.z;
	m_Mat.cell[4] = newy.x, m_Mat.cell[5] = newy.y, m_Mat.cell[6] = newy.z;
}

void Camera::RotateX( float a_Angle )
{
	if (a_Angle < 0) a_Angle += 360;
	float a = a_Angle * PI / 180;
	vector3 xaxis( m_Mat.cell[0], m_Mat.cell[1], m_Mat.cell[2] );
	vector3 yaxis( m_Mat.cell[4], m_Mat.cell[5], m_Mat.cell[6] );
	vector3 zaxis( m_Mat.cell[8], m_Mat.cell[9], m_Mat.cell[10] );
	vector3 newy = yaxis * cosf( a ) - zaxis * sinf( a );
	vector3 newz = xaxis.Cross( newy );
	m_Mat.cell[4] = newy.x, m_Mat.cell[5] = newy.y, m_Mat.cell[6] = newy.z;
	m_Mat.cell[8] = newz.x, m_Mat.cell[9] = newz.y, m_Mat.cell[10] = newz.z;
	m_Mat.Normalize();
}

void Camera::RotateY( float a_Angle )
{
	if (a_Angle < 0) a_Angle += 360;
	float a = (360 - a_Angle) * PI / 180;
	vector3 xaxis( m_Mat.cell[0], m_Mat.cell[1], m_Mat.cell[2] );
	vector3 yaxis( m_Mat.cell[4], m_Mat.cell[5], m_Mat.cell[6] );
	vector3 zaxis( m_Mat.cell[8], m_Mat.cell[9], m_Mat.cell[10] );
	vector3 newx = xaxis * cosf( a ) - zaxis * sinf( a );
	vector3 newz = newx.Cross( yaxis );
	m_Mat.cell[0] = newx.x, m_Mat.cell[1] = newx.y, m_Mat.cell[2] = newx.z;
	m_Mat.cell[8] = newz.x, m_Mat.cell[9] = newz.y, m_Mat.cell[10] = newz.z;
	m_Mat.Normalize();
}

void Camera::RotateZ( float a_Angle )
{	
	if (a_Angle < 0) a_Angle += 360;
	float a = a_Angle * PI / 180;
	vector3 xaxis( m_Mat.cell[0], m_Mat.cell[1], m_Mat.cell[2] );
	vector3 yaxis( m_Mat.cell[4], m_Mat.cell[5], m_Mat.cell[6] );
	vector3 zaxis( m_Mat.cell[8], m_Mat.cell[9], m_Mat.cell[10] );
	vector3 newx = xaxis * cosf( a ) - yaxis * sinf( a );
	vector3 newy = zaxis.Cross( newx );
	m_Mat.cell[0] = newx.x, m_Mat.cell[1] = newx.y, m_Mat.cell[2] = newx.z;
	m_Mat.cell[4] = newy.x, m_Mat.cell[5] = newy.y, m_Mat.cell[6] = newy.z;
	m_Mat.Normalize();
}

// -----------------------------------------------------------
// Texture class implementation
// -----------------------------------------------------------

Texture::Texture()
{
	m_B32 = 0;
}

void Texture::Init( unsigned int* a_Bitmap, unsigned int a_Width, unsigned int a_Height )
{
	m_B32 = a_Bitmap;
	m_Width = a_Width;
	m_Height = a_Height;
}

void Texture::Init( char* a_File )
{
	m_Name = 0;
	m_B32 = 0;
	FILE* f = fopen( a_File, "rb" );
	if (f)
	{
		// extract width and height from file header
		unsigned char buffer[20];
		fread( buffer, 1, 20, f );
		m_Width = *(buffer + 12) + 256 * *(buffer + 13);
		m_Height = *(buffer + 14) + 256 * *(buffer + 15);
		unsigned int depth = *(buffer + 16);
		unsigned int type = *(buffer + 2);
		m_HMask = m_Width - 1;
		m_VMask = m_Height - 1;
		m_AHMask[0] = m_AHMask[1] = m_AHMask[2] = m_AHMask[3] = m_HMask;
		m_AVMask[0] = m_AVMask[1] = m_AVMask[2] = m_AVMask[3] = m_VMask;
		unsigned int v = 1;
		for ( unsigned int b = 0; b < 16; b++ ) 
		{
			if (m_Width == v) m_HShift = b;
			v *= 2;
		}
		fclose( f );
		if (v == 1)
		{
			Log::Error( "Bad texture size (must be power of 2)", a_File );
		}
		else
		{
			// read pixel data
			m_B32 = (unsigned int*)MALLOC64( m_Width * m_Height * sizeof( unsigned int ) );
			Surface tmp( m_Width, m_Height, (Pixel*)m_B32, m_Width );
			tmp.LoadTGA( a_File, m_Width, m_Height, (Pixel*)m_B32 );
			tmp.SetBuffer( 0 );
			m_Name = new char[strlen( a_File ) + 1];
			strcpy( m_Name, a_File );
		}
	}
	else
	{
		Log::Error( "File not found", a_File );
	}
}

void Texture::ConvertToNormalMap()
{
	if (!m_B32) return;
#if 1
	float scale = 1.0f / 128.0f;
	for ( unsigned int y = 0; y < m_Height; y++ )
	{
		for ( unsigned int x = 0; x < m_Width; x++ )
		{
			Pixel c = m_B32[x + (y << m_HShift)];
			float px = scale * ((float)((c >> 16) & 255) - 128);
			float py = scale * ((float)((c >> 8) & 255) - 128);
			unsigned int nz = (unsigned int)((-px + 1) * 32700);
			unsigned int nx = (unsigned int)((py + 1) * 32700);
			m_B32[x + (y << m_HShift)] = (nx << 16) + nz; // sotre in BG
		}
	}
#else
	unsigned int* temp = new unsigned int[m_Width * m_Height];
	for ( unsigned int y = 0; y < m_Height; y++ )
	{
		for ( unsigned int x = 0; x < m_Width; x++ )
		{
			int x2 = (x + 1) & m_HMask;
			int y2 = (y + 1) & m_VMask;
			Pixel c1 = m_B32[x + (y << m_HShift)];
			Pixel c2 = m_B32[x2 + (y << m_HShift)];
			Pixel c3 = m_B32[x + (y2 << m_HShift)];
			float g1 = (float)(((c1 >> 16) & 255) + ((c1 >> 8) & 255) + (c1 & 255));
			float g2 = (float)(((c2 >> 16) & 255) + ((c2 >> 8) & 255) + (c2 & 255));
			float g3 = (float)(((c3 >> 16) & 255) + ((c3 >> 8) & 255) + (c3 & 255));
			vector3 N( g2 - g1, -255, g3 - g1 );
			NORMALIZE( N );
			unsigned int nz = (unsigned int)((N.z + 1) * 32700);
			unsigned int nx = (unsigned int)((N.x + 1) * 32700);
			temp[x + (y << m_HShift)] = (nz << 16) + nx; // sotre in BG
		}
	}
	memcpy( m_B32, temp, m_Width * m_Height * sizeof( Pixel ) );
	delete temp;
#endif
}

void Texture::Combine( Texture* a_Normals )
{
	if ((!m_B32) || (!a_Normals->m_B32))
	{
		Log::Error( "illegal reuse of texture data", m_Name );
		return;
	}
	if (m_B32 == a_Normals->m_B32)
	{
		Log::Error( "illegal use of texture map as normal map", m_Name );
		return;
	}
	m_TN32 = (unsigned int*)MALLOC64( m_Width * 2 * m_Height * sizeof( unsigned int ) );
	unsigned int idx = 0;
	for ( unsigned int y = 0; y < m_Height; y++ )
	{
		for ( unsigned int x = 0; x < m_Width; x++ )
		{
			m_TN32[idx++] = m_B32[x + (y << m_HShift)];
			m_TN32[idx++] = a_Normals->m_B32[x + (y << m_HShift)];
		}
	}
	m_HShift += 1;
	FREE64( m_B32 );
	FREE64( a_Normals->m_B32 );
	m_B32 = 0;
	a_Normals->m_B32 = 0;
}

// -----------------------------------------------------------
// Material manager class implementation
// -----------------------------------------------------------

MatManager::MatManager()
{
	m_Mat = new Material*[MAXMATERIAL];
	m_Mat[0] = MManager::NewMaterial();
	m_Mat[0]->SetName( "DEFAULT" );
	m_NrMat = 1;
}

void MatManager::LoadMTL( char* a_File )
{
	Log::Message( "entering MatManager::LoadMTL()" );
	FILE* f = fopen( a_File, "r" );
	if (!f) 
	{
		Log::Error( "can't open material file", a_File );
		return;
	}
	unsigned int curmat = 0;
	char buffer[256], cmd[128];
	while (!feof( f ))
	{
		fgets( buffer, 250, f );
		sscanf( buffer, "%s", cmd );
		if (!_stricmp( cmd, "newmtl" ))
		{
			curmat = m_NrMat++;
			m_Mat[curmat] = MManager::NewMaterial();
			char matname[128];
			sscanf( buffer + strlen( cmd ), "%s", matname );
			m_Mat[curmat]->Init();
			m_Mat[curmat]->SetName( matname );
			Log::Message( matname );
		}
		if (!_stricmp( cmd, "Ka" ))
		{
			float r, g, b;
			sscanf( buffer + 3, "%f %f %f", &r, &g, &b );
			Color c( r, g, b );
			m_Mat[curmat]->SetAmbient( c );
		}
		if (!_stricmp( cmd, "Kd" ))
		{
			float r, g, b;
			sscanf( buffer + 3, "%f %f %f", &r, &g, &b );
			Color c( r, g, b );
			m_Mat[curmat]->SetDiffuse( c );
		}
		if (!_stricmp( cmd, "Em" ))
		{
			float r, g, b;
			sscanf( buffer + 3, "%f %f %f", &r, &g, &b );
			Color c( r, g, b );
			m_Mat[curmat]->SetEmissive( c );
		}
		if (!_stricmp( cmd, "Ks" ))
		{
			float r, g, b;
			sscanf( buffer + 3, "%f %f %f", &r, &g, &b );
			Color c( r, g, b );
			m_Mat[curmat]->SetSpecular( c );
		}
		if (!_stricmp( cmd, "d" ))
		{
			float a;
			sscanf( buffer + 2, "%f", &a );
			m_Mat[curmat]->SetRefraction( 1 - a );
			m_Mat[curmat]->SetMinReflection( 0.2f );
			m_Mat[curmat]->SetMaxReflection( 1.3f );
		}
		if (!_stricmp( cmd, "map_Kd" ))
		{
			char tname[128];
			char fname[256];
			tname[0] = fname[0] = 0;
			sscanf( buffer + 7, "%s", tname );
			if (tname[0])
			{
				strcpy( fname, "textures/" );
				strcat( fname, tname );
				Texture* t = MManager::FindTexture( fname );
				if (!t)
				{
					t = MManager::NewTexture();
					t->Init( fname );
				}
				if (t->GetBitmap()) m_Mat[curmat]->SetTexture( t );
							   else m_Mat[curmat]->SetTexture( 0 );
			}
		}
	#ifdef BUMPMAPPING
		if (!_stricmp( cmd, "map_bump" ))
		{
			char tname[128];
			char fname[256];
			tname[0] = fname[0] = 0;
			sscanf( buffer + 9, "%s", tname );
			if (tname[0])
			{
				strcpy( fname, "textures/" );
				strcat( fname, tname );
				Texture* t = MManager::FindTexture( fname );
				if (!t)
				{
					t = MManager::NewTexture();
					t->Init( fname );
					t->ConvertToNormalMap();
				}
				if (t->GetBitmap()) m_Mat[curmat]->SetBumpMap( t );
							   else m_Mat[curmat]->SetBumpMap( 0 );
			}
		}
	#endif
	}
#ifdef BUMPMAPPING
	// check materials for bad combinations
	for ( unsigned int i = 0; i < m_NrMat; i++ )
	{
		Material* mat = m_Mat[i];
		if ((mat->GetTexture()) && (!mat->GetBumpMap()))
		{
			if (!mat->GetTexture()->GetBitmap())
			{
				Log::Error( "Texture without bump used with bump elsewhere", (char*)mat->GetName() );
			}
		}
	}
	Finalize();
#endif
	for ( unsigned int i = 0; i < m_NrMat; i++ )
	{
		Material* mat = m_Mat[i];
		Color col( 0, 0, 0 );
		if (mat->GetTexture())
		{
			Pixel* src = (Pixel*)mat->GetTexture()->GetBitmap();
			if (!src) src = (Pixel*)mat->GetTexture()->GetCombined();
			Pixel c = src[0]; // do a better estimate later
			const int red = (c >> 16) & 255, green = (c >> 8) & 255, blue = c & 255;
			col = Color( (float)red / 255, (float)green / 255, (float)blue / 255 );
		}
		else col = mat->GetAmbient();	
		mat->SetPhotonColor( col.rgba );
	}
	Log::Message( "leaving MatManager::LoadMTL()" );
}

#ifdef BUMPMAPPING
void MatManager::Finalize()
{
	Log::Message( "entering MatManager::Finalize()" );
	for ( unsigned int i = 0; i < m_NrMat; i++ )
	{
		Material* m = m_Mat[i];
		Texture* t = (Texture*)m->GetTexture();
		Texture* b = (Texture*)m->GetBumpMap();
		if (t && b)
		{
			if (t->m_B32 && b->m_B32)
			{
				if ((t->GetWidth() != b->GetWidth()) || (t->GetHeight() != b->GetHeight()))
					Log::Error( "Bump/texture size mismatch", (char*)t->GetName() );
				else
					((Texture*)m->GetTexture())->Combine( (Texture*)m->GetBumpMap() );
			}
		}
	}
	Log::Message( "leaving MatManager::Finalize()" );
}
#endif

Material* MatManager::GetMaterial( char* a_Name )
{
	for ( unsigned int i = 0; i < m_NrMat; i++ )
		if (!_stricmp( m_Mat[i]->GetName(), a_Name )) return m_Mat[i];
	Log::Write( "Can't find material", a_Name );
	return m_Mat[0];
}

// -----------------------------------------------------------
// Material class implementation
// -----------------------------------------------------------

Material::Material()
{
}

Material::~Material()
{
	delete m_Name;
}

void Material::Init()
{
	m_ReflLo = m_ReflHi = 0;
	m_Refr = m_DRefl = 0;
	m_ReflLo4 = m_ReflHi4 = _mm_set_ps1( 1.0f );
	SetRefrIndex( 1.0f );
	m_DRSize = 0.2f;
	m_Texture = 0;
	m_UScale = 1.0f;
	m_VScale = 1.0f;
	m_Name = new char[64];
	SetSpecular( Color( 0, 0, 0 ) );
	SetAmbient( Color( 0.2f, 0.2f, 0.2f ) );
	SetDiffuse( Color( 0.8f, 0.8f, 0.8f ) );
	SetEmissive( Color( 0, 0, 0 ) );
	m_Bumpmap = 0;
}

void Material::SetUVScale( const float a_UScale, const float a_VScale )
{ 
	m_UScale = a_UScale; 
	m_VScale = a_VScale; 
	m_RUScale = 1.0f / a_UScale;
	m_RVScale = 1.0f / a_VScale;
}

void Material::SetAmbient( const Color& a_Ambient )
{
	m_Ambient = a_Ambient;
	m_ARed4 = _mm_set_ps1( m_Ambient.r );
	m_AGreen4 = _mm_set_ps1( m_Ambient.g );
	m_ABlue4 = _mm_set_ps1( m_Ambient.b );
}

void Material::SetDiffuse( const Color& a_Diffuse )
{
	m_Diff = a_Diffuse;
	m_DRed4 = _mm_set_ps1( m_Diff.r );
	m_DGreen4 = _mm_set_ps1( m_Diff.g );
	m_DBlue4 = _mm_set_ps1( m_Diff.b );
	if ((m_Diff.r == 0) && (m_Diff.g == 0) && (m_Diff.b == 0)) 
	{
		m_DMask = _mm_setzero_ps(); 
	}
	else 
	{	
		__m128 dummy = _mm_set_ps1( 0 );
		m_DMask = _mm_cmpeq_ps( dummy, dummy );
	}
}

void Material::SetSpecular( const Color& a_Specular )
{
	m_Spec = a_Specular;
	m_SRed4 = _mm_set_ps1( m_Spec.r );
	m_SGreen4 = _mm_set_ps1( m_Spec.g );
	m_SBlue4 = _mm_set_ps1( m_Spec.b );
	if ((m_Spec.r == 0) && (m_Spec.g == 0) && (m_Spec.b == 0)) 
	{
		m_SMask = _mm_setzero_ps(); 
	}
	else 
	{	
		__m128 dummy = _mm_set_ps1( 0 );
		m_SMask = _mm_cmpeq_ps( dummy, dummy );
	}
}

void Material::SetEmissive( const Color& a_Emissive )
{
	m_Emis = a_Emissive;
	m_ERed4 = _mm_set_ps1( m_Emis.r * 256.0f );
	m_EGreen4 = _mm_set_ps1( m_Emis.g * 256.0f );
	m_EBlue4 = _mm_set_ps1( m_Emis.b * 256.0f );
}

void Material::SetName( char* a_Name ) 
{ 
	strcpy( m_Name, a_Name ); 
}

// -----------------------------------------------------------
// Primitive methods
// -----------------------------------------------------------

void Primitive::Init( Vertex* a_V1, Vertex* a_V2, Vertex* a_V3 )
{
	// m_Material = 0;
	m_Vertex[0] = a_V1, m_Vertex[1] = a_V2,	m_Vertex[2] = a_V3;
	// calculate normal
	vector3 c = a_V2->GetPos() - a_V1->GetPos();
	vector3 b = a_V3->GetPos() - a_V1->GetPos();
	m_N = b.Cross( c );
	m_N.Normalize();
	CalcTangents();
}

void Primitive::CalcTangents()
{
	const Vertex* vert0 = m_Vertex[0], *vert1 = m_Vertex[1], *vert2 = m_Vertex[2];
	const vector3 dp1 = vert1->m_Pos - vert0->m_Pos, dp2 = vert2->m_Pos - vert0->m_Pos;
	const float du1 = vert1->m_U - vert0->m_U, dv1 = vert1->m_V - vert0->m_V;
	if ((du1 != 0) || (dv1 != 0))
	{
		if (fabs( dv1 ) < EPSILON) 
		{
			if (du1 != 0) m_T = dp1 * (1.0f / du1);
		}
		else
		{
			const float du2 = vert2->m_U - vert0->m_U, dv2 = vert2->m_V - vert0->m_V;
			m_T = (dv1 * dp2 - dv2 * dp1) / (dv1 * du2 - dv2 * du1);
		}
		m_B = m_N.Cross( m_T );
		NORMALIZE( m_T );
		NORMALIZE( m_B );
		const vector3 NT = m_T.Cross( m_B );
		int major = 0;
		if (fabs( m_N.cell[1] ) > fabs( m_N.cell[major] )) major = 1;
		if (fabs( m_N.cell[2] ) > fabs( m_N.cell[major] )) major = 2;
		if (m_N.cell[major] > 0) m_B *= -1;
	}
}

void Primitive::CalcBBox( aabb& a_Box )
{
	a_Box.GetP1() = a_Box.GetP2() = m_Vertex[0]->GetPos();
	vector3& p1 = a_Box.GetP1(), &p2 = a_Box.GetP2();
	for ( int v = 1; v < 3; v++ )
	{
		vector3 p = m_Vertex[v]->GetPos();
		p1[0] = (p.cell[0] < p1[0])?p.cell[0]:p1[0];
		p2[0] = (p.cell[0] > p2[0])?p.cell[0]:p2[0];
		p1[1] = (p.cell[1] < p1[1])?p.cell[1]:p1[1];
		p2[1] = (p.cell[1] > p2[1])?p.cell[1]:p2[1];
		p1[2] = (p.cell[2] < p1[2])?p.cell[2]:p1[2];
		p2[2] = (p.cell[2] > p2[2])?p.cell[2]:p2[2];
	}
}

aabb Primitive::CalcBBox()
{
	aabb retval;
	retval.GetP1() = retval.GetP2() = m_Vertex[0]->GetPos();
	vector3& p1 = retval.GetP1(), &p2 = retval.GetP2();
	for ( int v = 1; v < 3; v++ )
	{
		vector3 p = m_Vertex[v]->GetPos();
		p1[0] = (p.cell[0] < p1[0])?p.cell[0]:p1[0];
		p2[0] = (p.cell[0] > p2[0])?p.cell[0]:p2[0];
		p1[1] = (p.cell[1] < p1[1])?p.cell[1]:p1[1];
		p2[1] = (p.cell[1] > p2[1])?p.cell[1]:p2[1];
		p1[2] = (p.cell[2] < p1[2])?p.cell[2]:p1[2];
		p2[2] = (p.cell[2] > p2[2])?p.cell[2]:p2[2];
	}
	return retval;
}

Primitive::~Primitive()
{
}

// -----------------------------------------------------------
// Vertex class implementation
// -----------------------------------------------------------
void Vertex::Transform( matrix& a_Mat, const vector3& a_Orig, const vector3& a_ONormal )
{
	m_Pos = a_Mat.Transform( a_Orig );
	matrix transform = a_Mat;
	transform.SetTranslation( vector3( 0, 0, 0 ) );
	m_Normal = a_Mat.Transform( a_ONormal );
}

// -----------------------------------------------------------
// Light class implementation
// -----------------------------------------------------------

void Light::Init( unsigned int a_Idx, char* a_Name, vector3& a_Pos, Color& a_Diffuse, Color& a_Specular, float a_Radius )
{
	m_Pos = a_Pos;
	m_Index = a_Idx;
	SetDiffuse( a_Diffuse );
	SetSpecular( a_Specular );
	m_Radius = a_Radius;
	m_RRadius = 1.0f / a_Radius;
	m_Radius4 = _mm_set_ps1( m_Radius );
	m_RRadius4 = _mm_set_ps1( m_RRadius );
	m_Shadows = 0;
	cx[0] = cx[1] = cx[2] = cx[3] = m_Pos.x;
	cy[0] = cy[1] = cy[2] = cy[3] = m_Pos.y;
	cz[0] = cz[1] = cz[2] = cz[3] = m_Pos.z;
	m_Name = new char[strlen( a_Name ) + 1];
	strcpy( m_Name, a_Name );
	vector3 d( 0, -1, 0 );
	SetDirection( d );
	float w = -2, w2 = -1.5f;
	SetWidth( w ); // ominlight, accept all directions
	SetSpotSize( w2 );
	m_Type = 0;
	m_Active = true;
}

void Light::Init( unsigned int a_Idx, char* a_Name, vector3& a_P1, vector3& a_P2, vector3& a_P3, Color& a_Diffuse, Color& a_Specular, float a_Radius )
{
	m_Index = a_Idx;
	SetDiffuse( a_Diffuse );
	SetSpecular( a_Specular );
	SetRadius( a_Radius );
	cx[0] = cx[1] = cx[2] = cx[3] = m_Pos.x;
	cy[0] = cy[1] = cy[2] = cy[3] = m_Pos.y;
	cz[0] = cz[1] = cz[2] = cz[3] = m_Pos.z;
	m_Name = new char[strlen( a_Name ) + 1];
	strcpy( m_Name, a_Name );
	vector3 d( 0, -1, 0 );
	SetDirection( d );
	float w = -2, w2 = -1.5f;
	SetWidth( w ); // ominlight, accept all directions
	SetSpotSize( w2 );
	m_Type = 0;
	m_Active = true;
}

void Light::SetRadius( const float a_Radius )
{
	m_Radius = a_Radius;
	m_RRadius = 1.0f / a_Radius;
	m_Radius4 = _mm_set_ps1( m_Radius );
	m_RRadius4 = _mm_set_ps1( m_RRadius );
}

void Light::SetPos( vector3& a_Pos )
{
	m_Pos = a_Pos;
	cx[0] = cx[1] = cx[2] = cx[3] = m_Pos.x;
	cy[0] = cy[1] = cy[2] = cy[3] = m_Pos.y;
	cz[0] = cz[1] = cz[2] = cz[3] = m_Pos.z;
}

void Light::SetDirection( vector3& a_Dir )
{
	m_Dir = a_Dir;
	dx[0] = dx[1] = dx[2] = dx[3] = m_Dir.x;
	dy[0] = dy[1] = dy[2] = dy[3] = m_Dir.y;
	dz[0] = dz[1] = dz[2] = dz[3] = m_Dir.z;
}

#ifdef MULTIBEAM
void Light::SetDirection( unsigned int a_Idx, vector3& a_Dir )
{
	m_BDir[a_Idx] = a_Dir;
	mdx4[a_Idx] = _mm_set_ps1( a_Dir.x );
	mdy4[a_Idx] = _mm_set_ps1( a_Dir.y );
	mdz4[a_Idx] = _mm_set_ps1( a_Dir.z );
}
#endif

void Light::SetDiffuse( Color& a_Diffuse )
{
	m_Diffuse = a_Diffuse;
	m_DiffR4 = _mm_set_ps1( m_Diffuse.r );
	m_DiffG4 = _mm_set_ps1( m_Diffuse.g );
	m_DiffB4 = _mm_set_ps1( m_Diffuse.b );
}

void Light::SetSpecular( Color& a_Specular )
{
	m_Specular = a_Specular;
	m_SpecR4 = _mm_set_ps1( m_Specular.r );
	m_SpecG4 = _mm_set_ps1( m_Specular.g );
	m_SpecB4 = _mm_set_ps1( m_Specular.b );
}

// -----------------------------------------------------------
// Sound class implementation
// -----------------------------------------------------------
Sound::~Sound()
{
#ifndef NOSOUND
	FMOD_RESULT result;
	result = m_System->release();
	if(result != FMOD_OK)
	{
		WriteLogLine("Release", result);
	}
#endif
}

void Sound::Init()
{
#ifndef NOSOUND
	FMOD_RESULT result;
	result = FMOD::System_Create(&m_System);		// Create the main system object.
	if(result != FMOD_OK)
	{
		WriteLogLine("Create", result);
	}

	result = m_System->init(100, FMOD_INIT_NORMAL, 0);	// Initialize FMOD.
	if(result != FMOD_OK)
	{
		WriteLogLine("Init", result);
	}
#endif
}

void Sound::Update()
{
#ifndef NOSOUND
	FMOD_RESULT result;
	result = m_System->update();
	if(result != FMOD_OK)
	{
		WriteLogLine("Update", result);
	}
#endif
}

FMOD::Sound* Sound::LoadSound( const char* file, bool stream, FMOD_MODE mode )
{
#ifndef NOSOUND
	FMOD_RESULT result;
	FMOD::Sound * sound;
	if(stream) result = m_System->createStream(file, mode, 0, &sound);
		  else result = m_System->createSound(file, mode, 0, &sound);
	if(result != FMOD_OK) WriteLogLine("Load", result);
	return sound;
#else
	return 0;
#endif
}

FMOD::Sound* Sound::LoadSound( const char* file, bool stream )
{
	return LoadSound(file, stream, FMOD_DEFAULT);
}

FMOD::Channel* Sound::PlaySound( FMOD::Sound* sound, bool paused )
{
#ifndef NOSOUND
	FMOD_RESULT result;
	FMOD::Channel *channel;
	result = m_System->playSound(FMOD_CHANNEL_FREE, sound, paused, &channel);
	if(result != FMOD_OK)
	{
		WriteLogLine("play", result);
	}
	return channel;
#else
	return 0;
#endif
}

void Sound::WriteLogLine( const char* line, FMOD_RESULT msg )
{
	FILE* f = fopen( "sounddebug.txt", "a" );
	fprintf( f, "%s::%s\n", line, FMOD_ErrorString(msg));
	fclose( f );
}

// -----------------------------------------------------------
// Scene class implementation
// -----------------------------------------------------------
Scene::Scene()
{
	m_Primitives = 0;
	m_MaxPrims = 0;
	m_Primitive = 0;
	m_DPrimitive = 0;
	m_DPrims = 0;
	m_State = 0;
	vector3 a( 0, 0, 0 );
	m_Extends = aabb( a, a );
	m_MatMan = new MatManager();
	m_Scale = 1.0f;
}

Scene::~Scene()
{
	delete m_Primitive;
	delete m_DPrimitive;
}

void Scene::GetCamRot( float& a_XRot, float& a_YRot, float& a_ZRot )
{
	a_XRot = m_CamRot.x;
	a_YRot = m_CamRot.y;
	a_ZRot = m_CamRot.z;
}

void Scene::RemoveLight( Light* a_Light )
{
	for ( unsigned int i = 0; i < m_Lights; i++ )
	{
		if (m_Light[i] == a_Light)
		{
			for ( unsigned int j = i + 1; j < m_Lights; j++ ) m_Light[j - 1] = m_Light[j];
			m_Lights--;
			break;
		}
	}
}

void Scene::ConvertOBJ( char* filename, vector3& a_Pos, float a_Scale )
{
	Log::Message( "entering Scene::ConvertOBJ()" );
	// count faces in file
	FILE* f = fopen( filename, "r" );
	if (!f)
	{
		Log::Error( "Scene not found", filename );
		return;
	}
	unsigned int fcount = 0, ncount = 0, uvcount = 0, vcount = 0;
	char buffer[256], cmd[256];
	while (1)
	{
		fgets( buffer, 250, f );
		if (feof( f )) break;
		// sscanf( buffer, "%s", cmd );
		if (buffer[0] == 'v')
		{
			if (buffer[1] == ' ') vcount++;
			else if (buffer[1] == 't') uvcount++;
			else if (buffer[1] == 'n') ncount++;
		}
		else if ((buffer[0] == 'f') && (buffer[1] == ' ')) fcount++;
	}
	fclose( f );
	// create output file
	char ofname[128];
	strcpy( ofname, filename );
	char* ext = strstr( ofname, ".obj" );
	strcpy( ext, ".bin" );
	FILE* o = fopen( ofname, "wb" );
	fwrite( &fcount, 4, 1, o );
	fwrite( &vcount, 4, 1, o );
	fwrite( &ncount, 4, 1, o );
	fwrite( &uvcount, 4, 1, o );
	// start conversion
	f = fopen( filename, "r" );
	while (1)
	{
		fgets( buffer, 250, f );
		if (feof( f )) break;
		unsigned char id;
		switch (buffer[0])
		{
		case 'f':
			{
				// read face data
				unsigned int vnr[9];
				unsigned int vars = sscanf( buffer + 2, "%i/%i/%i %i/%i/%i %i/%i/%i", 
					&vnr[0], &vnr[1], &vnr[2], &vnr[3], &vnr[4], &vnr[5], &vnr[6], &vnr[7], &vnr[8] );
				if (vars < 9) 
				{
					vars = sscanf( buffer + 2, "%i/%i %i/%i %i/%i", &vnr[0], &vnr[2], &vnr[3], &vnr[5], &vnr[6], &vnr[8] );
					if (vars < 6)
					{
						sscanf( buffer + 2, "%i//%i %i//%i %i//%i", &vnr[0], &vnr[2], &vnr[3], &vnr[5], &vnr[6], &vnr[8] );
					}
				}
				// write face data
				id = ID_FACE; 
				fwrite( &id, 1, 1, o );
				fwrite( vnr, 4, 9, o );
				break;
			}
		case 'g':
			// we can ignore this
			break;
		case 'm':
			if (!_strnicmp( buffer, "mtllib", 6 ))
			{
				char libname[128];
				sscanf( buffer + 7, "%s", libname );
				char fullname[256];
				strcpy( fullname, "meshes/" );
				strcat( fullname, libname );
				id = ID_MTLLIB;
				fwrite( &id, 1, 1, o );
				unsigned int len = strlen( fullname ) + 1;
				fwrite( &len, 4, 1, o );
				fwrite( fullname, 1, len, o );
			}
			break;
		case 'u':
			if (!_strnicmp( buffer, "usemtl", 6 ))
			{
				char matname[128];
				sscanf( buffer + 7, "%s", matname );
				unsigned int len = strlen( matname ) + 1;
				id = ID_USEMTL;
				fwrite( &id, 1, 1, o );
				fwrite( &len, 4, 1, o );
				fwrite( matname, 1, len, o );
			}
			break;
		case 'v':
			{
				if (buffer[1] == ' ')
				{
					// vertex, add to list
					float x, y, z;
					sscanf( buffer, "%s %f %f %f", cmd, &x, &y, &z );
					x *= a_Scale, y *= a_Scale, z *= a_Scale;
					vector3 pos = vector3( x, y, z ) + a_Pos;
					id = ID_VERTEX;
					fwrite( &id, 1, 1, o );
					fwrite( &pos, sizeof( vector3 ), 1, o );
					for ( unsigned int a = 0; a < 3; a++ )
					{
						if (pos.cell[a] < m_Extends.GetP1().cell[a]) m_Extends.GetP1().cell[a] = pos.cell[a];
						if (pos.cell[a] > m_Extends.GetP2().cell[a]) m_Extends.GetP2().cell[a] = pos.cell[a];
					}
				}
				else if (buffer[1] == 't')
				{
					// texture coordinate
					float u, v;
					sscanf( buffer, "%s %f %f", cmd, &u, &v );
					id = ID_UV;
					fwrite( &id, 1, 1, o );
					fwrite( &u, 4, 1, o );
					fwrite( &v, 4, 1, o );
				}
				else if (buffer[1] == 'n')
				{
					// vertex normal
					float x, y, z;
					sscanf( buffer, "%s %f %f %f", cmd, &x, &y, &z );
					id = ID_NORMAL;
					fwrite( &id, 1, 1, o );
					fwrite( &x, 4, 1, o );
					fwrite( &y, 4, 1, o );
					fwrite( &z, 4, 1, o );
				}
			}
		break;
		default:
			break;
		}
	}
	unsigned int id = ID_EOF;
	fwrite( &id, 1, 1, o );
	fwrite( &m_Extends, 1, sizeof( m_Extends ), o );
	fclose( f );
	fclose( o );
	Log::Message( "leaving Scene::ConvertOBJ()" );
}

void Scene::LoadBIN( char* filename, Material* a_Material )
{
	Log::Message( "entering Scene::LoadBIN()" );
	// count faces in file
	FILE* f = fopen( filename, "rb" );
	if (!f)
	{
		Log::Error( "Scene not found", filename );
		return;
	}
	unsigned int fcount = 0, ncount = 0, uvcount = 0, vcount = 0;
	fread( &fcount, 4, 1, f );
	fread( &vcount, 4, 1, f );
	fread( &ncount, 4, 1, f );
	fread( &uvcount, 4, 1, f );
	if (!m_Primitive)
	{
		MManager::Init( fcount + 32 );
		m_MaxPrims = fcount + 32;
		m_MaxSPrims = fcount * 2 + 32;
		m_Primitive = new Primitive*[fcount + 32];
		m_SPrim = new SubPrim*[m_MaxSPrims];
		SubPrim* sprims = (SubPrim*)MALLOC64( m_MaxSPrims * sizeof( SubPrim ) );
		for ( unsigned int i = 0; i < m_MaxSPrims; i++ ) m_SPrim[i] = &sprims[i];
	}
	Material* curmat = a_Material;
	unsigned int verts = 0, uvs = 0, normals = 0;
	// allocate arrays
	vector3* vert = new vector3[vcount];
	vector3* norm = new vector3[ncount];
	float* tu = new float[uvcount];
	float* tv = new float[uvcount];
	Vertex* vertex = (Vertex*)MALLOC64( (fcount * 3 + 4) * sizeof( Vertex ) );
	unsigned int vidx = 0;
	// load data
	unsigned int primidx = 0;
	bool endoffile = false;
	while (1)
	{	
		if (endoffile) break;
		unsigned char id;
		fread( &id, 1, 1, f );
		if (id != 5)
		{
			int w = 2347928374;
		}
		switch (id)
		{
		case ID_FACE:
			// face
			{
				Vertex* v[3];
				float cu[3], cv[3];
				const Texture* t = curmat->GetTexture();
				unsigned int vnr[9];
				fread( vnr, 4, 9, f );
				for ( unsigned int i = 0; i < 3; i++ )
				{
					v[i] = &vertex[vidx++];
					if (t)
					{
						cu[i] = tu[vnr[i * 3 + 1] - 1];
						cv[i] = tv[vnr[i * 3 + 1] - 1];
					}
					v[i]->SetNormal( norm[vnr[i * 3 + 2] - 1] );
					v[i]->SetPos( vert[vnr[i * 3] - 1] );
				}
				Primitive* p = m_Primitive[m_Primitives] = MManager::NewPrimitive();
				if (t)
				{
					while ((cu[0] < 0) || (cu[1] < 0) || (cu[2] < 0)) cu[0] += 8, cu[1] += 8, cu[2] += 8;
					while ((cv[0] < 0) || (cv[1] < 0) || (cv[2] < 0)) cv[0] += 8, cv[1] += 8, cv[2] += 8;
					v[0]->SetUV( cu[0] * t->m_Width, cv[0] * t->m_Height );
					v[1]->SetUV( cu[1] * t->m_Width, cv[1] * t->m_Height );
					v[2]->SetUV( cu[2] * t->m_Width, cv[2] * t->m_Height );
				}
				p->Init( v[0], v[1], v[2] );
				m_Primitive[m_Primitives++]->SetMaterial( curmat );
				if (m_Primitives == m_MaxPrims) Log::Error( "Not enough room for all polygons, check allocate command", "Fatal error" );
				primidx++;
			}
			break;
		case ID_MTLLIB:
			{
				unsigned int len;
				char fullname[256];
				fread( &len, 4, 1, f );
				fread( fullname, 1, len, f );
				m_MatMan->LoadMTL( fullname );
			}
			break;
		case ID_USEMTL:
			{
				char matname[128];
				unsigned int len;
				fread( &len, 4, 1, f );
				fread( matname, 1, len, f );
				curmat = m_MatMan->GetMaterial( matname );
			}
			break;
		case ID_VERTEX:
			{
				// vertex, add to list
				vector3 pos;
				fread( &pos, sizeof( vector3 ), 1, f );
				vert[verts++] = pos;
			}
			break;
		case ID_UV:
			{
				// texture coordinate
				float u, v;
				fread( &u, 4, 1, f );
				fread( &v, 4, 1, f );
				tu[uvs] = u, tv[uvs++] = -v; // prevent negative uv's
			}
			break;
		case ID_NORMAL:
			{
				// vertex normal
				float x, y, z;
				fread( &x, 4, 1, f );
				fread( &y, 4, 1, f );
				fread( &z, 4, 1, f );
				norm[normals++] = vector3( -x, -y, -z );
			}
			break;
		case ID_EOF:
			endoffile = true;
			break;
		default:
			break;
		}
	}
	fread( &m_Extends, 1, sizeof( m_Extends ), f );
	fclose( f );
	delete vert;
	delete norm;
	delete tu;
	delete tv;
	Log::Message( "leaving Scene::LoadBIN()" );
}

void Scene::LoadOBJ( char* filename, Material* a_Material, vector3& a_Pos, float a_Scale )
{
	Log::Message( "entering Scene::LoadOBJ()" );
	// count faces in file
	FILE* f = fopen( filename, "r" );
	if (!f)
	{
		Log::Error( "Scene not found", filename );
		return;
	}
	unsigned int fcount = 0, ncount = 0, uvcount = 0, vcount = 0;
	char buffer[256], cmd[256], objname[256];
	while (1)
	{
		fgets( buffer, 250, f );
		if (feof( f )) break;
		// sscanf( buffer, "%s", cmd );
		if (buffer[0] == 'v')
		{
			if (buffer[1] == ' ') vcount++;
			else if (buffer[1] == 't') uvcount++;
			else if (buffer[1] == 'n') ncount++;
		}
		else if ((buffer[0] == 'f') && (buffer[1] == ' ')) fcount++;
	}
	fclose( f );
	if (!m_Primitive)
	{
		MManager::Init( fcount + 32 );
		m_MaxPrims = fcount + 32;
		m_MaxSPrims = fcount * 2 + 32;
		m_Primitive = new Primitive*[fcount + 32];
		m_SPrim = new SubPrim*[m_MaxSPrims];
		SubPrim* sprims = (SubPrim*)MALLOC64( m_MaxSPrims * sizeof( SubPrim ) );
		for ( unsigned int i = 0; i < m_MaxSPrims; i++ ) m_SPrim[i] = &sprims[i];
	}
	f = fopen( filename, "r" );
	Material* curmat = a_Material;
	unsigned int verts = 0, uvs = 0, normals = 0;
	// allocate arrays
	vector3* vert = new vector3[vcount];
	vector3* norm = new vector3[ncount];
	float* tu = new float[uvcount];
	float* tv = new float[uvcount];
	Vertex* vertex = (Vertex*)MALLOC64( (fcount * 3 + 4) * sizeof( Vertex ) );
	unsigned int vidx = 0;
	char currobject[256];
	strcpy( currobject, "none" );
	// load data
	unsigned int primidx = 0;
	while (1)
	{
		fgets( buffer, 250, f );
		if (feof( f )) break;
		switch (buffer[0])
		{
		case 'v':
		{
			if (buffer[1] == ' ')
			{
				// vertex, add to list
				float x, y, z;
				sscanf( buffer, "%s %f %f %f", cmd, &x, &y, &z );
				x *= a_Scale, y *= a_Scale, z *= a_Scale;
				vector3 pos = vector3( x, y, z ) + a_Pos;
				vert[verts++] = pos;
				for ( unsigned int a = 0; a < 3; a++ )
				{
					if (pos.cell[a] < m_Extends.GetP1().cell[a]) m_Extends.GetP1().cell[a] = pos.cell[a];
					if (pos.cell[a] > m_Extends.GetP2().cell[a]) m_Extends.GetP2().cell[a] = pos.cell[a];
				}
			}
			else if (buffer[1] == 't')
			{
				// texture coordinate
				float u, v;
				sscanf( buffer, "%s %f %f", cmd, &u, &v );
				tu[uvs] = u, tv[uvs++] = -v; // prevent negative uv's
			}
			else if (buffer[1] == 'n')
			{
				// vertex normal
				float x, y, z;
				sscanf( buffer, "%s %f %f %f", cmd, &x, &y, &z );
				norm[normals++] = vector3( -x, -y, -z );
			}
		}
		break;
		default:
			break;
		}
	}
	fclose( f );
	f = fopen( filename, "r" );
	while (1)
	{
		fgets( buffer, 250, f );
		if (feof( f )) break;
		switch (buffer[0])
		{
		case 'f':
		{
			// face
			Vertex* v[3];
			float cu[3], cv[3];
			const Texture* t = curmat->GetTexture();
			unsigned int vnr[9];
			unsigned int vars = sscanf( buffer + 2, "%i/%i/%i %i/%i/%i %i/%i/%i", 
				&vnr[0], &vnr[1], &vnr[2], &vnr[3], &vnr[4], &vnr[5], &vnr[6], &vnr[7], &vnr[8] );
			if (vars < 9) 
			{
				vars = sscanf( buffer + 2, "%i/%i %i/%i %i/%i", &vnr[0], &vnr[2], &vnr[3], &vnr[5], &vnr[6], &vnr[8] );
				if (vars < 6)
				{
					sscanf( buffer + 2, "%i//%i %i//%i %i//%i", &vnr[0], &vnr[2], &vnr[3], &vnr[5], &vnr[6], &vnr[8] );
				}
			}
			for ( unsigned int i = 0; i < 3; i++ )
			{
				v[i] = &vertex[vidx++];
				if (t)
				{
					unsigned int vidx = vnr[i * 3 + 1] - 1;
					if (vidx >= uvcount) Log::Error( "Bad UV index", currobject );
					cu[i] = tu[vidx];
					cv[i] = tv[vidx];
					if ((cu[i] < -100) || (cu[i] > 100)) Log::Error( "Bad uv coordinate", currobject );
					if ((cv[i] < -100) || (cv[i] > 100)) Log::Error( "Bad uv coordinate", currobject );
				}
				unsigned int nidx = vnr[i * 3 + 2] - 1, vidx = vnr[i * 3] - 1;
				if (nidx >= normals) Log::Error( "Bad normal index", currobject );
				if (vidx >= vcount) Log::Error( "Bad vertex index", currobject );
				v[i]->SetNormal( norm[nidx] );
				v[i]->SetPos( vert[vidx] );
			}
			Primitive* p = m_Primitive[m_Primitives] = MManager::NewPrimitive();
			if (t)
			{
				while ((cu[0] < 0) || (cu[1] < 0) || (cu[2] < 0)) cu[0] += 8, cu[1] += 8, cu[2] += 8;
				while ((cv[0] < 0) || (cv[1] < 0) || (cv[2] < 0)) cv[0] += 8, cv[1] += 8, cv[2] += 8;
				v[0]->SetUV( cu[0] * t->m_Width, cv[0] * t->m_Height );
				v[1]->SetUV( cu[1] * t->m_Width, cv[1] * t->m_Height );
				v[2]->SetUV( cu[2] * t->m_Width, cv[2] * t->m_Height );
			}
			p->Init( v[0], v[1], v[2] );
			m_Primitive[m_Primitives++]->SetMaterial( curmat );
			if (m_Primitives == m_MaxPrims) Log::Error( "Not enough room for all polygons, check allocate command", "Fatal error" );
			primidx++;
			break;
		}
		case 'g':
			sscanf( buffer + 2, "%s", objname );
			Log::Message( "loading subobject ", objname );
			strcpy( currobject, objname );
			break;
		case 'm':
			if (!_strnicmp( buffer, "mtllib", 6 ))
			{
				char libname[128];
				sscanf( buffer + 7, "%s", libname );
				char fullname[256];
				strcpy( fullname, "meshes/" );
				strcat( fullname, libname );
				m_MatMan->LoadMTL( fullname );
			}
			break;
		case 'u':
			if (!_strnicmp( buffer, "usemtl", 6 ))
			{
				char matname[128];
				sscanf( buffer + 7, "%s", matname );
				curmat = m_MatMan->GetMaterial( matname );
			}
			break;
		default:
			break;
		}
	}
	fclose( f );
	delete vert;
	delete norm;
	delete tu;
	delete tv;
	Log::Message( "leaving Scene::LoadOBJ()" );
}

void Scene::InitSceneState()
{
	Log::Message( "entering Scene::InitSceneState()" );
	// scene initialization
	m_Name = new char[64];
	m_Primitive = 0; // new Primitive*[MAXTRI];
	m_Primitives = 0;
	m_DPrimitive = 0;
	m_DPrims = 0;
	m_Light = new Light*[MAXLIGHTS];
	m_Lights = 0;
	m_Scale = 1;
	m_Fog = false;
	m_Fullscreen = false;
	vector3 p1( 1000, 1000, 1000 );
	vector3 p2( -1000, -1000, -1000 );
	m_Extends = aabb( p1, p2 );
	// default material
	Material* mat1 = MManager::NewMaterial();
	Color grey( 0.8f, 0.8f, 0.8f );
	Color dgrey( 0.4f, 0.4f, 0.4f );
	mat1->SetAmbient( dgrey );
	mat1->SetDiffuse( grey );
	// init the sound
	Sound::Init();
	// prep trees
	m_BVH[0] = new BVHierarchy();
	m_BVH[1] = new BVHierarchy();
	m_BVH[1]->PrepThreadedBuild();
	m_LBVH = new LBVH();
#ifdef PHOTONMAPPING
	m_KdTree = new KdTree();
#endif
	// check object sizes
	unsigned int size1  = sizeof( Primitive );		Log::IntValue( "sizeof( Primitive ) = ", size1 );
	unsigned int size2  = sizeof( Light );			Log::IntValue( "sizeof( Light ) = ", size2 );
	unsigned int size3  = sizeof( Material );		Log::IntValue( "sizeof( Material ) = ", size3 );
	unsigned int size4  = sizeof( Texture );		Log::IntValue( "sizeof( Texture ) = ", size4 );
	unsigned int size5  = sizeof( LNode );			Log::IntValue( "sizeof( LNode ) = ", size5 );
	unsigned int size6  = sizeof( Vertex );			Log::IntValue( "sizeof( Vertex ) = ", size6 );
	unsigned int size7  = sizeof( Color );			Log::IntValue( "sizeof( Color ) = ", size7 );
	unsigned int size8  = sizeof( Color64 );		Log::IntValue( "sizeof( Color64 ) = ", size8 );
	unsigned int size9  = sizeof( LightList );		Log::IntValue( "sizeof( LightList ) = ", size9 );
	unsigned int size10 = sizeof( SubPrim );		Log::IntValue( "sizeof( SubPrim ) = ", size10 );
	unsigned int size11 = sizeof( Camera );			Log::IntValue( "sizeof( Camera ) = ", size11 );
	unsigned int size12 = sizeof( Scene );			Log::IntValue( "sizeof( Scene ) = ", size12 );
	unsigned int size13 = sizeof( MatManager );		Log::IntValue( "sizeof( MatManager ) = ", size13 );
	unsigned int size14 = sizeof( IData );			Log::IntValue( "sizeof( IData ) = ", size14 );
	unsigned int size15 = sizeof( IData1 );			Log::IntValue( "sizeof( IData1 ) = ", size15 );
	unsigned int size16 = sizeof( RayPacket );		Log::IntValue( "sizeof( RayPacket ) = ", size16 );
	unsigned int size17 = sizeof( KDStack );		Log::IntValue( "sizeof( KDStack ) = ", size17 );
	unsigned int size18 = sizeof( LineTracer );		Log::IntValue( "sizeof( LineTracer ) = ", size18 );
	unsigned int size19 = sizeof( MatManager );		Log::IntValue( "sizeof( MatManager ) = ", size19 );
	unsigned int size20 = sizeof( vector3 );		Log::IntValue( "sizeof( vector3 ) = ", size20 );
	Log::Message( "leaving Scene::InitSceneState()" );
}

void Scene::SetFog( float a_Top, Color& a_Color, float a_Density )
{
	m_FogTop4 = _mm_set_ps1( a_Top );
	m_FogTop = a_Top;
	m_FogDensity4 = _mm_set_ps1( a_Density );
	m_FogDensity = a_Density;
	m_FogColor = a_Color;
	m_Fog = true;
}

bool Scene::InitScene()
{
	Log::Message( "entering Scene::InitScene()" );
	InitSceneState();
	Material* mat1 = m_MatMan->GetMaterial( 0 );
	// parse scene description file
	float subdiv = 1;
	vector3 offset( 0, 0, 0 );
	bool camscale = false;
	unsigned int usescene = 0;
	unsigned int curscene = 0;
	m_GI = m_GIcolors = m_GIpoints = false;
	FILE* f = fopen( "scene.txt", "r" );
	char line[256], prm[256];
	PhotonMapper::SetParams( "darts_250.dat", 0.7f, 0.8f, 8.8f );
	while (!feof( f ))
	{
		fgets( line, 255, f );
		if (!_strnicmp( line, "usescene", 8 )) sscanf( line + 9, "%i", &usescene );
		if (!_strnicmp( line, "beginscene", 10 )) sscanf( line + 11, "%i", &curscene );
		if (!_strnicmp( line, "endscene", 8 )) curscene = 0;
		if ((curscene == 0) || (curscene == usescene))
		{
			if (!_strnicmp( line, "enablegi", 8 )) m_GI = true;
			if (!_strnicmp( line, "giparams", 8 ))
			{
				float dist, dot, brightness;
				char dfile[128];
				sscanf( line + 9, "%s %f %f %f", dfile, &dist, &dot, &brightness );
				PhotonMapper::SetParams( dfile, dist, dot, brightness );
			}
			if (!_strnicmp( line, "rebuildgipoints", 15 )) m_GIpoints = true;
			if (!_strnicmp( line, "rebuildgicolors", 15 )) m_GIcolors = true;
			if (!_strnicmp( line, "allocate", 8 ))
			{
				int count, scount;
				int params = sscanf( line + 9, "%i %i", &count, &scount );
				if (params == 1) scount = count * 2;
				MManager::Init( count );
				m_Primitive = new Primitive*[count + 4];
				m_MaxPrims = count;
				m_MaxSPrims = scount;
				m_SPrim = new SubPrim*[scount + 4];
				SubPrim* sprims = (SubPrim*)MALLOC64( scount * sizeof( SubPrim ) );
				for ( int i = 0; i < scount; i++ ) m_SPrim[i] = &sprims[i];
			}
			if (!_strnicmp( line, "fullscreen", 10 )) m_Fullscreen = true;
			if (!_strnicmp( line, "loadobj", 7 ))
			{
				float x, y, z, scale;
				sscanf( line + 8, "%s (%f %f %f) %f", prm, &x, &y, &z, &scale );
				vector3 p( x, y, z );
				if (strstr( prm, ".bin" ))
				{
					LoadBIN( prm, mat1 );
				}
				else
				{
					ConvertOBJ( prm, p, scale );
					LoadOBJ( prm, mat1, p, scale );
				}
				m_Scale = scale;
				char* ext = strstr( prm, ".obj" );
			#ifdef PHOTONMAPPING
				if (ext) 
				{ 
					bool rebuild = false;
					char orig[128];
					strcpy( orig, prm );
					strcpy( ext, ".kdt" ); 
					FILE* f = fopen( prm, "rb" );
					if (!f) 
					{
						rebuild = true;
						Log::Message( "kd-tree file not found", prm );
					}
					else
					{
						fclose( f );
						if (isnewer( orig, prm )) rebuild = true;
					}
					if (rebuild)
					{
						Log::Message( "kD-tree outdated or missing; rebuilding" );
						char cmd[1024];
						strcpy( cmd, "meshes/kdcompiler " );
						strcpy( ext, ".obj" );
						strcat( cmd, prm );
						WinExec( cmd, SW_SHOWNORMAL ); 
						strcpy( ext, ".kdt" );
					}
					Log::Write( "loading kd-tree from ", prm );
					m_KdTree->Load( prm ); }
			#endif
				if (ext) { *ext = 0; strcpy( m_Name, prm ); }
				else strcpy( m_Name, "noname" );
			}
			if (!_strnicmp( line, "ambient", 7 ))
			{
				float r, g, b;
				sscanf( line + 8, "(%f %f %f)", &r, &g, &b );
				Color c( r, g, b );
				SetAmbient( c );
			}
			if (!_strnicmp( line, "matrefl", 7 ))
			{
				float refllo, reflhi;
				sscanf( line + 8, "%s %f %f", prm, &refllo, &reflhi );
				m_MatMan->GetMaterial( prm )->SetMinReflection( refllo );
				m_MatMan->GetMaterial( prm )->SetMaxReflection( reflhi );
			}
			
			if (!_strnicmp( line, "matdrefl", 8 ))
			{
				float drefl, drsize;
				sscanf( line + 9, "%s %f %f", prm, &drefl, &drsize );
				m_MatMan->GetMaterial( prm )->SetDReflection( drefl );
				m_MatMan->GetMaterial( prm )->SetDReflSize( drsize );
			}
			if (!_strnicmp( line, "matrefr", 7 ))
			{
				float refr, idx;
				sscanf( line + 8, "%s %f %f", prm, &refr, &idx );
				m_MatMan->GetMaterial( prm )->SetRefraction( refr );
				m_MatMan->GetMaterial( prm )->SetRefrIndex( idx );
			}
			if (!_strnicmp( line, "matspec", 7 ))
			{
				float r, g, b;
				sscanf( line + 8, "%s (%f %f %f)", prm, &r, &g, &b );
				Color c( r, g, b );
				m_MatMan->GetMaterial( prm )->SetSpecular( c );
			}
			if (!_strnicmp( line, "matambient", 10 ))
			{
				float r, g, b;
				sscanf( line + 11, "%s (%f %f %f)", prm, &r, &g, &b );
				Color c( r, g, b );
				m_MatMan->GetMaterial( prm )->SetAmbient( c );
			}
			if (!_strnicmp( line, "matdiff", 7 ))
			{
				float r, g, b;
				sscanf( line + 8, "%s (%f %f %f)", prm, &r, &g, &b );
				Color c( r, g, b );
				m_MatMan->GetMaterial( prm )->SetDiffuse( c );
			}
			if (!_strnicmp( line, "shadows", 7 ))
			{
				char name[128];
				sscanf( line + 8, "%s", name );
				Light* l = (Light*)GetLight( name );
				if (l) l->SetShadows( true );
			}
			if (!_strnicmp( line, "quality", 7 ))
			{	
				uint q;
				sscanf( line + 8, "%i", &q );
				m_Quality = q;
			}
			if (!_strnicmp( line, "hdrblur", 7 ))
			{
				Engine::m_HDRBlur = true;
			}
			if (!_strnicmp( line, "addlight", 8 ))
			{
				float x, y, z, r, g, b, radius;
				float diff, spec;
				char name[128];
				sscanf( line + 9, "%s (%f %f %f) (%f %f %f %f %f) %f", name, &x, &y, &z, &r, &g, &b, &diff, &spec, &radius );
				m_Light[m_Lights] = MManager::NewLight();
				vector3 p( x, y, z );
				Color c( r, g, b );
				Color cdiff = (float)diff * c;
				Color cspec = (float)spec * c;
				char* pos = 0;
				if (pos = strstr( name + 1, "\"" )) *pos = 0;
				m_Light[m_Lights]->Init( m_Lights, name + 1, p, cdiff, cspec, radius );
				m_Lights++;
			}
			if (!_strnicmp( line, "spotlight", 9 ))
			{
				float x, y, z, s1, s2;
				char name[128], *pos = 0;
				sscanf( line + 10, "%s (%f %f %f) %f %f", name, &x, &y, &z, &s1, &s2 );
				if (pos = strstr( name + 1, "\"" )) *pos = 0;
				Light* l = (Light*)GetLight( name + 1 );
				if (l)
				{
					vector3 d( x, y, z );
					d.Normalize();
					l->SetWidth( s1 );
					l->SetSpotSize( s2 );
					l->SetDirection( d );
				}
			}
			if (!_strnicmp( line, "campos", 6 ))
			{
				float x, y, z;
				sscanf( line + 7, "(%f %f %f)", &x, &y, &z );
				m_CamPos = vector3( x, y, z );
				if (camscale)
				{
					m_CamPos *= m_Scale;
					m_CamPos += offset;
				}
			}
			if (!_strnicmp( line, "camtarget", 9 ))
			{
				float x, y, z;
				sscanf( line + 10, "(%f %f %f)", &x, &y, &z );
				m_CamTarget = vector3( x, y, z );
				if (camscale)
				{
					m_CamTarget *= m_Scale;
					m_CamTarget += offset;
				}
			}
			if (!_strnicmp( line, "camangle", 8 ))
			{
				float x, y, z;
				sscanf( line + 9, "(%f %f %f)", &x, &y, &z );
				m_CamRot = vector3( x, y, z );
			}
			if (!_strnicmp( line, "camscale", 8 )) camscale = true;
			if (!_strnicmp( line, "fog", 3))
			{
				float top, density, r, g, b;
				sscanf(line + 4, "%f %f (%f %f %f)", &top, &density, &r, &g, &b);
				m_FogTop4 = _mm_set_ps1( top );
				m_FogTop = top;
				m_FogDensity4 = _mm_set_ps1( density );
				m_FogDensity = density;
				m_FogColor = Color( r, g, b );
				m_Fog = true;
			}
		#ifndef NOSOUND
			if (!_strnicmp( line, "music", 5))
			{
				float volume;
				char file[255];
				FMOD::Sound* sound;
				FMOD::Channel* channel;
				sscanf(line + 6, "%s %f", file, &volume);
				if (volume > 1.0f) volume = 1.0f;
				else if (volume < 0.0f) volume = 0.0f;
				sound = Sound::LoadSound( file, true );
				channel = Sound::PlaySound( sound, true );
				channel->setMode( FMOD_LOOP_NORMAL );
				channel->setVolume( volume );
				channel->setPaused( false );
			}
		#endif
		}
	}
	// build the tree
	BVHierarchy* bvh = (BVHierarchy*)Scene::GetBVH( 0 );
	unsigned int newcount = 0;
	bvh->PreBuild( Scene::GetPrimArray(), Scene::GetNrPrimitives(), Scene::GetSPrimArray(), newcount );
	bvh->Build( Scene::GetSPrimArray(), newcount );
#ifdef PHOTONMAPPING
	if (m_GI)
	{
		PhotonMapper::InitStatics();
		if (!m_GIpoints)
		{
			PhotonMapper::LoadPhotons();
		}
		else
		{	
			PhotonMapper::CreatePhotonSources( (Light*)Scene::GetLight( (unsigned int)0 ) );
			PhotonMapper::SpawnPhotons( (Light*)Scene::GetLight( (unsigned int)0 ) );
			PhotonMapper::ResetStatics();
			PhotonMapper::LoadPhotons();
		}
		if (!m_GIcolors)
		{
			PhotonMapper::LoadColors();
		}
		else
		{
			unsigned int t1 = GetTickCount();
			PhotonMapper::CreateVPLs( (Light*)Scene::GetLight( (unsigned int)0 ) );
			unsigned int t2 = GetTickCount();
			PhotonMapper::BuildVPLBVH();
			unsigned int t3 = GetTickCount();
			Log::IntValue( "creating vpls took: ", t2 - t1 );
			Log::IntValue( "building vpl bvh took: ", t3 - t2 );
			PhotonMapper pm[MAXTHREADS];
			SYSTEM_INFO sinfo;
			GetSystemInfo( &sinfo );
			int cores = sinfo.dwNumberOfProcessors;
			if (cores > MAXTHREADS) cores = MAXTHREADS;
			unsigned int starttime = GetTickCount();
			Log::IntValue( "cores used for gi: ", cores );
			for ( int i = 0; i < cores; i++ )
			{
				pm[i].Init( i );
				pm[i].start();
			}
			WaitForMultipleObjects( cores, gidone, true, INFINITE );
			unsigned int rayscast = 0, sampled = 0, approximated = 0, badapprox = 0, coh = 0, inco = 0;
			for ( int i = 0; i < cores; i++ ) 
			{
				rayscast += pm[i].RaysCast();
				sampled += pm[i].VPLsSampled();
				approximated += pm[i].Approximated();
				badapprox += pm[i].BadApprox();
				coh += pm[i].Coherent();
				inco += pm[i].InCoherent();
			}
			unsigned int elapsed = GetTickCount() - starttime;
			/* float rayspersec = (rayscast * 0.001f) / (elapsed * 0.001f);
			Log::IntValue( "rays(K) cast for gi: ", rayscast / 1000 );
			Log::IntValue( "(per sampling point:)", rayscast / PhotonMapper::GetNrSamples() );
			Log::IntValue( "bvh nodes(K) visited: ", sampled / 1000 );
			Log::IntValue( "(per sampling point:)", sampled / PhotonMapper::GetNrSamples() );
			Log::IntValue( "shadow rays approximated (K): ", approximated / 1000 );
			Log::IntValue( "(per sampling point:)", approximated / PhotonMapper::GetNrSamples() );
			Log::IntValue( "badd approximations (K):", badapprox / 1000 );
			Log::IntValue( "coherent packets:", coh );
			Log::IntValue( "incoherent packets:", inco );
			if (badapprox > 0) Log::IntValue( "(percentage:)", badapprox / (approximated / 100) );
			Log::FloatValue( "vpls(K) probed per second: ", rayspersec ); */
			Log::IntValue( "time spent on gi (ms): ", elapsed );
			PhotonMapper::SaveColors();
		}
	}
#endif
	// done
	Log::Message( "leaving Scene::InitScene()" );
	return true;
}

const Light* Scene::GetLight( const char* a_Name )
{
	Light* l = 0;
	for ( unsigned int i = 0; i < m_Lights; i++ ) 
		if (l = m_Light[i]) 
			if (l->GetName())
				if (!_stricmp( l->GetName(), a_Name )) return l;
	return 0;
}

void Scene::RebuildDynamicTree()
{
	m_BVH[1]->ThreadedBuild( GetDPrimArray(), GetNrDynamicPrims() ); 
}