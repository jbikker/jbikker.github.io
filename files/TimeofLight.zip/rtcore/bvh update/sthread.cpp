// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#include "precomp.h"

using namespace Raytracer;

const int Thread::P_ABOVE_NORMAL = THREAD_PRIORITY_ABOVE_NORMAL;
const int Thread::P_BELOW_NORMAL = THREAD_PRIORITY_BELOW_NORMAL;
const int Thread::P_HIGHEST = THREAD_PRIORITY_HIGHEST;
const int Thread::P_IDLE = THREAD_PRIORITY_IDLE;
const int Thread::P_LOWEST = THREAD_PRIORITY_LOWEST;
const int Thread::P_NORMAL = THREAD_PRIORITY_NORMAL;
const int Thread::P_CRITICAL = THREAD_PRIORITY_TIME_CRITICAL;

unsigned int sthread_proc( void* param ) 
{
	Thread* tp = (Thread*)param;
	tp->run();
	return 0;
}

void Thread::sleep(long ms) 
{
	Sleep(ms);
}

void Thread::start() 
{
	DWORD tid = 0;	
	m_hThread = (unsigned long*)CreateThread(NULL,0,(LPTHREAD_START_ROUTINE)sthread_proc,(Thread*)this,0,&tid);
	setPriority( Thread::P_NORMAL );
}

void Thread::kill()
{
	TerminateThread( m_hThread, 0 );
}

void Thread::stop() 
{
	if (m_hThread == NULL) return;	
	WaitForSingleObject( m_hThread,INFINITE );
	CloseHandle( m_hThread );
	m_hThread = NULL;
}

void Thread::setPriority( int tp ) 
{
	SetThreadPriority( m_hThread, tp );
}

void Thread::suspend() 
{
	SuspendThread( m_hThread );
}

void Thread::resume() 
{
	ResumeThread( m_hThread );
}