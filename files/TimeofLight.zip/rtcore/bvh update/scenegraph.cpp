// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#include "precomp.h"

namespace Raytracer {

wallclock_t STimer;

Node** SceneGraph::m_Node;
unsigned int SceneGraph::m_NCount;
	
Node::Node()
{
	m_Prim = 0;
	m_OPrim = 0;
	m_PCount = 0;
	m_Mat = matrix();
}

Node::Node( int a_PCount )
{
	m_Prim = new Primitive*[a_PCount];
	m_OPrim = new Primitive*[a_PCount];
	m_PCount = 0;
	m_Mat = matrix();
}

void Node::Add( Primitive* a_Prim )
{ 
	m_OPrim[m_PCount] = a_Prim;
	m_Prim[m_PCount] = MManager::NewPrimitive();
	Vertex* ov0 = new Vertex(); *ov0 = *a_Prim->GetVertex( 0 );
	Vertex* ov1 = new Vertex(); *ov1 = *a_Prim->GetVertex( 1 );
	Vertex* ov2 = new Vertex(); *ov2 = *a_Prim->GetVertex( 2 );
	m_Prim[m_PCount]->SetMaterial( a_Prim->GetMaterial() );
	m_Prim[m_PCount++]->Init( ov0, ov1, ov2 );
}

Node::Node( char* a_Obj, vector3 a_Pos, float a_Scale )
{
	m_OPrim = 0;
	Load( a_Obj, a_Scale );
	m_Mat = matrix();
	m_Mat.SetTranslation( a_Pos );
}

Node::~Node()
{
	delete m_Prim;
}

void Node::Load( char* a_Obj, float a_Scale )
{
	// count faces in file
	FILE* f = fopen( a_Obj, "r" );
	if (!f) Log::Error( "Could not load dynamic object", a_Obj );
	unsigned int fcount = 0, ncount = 0, uvcount = 0, vcount = 0;
	char buffer[256];
	char cmd[32], objname[128];
	while (1)
	{
		fgets( buffer, 250, f );
		if (feof( f )) break;
		sscanf( buffer, "%s", cmd );
		if (!strcmp( cmd, "v" )) vcount++;
		else if (!strcmp( cmd, "vt" )) uvcount++;
		else if (!strcmp( cmd, "vn" )) ncount++;
		else if (!strcmp( cmd, "f" )) fcount++;
	}
	fclose( f );
	// allocate arrays
	unsigned int verts = 0, uvs = 0, normals = 0;
	m_Prim = new Primitive*[fcount];
	m_OPrim = new Primitive*[fcount];
	m_PCount = 0;
	vector3* vert = new vector3[vcount];
	vector3* norm = new vector3[ncount];
	float* tu = new float[uvcount];
	float* tv = new float[uvcount];
	// load object
	Material* curmat = 0;
	f = fopen( a_Obj, "r" );
	while (1)
	{
		fgets( buffer, 250, f );
		if (feof( f )) break;
		sscanf( buffer, "%s", cmd );
		if (!strcmp( cmd, "v" ))
		{
			// vertex, add to list
			float x, y, z;
			sscanf( buffer, "%s %f %f %f", cmd, &x, &y, &z );
			x *= a_Scale, y *= a_Scale, z *= a_Scale;
			vector3 pos = vector3( x, y, z );
			vert[verts++] = pos;
		}
		else if (!strcmp( cmd, "g" ))
		{
			sscanf( buffer + 2, "%s", objname );
		}
		else if (!strcmp( cmd, "mtllib" ))
		{
			char libname[128];
			sscanf( buffer + 7, "%s", libname );
			char fullname[256];
			strcpy( fullname, "meshes/" );
			strcat( fullname, libname );
			Scene::GetMatManager()->LoadMTL( fullname );
		}
		else if (!strcmp( cmd, "vt" ))
		{
			// texture coordinate
			float u, v;
			sscanf( buffer, "%s %f %f", cmd, &u, &v );
			tu[uvs] = u, tv[uvs++] = -v; // prevent negative uv's
		}
		else if (!strcmp( cmd, "vn" ))
		{
			// vertex normal
			float x, y, z;
			sscanf( buffer, "%s %f %f %f", cmd, &x, &y, &z );
			norm[normals++] = vector3( x, y, z );
		}
		else if (!strcmp( cmd, "usemtl" ))
		{
			// vertex normal
			char matname[128];
			sscanf( buffer + 7, "%s", matname );
			curmat = Scene::GetMatManager()->GetMaterial( matname );
		}
		else if (!strcmp( cmd, "f" ))
		{
			// face
			Vertex* v[3];
			float cu[3], cv[3];
			const Texture* t = curmat->GetTexture();
			unsigned int vnr[9];
			unsigned int vars = sscanf( buffer + 2, "%i/%i/%i %i/%i/%i %i/%i/%i", 
				&vnr[0], &vnr[1], &vnr[2], &vnr[3], &vnr[4], &vnr[5], &vnr[6], &vnr[7], &vnr[8] );
			if (vars < 9) 
			{
				vars = sscanf( buffer + 2, "%i/%i %i/%i %i/%i", &vnr[0], &vnr[2], &vnr[3], &vnr[5], &vnr[6], &vnr[8] );
				if (vars < 6)
				{
					sscanf( buffer + 2, "%i//%i %i//%i %i//%i", &vnr[0], &vnr[2], &vnr[3], &vnr[5], &vnr[6], &vnr[8] );
				}
			}
			for ( unsigned int i = 0; i < 3; i++ )
			{
				v[i] = new Vertex();
				if (t) cu[i] = tu[vnr[i * 3 + 1] - 1], cv[i] = tv[vnr[i * 3 + 1] - 1];
				v[i]->SetNormal( norm[vnr[i * 3 + 2] - 1] );
				v[i]->SetPos( vert[vnr[i * 3] - 1] );
			}
			Primitive* p = m_Prim[m_PCount] = MManager::NewPrimitive(), *op = m_OPrim[m_PCount] = MManager::NewPrimitive();
			if (t)
			{
				while ((cu[0] < 0) || (cu[1] < 0) || (cu[2] < 0)) cu[0] += 8, cu[1] += 8, cu[2] += 8;
				while ((cv[0] < 0) || (cv[1] < 0) || (cv[2] < 0)) cv[0] += 8, cv[1] += 8, cv[2] += 8;
				v[0]->SetUV( cu[0] * t->m_Width, cv[0] * t->m_Height );
				v[1]->SetUV( cu[1] * t->m_Width, cv[1] * t->m_Height );
				v[2]->SetUV( cu[2] * t->m_Width, cv[2] * t->m_Height );
			}
			p->Init( v[0], v[1], v[2] );
			Vertex* ov0 = new Vertex(); *ov0 = *p->GetVertex( 0 );
			Vertex* ov1 = new Vertex(); *ov1 = *p->GetVertex( 1 );
			Vertex* ov2 = new Vertex(); *ov2 = *p->GetVertex( 2 );
			op->Init( ov0, ov1, ov2 );
			p->SetMaterial( curmat );
			m_PCount++;
		}
	}
	fclose( f );
	delete vert;
	delete norm;
	delete tu;
	delete tv;
}

void Node::Transform()
{
	matrix transform = m_Mat;
	transform.SetTranslation( vector3( 0, 0, 0 ) );
	for ( int i = 0; i < m_PCount; i++ )
	{
		Primitive* p = m_Prim[i], *op = m_OPrim[i];
		for ( int v = 0; v < 3; v++ ) 
		{
			Vertex* vert = p->m_Vertex[v];
			Vertex* ovrt = op->m_Vertex[v];
			vert->m_Pos = m_Mat.Transform( ovrt->m_Pos );
			vert->m_Normal = -transform.Transform( ovrt->m_Normal );
		}
		vector3 e1 = p->m_Vertex[1]->GetPos() - p->m_Vertex[0]->GetPos();
		vector3 e2 = p->m_Vertex[2]->GetPos() - p->m_Vertex[0]->GetPos();
		p->SetNormal( e2.Cross( e1 ) );
		NORMALIZE( p->m_N );
	}
}

void Node::SetMaterial( Material* a_Mat )
{
	for ( int i = 0; i < m_PCount; i++ )
	{
		m_Prim[i]->SetMaterial( a_Mat );
		if (m_OPrim) m_OPrim[i]->SetMaterial( a_Mat );
	}
}

#ifdef MULTIBEAM
void MultiBeam::Transform( matrix& a_Mat )
{
	for ( int i = 0; i < MULTIBEAMDIRS; i++ ) 
	{
		vector3 t = a_Mat.Transform( m_Dir[i] );
		m_Light->SetDirection( i, t );
	}
}
#endif

void Node::Break()
{
	// nothing here
}

void Node::Break(vector3 a_Direction)
{
	// nothing here
}

void Node::SetGravity(bool a_Bool, vector3 a_Vector)
{
	// nothing here
}

Breakable::Breakable()
{
	// nothing here
}

Breakable::Breakable( char* a_Obj, vector3 a_Pos, float a_Scale )
: m_Broken(false), m_BlastDirection(vector3(0,0,0))
{
	m_OPrim = 0;
	Load( a_Obj, a_Scale );
	m_Mat = matrix();
	m_Mat.SetTranslation( a_Pos );
	// create matrices
	m_Rot = new vector3[16];
	m_DRot = new vector3[16];
	m_Trans = new matrix[16];
	for ( int i = 0; i < 16; i++ )
	{
		m_Rot[i] = vector3( 0, 0, 0 );
		m_DRot[i] = vector3( Rand( 1 ) - 0.5f, Rand( 1 ) - 0.5f, Rand( 1 ) - 0.5f );
		m_DRot[i] = vector3(0,0,0);
		m_Trans[i].Identity();
	}
}

Breakable::Breakable(char* a_Obj, vector3 a_Pos, float a_Scale, vector3 a_Direction)
: m_Broken(false), m_BlastDirection(a_Direction)
{
	m_OPrim = 0;
	Load( a_Obj, a_Scale );
	m_Mat = matrix();
	m_Mat.SetTranslation( a_Pos );
	// create matrices
	m_Rot = new vector3[16];
	m_DRot = new vector3[16];
	m_Trans = new matrix[16];
	for ( int i = 0; i < 16; i++ )
	{
		m_Rot[i] = vector3( 0, 0, 0 );
		m_DRot[i] = vector3( Rand( 1 ) - 0.5f, Rand( 1 ) - 0.5f, Rand( 1 ) - 0.5f );
		m_DRot[i] = vector3(0,0,0);
		m_Trans[i].Identity();
	}
}

Breakable::~Breakable()
{
	// nothing here
}

void Breakable::Load( char* a_Obj, float a_Scale )
{
	Node::Load( a_Obj, a_Scale );
	// make all polygons double sided
	Primitive** newprimlist = new Primitive*[m_PCount * 2];
	Primitive** newoprimlist = new Primitive*[m_PCount * 2];
	memcpy( newprimlist, m_Prim, m_PCount * sizeof( Primitive* ) );
	memcpy( newoprimlist, m_OPrim, m_PCount * sizeof( Primitive* ) );
	delete m_Prim;
	delete m_OPrim;
	m_Prim = newprimlist;
	m_OPrim = newoprimlist;
	for ( int i = 0; i < m_PCount; i++ )
	{
		Primitive* orig = m_Prim[i];
		vector3 N = orig->m_N;
		Primitive* p = m_Prim[i + m_PCount] = MManager::NewPrimitive();
		Primitive* op = m_OPrim[i + m_PCount] = MManager::NewPrimitive();
		Vertex* v0 = (Vertex*)orig->GetVertex( 0 ), *v1 = (Vertex*)orig->GetVertex( 1 ), *v2 = (Vertex*)orig->GetVertex( 2 );
		p->Init( v2, v1, v0 ); // reversed
		Vertex* ov0 = new Vertex(); *ov0 = *v0;
		Vertex* ov1 = new Vertex(); *ov1 = *v1;
		Vertex* ov2 = new Vertex(); *ov2 = *v2;
		op->Init( ov2, ov1, ov0 );
		p->SetMaterial( orig->GetMaterial() );
	}
	m_Pos = new vector3[m_PCount];
	m_DPos = new vector3[m_PCount];
	Reset();
	m_PCount *= 2;
}

void Breakable::Reset()
{
	for ( int i = 0; i < m_PCount; i++ )
	{
		m_Pos[i] = vector3( 0, 0, 0 );
		vector3 dir = m_Prim[i]->GetVertex( 0 )->GetPos();
		dir.Normalize();
		m_DPos[i] = 0.5 * dir * (Rand( 0.7f ) + 0.3f);
	}
	m_Broken = false;
}

void Breakable::Transform()
{
	if (!m_Broken) 
	{ 
		Node::Transform(); 
		return; 
	}
	// create the 16 transformation matrices (holding orientation)
	matrix mat[16], nmat[16];
	for ( int i = 0; i < 16; i++ )
	{
		mat[i].Identity();
		mat[i].Rotate( vector3( 0, 0, 0 ), m_Rot[i].x, m_Rot[i].y, m_Rot[i].z );
		nmat[i] = mat[i];
		nmat[i].Concatenate( m_Mat );
		nmat[i].SetTranslation( vector3( 0, 0, 0 ) );
		m_Rot[i] += 20 * m_DRot[i];
	}
	// transform the object
	matrix transform = m_Mat;
	transform.SetTranslation( vector3( 0, 0, 0 ) );
	int count = m_PCount / 2;
	for ( int i = 0; i < count; i++ )
	{
		Primitive* p = m_Prim[i], *op = m_OPrim[i];
		Primitive* dp = m_Prim[i + count], *dop = m_OPrim[i + count];
		vector3 basepos = (op->GetVertex( 0 )->GetPos() + op->GetVertex( 1 )->GetPos() + op->GetVertex( 2 )->GetPos()) * 0.3333f;
		for ( int v = 0; v < 3; v++ ) 
		{
			Vertex* vert = p->m_Vertex[v], *dvert = dp->m_Vertex[2 - v];
			Vertex* ovrt = op->m_Vertex[v], *dovrt = dop->m_Vertex[2 - v];
			vert->m_Pos = dvert->m_Pos = mat[i & 15].Transform( ovrt->m_Pos - basepos ) + m_Mat.Transform( ovrt->m_Pos + m_Pos[i] );
			vert->m_Normal = nmat[i & 15].Transform( ovrt->m_Normal );
			dvert->m_Normal = vert->m_Normal * -1;
		}
		vector3 e1 = p->m_Vertex[1]->GetPos() - p->m_Vertex[0]->GetPos();
		vector3 e2 = p->m_Vertex[2]->GetPos() - p->m_Vertex[0]->GetPos();
		p->SetNormal( e2.Cross( e1 ) );
		NORMALIZE( p->m_N );
		dp->m_N = p->m_N * -1;
		// apply some physics to movement
		vector3 delta = 1.2f * m_DPos[i];
		Primitive* prim = 0;
		vector3 worldpos = (p->GetVertex( 0 )->GetPos() + p->GetVertex( 1 )->GetPos() + p->GetVertex( 2 )->GetPos()) * 0.3333f;
		if ((m_DPos[i].x != 0) || (m_DPos[i].y != 0) || (m_DPos[i].z != 0))
		{
			float maxdist = delta.SqrLength();
			vector3 D = delta.Normalized();
			float dist = Engine::Trace( worldpos + D * 0.001f, D, prim, false );
			if ((dist * dist) < maxdist)
			{
				// mirror m_DPos[i] in primitive normal
				vector3 N = -prim->m_N;
				m_DPos[i] = m_DPos[i] - 2 * N.Dot( m_DPos[i] ) * N;
				m_Pos[i] += m_DPos[i];
			}
			else m_Pos[i] += delta;
		}
		m_DPos[i] *= 0.98f; // apply friction
		if (m_DPos[i].Length() < 0.01f) m_DPos[i] = vector3( 0, 0, 0 );
		if(m_BGravity) m_DPos[i] += m_VGravity; // apply gravity
	}
	//m_VGravity *= 1.1f;
}

void Breakable::Break()
{
	for(int i=0; i<16; i++) m_DRot[i] = vector3( Rand( 1 ) - 0.5f, Rand( 1 ) - 0.5f, Rand( 1 ) - 0.5f );
	m_Broken = true;

	if( m_BlastDirection == vector3(0,0,0)) return;

	for ( int i = 0; i < m_PCount>>1; i++ )
	{
		vector3 dir;
		dir.x = (Rand( 0.4f ) - 0.2f) + m_BlastDirection.x * (Rand( 0.6f ) + 0.7f);
		dir.y = (Rand( 0.4f ) - 0.2f) + m_BlastDirection.y * (Rand( 0.6f ) + 0.7f);
		dir.z = (Rand( 0.4f ) - 0.2f) + m_BlastDirection.z * (Rand( 0.6f ) + 0.7f);
		m_DPos[i] = dir;
	}
}

void Breakable::Explode()
{
	for(int i=0; i<16; i++)
		m_DRot[i] = vector3( Rand( 1 ) - 0.5f, Rand( 1 ) - 0.5f, Rand( 1 ) - 0.5f );
	m_Broken = true;
	for ( int i = 0; i < m_PCount>>1; i++ )
	{
		vector3 dir = m_DPos[i];
		dir += m_BlastDirection;
		dir.Normalize();
		m_DPos[i] = dir;
	}
}

void Breakable::Break(vector3 a_Direction)
{
	for(int i=0; i<16; i++)
		m_DRot[i] = vector3( Rand( 1 ) - 0.5f, Rand( 1 ) - 0.5f, Rand( 1 ) - 0.5f );
	m_Broken = true;

	if(a_Direction == vector3(0,0,0)) return;
	for ( int i = 0; i < m_PCount>>1; i++ )
	{
		vector3 dir = m_DPos[i];
		dir += a_Direction.Normalized();
		dir.Normalize();
		m_DPos[i] = dir;
	}
}

void Breakable::SetGravity(bool a_Bool, vector3 a_Vector)
{
	m_BGravity=a_Bool;
	m_VGravity=a_Vector;
}

MD2Node::MD2Node( char* a_Obj, vector3 a_Pos, float a_Scale )
{
	Load( a_Obj, a_Scale );
	m_Mat = matrix();
	m_Mat.SetTranslation( a_Pos );
	m_First = 0;
	m_Last = 1;
	m_APos = 0;
}

void MD2Node::Load( char* a_Obj, float a_Scale )
{
	// read header
	FILE* f = fopen( a_Obj, "rb" );
	if (!f) Log::Error( "Could not load MD2 object", a_Obj );
	fread( &m_Header, 1, sizeof( MD2Header ), f );
	// memory allocation
	m_Skins = (MD2Skin*)malloc( sizeof( MD2Skin ) * m_Header.num_skins );
	m_TCoords = (MD2UV*)malloc( sizeof( MD2UV ) * m_Header.num_st );
	m_Tris = (MD2Tri*)malloc( sizeof( MD2Tri ) * m_Header.num_tris );
	m_Frames = (MD2Frame*)malloc( sizeof( MD2Frame ) * m_Header.num_frames );
	m_GLCmds = (int*)malloc( sizeof( int ) * m_Header.num_glcmds);
	// read model data
	fseek( f, m_Header.offset_skins, SEEK_SET );
	fread( m_Skins, sizeof( MD2Skin ), m_Header.num_skins, f );
	fseek( f, m_Header.offset_st, SEEK_SET );
	fread( m_TCoords, sizeof( MD2UV ), m_Header.num_st, f );
	fseek( f, m_Header.offset_tris, SEEK_SET );
	fread( m_Tris, sizeof( MD2Tri ), m_Header.num_tris, f );
	fseek( f, m_Header.offset_glcmds, SEEK_SET );
	fread( m_GLCmds, sizeof( int ), m_Header.num_glcmds, f );
	// read frames
	fseek ( f, m_Header.offset_frames, SEEK_SET );
	int i;
	MD2Vert* verts = (MD2Vert*)malloc( sizeof( MD2Vert ) * m_Header.num_vertices);
	for ( i = 0; i < m_Header.num_frames; ++i)
	{
		// read frame data
		m_Frames[i].verts = new vector3[m_Header.num_vertices];
		fread( &m_Frames[i].scale, sizeof( vector3 ), 1, f );
		fread( &m_Frames[i].translate, sizeof( vector3 ), 1, f );
		fread( m_Frames[i].name, sizeof (char), 16, f );
		fread( verts, sizeof( MD2Vert ), m_Header.num_vertices, f );
		for ( int j = 0; j < m_Header.num_vertices; j++ )
		{
			float x = (float)verts[j].v[0] / 128 - 1;
			float y = (float)verts[j].v[1] / 128 - 1;
			float z = (float)verts[j].v[2] / 128 - 1;
			m_Frames[i].verts[j] = vector3( x * a_Scale, z * a_Scale, y * a_Scale );
		}
	}
	fclose( f );
	// build the initial mesh
	m_PCount = m_Header.num_tris;
	m_Prim = new Primitive*[m_PCount];
	m_VArray = new Vertex[m_Header.num_vertices];
	for ( i = 0; i < m_Header.num_vertices; i++ ) m_VArray[i].SetPos( m_Frames[0].verts[i] );
	for ( i = 0; i < m_PCount; i++ )
	{
		m_Prim[i] = MManager::NewPrimitive();
		MD2Tri t = m_Tris[i];
		Vertex* v1 = new Vertex();
		Vertex* v2 = new Vertex();
		Vertex* v3 = new Vertex();
		m_Prim[i]->Init( v1, v2, v3 );
	}
}

void MD2Node::SetAnim( char* a_Name )
{
	int len = strlen( a_Name );
	m_First = -1, m_Last = -1;
	bool ffound = false;
	for ( int i = 0; i < m_Header.num_frames; i++ )
	{
		if (!strncmp( m_Frames[i].name, a_Name, len ))
			if (!ffound) ffound = true, m_First = i; else m_Last = i;
	}
	m_APos = 0;
}

int MD2Node::FindFirstFrame( char* a_Name )
{
	int len = strlen( a_Name );
	for ( int i = 0; i < m_Header.num_frames; i++ )
	{
		if (!strncmp( m_Frames[i].name, a_Name, len )) return i;
	}
	return -1;
}

int MD2Node::FindLastFrame( char* a_Name )
{
	int len = strlen( a_Name );
	int first = -1, last = -1;
	bool ffound = false;
	for ( int i = 0; i < m_Header.num_frames; i++ )
	{
		if (!strncmp( m_Frames[i].name, a_Name, len ))
			if (!ffound) ffound = true, first = i; else last = i;
	}
	return last;
}

void MD2Node::Transform()
{
	matrix transform = m_Mat;
	transform.SetTranslation( vector3( 0, 0, 0 ) );
	int i;
	float tperframe = 1.0f / (float)(m_Last - m_First + 1);
	float tinframe = m_APos * (float)(m_Last - m_First + 1);
	tinframe -= (float)((int)tinframe);
	int frame1 = m_First + (int)(m_APos * (float)(m_Last - m_First + 1));
	int frame2 = frame1 + 1;
	if (frame2 > m_Last) frame2 = m_First;
	if (frame1 > m_Last) frame1 = m_First;
	for ( i = 0; i < m_Header.num_vertices; i++ )
	{
		const vector3 v1 = m_Frames[frame1].verts[i];
		const vector3 v2 = m_Frames[frame2].verts[i];
		vector3 final = v1 + (v2 - v1) * tinframe;
		m_VArray[i].SetPos( m_Mat.Transform( final ) );
		// m_VArray[i].m_Normal = transform.Transform( m_VArray[i].m_ONormal );
	}
	for ( int i = 0; i < m_PCount; i++ )
	{
		Primitive* p = m_Prim[i];
		MD2Tri t = m_Tris[i];
		p->m_Vertex[0]->SetPos( m_VArray[t.vertex[0]].GetPos() );
		p->m_Vertex[1]->SetPos( m_VArray[t.vertex[1]].GetPos() );
		p->m_Vertex[2]->SetPos( m_VArray[t.vertex[2]].GetPos() );
		p->m_Vertex[0]->SetUV( (float)m_TCoords[t.uv[0]].u, 256 - (float)m_TCoords[t.uv[0]].v );
		p->m_Vertex[1]->SetUV( (float)m_TCoords[t.uv[1]].u, 256 - (float)m_TCoords[t.uv[1]].v );
		p->m_Vertex[2]->SetUV( (float)m_TCoords[t.uv[2]].u, 256 - (float)m_TCoords[t.uv[2]].v );
		vector3 e1 = p->m_Vertex[1]->GetPos() - p->m_Vertex[0]->GetPos();
		vector3 e2 = p->m_Vertex[2]->GetPos() - p->m_Vertex[0]->GetPos();
		NORMALIZE( e1 );
		NORMALIZE( e2 );
		vector3 N = e2.Cross( e1 );
		NORMALIZE( N );
		p->SetNormal( N );
		p->m_Vertex[0]->SetNormal( p->m_N );
		p->m_Vertex[1]->SetNormal( p->m_N );
		p->m_Vertex[2]->SetNormal( p->m_N );
	}
}

SceneGraph::SceneGraph()
{
	m_Node = new Node*[50];
	m_NCount = 0;
}

SceneGraph::~SceneGraph()
{
	delete m_Node;
}

void SceneGraph::UpdatePrimList()
{
	unsigned int prims = 0;
	for ( unsigned int i = 0; i < m_NCount; i++ ) 
		for ( int p = 0; p < m_Node[i]->GetPrimCount(); p++ )
			Scene::SetDPrim( prims++, m_Node[i]->GetPrim( p ) );
	Scene::SetDPrimCount( prims );
}

void SceneGraph::Update()
{
	STimer.reset();
	vector3 p1( vector3( 10000, 10000, 10000 ) );
	vector3 p2( vector3( -10000, -10000, -10000 ) );
	for ( unsigned int i = 0; i < m_NCount; i++ ) m_Node[i]->Transform();
	Engine::m_SceneTime = (float)STimer.elapsed();
}

void SceneGraph::Break(vector3 a_Direction)
{
	for(unsigned int i=0; i<m_NCount; i++ ) m_Node[i]->Break(a_Direction);
}
void SceneGraph::Break()
{
	for(unsigned int i=0; i<m_NCount; i++ ) m_Node[i]->Break();
}
void SceneGraph::SetGravity(bool a_Bool, vector3 a_Vector)
{
	for(unsigned int i=0; i<m_NCount; i++) m_Node[i]->SetGravity(a_Bool,a_Vector);
}

} // namespace RTGame
