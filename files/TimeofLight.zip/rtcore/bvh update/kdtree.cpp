// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#include "precomp.h"

namespace Raytracer {

// -----------------------------------------------------------
// KdTree class implementation
// -----------------------------------------------------------
KdTree::KdTree()
{
	m_Root = 0;
	m_ObjList = 0;
}

void KdTree::Load( char* a_File )
{
	FILE* f = fopen( a_File, "r" );
	char buffer[512];
	if (f)
	{
		fgets( buffer, 500, f );
		unsigned int nodes;
		sscanf( buffer, "n%i", &nodes );
		KdTreeNode* node = new KdTreeNode[nodes];
		for ( unsigned int i = 0; i < nodes; i++ )
		{
			fgets( buffer, 500, f );
			if (!strncmp( buffer, "dummy", 5 ))
			{
				// dummy node, ignore
			}
			else if (buffer[0] == 'L')
			{
				// leaf node
				int first, count;
				sscanf( buffer, "L p1:%i c:%i", &first, &count );
				node[i].SetLeft( 0 );
				node[i].SetObjList( first, count );
				node[i].SetLeaf( true );
			}
			else
			{
				// interior node
				int left;
				char caxis;
				float split;
				sscanf( buffer, "%c|%f %i<>", &caxis, &split, &left );
				node[i].SetLeaf( false );
				node[i].SetLeft( &node[left] ); // automatically sets right to node[left + 1]
				node[i].SetSplitPos( split );
				node[i].SetAxis( caxis - 'X' );
			}
		}
		m_Root = &node[0];
		fgets( buffer, 500, f );
		unsigned int olsize;
		sscanf( buffer, "o%i", &olsize );
		m_ObjList = new Primitive*[olsize];
		for ( unsigned int i = 0; i < olsize; i++ )
		{
			fgets( buffer, 500, f );
			unsigned int pidx;
			sscanf( buffer, "%i", &pidx );
			m_ObjList[i] = (Primitive*)Scene::GetPrimitive( pidx );
		}
	}
}

}; // namespace Raytracer