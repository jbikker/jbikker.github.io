// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#include "precomp.h"

using namespace Raytracer;

#define ORDERPHOTONS

Cell* PhotonMapper::m_Grid;
Photon* PhotonMapper::m_Photon;
int PhotonMapper::m_Total;
vector3* PhotonMapper::m_Dart;
unsigned int PhotonMapper::m_Darts;
vector3* PhotonMapper::m_VPS, *PhotonMapper::m_VPSN, *PhotonMapper::m_VPL, *PhotonMapper::m_VPN;
__m128* PhotonMapper::m_VPcol;
int PhotonMapper::m_NrVPS, PhotonMapper::m_NrVPL;
vector3 PhotonMapper::m_EP1, PhotonMapper::m_EP2;
vector3 PhotonMapper::m_ESize, PhotonMapper::m_ERSize, PhotonMapper::m_ECSize;
vector3 PhotonMapper::m_ERad;
RayPacket* PhotonMapper::m_RP;
IData* PhotonMapper::m_ID;
int PhotonMapper::m_Cores;
float PhotonMapper::m_SampleDist, PhotonMapper::m_SampleSqDist, PhotonMapper::m_SampleDot, PhotonMapper::m_Brightness;
char* PhotonMapper::m_DartsFile;
VPLBVHNode* PhotonMapper::m_Root, *PhotonMapper::m_First;

extern HANDLE waitpmreq[MAXTHREADS];
extern HANDLE gidone[MAXTHREADS];
extern unsigned int _raydir[8][3][2];

static bool order = false;
static const __m128 _one = _mm_set_ps1( 1.0f ), _half4 = _mm_set_ps1( 0.5f );
static const __m128 _three = _mm_set_ps1( 3.0f ), _zero4 = _mm_set_ps1( 0 );

static __forceinline __m128 fastrsqrt( const __m128 v )
{
	const __m128 nr = _mm_rsqrt_ps( v );
	const __m128 muls = _mm_mul_ps( _mm_mul_ps( v, nr ), nr );
	return _mm_mul_ps( _mm_mul_ps( _half4, nr ), _mm_sub_ps( _three, muls ) );
}

static __forceinline float fastsqrtf( float v )
{
	const __m128 v1 = _mm_load_ss( &v );
	const __m128 v2 = _mm_rsqrt_ss( v1 );
	float final;
	_mm_store_ss( &final, _mm_mul_ps( v1, v2 ) );
	return final;
}

static __forceinline float fastrsqrtf( float v )
{
	const __m128 v1 = _mm_load_ss( &v );
	float final;
	_mm_store_ss( &final, _mm_rsqrt_ss( v1 ) );
	return final;
}

#ifdef PHOTONMAPPING

void PhotonMapper::InitStatics()
{
	FILE* f = fopen( "darts_18k.dat", "rb" );
	if (!f) Log::Message( "ERROR: darts_18k.dat not found" );
	fread( &m_Darts, 4, 1, f );
	m_Dart = new vector3[m_Darts];
	fread( m_Dart, sizeof( vector3 ), m_Darts, f );
	fclose( f );
	m_Photon = (Photon*)MALLOC64( 5000000 * sizeof( Photon ) );
	const unsigned int size = PHOTONGRIDX * PHOTONGRIDY * PHOTONGRIDZ;
	m_Grid = (Cell*)MALLOC64( size * sizeof( Cell ) );
	for ( int i = 0; i < size; i++ ) m_Grid[i].Init();
	m_Total = 0;
	aabb ext = Scene::GetExtends();
	m_EP1 = ext.GetP1() * 1.1f;
	m_EP2 = ext.GetP2() * 1.1f;
	m_ESize = m_EP2 - m_EP1;
	m_ERad = vector3( m_SampleDist * 1.01f, m_SampleDist * 1.01f, m_SampleDist * 1.01f );
	m_ERSize = vector3( PHOTONGRIDX / m_ESize.x, PHOTONGRIDY / m_ESize.y, PHOTONGRIDZ / m_ESize.z );
	m_ECSize = vector3( m_ESize.x / PHOTONGRIDX, m_ESize.y / PHOTONGRIDY, m_ESize.z / PHOTONGRIDZ );
	SYSTEM_INFO sinfo;
	GetSystemInfo( &sinfo );
	m_Cores = sinfo.dwNumberOfProcessors;
	if (m_Cores > MAXTHREADS) m_Cores = MAXTHREADS;
	m_RP = (RayPacket*)MALLOC64( sizeof( RayPacket ) );
	m_ID = (IData*)MALLOC64( sizeof( IData ) );
}

void PhotonMapper::ResetStatics()
{
	FREE64( m_Photon );
	FREE64( m_Grid );
	m_Photon = (Photon*)MALLOC64( 5000000 * sizeof( Photon ) );
	const unsigned int size = PHOTONGRIDX * PHOTONGRIDY * PHOTONGRIDZ;
	m_Grid = (Cell*)MALLOC64( size * sizeof( Cell ) );
	for ( int i = 0; i < size; i++ ) m_Grid[i].Init();
	m_Total = 0;
}

void PhotonMapper::Init( int a_Thread )
{
	m_Thread = a_Thread;
	memcpy( (void*)raydir, _raydir, 192 );
	for ( int i = 0; i < 16; i++ )
	{
		masktable[i * 4 + 3] = (i & 8)?0xffffffff:0;	
		masktable[i * 4 + 2] = (i & 4)?0xffffffff:0;	
		masktable[i * 4 + 1] = (i & 2)?0xffffffff:0;	
		masktable[i * 4 + 0] = (i & 1)?0xffffffff:0;	
	}
}

void PhotonMapper::TraverseEx( const vector3& O, const vector3& D, Primitive*& a_Prim, float& a_Dist, float& a_U, float& a_V )
{
	const Primitive** restrict objlist = (const Primitive**)Scene::GetKdTree()->GetObjectList();
	KDStack stack[128];
	const vector3 rd( 1.0f / D.x, 1.0f / D.y, 1.0f / D.z );
	const unsigned int quad = ((D.x < 0)?1:0) + ((D.y < 0)?2:0) + ((D.z < 0)?4:0), *rdir = &_raydir[quad][0][0];
	Primitive* prim = 0;
	float tnear = EPSILON, tfar = a_Dist;
	unsigned int stackptr = 0;
	KdTreeNode* node = Scene::GetKdTree()->GetRoot();
	while (1)
	{
		while (!node->IsLeaf())
		{
			unsigned int axis = node->GetAxis();
			KdTreeNode* front = (KdTreeNode*)(node->GetLeft() + rdir[axis * 2]);
			float d = (node->m_Split - O.cell[axis]) * rd.cell[axis];
			KdTreeNode* back = node = (KdTreeNode*)(node->GetLeft() + rdir[axis * 2 + 1]);
			if (d < tnear) continue;
			node = (KdTreeNode*)front;
			if (d > tfar) continue;
			stack[stackptr].tfar = tfar;
			stack[stackptr].tnear = MAX( tnear, d );
			stack[stackptr++].kdnode = (KdTreeNode*)back;
			tfar = MIN( tfar, d );
		}
		unsigned int start = node->GetObjOffset();
		const unsigned int count = node->GetObjCount();
		for ( unsigned int i = 0; i < count; i++ )
		{
			const Primitive* restrict pr = objlist[start++];
			const vector3 ao = pr->m_Vertex[0]->m_Pos - O;
			if ((ao.x * pr->m_N.x + ao.y * pr->m_N.y + ao.z * pr->m_N.z) > 0)
			{
				const vector3 bo = pr->m_Vertex[1]->m_Pos - O, co = pr->m_Vertex[2]->m_Pos - O;
				const vector3 v1c = bo^ao, v2c = ao^co, v0c = co^bo;
				const float nominator = DOT( ao, pr->m_N );
				const float v0d = DOT( v0c, D ), v1d = DOT( v1c, D ), v2d = DOT( v2c, D );
				if ((intcast(v0d)|intcast(v1d)|intcast(v2d)) > 0)
				{
					const float t = nominator / DOT( D, pr->m_N );
					if (intcast( t) < intcast( a_Dist )) 
					{
						a_Dist = t;
						a_Prim = (Primitive*)pr;
						const float div = 1.0f / (v0d + v1d + v2d);
						a_U = v2d * div;
						a_V = v1d * div;
					}
				}
			}
		}
		if ((a_Dist < tfar) || (!stackptr)) break;
		node = stack[--stackptr].kdnode;
		tfar = stack[stackptr].tfar;
		tnear = stack[stackptr].tnear;
	}
}

void PhotonMapper::CreatePhotonSources( Light* a_Light )
{
	Log::Message( "entering PhotonMapper::CreatePhotonSources()" );
	unsigned int bounces = 4;
	unsigned idx = 0;
	m_VPS = new vector3[m_Darts * bounces];
	m_VPSN = new vector3[m_Darts * bounces];
	m_NrVPS = 0;
	int count[4] = { 0, 0, 0, 0 };
	for ( unsigned int i = 0; i < m_Darts; i++ )
	{
		// find nearest scene intersection
		vector3 vpos = a_Light->GetPos();
		vector3 dir( m_Dart[i].x, m_Dart[i].y, m_Dart[i].z );
		for ( unsigned int bounce = 0; bounce < bounces; bounce++ )
		{
			vpos += dir * 0.0001f;
			Primitive* prim = 0;
			float dist = 10000, u, v;
			TraverseEx( vpos, dir, prim, dist, u, v );
			if (!prim) break;
			m_VPS[m_NrVPS] = vpos + dist * dir * 0.999f;
			m_VPSN[m_NrVPS++] = prim->m_N;
			vpos += dist * dir;
			dir = m_Dart[idx];
			if (++idx == m_Darts) idx = 0;
			if (dir.Dot( prim->m_N ) > 0) dir *= -1;
			count[bounce]++;
		}
	}
	Log::IntValue( "particle fountains created [LEVEL1]: ", count[0] );
	Log::IntValue( "particle fountains created [LEVEL2]: ", count[1] );
	Log::IntValue( "particle fountains created [LEVEL3]: ", count[2] );
	Log::IntValue( "particle fountains created [LEVEL4]: ", count[3] );
	Log::Message( "leaving PhotonMapper::CreatePhotonSources()" );
}

void PhotonMapper::CreateVPLs( Light* a_Light )
{
	Log::Message( "entering PhotonMapper::CreateVPLs()" );
	unsigned idx = 0, bounces = 1, darts = 0;
	FILE* f = fopen( m_DartsFile, "rb" );
	if (!f)
	{
		Log::Write( "ERROR: could not open ", m_DartsFile );
		return;
	}
	fread( &darts, 1, 4, f );
	Log::IntValue( "loaded darts for VPL creation", darts );
	vector3* dart = new vector3[darts];
	fread( dart, darts, sizeof( vector3 ), f );
	m_VPL = new vector3[darts * bounces];
	m_VPN = new vector3[darts * bounces];
	m_VPcol = (__m128*)MALLOC64( sizeof( Color ) * darts * bounces );
	m_NrVPL = 0;
	for ( unsigned int i = 0; i < darts; i++ )
	{
		// find nearest scene intersection
		vector3 vpos = a_Light->GetPos();
		vector3 dir( m_Dart[i].x, m_Dart[i].y, m_Dart[i].z );
		__m128 pcol = a_Light->GetDiffuse().rgba;
		for ( unsigned int bounce = 0; bounce < bounces; bounce++ )
		{
			vpos += dir * 0.0001f;
			Primitive* prim = 0;
			float dist = 10000, u, v;
			TraverseEx( vpos, dir, prim, dist, u, v );
			if (!prim) break;
			pcol = _mm_mul_ps( prim->GetMaterial()->GetPhotonColor(), pcol );
			if (dist > 4)
			{
				m_VPL[m_NrVPL] = vpos + dist * dir * 0.999f;
				m_VPN[m_NrVPL] = prim->GetNormal( u, v );
				m_VPcol[m_NrVPL] = pcol;
				m_NrVPL++;
			}
			vpos += dist * dir;
			dir = m_Dart[idx];
			if (++idx == m_Darts) idx = 0;
			if (dir.Dot( prim->m_N ) > 0) dir *= -1;
		}
	}
	Log::IntValue( "created VPLs: ", m_NrVPL );
	delete dart;
	Log::Message( "leaving PhotonMapper::CreateVPLs()" );
}

bool PhotonMapper::FindInCell( const unsigned int a_Idx, const vector3& a_Pos, const vector3& a_N )
{
	const unsigned int count = m_Grid[a_Idx].GetPhotonCount();
	Photon** plist = m_Grid[a_Idx].GetPhotons();
	for ( unsigned int i = 0; i < count; i++ ) if ((!plist[i]->Removed()) && (plist[i]->N.Dot( a_N ) > MAXPOINTANGLE))
	{
		float maxdist = m_SampleSqDist;
		if (plist[i]->Fixed()) maxdist *= 0.5f;
		const float dist = (plist[i]->pos - a_Pos).SqrLength();
		if (dist < maxdist) return true;
	}
	return false;
}

bool PhotonMapper::Occupied( const vector3& a_Pos, const vector3& a_N )
{
	const vector3 gpos = (a_Pos - m_EP1) * m_ERSize;
	const int ix = (int)floor( gpos.x ), iy = (int)floor( gpos.y ), iz = (int)floor( gpos.z );
	return (FindInCell( ix + (iy << PHOTONYSHIFT) + (iz << PHOTONZSHIFT), a_Pos, a_N ));
}

void PhotonMapper::AddPhoton( const vector3& a_Pos, Primitive* a_Prim, const vector3& a_N, const unsigned int a_Flags )
{
	// add to photon array
	m_Photon[m_Total].pos = a_Pos;
	m_Photon[m_Total].N = a_N;
	m_Photon[m_Total].SetPrimitive( a_Prim );
	m_Photon[m_Total].SetFlags( a_Flags );
	// add to grid
	const vector3 gpos = (a_Pos - m_EP1) * m_ERSize;
	const int ix = (int)floor( gpos.x ), iy = (int)floor( gpos.y ), iz = (int)floor( gpos.z );
	m_Grid[ix + (iy << PHOTONYSHIFT) + (iz << PHOTONZSHIFT)].Add( &m_Photon[m_Total] );
	// add to neighbouring cells if close to edge
	for ( int z = iz - 1; z < iz + 2; z++ ) for ( int y = iy - 1; y < iy + 2; y++ ) for ( int x = ix - 1; x < ix + 2; x++ )
	{
		if ((x < 0) || (x == PHOTONGRIDX) || (y < 0) || (y == PHOTONGRIDY) || (z < 0) || (z == PHOTONGRIDZ)) continue;
		if ((x == ix) && (y == iy) && (z == iz)) continue;
		vector3 cmin = m_EP1 + vector3( (float)x * m_ECSize.x, (float)y * m_ECSize.y, (float)z * m_ECSize.z );
		vector3 cmax = cmin + m_ECSize;
		cmin -= m_ERad, cmax += m_ERad;
		if ((a_Pos.x >= cmin.x) && (a_Pos.x <= cmax.x) &&
			(a_Pos.y >= cmin.y) && (a_Pos.y <= cmax.y) &&
			(a_Pos.z >= cmin.z) && (a_Pos.z <= cmax.z))
		{
			m_Grid[x + (y << PHOTONYSHIFT) + (z << PHOTONZSHIFT)].Add( &m_Photon[m_Total] );
		}
	}
	m_Total++;
}

void PhotonMapper::AddPhoton( Photon* p )
{
	// add to grid
	const vector3 gpos = (p->pos - m_EP1) * m_ERSize;
	const int ix = (int)floor( gpos.x ), iy = (int)floor( gpos.y ), iz = (int)floor( gpos.z );
	m_Grid[ix + (iy << PHOTONYSHIFT) + (iz << PHOTONZSHIFT)].Add( p );
	// add to neighbouring cells if close to edge
	for ( int z = iz - 3; z < iz + 4; z++ ) for ( int y = iy - 3; y < iy + 4; y++ ) for ( int x = ix - 3; x < ix + 4; x++ )
	{
		if ((x < 0) || (x == PHOTONGRIDX) || (y < 0) || (y == PHOTONGRIDY) || (z < 0) || (z == PHOTONGRIDZ)) continue;
		if ((x == ix) && (y == iy) && (z == iz)) continue;
		vector3 cmin = m_EP1 + vector3( (float)x * m_ECSize.x, (float)y * m_ECSize.y, (float)z * m_ECSize.z );
		vector3 cmax = cmin + m_ECSize;
		vector3 size = cmax - cmin;
		aabb box( cmin, size );
		if (box.Intersect( p->pos, SEARCHRADIUS ))
		{
			m_Grid[x + (y << PHOTONYSHIFT) + (z << PHOTONZSHIFT)].Add( p );
		}
	}
}

void PhotonMapper::SpawnPhotons( Light* a_Light )
{
	Log::Message( "entering PhotonMapper::SpawnPhotons()" );
	// STEP 1: Add sampling points for primitive edges
	const unsigned int prims = Scene::GetNrPrimitives();
	const float erad = m_SampleDist * 1.5f;
	const float sqerad = erad * erad;
	const float inverad = 1.0f / erad;
	for ( unsigned int i = 0; i < prims; i++ )
	{
		Primitive* prim = (Primitive*)Scene::GetPrimitive( i );
		const vector3 v[3] = { prim->GetVertex( 0 )->GetPos(), prim->GetVertex( 1 )->GetPos(), prim->GetVertex( 2 )->GetPos() };
		for ( int k = 0; k < 3; k++ ) AddPhoton( v[k], prim, prim->GetVertex( k )->GetNormal(), Photon::FIXED + Photon::VERTEX );
		const float sqlen[3] = { (v[1] - v[0]).SqrLength(), (v[2] - v[1]).SqrLength(), (v[0] - v[2]).SqrLength() };
		for ( int k = 0; k < 3; k++ )
		{
 			if (sqlen[k] > sqerad)
			{
				const float len = sqrtf( sqlen[k] );
				const int steps = 1 + (int)floor( len * inverad );
				const float rsteps = 1.0f / (float)steps;
				const vector3 edge = v[(k + 1) % 3] - v[k];
				const vector3 step = edge * rsteps;
				for ( int j = 1; j < steps; j++ ) 
				{
					const float f = (float)j * rsteps;
					vector3 N = (f * prim->GetVertex( k )->GetNormal()) + ((1 - f) * prim->GetVertex( (k + 1) % 3 )->GetNormal());
					N.Normalize();
					AddPhoton( v[k] + (float)j * step, prim, N, Photon::FIXED );
				}
			}
		}
	}
	// STEP 2: Clean after first stage
	const unsigned int size = PHOTONGRIDX * PHOTONGRIDY * PHOTONGRIDZ;
	// 2b _ remove edge photons between planar triangles
	unsigned int edgeremoved = 0, dupvertex = 0;
	for ( int i = 0; i < size; i++ )
	{
		Photon** plist = m_Grid[i].GetPhotons();
		if (!plist) continue;
		const unsigned int count = m_Grid[i].GetPhotonCount();
		for ( unsigned int j = 0; j < count; j++ ) if ((!plist[j]->Removed()) && (plist[j]->Fixed()))
		{
			if (plist[j]->IsVertex())
			{
				// vertex point; delete duplicates
				const vector3 N = plist[j]->N;
				const vector3 pos = plist[j]->pos;
				for ( unsigned int k = 0; k < count; k++ ) if ((k != j) && (!plist[k]->Removed()) && (plist[k]->IsVertex()))
				{
					if (plist[k]->IsCloseTo( plist[j], m_SampleDist ))
					{
						plist[k]->Remove();
						dupvertex++;	
					}
				}
			}
			else
			{
				// point on edge; delete both if a planar one is found
				const vector3 N = plist[j]->N;
				const vector3 pos = plist[j]->pos;
				for ( unsigned int k = 0; k < count; k++ ) if ((k != j) && (!plist[k]->Removed()) && (plist[k]->Fixed()) && (!plist[k]->IsVertex()))
				{
					if (plist[k]->IsCloseTo( plist[j], m_SampleDist ))
					{
						plist[j]->Remove();
						plist[k]->Remove();
						edgeremoved += 2;
						break;
					}
				}
			}
		}
	}	
	for ( int i = 0; i < size; i++ ) m_Grid[i].Optimize();
	Log::IntValue( "points on planar edges removed:", edgeremoved );
	Log::IntValue( "duplicate vertices removed:", dupvertex );
	// STEP 3: Move points away from planes
	for ( int i = 0; i < size; i++ )
	{
		Photon** plist = m_Grid[i].GetPhotons();
		if (!plist) continue;
		unsigned int count = m_Grid[i].GetPhotonCount();
		for ( unsigned int j = 0; j < count; j++ )
		{
			// make sure this photon is not on any of the planes in the current cell
			const vector3 pos = plist[j]->pos;
			const vector3 N = plist[j]->N;
			for ( unsigned int k = 0; k < count; k++ ) if (N.Dot( plist[k]->N ) < 0.8f)
			{
				Primitive* prim = plist[k]->GetPrimitive();
				float D = prim->GetVertex( 0 )->GetPos().Dot( prim->m_N );
				float dist = prim->m_N.Dot( pos ) - D;
				if ((dist > -0.005f) && (dist < 0.005f)) plist[j]->pos -= prim->m_N * (dist + 0.005f);
			}
		}
	}
	// STEP 4: Fill up space by throwing darts
	int idx = 0, failed = 0;
	const __m128 m500 = _mm_set_ps1( 500 ), m1 = _mm_set_ps1( 1 ), zero = _mm_set_ps1( 0 );
	Primitive* dprim = (Primitive*)Scene::GetPrimitive( 0 );
	KDStack stack[128];
	unsigned int i = 0;
	while (1)
	{
		if (++i == m_NrVPS) i = 0;
		for ( int p = 0; p < 256; p++ )
		{
			const vector3 N = m_VPSN[i];
			m_RP->dx[p] = m_Dart[idx].x, m_RP->dy[p] = m_Dart[idx].y, m_RP->dz[p] = m_Dart[idx].z;
			if (++idx == m_Darts) idx = 0;
			if ((m_RP->dx[p] * N.x + m_RP->dy[p] * N.y + m_RP->dz[p] * N.z) > 0) 
				m_RP->dx[p] = -m_RP->dx[p], m_RP->dy[p] = -m_RP->dy[p], m_RP->dz[p] = -m_RP->dz[p];
		}
		// direction normalize & reciprocal
		for ( int p = 0; p < 64; p++ ) m_RP->CalcReciprocal4( p );
		const Primitive** restrict objlist = (const Primitive**)Scene::GetKdTree()->GetObjectList();
		const vector3 vpos = m_VPS[i];
		const __m128 ox4 = _mm_set_ps1( vpos.x ), oy4 = _mm_set_ps1( vpos.y ), oz4 = _mm_set_ps1( vpos.z );
		for ( int p = 0; p < 256; p++ )
		{
			// find nearest scene intersection
			KdTreeNode* node = Scene::GetKdTree()->GetRoot();
			const vector3 dir( m_RP->dx[p], m_RP->dy[p], m_RP->dz[p] );
			Primitive* prim = m_ID->prim[p];
			const unsigned int quad = ((dir.x < 0)?1:0) + ((dir.y < 0)?2:0) + ((dir.z < 0)?4:0);
			const unsigned int* rdir = &_raydir[quad][0][0];
			float tnear = 1, tfar = 10000, dist = 10000, u = 0, v = 0;
			unsigned int stackptr = 0;
			while (1)
			{
				while (!node->IsLeaf())
				{
					unsigned int axis = node->GetAxis();
					KdTreeNode* front = (KdTreeNode*)(node->GetLeft() + rdir[axis * 2]);
					float d = (node->m_Split - vpos.cell[axis]) * m_RP->rdc[axis * PACKETSIZE + p];
					KdTreeNode* back = node = (KdTreeNode*)(node->GetLeft() + rdir[axis * 2 + 1]);
					if (d < tnear) continue;
					node = (KdTreeNode*)front;
					if (d > tfar) continue;
					stack[stackptr].tfar = tfar;
					stack[stackptr].tnear = MAX( tnear, d );
					stack[stackptr++].kdnode = (KdTreeNode*)back;
					tfar = MIN( tfar, d );
				}
				unsigned int start = node->GetObjOffset();
				const unsigned int count = node->GetObjCount();
				for ( unsigned int i = 0; i < count; i++ )
				{
					const Primitive* restrict pr = objlist[start++];
					const vector3 ao = pr->m_Vertex[0]->m_Pos - vpos;
					if ((ao.x * pr->m_N.x + ao.y * pr->m_N.y + ao.z * pr->m_N.z) > 0)
					{
						const vector3 bo = pr->m_Vertex[1]->m_Pos - vpos;
						const vector3 co = pr->m_Vertex[2]->m_Pos - vpos;
						const vector3 v1c = bo^ao, v2c = ao^co, v0c = co^bo;
						const float nominator = DOT( ao, pr->m_N );
						// intersection test
						const float v0d = DOT( v0c, dir ), v1d = DOT( v1c, dir ), v2d = DOT( v2c, dir );
						if ((intcast(v0d)|intcast(v1d)|intcast(v2d)) > 0)
						{
							const float t = nominator / DOT( dir, pr->m_N );
							if (intcast( t) < intcast( dist )) 
							{
								prim = (Primitive*)pr, dist = t;
								const float div = 1.0f / (v0d + v1d + v2d);
								u = v2d * div, v = v1d * div;
							}
						}
					}
				}
				if ((dist < tfar) || (!stackptr)) break;
				node = stack[--stackptr].kdnode;
				tfar = stack[stackptr].tfar;
				tnear = stack[stackptr].tnear;
			}
			m_ID->dist[p] = dist, m_ID->prim[p] = prim, m_ID->u[p] = u, m_ID->v[p] = v;
		}
		for ( int p = 0; p < 64; p++ )
		{
			for ( int j = 0; j < 4; j++ ) if (m_ID->dist[p * 4 + j] < 500)
			{
				const unsigned int pj = p * 4 + j;
				const vector3 pos( vpos.x + m_RP->dx[pj] * m_ID->dist[pj],
								   vpos.y + m_RP->dy[pj] * m_ID->dist[pj],
								   vpos.z + m_RP->dz[pj] * m_ID->dist[pj] );
				if (Occupied( pos, m_ID->prim[pj]->m_N )) failed++; else
				{
					Primitive* p = m_ID->prim[pj];
					AddPhoton( pos, p, p->GetNormal( m_ID->u[pj], m_ID->v[pj] ), 0 );
					failed = 0;
				}
			}
		}
		if (failed > 5000) break;
	}
	for ( int i = 0; i < size; i++ ) m_Grid[i].Optimize();
	// STEP 6: Create a grid with more overlap
	Cell* oldgrid = m_Grid;
	m_Grid = (Cell*)MALLOC64( size * sizeof( Cell ) );
	for ( int i = 0; i < size; i++ ) m_Grid[i].Init();
	m_ERad = vector3( SEARCHRADIUS, SEARCHRADIUS, SEARCHRADIUS );
	int totalvalid = 0;
	for ( int i = 0; i < m_Total; i++ )
	{
		Photon* p = &m_Photon[i];
		if (p->Removed()) continue;
		totalvalid++;
		AddPhoton( p );	
	}
	// summary & store on disk
	Log::IntValue( "final point count:", totalvalid );
	char name[128];
	strcpy( name, Scene::GetSceneName() );
	strcat( name, ".drt" );
	FILE* f = fopen( name, "wb" );
	fwrite( &totalvalid, 4, 1, f );
#ifndef ORDERPHOTONS
	// unordered write
	for ( int i = 0; i < m_Total; i++ ) if (!m_Photon[i].Removed())
	{
		vector3 pos = m_Photon[i].pos;
		vector3 N = m_Photon[i].N;
		fwrite( &pos, 12, 1, f );
		fwrite( &N, 12, 1, f );
		m_Photon[i].InitSSE();
	}
#else
	// ordered write
	for ( int i = 0; i < m_Total; i++ ) m_Photon[i].flag = 0;
	for ( int i = 0; i < size; i++ )
	{
		Photon** plist = m_Grid[i].GetPhotons();
		if (!plist) continue;
		unsigned int count = m_Grid[i].GetPhotonCount();
		for ( unsigned int j = 0; j < count; j++ ) if ((!plist[j]->Removed()) && (plist[j]->flag == 0))
		{
			vector3 pos = plist[j]->pos;
			vector3 N = plist[j]->N;
			fwrite( &pos, 12, 1, f );
			fwrite( &N, 12, 1, f );
			plist[j]->InitSSE();
			plist[j]->flag = 1;
		}
	}
	order = true;
#endif
	fclose( f );
	Log::Message( "leaving PhotonMapper::SpawnPhotons()" );
}

void PhotonMapper::LoadPhotons()
{
	// load photons from file
	m_ERad = vector3( SEARCHRADIUS, SEARCHRADIUS, SEARCHRADIUS );
	char name[128];
	strcpy( name, Scene::GetSceneName() );
	strcat( name, ".drt" );
	FILE* f = fopen( name, "rb" );
	if (!f) 
	{	
		Log::Write( "Error: Sampling point file not found", name );
		return;
	}
	fread( &m_Total, 4, 1, f );
	Log::IntValue( "loading sampling points: ", m_Total );
	for ( int i = 0; i < m_Total; i++ )
	{
		vector3 pos, N;
		fread( &pos, 12, 1, f );
		fread( &N, 12, 1, f );
		m_Photon[i].pos = pos;
		m_Photon[i].N = N;
		m_Photon[i].SetFlags( 0 );
		AddPhoton( &m_Photon[i] );
		m_Photon[i].InitSSE();
	}	
	fclose( f );
}

void PhotonMapper::LoadColors()
{
	char name[128];
	strcpy( name, Scene::GetSceneName() );
	strcat( name, ".gi" );
	FILE* f = fopen( name, "rb" );
	const __m128 scale4 = _mm_set_ps( 0, m_Brightness, m_Brightness, m_Brightness );
	if (!f) 
	{	
		Log::Write( "Error: Sampling point color file not found", name );
		return;
	}
	unsigned int count;
	fread( &count, 4, 1, f );
	for ( unsigned int i = 0; i < count; i++ )
	{
		__m128 c;
		fread( &c, 16, 1, f );
		m_Photon[i].GI = _mm_mul_ps( c, scale4 );
	}
	fclose( f );
}

void PhotonMapper::SaveColors()
{
	char name[128];
	strcpy( name, Scene::GetSceneName() );
	strcat( name, ".gi" );
	FILE* f = fopen( name, "wb" );
	unsigned int totalvalid = 0;
	for ( int i = 0; i < m_Total; i++ ) if (!m_Photon[i].Removed()) totalvalid++;
	fwrite( &totalvalid, 4, 1, f );
	const __m128 scale4 = _mm_set_ps( 0, 1.0f / m_Brightness, 1.0f / m_Brightness, 1.0f / m_Brightness );
	if (order)
	{
		// ordered write
		const unsigned int size = PHOTONGRIDX * PHOTONGRIDY * PHOTONGRIDZ;
		for ( int i = 0; i < m_Total; i++ ) m_Photon[i].flag = 0;
		for ( int i = 0; i < size; i++ )
		{
			Photon** plist = m_Grid[i].GetPhotons();
			if (!plist) continue;
			unsigned int count = m_Grid[i].GetPhotonCount();
			for ( unsigned int j = 0; j < count; j++ ) if ((!plist[j]->Removed()) && (plist[j]->flag == 0))
			{
				__m128 c = _mm_mul_ps( plist[j]->GI, scale4 );
				fwrite( &c, 16, 1, f );
				plist[j]->flag = 1;
			}
		}
	}
	else
	{
		for ( int i = 0; i < m_Total; i++ ) if (!m_Photon[i].Removed())
		{
			__m128 c = _mm_mul_ps( m_Photon[i].GI, scale4 );
			fwrite( &c, 16, 1, f );
		}
	}
	fclose( f );
}

void PhotonMapper::Traverse( const vector3& O, const vector3& D, Primitive*& a_Prim, float a_Dist )
{
	const Primitive** restrict objlist = (const Primitive**)Scene::GetKdTree()->GetObjectList();
	KDStack stack[128];
	const vector3 rd( 1.0f / D.x, 1.0f / D.y, 1.0f / D.z );
	const unsigned int quad = ((D.x < 0)?1:0) + ((D.y < 0)?2:0) + ((D.z < 0)?4:0), *rdir = &_raydir[quad][0][0];
	Primitive* prim = 0;
	float tnear = EPSILON, tfar = a_Dist;
	unsigned int stackptr = 0;
	KdTreeNode* node = Scene::GetKdTree()->GetRoot();
	while (1)
	{
		while (!node->IsLeaf())
		{
			unsigned int axis = node->GetAxis();
			KdTreeNode* front = (KdTreeNode*)(node->GetLeft() + rdir[axis * 2]);
			float d = (node->m_Split - O.cell[axis]) * rd.cell[axis];
			KdTreeNode* back = node = (KdTreeNode*)(node->GetLeft() + rdir[axis * 2 + 1]);
			if (d < tnear) continue;
			node = (KdTreeNode*)front;
			if (d > tfar) continue;
			stack[stackptr].tfar = tfar;
			stack[stackptr].tnear = MAX( tnear, d );
			stack[stackptr++].kdnode = (KdTreeNode*)back;
			tfar = MIN( tfar, d );
		}
		unsigned int start = node->GetObjOffset();
		const unsigned int count = node->GetObjCount();
		for ( unsigned int i = 0; i < count; i++ )
		{
			const Primitive* restrict pr = objlist[start++];
			const vector3 ao = pr->m_Vertex[0]->m_Pos - O;
			if ((ao.x * pr->m_N.x + ao.y * pr->m_N.y + ao.z * pr->m_N.z) > 0)
			{
				const vector3 bo = pr->m_Vertex[1]->m_Pos - O, co = pr->m_Vertex[2]->m_Pos - O;
				const vector3 v1c = bo^ao, v2c = ao^co, v0c = co^bo;
				const float nominator = DOT( ao, pr->m_N );
				const float v0d = DOT( v0c, D ), v1d = DOT( v1c, D ), v2d = DOT( v2c, D );
				if ((intcast(v0d)|intcast(v1d)|intcast(v2d)) > 0)
				{
					const float t = nominator / DOT( D, pr->m_N );
					if (intcast( t) < intcast( a_Dist )) { a_Prim = (Primitive*)1; return; }
				}
			}
		}
		if ((a_Dist < tfar) || (!stackptr)) break;
		node = stack[--stackptr].kdnode;
		tfar = stack[stackptr].tfar;
		tnear = stack[stackptr].tnear;
	}
}

void PhotonMapper::InitPhotonColors( int a_First, int a_Last )
{
	m_Sampled = 0, m_SRays = 0, m_Approx = 0, m_BadApprox = 0, m_Coherent = 0, m_InCoherent = 0;
	__m128 divisor = _mm_set_ps1( m_Brightness / (float)m_NrVPL );
	VPLBVHNode** vpl = new VPLBVHNode*[m_NrVPL];
	VPLBVHNode* stack[128];
	CopyVPLBVH();
	for ( int i = a_First; i < a_Last; i++ )
	{
		Photon* p = &m_Photon[i];
		const vector3 pos = p->GetPos(), N = p->GetNormal();
		p->GI = _mm_setzero_ps();
		// use the BVH to figure out which VPLs to use
		unsigned int count = 0;
		VPLBVHNode* node = m_LRoot;
		const float maxratio = 0.1f * 0.1f;
		unsigned int sp = 0;
		while (1)
		{
			if (node->left)
			{
				const float lratio = node->left->sqrad * (node->left->pos - pos).SqrLength();
				if (lratio > maxratio) stack[sp++] = node->left; else 
				{
					const vector3 dir = pos - node->left->pos;
					if ((dir.Dot( N ) > 0) && (dir.Dot( node->left->N ) < 0)) vpl[count++] = node->left;
				}
				const float rratio = node->right->sqrad * (node->right->pos - pos).SqrLength();
				if (rratio > maxratio) stack[sp++] = node->right; else 
				{
					const vector3 dir = pos - node->right->pos;
					if ((dir.Dot( N ) > 0) && (dir.Dot( node->right->N ) < 0)) vpl[count++] = node->right;
				}
			}
			else 
			{
				const vector3 dir = pos - node->pos;
				if ((dir.Dot( N ) > 0) && (dir.Dot( node->N ) < 0)) vpl[count++] = node;
			}
			if (!sp) break;
			node = stack[--sp];
		}
		if (count == 0) continue;
		Primitive* lastocc = 0;
		VPLBVHNode* lastparent = 0;
		float sum = 0, skipped = 0;
		for ( unsigned int j = 0; j < count; j++ ) 
		{
			vpl[j]->dir = pos - vpl[j]->pos;
			const float angle = -vpl[j]->dir.Dot( vpl[j]->N );
			vpl[j]->scale = 0;
			if (angle > 0)
			{
				vpl[j]->dist = vpl[j]->dir.Length();
				const float div = 1.0f / vpl[j]->dist;
				vpl[j]->dir *= div;
				vpl[j]->dist *= 0.995f;
				const float ldist = (vpl[j]->dist < 6)?(6 * 0.005f):(vpl[j]->dist * 0.005f);
				vpl[j]->scale = (angle * div) / (ldist * ldist);
				sum += vpl[j]->scale * vpl[j]->total;
			}
		}
		const float minval = sum / ((float)count * 7.0f);
		// trace remaining vpls
		for ( unsigned int j = 0; j < count; j++ )
		{
			if (vpl[j]->scale < minval) skipped += vpl[j]->scale; else if (lastparent == vpl[j]->parent)
			{
				if (!lastocc) p->GI = _mm_add_ps( p->GI, _mm_mul_ps( _mm_set_ps1( vpl[j]->scale ), vpl[j]->sum4 ) );
			}
			else
			{
				Primitive* prim = 0;
				Traverse( vpl[j]->pos, vpl[j]->dir, prim, vpl[j]->dist );
				lastparent = vpl[j]->parent, lastocc = prim;
				if (!prim) p->GI = _mm_add_ps( p->GI, _mm_mul_ps( _mm_set_ps1( vpl[j]->scale ), vpl[j]->sum4 ) );
			}
		}
		p->GI = _mm_add_ps( p->GI, _mm_mul_ps( p->GI, _mm_set_ps1( skipped / sum ) ) );
		p->GI = _mm_mul_ps( p->GI, divisor );
		m_Sampled += count;
	}
	delete vpl;
}

void PhotonMapper::run()
{
	int perthread = m_Total / m_Cores;
	int first = m_Thread * perthread;
	int last = (m_Thread + 1) * perthread;
	InitPhotonColors( first, last );
	SetEvent( gidone[m_Thread] );
}

VPLBVHNode* PhotonMapper::SubDivBVH( VPLBVHNode** list, int first, int last, int axis, int& next )
{
	VPLBVHNode* node = &m_First[next++]; // (VPLBVHNode*)MALLOC64( sizeof( VPLBVHNode ) );
	// sort over axis (quicksort)
	int sp = 0, sl[128], sr[128], start = first, end = last;
	while (1)
	{
		const float pivot = list[start]->pos.cell[axis];
		int left = start + 1, right = end;
		while (left < right)
		{
			if (list[left]->pos.cell[axis] < pivot) left++;
			else { VPLBVHNode* T = list[left]; list[left] = list[right]; list[right--] = T; }
		}
		VPLBVHNode* T = list[--left]; list[left--] = list[start]; list[start] = T;
		if (left > start) sl[sp] = start, sr[sp++] = left;
		if (end > right) sl[sp] = right, sr[sp++] = end;
		if (!sp) break;
		start = sl[--sp], end = sr[sp];
	}
	// create node
	const int pivot = (first + last) >> 1, nextaxis = (axis + 1) % 3;
	VPLBVHNode* left, *right;
	if (first != pivot) left = SubDivBVH( list, first, pivot, nextaxis, next );
				   else left = list[first];
	if ((pivot + 1) != last) right = SubDivBVH( list, pivot + 1, last, nextaxis, next );
						else right = list[pivot + 1];
	node->left = left;
	node->right = right;
	node->sum4 = _mm_add_ps( left->sum4, right->sum4 );
	node->total = node->sum[0] + node->sum[1] + node->sum[2];
	const float m1 = 0.001f + left->sum[0] + left->sum[1] + left->sum[2];
	const float m2 = 0.001f + right->sum[0] + right->sum[1] + right->sum[2];
	const float w1 = m1 / (m1 + m2), w2 = m2 / (m1 + m2);
	const float dotadjust = -left->N.Dot( right->N ) + 2;
	node->sqrad = (left->pos - right->pos).SqrLength() * dotadjust;
	node->N = (left->N * w1) + (right->N * w2);
	node->N.Normalize();
	node->pos = (left->pos * w1) + (right->pos * w2);
	left->parent = right->parent = node;
	// done
	return node;
}

void PhotonMapper::BuildVPLBVH()
{
	Log::Message( "entering PhotonMapper::BuildVPLBVH()" );
	// create leaf nodes
	m_First = (VPLBVHNode*)MALLOC64( (m_NrVPL * 2 + 2) * sizeof( VPLBVHNode ) );
	VPLBVHNode** node = new VPLBVHNode*[m_NrVPL * 2 + 2];
	for ( int i = 0; i < m_NrVPL; i++ )
	{
		node[i] = &m_First[i];
		node[i]->pos = m_VPL[i];
		node[i]->N = m_VPN[i];
		node[i]->sum4 = m_VPcol[i];
		node[i]->total = node[i]->sum[0] + node[i]->sum[1] + node[i]->sum[2];
		node[i]->left = node[i]->right = 0;
		node[i]->sqrad = 0;
	}
	// subdivide
	int axis = 0;
	int first = 0, last = m_NrVPL - 1;
	int next = m_NrVPL;
	m_Root = SubDivBVH( node, 0, m_NrVPL - 1, 0, next );
	unsigned int leafs = 0, nodes = 0;
	Log::Message( "leaving PhotonMapper::BuildVPLBVH()" );
}

void PhotonMapper::CopyVPLBVH()
{
	m_LFirst = (VPLBVHNode*)MALLOC64( (m_NrVPL * 2 + 2) * sizeof( VPLBVHNode ) );
	memcpy( m_LFirst, m_First, (m_NrVPL * 2 + 2) * sizeof( VPLBVHNode ) );
	for ( int i = 0; i < (m_NrVPL * 2 + 2 ); i++ ) 
	{
		if (m_LFirst[i].left) 
		{
			m_LFirst[i].ileft -= (unsigned int)m_First;
			m_LFirst[i].ileft += (unsigned int)m_LFirst;
		}
		if (m_LFirst[i].right) 
		{
			m_LFirst[i].iright -= (unsigned int)m_First;
			m_LFirst[i].iright += (unsigned int)m_LFirst;
		}
		m_LFirst[i].parent -= (unsigned int)m_First;
		m_LFirst[i].parent += (unsigned int)m_LFirst;
	}
	m_LRoot = m_LFirst + (m_Root - m_First);
}

#endif