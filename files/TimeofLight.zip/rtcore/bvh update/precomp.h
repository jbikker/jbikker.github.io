// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#define WIN32_LEAN_AND_MEAN
#define _WIN32_WINNT 0x0400

#include "core.h"
#include "scene.h"
#include "bvh.h"
#include "kdtree.h"
#include "lightbvh.h"
#include "photonmap.h"
#include "twister.h"
#include "common.h"
#include "windows.h"
#include "winbase.h"
#include "memory.h"
#include "math.h"
#include "stdio.h"
#include "string.h"
#include "stdio.h"
#include "sthread.h"
#include <d3d9.h>
#include <d3dx9.h>
#include <dxerr9.h>
#include "surface.h"
#include "scenegraph.h"