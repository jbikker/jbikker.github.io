// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#pragma once

#include "common.h"
#include "sthread.h"

namespace Raytracer {

// -----------------------------------------------------------
// PhotonMapper class definition
// -----------------------------------------------------------
class Photon
{
public:
	enum
	{
		FIXED = 1,
		REMOVED = 2,
		VERTEX = 4
	};
	vector3& GetNormal() { return N; }
	vector3& GetPos() { return pos; }
	void Fixed( unsigned int fix ) { data = (data & (0xffffffff - 1)) + fix; }
	void Remove() { data |= 2; }
	void Vertex( unsigned int vert) { data = (data & (0xffffffff - 4)) + (vert << 2); }
	void SetFlags( unsigned int flags ) { data = (data & (0xffffffff - 7)) + flags; }
	const unsigned int Fixed() const { return data & 1; }
	const unsigned int Removed() const { return data & 2; }
	const unsigned int IsVertex() const { return data & 4; }
	const unsigned int GetFlags() const { return data & 7; }
	Primitive* GetPrimitive() { return (Primitive*)(data & (0xffffffff - 7)); }
	void SetPrimitive( Primitive* prim ) { data = (unsigned int)prim + (data & 7); }
	bool IsCloseTo( Photon* p2, const float a_Dist )
	{
		const vector3 l = pos - p2->pos;
		const float projd = fabs( N.Dot( pos ) - N.Dot( p2->pos ) );
		return ((N.Dot( p2->N ) > MAXPOINTANGLE) && (l.SqrLength() < (a_Dist * a_Dist)) && (projd < (a_Dist * 0.3f)));
	}
	void InitSSE()
	{
		x4 = _mm_set_ps1( pos.x );
		y4 = _mm_set_ps1( pos.y );
		z4 = _mm_set_ps1( pos.z );
		Nx4 = _mm_set_ps1( N.x );
		Ny4 = _mm_set_ps1( N.y );
		Nz4 = _mm_set_ps1( N.z );
	}
	// data members
	__m128 x4, y4, z4;		// 48 bytes
	__m128 Nx4, Ny4, Nz4;	// 48 bytes
	__m128 GI;				// 16 bytes
	vector3 pos, N;			// 24 bytes
	union
	{
		Primitive* prim;
		unsigned int data;	// 4 bytes
	};
	unsigned int flag;		// 4 bytes
};

class Cell
{
public:
	void Add( Photon* p )
	{
		unsigned int lsize = size >> 16;
		unsigned int curr = GetPhotonCount();
		if (curr == lsize)
		{
			Photon** newlist = new Photon*[lsize * 2 + 4];
			memcpy( newlist, list, sizeof( Photon* ) * lsize );
			lsize = lsize * 2 + 4;
			size = (lsize << 16) + curr;
			delete list;
			list = newlist;
		}
		list[curr] = p;
		size++;
	}
	void Init() { size = 0; list = 0; }
	const unsigned int GetPhotonCount() const { return size & 0xffff; }
	Photon** GetPhotons() const { return list; }
	void Optimize()
	{
		unsigned int count = GetPhotonCount(), lsize = size >> 16, curr = 0;
		Photon** newlist = new Photon*[lsize];
		for ( unsigned int i = 0; i < count; i++ ) if (!list[i]->Removed()) newlist[curr++] = list[i];
		memcpy( list, newlist, 4 * lsize );
		size = curr + (lsize << 16);
		delete newlist;
	}
	// data members
	unsigned int size;
	Photon** list;
};

class VPLBVHNode
{
public:
	union { __m128 sum4; float sum[4]; };	// 16
	vector3 pos, N;							// 24
	float total;							// 4
	float scale;							// 4
	vector3 dir;							// 12
	float dist;								// 4
	float sqrad;							// 4
	union 
	{
		VPLBVHNode* left;
		unsigned int ileft;					// 4
	};
	union
	{
		VPLBVHNode* right;
		unsigned int iright;				// 4
	};
	union
	{
		VPLBVHNode* parent;
		unsigned int iparent;				// 4
	};										
};

struct NodeList
{
	VPLBVHNode* node;
	NodeList* next;
};

struct TraceTask
{
	// structure to gather four ray queries for simultaneous traversal using SIMD packet traversal
	union
	{
		struct
		{
			union { __m128 ox4; float ox[4]; };	// origin for the four ray queries (x)
			union { __m128 oy4; float oy[4]; };	// origin for the four ray queries (y)
			union { __m128 oz4; float oz[4]; };	// origin for the four ray queries (z)
		};
		__m128 oc4[3];
	};
	union
	{
		struct
		{
			union { __m128 dx4; float dx[4]; };	// direction for the four ray queries (x)
			union { __m128 dy4; float dy[4]; };	// direction for the four ray queries (y)
			union { __m128 dz4; float dz[4]; };	// direction for the four ray queries (z)
		};
		__m128 dc4[3];
	};
	union { __m128 shadow4; Primitive* prim[4]; };	// for the result of the ray query
	union { __m128 dist4; float dist[4]; };			// distance of the VPL from the sampling point; maximum query range
	vector3 O;										// origin and direction of the four queries (legacy, remove me)
	float u[4], v[4];								// for the result of the ray query
	vector3 dir[4];									// vector from sampling point to VPL
};

class Light;
class PhotonMapper : public Thread
{
public:
	void Init( int a_Thread );
	Photon* GetPhotons() { return m_Photon; }
	void run();
	void InitPhotonColors( int a_First, int a_Last );
	int RaysCast() { return m_SRays; }
	int Approximated() { return m_Approx; }
	int BadApprox() { return m_BadApprox; }
	int Coherent() { return m_Coherent; }
	int InCoherent() { return m_InCoherent; }
	int VPLsSampled() { return m_Sampled; }
	void CopyVPLBVH();
	// static methods
	static void TraverseEx( const vector3& O, const vector3& D, Primitive*& a_Prim, float& a_Dist, float& a_U, float& a_V );
	static void Traverse( const vector3& O, const vector3& D, Primitive*& a_Prim, float a_Dist );
	static VPLBVHNode* SubDivBVH( VPLBVHNode** list, int first, int last, int axis, int& next );
	static void BuildVPLBVH();
	static void CreateVPLs( Light* a_Light );
	static void SpawnPhotons( Light* a_Light );
	static bool FindInCell( const unsigned int a_Idx, const vector3& a_Pos, const vector3& a_N );
	static bool Occupied( const vector3& a_Pos, const vector3& a_N );
	static void AddPhoton( Photon* p );
	static void AddPhoton( const vector3& a_Pos, Primitive* a_Prim, const vector3& a_N, const unsigned int a_Flags );
	static void InitStatics();
	static void ResetStatics();
	static void CreatePhotonSources( Light* a_Light );
	static void LoadPhotons();
	static void SaveColors();
	static void LoadColors();
	static Cell* GetPhotonGrid() { return m_Grid; }
	static unsigned int GetTotalPhotons() { return m_Total; }
	static int GetNrSamples() { return m_Total; }
	static void SetParams( char* a_DFile, float a_Dist, float a_Dot, float a_Brightness ) 
	{ 
		m_DartsFile = new char[strlen( a_DFile ) + 1];
		strcpy( m_DartsFile, a_DFile );
		m_SampleDist = a_Dist; 
		m_SampleSqDist = a_Dist * a_Dist;
		m_SampleDot = a_Dot; 
		m_Brightness = a_Brightness;
		char t[256];
		sprintf( t, "gi params: %s, dist=%f, dot=%f, brightness=%f", a_DFile, a_Dist, a_Dot, a_Brightness );
		Log::Message( t );
	}
private:
	// static member variables
	static Photon* m_Photon;
	static Cell* m_Grid;
	static int m_Total;
	static vector3* m_Dart;
	static unsigned int m_Darts; 
	static vector3* m_VPS, *m_VPSN, *m_VPL, *m_VPN;
	static __m128* m_VPcol;
	static int m_NrVPS, m_NrVPL;
	static vector3 m_EP1, m_EP2;
	static vector3 m_ESize, m_ERSize, m_ECSize;
	static vector3 m_ERad;
	static RayPacket* m_RP;
	static IData* m_ID;
	static int m_Cores;
	static float m_SampleDist, m_SampleSqDist, m_SampleDot, m_Brightness;
	static char* m_DartsFile;
	static VPLBVHNode* m_Root, *m_First;
	// non-static member variables
	int m_Thread, m_Sampled, m_SRays, m_Approx, m_BadApprox, m_Coherent, m_InCoherent;
	unsigned int raydir[8][3][2];
	union { __m128 masktable4[16]; unsigned int masktable[64]; };
	VPLBVHNode* m_LRoot, *m_LFirst;
};

}; // namespace Raytracer