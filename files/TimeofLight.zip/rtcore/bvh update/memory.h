// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#pragma once

namespace Raytracer {

class RayPacket;
class IData;
class Primitive;
class Light;
class Material;
class Texture;
class LightList;
class LNode;
class MManager
{
public:
	MManager();
	static void Init( unsigned int a_Size );
	static Light* NewLight();
	static Primitive* NewPrimitive();
	static Material* NewMaterial();
	static Texture* NewTexture();
	static Texture* FindTexture( char* a_Name );
	static LightList* NewLightList() { LightList* r = m_LLPtr; m_LLPtr = r->GetNext(); return r; }
	static void FreeLightList( LightList* l ) { l->SetNext( m_LLPtr ); m_LLPtr = l; }
	static LNode* NewLNode() { LNode* r = m_LNPtr; m_LNPtr = r->GetLeft(); return r; }
	static void FreeLNode( LNode* l ) { l->SetLeft( m_LNPtr ); m_LNPtr = l; }
public:
	static RayPacket* m_RP;
	static IData* m_ID;
	static unsigned int m_CurText;
private:
	static Texture* m_TPtr;
	static Light* m_LgtPtr;
	static Material* m_MPtr;
	static Primitive* m_PrimPtr;
private:
	static LightList* m_LLPtr;
	static LNode* m_LNPtr;
	static unsigned int m_CurPrim;
	static unsigned int m_CurLight;
	static unsigned int m_CurMat;
};

}; // namespace Raytracer