// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#pragma once

#include "common.h"
#include "sthread.h"
#include "memory.h"

#define MAXPOINTSINLEAF	6

namespace Raytracer {

// -----------------------------------------------------------
// PhotonMapper class definition
// -----------------------------------------------------------
class SamplingPoint
{
public:
	enum
	{
		FIXED = 1,
		REMOVED = 2,
		VERTEX = 4,
		STORED = 8
	};
	vector3& GetNormal() { return N; }
	vector3& GetPos() { return pos; }
	void Fixed( unsigned int fix ) { data = (data & (0xffffffff - 1)) + fix; }
	void Remove() { data |= 2; }
	void Vertex( unsigned int vert) { data = (data & (0xffffffff - 4)) + (vert << 2); }
	void Stored() { data |= 8; }
	void NotStored() { data = (data & (0xffffffff - 8)); }
	void SetFlags( unsigned int flags ) { data = (data & (0xffffffff - 15)) + flags; }
	void SetPolyIdx( unsigned int idx ) { data = (idx << 4) + (data & 15); }
	const unsigned int PolyIdx() const { return data >> 4; }
	const unsigned int Fixed() const { return data & 1; }
	const unsigned int Removed() const { return data & 2; }
	const unsigned int IsVertex() const { return data & 4; }
	const unsigned int IsStored() const { return data & 8; }
	const unsigned int GetFlags() const { return data & 15; }
	bool IsCloseTo( SamplingPoint* p2, const float a_Dist, float a_Angle )
	{
		const vector3 l = pos - p2->pos;
		const float projd = fabs( N.Dot( pos ) - N.Dot( p2->pos ) );
		return ((N.Dot( p2->N ) > a_Angle) && (l.SqrLength() < (a_Dist * a_Dist)) && (projd < (a_Dist * 0.3f)));
	}
	vector3 pos, orig, N;	// 36 bytes
	unsigned int data;		// 4 bytes
	float radius;			// 4 bytes
	unsigned int dummy;		// 4 bytes
	__m128 GI;				// 16 bytes, total 48 bytes
	__m128 temp[2];			// 32 bytes, total 176 bytes
};

class Cell
{
public:
	void Remove( SamplingPoint* p )
	{
		if (!list) return;
		unsigned int lsize = GetListSize();
		unsigned int curr = GetSampleCount();
		if (curr == 1) 
		{ 
			if (list[0] == p) curr--; 
		}
		else 
		{
			for ( int i = 0; i < curr; i++ )
			{
				if (list[i] == p) { list[i] = list[curr - 1]; curr--; break; }
			}
		}
		size = (lsize << 11) + curr;
		if (curr == 0)
		{
			MManager::FreeTiny( list, lsize );
			size = 0, list = 0;
		}
	}
	void Add( SamplingPoint* p )
	{
		unsigned int lsize = GetListSize();
		const unsigned int curr = GetSampleCount();
		if (curr == lsize)
		{
		#if 1
			SamplingPoint** newlist = (SamplingPoint**)MManager::NewTiny( lsize * 2 + 4 );
			memcpy( newlist, list, sizeof( SamplingPoint* ) * lsize );
			if (lsize) MManager::FreeTiny( list, lsize );
			lsize = lsize * 2 + 4;
			size = (lsize << 11) + curr;
		#else
			SamplingPoint** newlist = new SamplingPoint*[lsize * 2 + 4];
			memcpy( newlist, list, sizeof( SamplingPoint* ) * lsize );
			lsize = lsize * 2 + 4;
			size = (lsize << 11) + curr;
			delete list;
		#endif
			list = newlist;
		}
		list[curr] = p;
		size++;
	}
	void Init() { size = 0; list = 0; }
	const unsigned int GetListSize() const { return (size >> 11) & 2047; }
	const unsigned int GetSampleCount() const { return size & 2047; }
	const unsigned int GetCentreCount() const { return (size >> 22); }
	void Remove( int idx ) { list[idx] = list[GetSampleCount() - 1]; size--; }
	SamplingPoint** GetSamples() const { return list; }
	void Optimize()
	{
		unsigned int count = GetSampleCount(), lsize = GetListSize(), curr = 0;
		SamplingPoint** newlist = (SamplingPoint**)MManager::NewTiny( lsize );
		for ( unsigned int i = 0; i < count; i++ ) if (!list[i]->Removed()) newlist[curr++] = list[i];
		memcpy( list, newlist, 4 * lsize );
		size = curr + (lsize << 11);
		MManager::FreeTiny( newlist, lsize );
	}
	void Finalize( const vector3& p1, const vector3& p2 )
	{
		// put the sampling points with centres in this cell at the start of the list
		int ccount = 0;
		const int items = GetSampleCount();
		for ( int i = 0; i < items; i++ )
		{
			const vector3 pos = list[i]->pos;
			if ((pos.x >= p1.x) && (pos.y >= p1.y) && (pos.z >= p1.z) &&
				(pos.x < p2.x) && (pos.y < p2.y) && (pos.z < p2.z))
			{
				SamplingPoint* tmp = list[ccount];
				list[ccount++] = list[i];
				list[i] = tmp;
			}
		}
		size = (size & 0x3fffff) + (ccount << 22);
	}
private:
	// data members
	unsigned int size;
	SamplingPoint** list;
};

class VPLBVHNode
{
public:
	union { __m128 sum4; float sum[4]; };	// 16
	vector3 pos, N;							// 24
	float total;							// 4
	float scale;							// 4
	vector3 dir;							// 12
	float dist;								// 4
	float sqrad;							// 4
	union 
	{
		VPLBVHNode* left;
		unsigned int ileft;					// 4
	};
	union
	{
		VPLBVHNode* right;
		unsigned int iright;				// 4
	};
	union
	{
		VPLBVHNode* parent;
		unsigned int iparent;				// 4
	};										
};

struct NodeList
{
	VPLBVHNode* node;
	NodeList* next;
};

class Polygon
{
public:
	Primitive* GetOrig() { return (Primitive*)(orig & -2); }
	void SetOrig( Primitive* a_Orig ) { orig = (unsigned int)a_Orig; }
	void Translated() { orig |= 1; }
	unsigned int IsTranslated() { return orig & 1; }
	union
	{
		int idx[3];			// 12
		Vertex* vert[3];
	};
	Polygon* neigh[3];		// 4
	SamplingPoint** point;	// 4
	unsigned int pcount;	// 4
private:
	unsigned int orig;		// 4
	unsigned int dummy;		// 4, total 32
};

struct PolyGridCell
{
	int count;
	Polygon** list;
};

class Light;
class PhotonMapper : public Thread
{
public:
	void Init( int a_Thread );
	static SamplingPoint* GetSamples() { return m_Sample; }
	void run();
	void InitSampleColors( int a_First, int a_Last );
	int RaysCast() { return m_SRays; }
	int Approximated() { return m_Approx; }
	int BadApprox() { return m_BadApprox; }
	int Coherent() { return m_Coherent; }
	int InCoherent() { return m_InCoherent; }
	int VPLsSampled() { return m_Sampled; }
	void CopyVPLBVH();
	// static methods
	static void InitSampleColor( SamplingPoint* p );
	static void FindNearest( const vector3& O, const vector3& D, Primitive*& a_Prim, float& a_Dist, float& a_U, float& a_V );
	static void FindOcclusion( const vector3& O, const vector3& D, Primitive*& a_Prim, float a_Dist );
	static VPLBVHNode* SubDivBVH( VPLBVHNode** list, int first, int last, int axis, int& next );
	static void BuildVPLBVH();
	static void CreateVPLs( Light* a_Light );
	static float AmbientOcclusion( const vector3& a_Pos, const vector3& a_N );
	static void CreateWingedEdges();
	static void LinkPointsToPolygons();
	static bool ValidPos( const vector3& a_Pos, const vector3& a_N );
	static void AddPointsOnEdges();
	static void CreateSamplingPoints( Light* a_Light );
	static bool FindInCell( const unsigned int a_Idx, const vector3& a_Pos, const vector3& a_N );
	static bool Occupied( const vector3& a_Pos, const vector3& a_N );
	static bool OccupiedRadius( const vector3& a_Pos, const vector3& a_N, float a_Dist );
	static void AddSample( SamplingPoint* p );
	static void RemoveSample( SamplingPoint* p );
	static void AddSample( const vector3& a_Pos, const vector3& a_N, const unsigned int a_Flags, const float a_Radius, int a_Idx );
	static void WhiteOut( Primitive* a_Prim );
	static void PrepareDynamics();
	static void UpdateDynamics();
	static void InitStatics();
	static void ResetStatics();
	static void CreateDartSources( Light* a_Light );
	static void LoadSamplingPoints();
	static void SaveColors();
	static void LoadColors();
	static void ApplyDirectLighting( Light* a_Light );
	static void UpdateDirectLighting( Light* a_Light, int a_Step );
	static void CombineLighting();
	static void OptimizeGrid();
	static Cell* GetSampleGrid() { return m_Grid; }
	static aabb& GetSceneExtends() { return m_Extends; }
	static unsigned int GetTotalSamples() { return m_Total; }
	static int GetNrSamples() { return m_Total; }
	static void AddInterior( const vector3& a_Pos ) { m_Interior[m_Interiors++] = a_Pos; }
	static void SetParams( char* a_DFile, float a_Dist, float a_Dot, float a_Brightness, int a_Attempts, float a_Sens, float a_AORad, float a_Rel ) 
	{ 
		m_DartsFile = new char[strlen( a_DFile ) + 1];
		strcpy( m_DartsFile, a_DFile );
		m_SampleDist = a_Dist; 
		m_SampleSqDist = a_Dist * a_Dist;
		m_SampleDot = a_Dot; 
		m_SearchDist = a_Dist * 2;
		m_Brightness = a_Brightness;
		m_Attempts = a_Attempts;
		m_Sensitivity = a_Sens;
		m_ReciSens = 1.0f / (1.0f - a_Sens);
		m_AORad = a_AORad;
		m_Relative = a_Rel;
		char t[256];
		sprintf( t, "gi params: %s, dist=%f, dot=%f, brightness=%f", a_DFile, a_Dist, a_Dot, a_Brightness );
		Log::Message( t );
	}
private:
	// static member variables
	static SamplingPoint* m_Sample;
	static Cell* m_Grid, **m_CList;
	static int m_Total, m_Filled;
	static vector3* m_Dart, *m_AmbRay;
	static unsigned int m_Darts, m_AmbRays; 
	static vector3* m_VPS, *m_VPSN, *m_VPL, *m_VPN;
	static __m128* m_VPcol;
	static int m_NrVPS, m_NrVPL;
	static vector3 m_EP1, m_EP2;
	static vector3 m_ESize, m_ERSize, m_ECSize;
	static vector3 m_ERad;
	static RayPacket* m_RP;
	static IData* m_ID;
	static int m_Cores;
public:
	static float m_SampleDist, m_SampleSqDist, m_SearchDist, m_SampleDot, m_Brightness;
	static int m_Attempts;
	static float m_Sensitivity, m_ReciSens, m_AORad, m_Relative;
private:
	static char* m_DartsFile;
	static VPLBVHNode* m_Root, *m_First;
	// non-static member variables
	int m_Thread, m_Sampled, m_SRays, m_Approx, m_BadApprox, m_Coherent, m_InCoherent;
	unsigned int raydir[8][3][2];
	union { __m128 masktable4[16]; unsigned int masktable[64]; };
	static aabb m_Extends;
	static vector3 m_Interior[10];
	static int m_Interiors;
	static Polygon* m_Poly;
	static int m_PCount;
	VPLBVHNode* m_LRoot, *m_LFirst;
};

}; // namespace Raytracer