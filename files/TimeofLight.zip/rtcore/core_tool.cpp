// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#include "precomp.h"

using namespace std;
using namespace Raytracer;

int filesize( FILE* f )
{
	int cp = ftell( f );
	fseek( f, 0, SEEK_END );
	int l = ftell( f );
	fseek( f, cp, SEEK_SET );
	return l;
}

bool isnewer( char* fname1, char* fname2 )
{
	HANDLE f = CreateFile( fname1, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL );
	if (f == INVALID_HANDLE_VALUE) return true;
	BY_HANDLE_FILE_INFORMATION fi1, fi2;
	GetFileInformationByHandle( f, &fi1 );
	CloseHandle( f );
	f = CreateFile( fname2, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL );
	if (f == INVALID_HANDLE_VALUE) return true;
	GetFileInformationByHandle( f, &fi2 );
	CloseHandle( f );
	long result = CompareFileTime( &fi1.ftLastWriteTime, &fi2.ftLastWriteTime );
	return (result == 1);
}

// -----------------------------------------------------------
// Log class implementation
// Store system messages
// -----------------------------------------------------------
Log::Log( char* a_File )
{
	#ifdef USE_CONSOLE
	RedirectIOToConsole();
	#endif
	m_File = new char[strlen( a_File ) + 1];
	strcpy( m_File, a_File );
	FILE* f = fopen( a_File, "w" ); // clear the file
	fprintf( f, "Logging started.\n" );
	if (f) fclose( f );
}

// -----------------------------------------------------------
// RedirectIOToConsole
// "Adding Console I/O to a Win32 GUI App", Windows Developer Journal, December 1997
// -----------------------------------------------------------
void Log::RedirectIOToConsole()
{
	static const WORD MAX_CONSOLE_LINES = 500;
	int hConHandle;
	long lStdHandle;
	CONSOLE_SCREEN_BUFFER_INFO coninfo;
	FILE *fp;
	// allocate a console for this app
	AllocConsole();
	// set the screen buffer to be big enough to let us scroll text
	GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE),
	&coninfo);
	coninfo.dwSize.Y = MAX_CONSOLE_LINES;
	SetConsoleScreenBufferSize(GetStdHandle(STD_OUTPUT_HANDLE),
	coninfo.dwSize);
	// redirect unbuffered STDOUT to the console
	lStdHandle = (long)GetStdHandle(STD_OUTPUT_HANDLE);
	hConHandle = _open_osfhandle(lStdHandle, _O_TEXT);
	fp = _fdopen( hConHandle, "w" );
	*stdout = *fp;
	setvbuf( stdout, NULL, _IONBF, 0 );
	// redirect unbuffered STDIN to the console
	lStdHandle = (long)GetStdHandle(STD_INPUT_HANDLE);
	hConHandle = _open_osfhandle(lStdHandle, _O_TEXT);
	fp = _fdopen( hConHandle, "r" );
	*stdin = *fp;
	setvbuf( stdin, NULL, _IONBF, 0 );
	// redirect unbuffered STDERR to the console
	lStdHandle = (long)GetStdHandle(STD_ERROR_HANDLE);
	hConHandle = _open_osfhandle(lStdHandle, _O_TEXT);
	fp = _fdopen( hConHandle, "w" );
	*stderr = *fp;
	setvbuf( stderr, NULL, _IONBF, 0 );
	// make cout, wcout, cin, wcin, wcerr, cerr, wclog and clog
	// point to console as well
	ios::sync_with_stdio();
}

void Log::Write( char* a_Txt, char* a_Data )
{
	FILE* f = fopen( m_File, "a" );
	if (f)
	{
		fprintf( f, "MSG:  %s\nDATA: %s\n", a_Txt, a_Data );
		fflush( f );
		fclose( f );
	}
	printf("MSG:  %s\nDATA: %s\n", a_Txt, a_Data );
}

void Log::Message( char* a_Txt )
{
	FILE* f = fopen( m_File, "a" );
	if (f)
	{
		fprintf( f, "%s\n", a_Txt );
		fflush( f );
		fclose( f );
	}
	printf("%s\n", a_Txt );
}

void Log::Message( char* a_Txt, char* a_Txt2 )
{
	FILE* f = fopen( m_File, "a" );
	if (f)
	{
		fprintf( f, "%s%s\n", a_Txt, a_Txt2 );
		fflush( f );
		fclose( f );
	}
	printf("%s%s\n", a_Txt, a_Txt2 );
}

void Log::IntValue( char* a_Txt, int a_Data )
{
	FILE* f = fopen( m_File, "a" );
	char t[64];
	sprintf( t, "%i", a_Data );
	if (f)
	{
		fprintf( f, "%s %s\n", a_Txt, t );
		fflush( f );
		fclose( f );
	}
	printf("%s %s\n", a_Txt, t );
}

void Log::FloatValue( char* a_Txt, float a_Data )
{
	FILE* f = fopen( m_File, "a" );
	char t[64];
	sprintf( t, "%f", a_Data );
	if (f)
	{
		fprintf( f, "%s %s\n", a_Txt, t );
		fflush( f );
		fclose( f );
	}
	printf("%s %s\n", a_Txt, t );
}

void Log::CharValue( char* a_Txt, char* a_Data )
{
	FILE* f = fopen( m_File, "a" );
	if (f)
	{
		fprintf( f, "%s %s\n", a_Txt, a_Data );
		fflush( f );
		fclose( f );
	}
	printf("%s %s\n", a_Txt, a_Data );
}

void Log::Error( char* a_Error, char* a_Param )
{
	Message( "halted for a catastrophic error:" );
	Message( a_Error, a_Param );
	MessageBox( NULL, a_Param, a_Error, MB_OK | MB_ICONINFORMATION );
	_exit( 0 );
}

// -----------------------------------------------------------
// Engine::IsVisible
// Checks if a 3D position is visible from the current camera
// -----------------------------------------------------------
bool Engine::IsVisible( const vector3& a_Pos, sint& a_X, sint& a_Y )
{
	const vector3 O = Scene::GetCamera()->GetPosition();
	const vector3 V = Scene::GetCamera()->GetTarget() - O;
	return IsVisible( a_Pos, O, V, a_X, a_Y );
}

// -----------------------------------------------------------
// Engine::IsVisible
// Checks if a 3D position is visible from the current camera
// -----------------------------------------------------------
bool Engine::IsVisible( const vector3& a_Pos, const vector3& a_Campos, const vector3& a_Camdir, sint& a_X, sint& a_Y )
{
	vector3 L = a_Pos - a_Campos;
	const float sqdist = L.x * L.x + L.y * L.y + L.z * L.z;
	NORMALIZE( L );
	Primitive* prim = 0;
	const float odist = Engine::Trace( a_Campos, L, prim );
	bool retval = (sqdist < (odist * odist));
	float d = DOT( a_Camdir, L );
	if (d > 0)
	{
		vector3 xaxis = Engine::GetP1() - Engine::GetP2();
		vector3 yaxis = Engine::GetP1() - Engine::GetP4();
		const float len1 = LENGTH( xaxis ), len2 = LENGTH( yaxis );
		xaxis *= 1.0f / (len1 * len1), yaxis *= 1.0f / (len2 * len2);
		const vector3 i = a_Campos + ((DOT( a_Camdir, a_Campos ) - DOT( a_Camdir, Engine::GetP1() )) / d) * L;
		a_X = (int)((float)m_Width * (DOT( i, xaxis ) - DOT( Engine::GetP2(), xaxis )));
		a_Y = (int)((float)m_Height * (DOT( i, yaxis ) - DOT( Engine::GetP4(), yaxis )));
		if ((a_X < 0) && (a_Y < 0) && (a_X >= m_Width) && (a_Y >= m_Height)) retval = false;
	}
	return retval;
}

// -----------------------------------------------------------
// Engine::Trace
// Sends a single ray through the kd-tree
// -----------------------------------------------------------
float Engine::Trace( const vector3& a_O, const vector3& a_D, Primitive*& a_Prim, Material** a_SkipList, int a_NumSkip )
{
	BVHStack stack[128];
	float dist = 10000;
	vector3 R( 1.0f / a_D.x, 1.0f / a_D.y, 1.0f / a_D.z );
	unsigned int stackptr = 0;
	BVHNode* node = SceneGraph::GetSceneRoot();
	Primitive** prim = MManager::GetBVHPrims();
	BVHNode* pool = MManager::GetBVHPool();
	while (1)
	{
		// see if ray intersects current node
		float tmin = 0.00001f, tmax = dist;
		for ( uint axis = 0; axis < 3; ++axis ) 
		{
			const float t0 = (node->min.cell[axis] - a_O.cell[axis]) * R.cell[axis];
			const float t1 = (node->max.cell[axis] - a_O.cell[axis]) * R.cell[axis];
			const float nr = (t0 < t1) ? t0 : t1, fr = (t0 < t1) ? t1 : t0;
			tmin = (tmin < nr) ? nr : tmin, tmax = (fr <  tmax) ? fr : tmax;
		}
		if (tmin <= tmax)
		{
			// walk tree
			if (!node->IsLeaf())
			{
				stack[stackptr++].node = &pool[node->GetLeft() + 1];
				node = &pool[node->GetLeft()];
				continue;
			}
			else
			{
				// intersect
				const uint start = node->GetStart(), count = node->GetTCount();
				for ( uint i = 0; i < count; ++i ) 
				{
					const Primitive* restrict pr = prim[start + i];
					const vector3 ao = pr->m_Vertex[0]->m_Pos - a_O;
					if ((ao.x * pr->m_N.x + ao.y * pr->m_N.y + ao.z * pr->m_N.z) < 0) continue;
					const vector3 bo = pr->m_Vertex[1]->m_Pos - a_O;
					const vector3 co = pr->m_Vertex[2]->m_Pos - a_O;
					const vector3 v1c = bo^ao, v2c = ao^co, v0c = co^bo;
					const float nominator = DOT( ao, pr->m_N );
					// intersection test
					const float v0d = DOT( v0c, a_D ), v1d = DOT( v1c, a_D ), v2d = DOT( v2c, a_D );
					if ((v0d > 0) && (v1d > 0) && (v2d > 0))
					{
						const float t = nominator * (1.0f / DOT( a_D, pr->m_N ));
						if ((t < dist) && (t >= 0)) 
						{
							bool skip = false;
							if (a_NumSkip) for ( int j = 0; j < a_NumSkip; j++ ) if (pr->GetMaterial() == a_SkipList[j]) skip = true;
							if (!skip)
							{
								a_Prim = (Primitive*)pr;
								dist = t;
							}
						}
					}
				}
			}
		}
		if (!stackptr) break;
		node = stack[--stackptr].node;
	}
	return dist;
}

// -----------------------------------------------------------
// Engine::TracePixel
// Trace a ray through a screen pixel
// -----------------------------------------------------------
float Engine::TracePixel( int x, int y, Primitive*& p )
{
	const vector3 I = m_P1 + ((m_P2 - m_P1) * ((float)x / (float)m_Width)) + ((m_P4 - m_P1) * ((float)y / (float)m_Height));
	const vector3 O = m_Origin, D = (I - O).Normalized();
	return Trace( O, D, p );
}

// -----------------------------------------------------------
// Engine::TraceEx
// Returns additional intersection data for a single ray
// -----------------------------------------------------------
void Engine::TraceEx( const vector3& a_O, const vector3& a_D, IData1& a_IData )
{
	BVHStack stack[128];
	a_IData.dist = 10000;
	a_IData.prim = 0;
	vector3 R( 1.0f / a_D.x, 1.0f / a_D.y, 1.0f / a_D.z );
	unsigned int stackptr = 0;
	BVHNode* node = SceneGraph::GetSceneRoot();
	Primitive** prim = MManager::GetBVHPrims();
	BVHNode* pool = MManager::GetBVHPool();
	while (1)
	{
		// see if ray intersects current node
		float tmin = 0.00001f, tmax = a_IData.dist;
		for ( uint axis = 0; axis < 3; ++axis ) 
		{
			const float t0 = (node->min.cell[axis] - a_O.cell[axis]) * R.cell[axis];
			const float t1 = (node->max.cell[axis] - a_O.cell[axis]) * R.cell[axis];
			const float nr = (t0 < t1) ? t0 : t1, fr = (t0 < t1) ? t1 : t0;
			tmin = (tmin < nr) ? nr : tmin, tmax = (fr <  tmax) ? fr : tmax;
		}
		if (tmin <= tmax)
		{
			// walk tree
			if (!node->IsLeaf())
			{
				stack[stackptr++].node = &pool[node->GetLeft() + 1];
				node = &pool[node->GetLeft()];
				continue;
			}
			else
			{
				// intersect
				const uint start = node->GetStart(), count = node->GetTCount();
				for ( uint i = 0; i < count; ++i ) 
				{
					const Primitive* restrict pr = prim[start + i];
					const vector3 ao = pr->m_Vertex[0]->m_Pos - a_O;
					if ((ao.x * pr->m_N.x + ao.y * pr->m_N.y + ao.z * pr->m_N.z) < 0) continue;
					const vector3 bo = pr->m_Vertex[1]->m_Pos - a_O;
					const vector3 co = pr->m_Vertex[2]->m_Pos - a_O;
					const vector3 v1c = bo^ao, v2c = ao^co, v0c = co^bo;
					const float nominator = DOT( ao, pr->m_N );
					// intersection test
					const float v0d = DOT( v0c, a_D ), v1d = DOT( v1c, a_D ), v2d = DOT( v2c, a_D );
					if ((v0d > 0) && (v1d > 0) && (v2d > 0))
					{
						const float t = nominator * (1.0f / DOT( a_D, pr->m_N ));
						if ((t < a_IData.dist) && (t >= 0)) 
						{
							a_IData.prim = (Primitive*)pr;
							a_IData.dist = t;
							const float div = 1.0f / (v0d + v1d + v2d);
							a_IData.u = v2d * div;
							a_IData.v = v1d * div;
						}
					}
				}
			}
		}
		if (!stackptr) break;
		node = stack[--stackptr].node;
	}
	if (a_IData.prim) a_IData.N = a_IData.prim->GetNormal( a_IData.u, a_IData.v );
}