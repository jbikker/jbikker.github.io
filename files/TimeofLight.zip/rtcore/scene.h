// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#pragma once

#include "common.h"
#include "string.h"
#include "bvh.h"

namespace Raytracer {

// -----------------------------------------------------------
// Texture class definition
// -----------------------------------------------------------

class Texture
{
public:
	Texture();
	void Init( unsigned int* a_Bitmap, unsigned int a_Width, unsigned int a_Height );
	void Init( char* a_File );
	void ConvertToHemisphere();
	void ConvertToNormalMap();
	void Combine( Texture* m_Normals );
	const char* GetName() const { return m_Name; }
	const unsigned int* GetBitmap() const { return m_B32; }
	const float* GetHDRData() const { return m_HDR; }
	const unsigned int* GetCombined() const { return m_TN32; }
	const unsigned int GetWidth() const { return m_Width; }
	const unsigned int GetHeight() const { return m_Height; }
	const unsigned int GetHMask() const { return m_HMask; }
	const unsigned int GetVMask() const { return m_VMask; }
	const unsigned int GetHShift() const { return m_HShift; }
	// data members
	union { __m128i m_HMask4; unsigned int m_AHMask[4]; };	// 16			16
	union { __m128i m_VMask4; unsigned int m_AVMask[4]; };	// 16			16
	unsigned int* m_B32;									// 4			8
	unsigned int* m_TN32;									// 4			8
	float* m_HDR;											// 4
	unsigned int m_Width, m_Height;							// 8			8
	unsigned int m_HMask, m_VMask, m_HShift;				// 12			12
	char* m_Name;											// 4
#ifndef _WIN64
	unsigned int dummy1, dummy2, dumm3;						// 12, totoal 80
#endif
};

// -----------------------------------------------------------
// Material class definition
// -----------------------------------------------------------

class Material
{
public:
	Material();
	~Material();
	void Init();
	void SetAmbient( const Color& a_Ambient );
	void SetDiffuse( const Color& a_Diff );
	void SetSpecular( const Color& a_Spec );
	void SetEmissive( const Color& a_Emis );
	void SetPhotonColor( const __m128 a_PCol ) { m_PColor = a_PCol; }
	void SetMinReflection( const float a_Refl ) { m_ReflLo = a_Refl; m_ReflLo4 = _mm_set_ps1( a_Refl ); }
	void SetMaxReflection( const float a_Refl ) { m_ReflHi = a_Refl; m_ReflHi4 = _mm_set_ps1( a_Refl ); }
	void SetRefraction( const float a_Refr ) { m_Refr = a_Refr; }
	void SetAbsorbance( const Color& a_Absorbance ) { m_Absorbance = a_Absorbance; }
	const Color GetAmbient() const { return m_Ambient; }
	const Color GetSpecular() const { return m_Spec; }
	const Color GetDiffuse() const { return m_Diff; }
	const Color GetEmissive() const { return m_Emis; }
	const Color GetAbsorbance() const { return m_Absorbance; }
	const __m128 GetPhotonColor() const { return m_PColor; }
	const __m128 GetAmbientRed4() const { return m_ARed4; }
	const __m128 GetAmbientGreen4() const { return m_AGreen4; }
	const __m128 GetAmbientBlue4() const { return m_ABlue4; }
	const __m128 GetDiffuseRed4() const { return m_DRed4; }
	const __m128 GetDiffuseGreen4() const { return m_DGreen4; }
	const __m128 GetDiffuseBlue4() const { return m_DBlue4; }
	const __m128 GetSpecularRed4() const { return m_SRed4; }
	const __m128 GetSpecularGreen4() const { return m_SGreen4; }
	const __m128 GetSpecularBlue4() const { return m_SBlue4; }
	const __m128 GetEmissiveRed4() const { return m_ERed4; }
	const __m128 GetEmissiveGreen4() const { return m_EGreen4; }
	const __m128 GetEmissiveBlue4() const { return m_EBlue4; }
	const __m128 GetDiffMask() const { return m_DMask; }
	const __m128 GetSpecMask() const { return m_SMask; }
	const float GetMinReflection() const { return m_ReflLo; }
	const float GetMaxReflection() const { return m_ReflHi; }
	const __m128 GetMinReflection4() const { return m_ReflLo4; }
	const __m128 GetMaxReflection4() const { return m_ReflHi4; }
	const float GetRefraction() const { return m_Refr; }
	void SetRefrIndex( const float a_Refr ) { m_RIndex = 1.0f / a_Refr; m_RIndex4 = _mm_set_ps1( m_RIndex ); }
	const float GetRefrIndex() const { return m_RIndex; }
	const __m128 GetRefrIndex4() const { return m_RIndex4; }
	void SetTexture( const Texture* a_Texture ) { m_Texture = (Texture*)a_Texture; }
	const Texture* GetTexture() const { return m_Texture; }
	void SetBumpMap( const Texture* a_Bumpmap ) { m_Bumpmap = (Texture*)a_Bumpmap; }
	const Texture* GetBumpMap() const { return m_Bumpmap; }
	void SetUVScale( const float a_UScale, float a_VScale );
	const float GetUScale() const { return m_UScale; }
	const float GetVScale() const { return m_VScale; }
	const float GetUScaleReci() const { return m_RUScale; }
	const float GetVScaleReci() const { return m_RVScale; }
	void SetName( char* a_Name );
	char* GetName() { return m_Name; }
	void SetIdx( unsigned int a_Idx ) { m_Idx = a_Idx; }
	unsigned int GetIdx() { return m_Idx; }
	const unsigned int GetAlpha() const { return m_Alpha; }
	void SetAlpha( unsigned int a_Alpha ) { m_Alpha = a_Alpha; }
	const unsigned int CastsShadow() const { return m_Shadow; }
	void SetShadow( unsigned int a_Shadow ) { m_Shadow = a_Shadow; }
private:
	Texture* m_Texture, *m_Bumpmap;						// 8
	unsigned int m_Shadow, m_Alpha;						// 8
	Color m_Ambient, m_Diff, m_Spec, m_Emis;			// 48
	Color m_Absorbance;									// 12
	__m128 m_PColor;									// 16
	__m128 m_ARed4, m_AGreen4, m_ABlue4;				// 48
	__m128 m_DRed4, m_DGreen4, m_DBlue4;				// 48
	__m128 m_SRed4, m_SGreen4, m_SBlue4;				// 48
	__m128 m_ERed4, m_EGreen4, m_EBlue4;				// 48
	__m128 m_DMask, m_SMask;							// 32
	__m128 m_ReflLo4, m_ReflHi4;						// 32
	__m128 m_RIndex4;									// 16
	float m_ReflLo, m_ReflHi, m_Refr;					// 16
	float m_RIndex;										// 4
	float m_UScale, m_VScale, m_RUScale, m_RVScale;		// 16
	char* m_Name;										// 4
	unsigned int m_Idx;									// 4
#ifndef _WIN64
	unsigned int dummy1, dumm2, dumm3;					// 8, total is 16 byte aligned
#else
	unsigned int dummy1, dummy2, dummy3;				// 12, total is 16 byte aligned
#endif

};

// -----------------------------------------------------------
// Material manager class definition
// -----------------------------------------------------------

class MatManager
{
public:
	MatManager();
	void LoadMTL( char* a_File );
	Material* FindMaterial( char* a_Name );
	Material* GetMaterial( int a_Idx ) { return m_Mat[a_Idx]; }
	void Reset() { m_NrMat = 0; }
	void AddMaterial( Material* a_Mat ) { m_Mat[m_NrMat++] = a_Mat; }
	unsigned int GetMatCount() { return m_NrMat; }
	void Finalize();
private:
	Material** m_Mat;				// 4					8
	unsigned int m_NrMat;			// 4					4
#ifndef _WIN32
	unsigned int dummy1;			// 4					
#endif
	unsigned int dummy2;			// 4, total 16 bytes	4, total 16 bytes
};

// -----------------------------------------------------------
// Vertex class definition
// -----------------------------------------------------------

class Vertex
{
public:
	Vertex() {};
	Vertex( vector3 a_Pos ) { m_Pos = a_Pos; }
	const vector3& GetNormal() const { return m_N; }
	const vector3& GetPos() const { return m_Pos; }
	void SetPos( const vector3& a_Pos ) { m_Pos = a_Pos; }
	void SetNormal( const vector3& a_N ) { m_N = a_N; }
	const float GetU() const { return m_U; }
	const float GetV() const { return m_V; }
	void SetUV( float a_U, float a_V ) { m_U = a_U; m_V = a_V; }
	void Transform( matrix& a_Mat, const vector3& a_Orig, const vector3& a_ONormal );
	// member data
	vector3 m_N;			// 12
	vector3 m_Pos;			// 12
	float m_U, m_V;			// 8, total 32
};

// -----------------------------------------------------------
// Light class definition
// -----------------------------------------------------------

class Light
{
public:
	Light() { m_Type = 0; m_Name = 0; /* i.e., not a 'multibeam', which is '1' */ };
	void Init( unsigned int a_Idx, char* a_Name, vector3& a_Pos, Color& a_Diffuse, Color& a_Specular, float a_Radius );
	void Init( unsigned int a_Idx, char* a_Name, vector3& a_P1, vector3& a_P2, vector3& a_P3, Color& a_Diffuse, Color& a_Specular, float a_Radius );
	void SetPos( vector3& a_Pos );
	void SetDirection( vector3& a_Dir );
	void SetDirection( unsigned int a_Idx, vector3& a_Dir );
	void SetWidth( float a_Width ) { m_Width = a_Width; m_Width4 = _mm_set_ps1( a_Width ); }
	void SetSpotSize( float a_Size ) { m_SWidth = a_Size; m_SWidth4 = _mm_set_ps1( a_Size ); }
	void SetShadows( bool a_Shadows ) { m_Shadows = a_Shadows?1:0; }
	void MultiBeam( bool a_MB ) { m_Type = (a_MB)?1:0; }
	const unsigned int IsMultiBeam() const { return m_Type; }
	const unsigned int Shadows() const { return m_Shadows; }
	const vector3& GetPos() const { return m_Pos; }
	const vector3& GetDirection() const { return m_Dir; }
	const vector3& GetDirection( int a_Idx ) { return m_BDir[a_Idx]; }
	const float GetWidth() const { return m_Width; }
	const __m128 GetWidth4() const { return m_Width4; }
	const float GetSpotSize() const { return m_SWidth; }
	const __m128 GetSpotSize4() const { return m_SWidth4; }
	const Color& GetDiffuse() const { return m_Diffuse; }
	const Color& GetSpecular() const { return m_Specular; }
	void SetDiffuse( Color& a_Diffuse );
	void SetSpecular( Color& a_Specular );
	void SetIndex( const unsigned int a_Index ) { m_Index = a_Index; }
	unsigned int GetIndex() const { return m_Index; }
	const __m128 GetDiffuseRed4() const { return m_DiffR4; }
	const __m128 GetDiffuseGreen4() const { return m_DiffG4; }
	const __m128 GetDiffuseBlue4() const { return m_DiffB4; }
	const __m128 GetSpecularRed4() const { return m_SpecR4; }
	const __m128 GetSpecularGreen4() const { return m_SpecG4; }
	const __m128 GetSpecularBlue4() const { return m_SpecB4; }
	void SetRadius( const float a_Radius );
	const float GetRadius() const { return m_Radius; }
	const float GetRRadius() const { return m_RRadius; }
	const __m128 GetRadius4() const { return m_Radius4; }
	const __m128 GetRRadius4() const { return m_RRadius4; }
	const char* GetName() const { return m_Name; }
	const unsigned int IsActive() const { return m_Active; }
	void Active( unsigned int a_Active ) { m_Active = a_Active; }
	void SetName( char* a_Name )
	{
		delete m_Name;
		m_Name = new char[strlen( a_Name ) + 1];
		strcpy( m_Name, a_Name );
	}
	// data members
	union { __m128 cx4; float cx[4]; };		// 16
	union { __m128 cy4; float cy[4]; };		// 16
	union { __m128 cz4; float cz[4]; };		// 16
	union { __m128 dx4; float dx[4]; };		// 16
	union { __m128 dy4; float dy[4]; };		// 16
	union { __m128 dz4; float dz[4]; };		// 16
#ifdef MULTIBEAM
	union { __m128 mdx4[MULTIBEAMDIRS]; float mdx[MULTIBEAMDIRS * 4]; }; // 256
	union { __m128 mdy4[MULTIBEAMDIRS]; float mdy[MULTIBEAMDIRS * 4]; }; // 256
	union { __m128 mdz4[MULTIBEAMDIRS]; float mdz[MULTIBEAMDIRS * 4]; }; // 256
#endif
private:
	__m128 m_DiffR4, m_DiffG4, m_DiffB4;	// 48
	__m128 m_SpecR4, m_SpecG4, m_SpecB4;	// 48
	__m128 m_Radius4, m_RRadius4;			// 32
	__m128 m_Width4, m_SWidth4;				// 32
	vector3 m_Pos;							// 12
	float m_RRadius;						// 4
	vector3 m_Dir;							// 12
	unsigned int m_Type;					// 4
	vector3 m_BDir[16];						// 192 (special, for light ball)
	unsigned int m_Shadows;					// 4
	float m_Radius, m_Width, m_SWidth;		// 12
	Color m_Diffuse, m_Specular;			// 32
	unsigned int m_Index;					// 4
	char* m_Name;							// 4
#ifndef _WIN32
	unsigned int dummy1;					// 4
#endif
	unsigned int m_Active;					// 4, total aligned on 16 byte boundary
};

// -----------------------------------------------------------
// Light list class definition
// -----------------------------------------------------------
class LightList
{
public:
	// ctor/dtor
	LightList() {}
	// data access
	Light* GetLight() const { return m_Light; }
	void SetLight( Light* a_Light ) { m_Light = a_Light; }
	LightList* GetNext() const { return m_Next; }
	void SetNext( LightList* a_Next ) { m_Next = a_Next; }
private:
	// data members
	Light* m_Light;
	LightList* m_Next;
};

// -----------------------------------------------------------
// LNode class definition
// -----------------------------------------------------------
class LNode
{
public:
	LNode() {}
	// data access
	LNode* GetLeft() const { return m_Left; }
	LNode* GetRight() const { return m_Right; }
	void SetLeft( LNode* a_Left ) { m_Left = a_Left; }
	void SetRight( LNode* a_Right ) { m_Right = a_Right; }
	float GetSplitPos() const { return m_Split; }
	void SetSplitPos( float a_Pos ) { m_Split = a_Pos; }
	LightList* GetLightList() const { return m_Light; }
	void SetLightList( LightList* a_List ) { m_Light = a_List; }
	unsigned int GetAxis() const { return m_Axis; }
	void SetAxis( unsigned int a_Axis ) { m_Axis = a_Axis; }
	// data members
	LNode* m_Left, *m_Right;		// 8		16
	unsigned int m_Axis;			// 4		4
	union
	{
		LightList* m_Light;			// 4		8
		float m_Split;
	};
};

// -----------------------------------------------------------
// Primitive class definition
// -----------------------------------------------------------

struct BVHNode;
class Primitive
{
public:
	enum
	{
		PRIM_TRI = 0,
		PRIM_SPHERE = 1
	};
	Primitive() : m_Type( PRIM_TRI ) {};
	void Init( Vertex* a_V1, Vertex* a_V2, Vertex* a_V3 );
	~Primitive();
	const Material* restrict GetMaterial() const { return m_Material; }
	void SetMaterial( const Material* restrict a_Mat ) { m_Material = (Material*)a_Mat; }
	// triangle primitive methods
	const vector3 GetNormal() const { return m_N; }
	void SetNormal( const vector3& a_N ) { m_N = a_N; }
	void SetType( unsigned int a_Type ) { m_Type = (a_Type & 0xfffffff0) + a_Type; }
	void SetData( unsigned int a_Data ) { m_Type = (a_Data << 4) + (m_Type & 15); }
	const unsigned int GetData() const { return m_Type >> 4; }
	const unsigned int GetType() const { return m_Type & 15; }
	void UpdateNormal();
	const Vertex* restrict GetVertex( const uint a_Idx ) const { return m_Vertex[a_Idx]; }
	void SetVertex( const uint a_Idx, Vertex* restrict a_Vertex ) { m_Vertex[a_Idx] = a_Vertex; }
	__forceinline const vector3 GetNormal( float u, float v ) const
	{
	#ifdef INTERPNORMALS
		const vector3 N1 = m_Vertex[0]->m_N, N2 = m_Vertex[1]->m_N, N3 = m_Vertex[2]->m_N;
		const float x = N1.x + u * (N2.x - N1.x) + v * (N3.x - N1.x);
		const float y = N1.y + u * (N2.y - N1.y) + v * (N3.y - N1.y);
		const float z = N1.z + u * (N2.z - N1.z) + v * (N3.z - N1.z);
		return vector3( x, y, z );
	#else
		return m_N;
	#endif
	}
	// helpers
	void CalcTangents();
	// data members
	vector3 m_N;							// 12 (doubles as centre)
	Vertex* m_Vertex[3];					// 12
	vector3 m_T, m_B;						// 24
	Material* m_Material;					// 4
private:
	unsigned int m_Type;					// 4, total 52
};

// -----------------------------------------------------------
// Subprim class definition
// -----------------------------------------------------------

class SubPrim
{
public:
	aabb bbox;			// 32
	Primitive* prim;	// 4, total 48
};

// -----------------------------------------------------------
// Camera class definition
// -----------------------------------------------------------

class Camera
{
public:
	Camera();
	vector3 GetPosition();
	vector3 GetTarget();
	void SetPosition( const vector3& a_Pos );
	void SetTarget( const vector3& a_Target );
	matrix& GetMatrix() { return m_Mat; }
	// student helper functions
	void Forward( float a_Dist );
	void Reverse( float a_Dist );
	void MoveUp( float a_Dist );
	void MoveDown( float a_Dist );
	void MoveLeft( float a_Dist );
	void MoveRight( float a_Dist );
	void RotateZ( float a_Angle );
	void RotateY( float a_Angle );
	void RotateX( float a_Angle );
	void ForceUpVector( vector3& a_Vec );
	// data members
private:
	vector3 m_Pos, m_Target;
	matrix m_Mat;
};

// -----------------------------------------------------------
// Scene class definition
// -----------------------------------------------------------

class LBVH;
class PhotonMapper;
class Scene
{
public:
	enum
	{
		ID_FACE = 0,
		ID_MTLLIB,
		ID_USEMTL,
		ID_VERTEX,
		ID_NORMAL,
		ID_UV,
		ID_EOF
	};
	Scene();
	~Scene();
	static void InitSceneState();
	static bool InitScene( const char* a_File = "scene.txt" );
	static const uint GetNrLights() { return m_Lights; }
	static const Light* GetLight( uint a_Idx ) { return m_Light[a_Idx]; }
	static const Light* GetLight( const char* a_Name );
	static Light** GetLights() { return m_Light; }
	static LBVH* GetLightBVH() { return m_LBVH; }
	static void AddLight( Light* a_Light ) { m_Light[m_Lights++] = a_Light; }
	static void RemoveLight( Light* a_Light );
	static void SetLight( const uint a_Idx, Light* a_Light ) { m_Light[a_Idx] = a_Light; }
	static void SetAmbient( const Color& a_Ambient ) { m_Ambient = a_Ambient; }
	static Color GetAmbient() { return m_Ambient; }
	static const aabb& GetExtends() { return m_Extends; }
	static void SetExtends( aabb a_Box ) { m_Extends = a_Box; }
	static void SetFog( float a_Top, Color& a_Color, float a_Density );
	static void EnableFog() { m_Fog = true; }
	static void DisableFog() { m_Fog = false; }
	static const bool FullScreen() { return m_Fullscreen; }
	static MatManager* GetMatManager() { return m_MatMan; }
	static Camera* GetCamera() { return &m_Camera; }
	static char* GetSceneName() { return m_Name; }
	static uint GetQuality() { return m_Quality; }
	static void UpdateSceneExtends();
	static void DoGIStuff();
private:
	static uint m_Primitives, m_MaxPrims, m_MaxSPrims, m_Lights;
	static char* m_Name;
	static Camera m_Camera;
	static Light** m_Light;
	static LBVH* m_LBVH;
	static aabb m_Extends;
	static MatManager* m_MatMan;
	static vector3 m_CamPos, m_CamTarget;
	static vector3 m_CamRot;
	static bool m_Fullscreen;
	static uint m_Quality;
	// state variable to split the init in bits
	static uint m_State;
public:
	// scene construction methods
	static void LoadOBJ( char* filename, Material* a_Material, matrix &a_Matrix );
	static void LoadBIN( char* filename, Material* a_Material );
	static void ConvertOBJ( char* filename, matrix &a_Matrix );
	// data access
	static const vector3& GetCamPos() { return m_CamPos; }
	static const vector3& GetCamTarget() { return m_CamTarget; }
	static void GetCamRot( float& a_XRot, float& a_YRot, float& a_ZRot ); 
	// fog variables
	static __m128 m_FogTop4, m_FogDensity4;
	static float m_FogTop, m_FogDensity;
	static Color m_FogColor, m_Ambient;
	static bool m_Fog, m_GI, m_GIcolors, m_GIpoints;
	// sky dome
	static Primitive* m_Dome;
	static float m_SDScale;
};

}; // namespace Raytracer