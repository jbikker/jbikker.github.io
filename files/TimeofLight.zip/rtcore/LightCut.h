#pragma once

#include "common.h"

namespace Raytracer {

class VPL;
class LightCutNode;

class LightCutHeapEntry
{
public:
	LightCutNode* n;
	float err;
	LightCutHeapEntry(LightCutNode* n_, float err_)
	{
		n = n_;
		err = err_;
	}
	
	LightCutHeapEntry()
	{
	}

	bool operator >=(const LightCutHeapEntry& n) const {	return err >= n.err; }
	bool operator >(const LightCutHeapEntry& n) const {	return err > n.err; }
	bool operator <(const LightCutHeapEntry& n) const {	return err < n.err; }
	bool operator <=(const LightCutHeapEntry& n) const {	return err <= n.err; }
	bool operator ==(const LightCutHeapEntry& n) const {	return err == n.err; }
};

template<class T, int n>
class MaxHeap
{
public:
	T h[n];
	int nheap;

public:
	MaxHeap() : nheap(0)
	{
		//std::ostream
	}

	void clear()
	{
		nheap = 0;
	}

	void add(const T& e)
	{
		//add it to the heap
		h[nheap++] = e;

		//fix heap
		for(int i=nheap-1; i!=0; )
		{
			int p=(i-1)/2;
			if (!(h[p] >= h[i]))		//heap violated?
			{
				T temp=h[i];			//then swap
				h[i]=h[p];
				h[p]=temp;
			}
			else
				break;
			i=p;
		}
	}

	T maxElement()
	{
		return h[0];
	}

	//16:10, spoor 6
	void removeRoot()
	{
		//remove node
		h[0] = h[--nheap];

		//fix heap
		for(int i=0;;)
		{
			const int c=i*2+1;
			if (c >= nheap)										//no children
			{
				break;
			}

			if (c+1 == nheap)									//one child
			{
				if (h[i] < h[c])
				{
					T temp=h[c];				//swap
					h[c]=h[i];
					h[i]=temp;
				}
				break;
			}

			if (h[i] < h[c+1] || h[i] < h[c])	//smaller than one of its children?	454ms 453ms 453ms
			//if (h[i] < h[c] || h[i] < h[c+1] )	//smaller than one of its children? 469ms
			{
				if (h[c+1] >= h[c])						//biggest or equal kid is c+1?
				{
					T temp=h[c+1];				//then swap
					h[c+1]=h[i];
					h[i]=temp;
					i=c+1;
					continue;
				}
				else											//smaller kid is c
				{
					T temp=h[c];				//swap
					h[c]=h[i];
					h[i]=temp;
					i=c;
					continue;
				}
			}
			else
				break;
		}
	}
};

class LightCut
{
public:
	LightCutNode* root;
public:
	LightCut(void);
	~LightCut(void);

	void build(VPL* vpl, int m_NrVPL);
	//void makeVPLs(int& n, VPL** vpl, LightCutNode* node, int depth, VPL* pool, int& npool);
};

class VPL
{
public:
	__m128 color;
	vector3 position;
	vector3 normal;
	int fill, fill2;

	VPL(const vector3& pos,const vector3& nor,__m128 col) : position(pos), normal(nor), color(col)
	{
	}
	
	VPL()
	{
	}
};

class LightCutNode
{
public:
_declspec(align(16)) 
	__m128 totlight;
	aabb box;
	VPL* reprlight;
	LightCutNode *left,*right;
	int fill;

	__m128 updateLight()
	{
		//printf("%d\n",sizeof(LightCutNode));
		//printf("%x\n",&totlight);
		//printf("%x\n",&totlight);
		if (left!=0)
		{
			totlight = left->updateLight();
			totlight = _mm_add_ps( totlight, right->updateLight() );
		}
		else
		{
			totlight = reprlight->color;
		}
		return totlight;
	}

	void printtest1()
	{
		if (left==0)
		{
			printf(reprlight->fill==1?"1":"0");
			return;		
		}
		left->printtest();
		right->printtest();
	}

	void printtest()
	{
		if (leadsToVVPL())
		{
			printf("1");
			if (left!=0)
			{
				left->printtest();
				right->printtest();
			}
		}
		else
			printf("0");
	}

	bool leadsToVVPL()
	{
		if (left==0)
			return reprlight->fill==1;
		return left->leadsToVVPL() | right->leadsToVVPL();
	}

	//returns the value of the metric when `l' would have been added
	float getNewMetric(const LightCutNode& l)
	{
		aabb newbox = aabb::merge(box,l.box);

		return (newbox.m_P1-newbox.m_P2).SqrLength();
	}

	//creates a parent of left and right
	LightCutNode(LightCutNode* left_, LightCutNode* right_)
	{
		//printf("i %x point to %x and %x\n",this,left,right);
		left = left_;
		right = right_;
		box = aabb::merge(left_->box, right_->box);
		reprlight = rand()%2==0 ? left->reprlight : right->reprlight;
	}

	//creates a lightcutnode-leaf that represents the single light `vpl'
	LightCutNode(VPL* vpl) : reprlight(vpl), left(0), right(0)
	{
		box = aabb::FromPosSize(vpl->position,vector3(0,0,0));	//point-sized aabb
	}

	LightCutNode()
	{		
	}


};

}; // namespace Raytracer