// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#pragma once

#include <iostream>	//roel hacks

namespace Raytracer {

class vector3
{
public:
	vector3() : x( 0.0f ), y( 0.0f ), z( 0.0f ) {};
	vector3( float a_X, float a_Y, float a_Z ) : x( a_X ), y( a_Y ), z( a_Z ) {};
	void Set( float a_X, float a_Y, float a_Z ) { x = a_X; y = a_Y; z = a_Z; }
	void Normalize() { float l = 1.0f / Length(); x *= l; y *= l; z *= l; }
	const vector3 Normalized() { float l = 1.0f / Length(); return vector3( x * l, y * l, z * l ); }
	float Length() const { return (float)sqrt( x * x + y * y + z * z ); }
	float SqrLength() const { return x * x + y * y + z * z; }
	vector3 Perp( vector3& a, vector3& axis);
	vector3 Parallel( vector3& a, vector3& axis );
	float Dot( vector3 a_V ) const { return x * a_V.x + y * a_V.y + z * a_V.z; }
	vector3 Cross( vector3 v ) const { return vector3( y * v.z - z * v.y, z * v.x - x * v.z, x * v.y - y * v.x ); }
	vector3 RotateAround( vector3& a_Axis, float a_Angle );
	vector3 Perpendicular();
	static vector3 Min(const vector3& a, const vector3& b)
	{
		return vector3( a.x < b.x ? a.x : b.x, a.y < b.y ? a.y : b.y, a.z < b.z ? a.z : b.z );
	}
	static vector3 Max(const vector3& a, const vector3& b)
	{
		return vector3( a.x > b.x ? a.x : b.x, a.y > b.y ? a.y : b.y, a.z > b.z ? a.z : b.z );
	}

	float Distance( vector3 p1, vector3 p2 );
	float SqDistance( vector3 p1, vector3 p2 );
	void operator += ( const vector3& a_V ) { x += a_V.x; y += a_V.y; z += a_V.z; }
	void operator += ( vector3* a_V ) { x += a_V->x; y += a_V->y; z += a_V->z; }
	void operator -= ( const vector3& a_V ) { x -= a_V.x; y -= a_V.y; z -= a_V.z; }
	void operator -= ( vector3* a_V ) { x -= a_V->x; y -= a_V->y; z -= a_V->z; }
	void operator *= ( const float f ) { x *= f; y *= f; z *= f; }
	void operator *= ( const vector3& a_V ) { x *= a_V.x; y *= a_V.y; z *= a_V.z; }
	void operator *= ( vector3* a_V ) { x *= a_V->x; y *= a_V->y; z *= a_V->z; }
	float& operator [] ( int a_N ) { return cell[a_N]; }
	vector3 operator- () const { return vector3( -x, -y, -z ); }
	friend vector3 operator + ( const vector3& v1, const vector3& v2 ) { return vector3( v1.x + v2.x, v1.y + v2.y, v1.z + v2.z ); }
	friend vector3 operator + ( const vector3& v1, vector3* v2 ) { return vector3( v1.x + v2->x, v1.y + v2->y, v1.z + v2->z ); }
	friend vector3 operator - ( const vector3& v1, const vector3& v2 ) { return vector3( v1.x - v2.x, v1.y - v2.y, v1.z - v2.z ); }
	friend vector3 operator - ( const vector3& v1, vector3* v2 ) { return vector3( v1.x - v2->x, v1.y - v2->y, v1.z - v2->z ); }
	friend vector3 operator - ( const vector3* v1, vector3& v2 ) { return vector3( v1->x - v2.x, v1->y - v2.y, v1->z - v2.z ); }
	// friend vector3 operator - ( const vector3* v1, vector3* v2 ) { return vector3( v1->x - v2->x, v1->y - v2->y, v1->z - v2->z ); }
	friend vector3 operator ^ ( const vector3& A, const vector3& B ) { return vector3(A.y*B.z-A.z*B.y,A.z*B.x-A.x*B.z,A.x*B.y-A.y*B.x); }
	friend vector3 operator ^ ( const vector3& A, vector3* B ) { return vector3(A.y*B->z-A.z*B->y,A.z*B->x-A.x*B->z,A.x*B->y-A.y*B->x); }
	friend vector3 operator * ( const vector3& v, const float f ) { return vector3( v.x * f, v.y * f, v.z * f ); }
	friend vector3 operator * ( const vector3& v1, const vector3& v2 ) { return vector3( v1.x * v2.x, v1.y * v2.y, v1.z * v2.z ); }
	friend vector3 operator * ( const float f, const vector3& v ) { return vector3( v.x * f, v.y * f, v.z * f ); }
	friend vector3 operator / ( const vector3& v, const float f ) { return vector3( v.x / f, v.y / f, v.z / f ); }
	friend vector3 operator / ( const vector3& v1, const vector3& v2 ) { return vector3( v1.x / v2.x, v1.y / v2.y, v1.z / v2.z ); }
	friend vector3 operator / ( const float f, const vector3& v ) { return vector3( v.x / f, v.y / f, v.z / f ); }
	bool operator == ( const vector3& a_V ) const { if((x==a_V.x)&&(y==a_V.y)&&(z==a_V.z)) return true; return false; }
	bool operator == ( const vector3* a_V ) const { if((x==a_V->x)&&(y==a_V->y)&&(z==a_V->z)) return true; return false; }
	bool operator != ( const vector3& a_V ) const { if((x==a_V.x)&&(y==a_V.y)&&(z==a_V.z)) return false; return true; }
	bool operator != ( const vector3* a_V ) const { if((x==a_V->x)&&(y==a_V->y)&&(z==a_V->z)) return false; return true; }
	friend std::ostream& operator <<(std::ostream &os, const vector3& v)	//roel
	{
		return os<<"("<<v.x<<","<<v.y<<","<<v.z<<")";
	}
private:
	int MinAxis() { return (fabs(x)<=fabs(y)?((fabs(x)<=fabs(z))?0:2):((fabs(y)<=fabs(z))?1:2)); }
public:
	union
	{
		struct { float x, y, z; };
		struct { float cell[3]; };
	};
};

class RayPacket64;
class aabb
{
private:
	aabb( const vector3& min, const vector3& max ) : m_P1( min ), m_P2( max ) {};

public:
	aabb() : m_P1( vector3( 0, 0, 0 ) ), m_P2( vector3( 0, 0, 0 ) ) {};
	static aabb FromPosSize(const vector3& a_Pos, const vector3& a_Size)
	{
		return aabb(a_Pos, a_Pos + a_Size );
	}
	static aabb FromMinMax(const vector3& min, const vector3& max)
	{
		return aabb(min, max);
	}
	vector3& GetPos() { return m_P1; }
	vector3& GetP1() { return m_P1; }
	vector3& GetP2() { return m_P2; }
	void SetP1( vector3& a_P1 ) { m_P1 = a_P1; }
	void SetP2( vector3& a_P2 ) { m_P2 = a_P2; }
	const vector3 GetSize() const { return vector3( w(), h(), d() ); }
	bool Intersect( aabb& b2 ) const;
	bool Intersect( const vector3& C, const float r );
	bool Intersect( const vector3& C, const vector3& N, const float r );
	bool Intersect( RayPacket64* rp, unsigned int r, float t0, float t1 );
	bool Contains( vector3 a_Pos ) const;
	void BuildFrom( vector3& p1, vector3& p2, vector3& p3 );
	const float area() const { return 2.0f * (w() * h() + w() * d() + d() * h()); }
	const float w() const { return m_P2.x - m_P1.x; }
	const float h() const { return m_P2.y - m_P1.y; }
	const float d() const { return m_P2.z - m_P1.z; }
	const float x() const { return m_P1.x; }
	const float y() const { return m_P1.y; }
	const float z() const { return m_P1.z; }
	const float Centre( int a_Axis ) const { return (m_P1.cell[a_Axis] + m_P2.cell[a_Axis]) * 0.5f; }
	float& Min( int a_Axis ) { return m_P1.cell[a_Axis]; }
	float& Max( int a_Axis ) { return m_P2.cell[a_Axis]; }
	const int LongestSide() const;
	aabb merge(const aabb& b)
	{
		m_P1=vector3::Min(m_P1, b.m_P1);
		m_P2=vector3::Max(m_P2, b.m_P2);
		return *this;
	}
	static aabb merge(const aabb& a, const aabb& b)
	{
		return aabb::FromMinMax(vector3::Min(a.m_P1,b.m_P1), vector3::Max(a.m_P2,b.m_P2));
	}
	//returns the shortest distance from p to the aabb. 0 for a p inside the box.
	float squaredDistance(const vector3& p) const;
	vector3 m_P1, m_P2;
};

class plane
{
public:
	plane() : N( 0, 0, 0 ), D( 0 ) {};
	plane( vector3 a_Normal, float a_D ) : N( a_Normal ), D( a_D ) {};
	vector3 N;
	float D;
};

class matrix
{
public:
	enum 
	{ 
		TX=3, 
		TY=7, 
		TZ=11, 
		D0=0, D1=5, D2=10, D3=15, 
		SX=D0, SY=D1, SZ=D2, 
		W=D3 
	};
	matrix() { Identity(); }
	float& operator [] ( int a_N ) { return cell[a_N]; }
	void Identity();
	void Rotate( vector3 a_Pos, float a_RX, float a_RY, float a_RZ );
	void RotateX( float a_RX );
	void RotateY( float a_RY );
	void RotateZ( float a_RZ );
	void Translate( vector3 a_Pos ) { cell[TX] += a_Pos.x; cell[TY] += a_Pos.y; cell[TZ] += a_Pos.z; }
	void SetTranslation( vector3 a_Pos ) { cell[TX] = a_Pos.x; cell[TY] = a_Pos.y; cell[TZ] = a_Pos.z; }
	void Normalize();
	void Concatenate( matrix& m2 );
	vector3 Transform( const vector3& v );
	vector3 GetTranslation() { return vector3(cell[TX], cell[TY], cell[TZ]); }
	void Invert();
	float cell[16];
};

class quaternion
{
public:
	quaternion();
	void ConvertToMatrix( matrix& a_Mat );
	float Length();
	void Normalize();
	void CreateFromAxisAngle( const vector3& a_Axis, const float a_Angle );
	quaternion operator * ( const quaternion &q );
private:
	float x, y, z, w;
};

struct quat4
{
	union
	{
		struct { float x, y, z, w; };
		float q[4];
	};
	quat4() : x(0.0f),y(0.0f),z(0.0f),w(1.0f) {}
	quat4( float X, float Y, float Z, float W) : x(X),y(Y),z(Z),w(W){}
	inline float Length() const { return sqrt( x * x + y * y + z * z + w * w );}
	inline float LengthSq() const { return (x*x + y*y + z*z + w*w);}
	inline void ComputeW();
	inline void Normalize();
	inline float Dot( const quat4& q4 ) const;
	inline quat4 GetReverse() const;
	inline quat4 MultQuat( const quat4& q4 ); 
	inline quat4 MultVec( const vector3& v3 );
	inline vector3 quat4::quat4RotatePoint( const vector3 in );
	operator const float*() { return q; }
	const void operator += ( const quat4 &a_V ) { x += a_V.x; y += a_V.y; z += a_V.z; w += a_V.w; }
	const void operator -= ( const quat4 &a_V ) { x -= a_V.x; y -= a_V.y; z -= a_V.z; w -= a_V.w; }
	const void operator *= ( const float &a_F ) { x *= a_F; y *= a_F; z *= a_F; w *= a_F; }
	bool operator == ( const quat4& a_Q ) const { return ((x == a_Q.x) && (y == a_Q.y) && (z == a_Q.z) && (w == a_Q.w)); }
	bool operator != ( const quat4& a_Q ) const { return ((x != a_Q.x) || (y != a_Q.y) || (z != a_Q.z) || (w != a_Q.w)); }
 
};

inline quat4 operator*(const quat4 &lhs, float rhs);
inline quat4 operator*(float lhs, const quat4 &rhs);
inline quat4 operator*(const quat4 &lhs, const vector3 &v);
inline quat4 operator*(const quat4 &lhs, const quat4 &rhs);
inline quat4 operator-(const quat4 &lhs, const quat4 &rhs);
inline quat4 operator+(const quat4 &lhs, const quat4 &rhs);
inline quat4 operator/(const quat4 &lhs, float rhs);

inline void quat4::ComputeW()
{
	float t = 1.0f - (x * x) - (y * y) - (z * z);
	if (t < 0.0f) w = 0.0f; else w = -sqrt(t);
}

inline void quat4::Normalize()
{ 
	float vector_length = this->Length();
	if (vector_length > 0)
	{
		this->x /= vector_length;
		this->y /= vector_length;
		this->z /= vector_length;
		this->w /= vector_length;
	}
}

inline float quat4::Dot( const quat4 &q4 ) const
{
	return x * q4.x + y * q4.y + z * q4.z + w * q4.w;
}

inline quat4 quat4::GetReverse() const
{
	return quat4(-this->x, -this->y, -this->z, this->w);
}

inline quat4 quat4::MultQuat( const quat4& q4 )
{
	quat4 q;
	q.x = (x * q4.w) + (w * q4.x) + (y * q4.z) - (z * q4.y);
	q.y = (y * q4.w) + (w * q4.y) + (z * q4.x) - (x * q4.z);
	q.z = (z * q4.w) + (w * q4.z) + (x * q4.y) - (y * q4.x);
	q.w = (w * q4.w) - (x * q4.x) - (y * q4.y) - (z * q4.z);
	return q;
}

inline quat4 quat4::MultVec( const vector3& v3 )
{
	quat4 q;
	q.x =    (w * v3.x) + (y * v3.z) - (z * v3.y);
	q.y =    (w * v3.y) + (z * v3.x) - (x * v3.z);
	q.z =    (w * v3.z) + (x * v3.y) - (y * v3.x);
	q.w =  - (x * v3.x) - (y * v3.y) - (z * v3.z);
	return q;
}

inline vector3 quat4::quat4RotatePoint( const vector3 in )
{
	quat4 inv = GetReverse();
	inv.Normalize();
	quat4 final = MultVec( in ).MultQuat( inv );
	return vector3( final.x, final.y, final.z );
}

inline quat4 quat4Normalize( const quat4 &q )
{
	quat4 quat = q;
	float vector_length = quat.Length();
	if (vector_length > 0)
	{
		quat.x /= vector_length;
		quat.y /= vector_length;
		quat.z /= vector_length;
		quat.w /= vector_length;
	}
	return quat;
}

inline float quat4Length( const quat4& q )
{
	return sqrt(q.x*q.x + q.y*q.y + q.z*q.z + q.w*q.w);
}

inline float quat4LengthSq( const quat4& q )
{
	return (q.x*q.x + q.y*q.y + q.z*q.z + q.w*q.w);
}

inline quat4 quat4MultQuat( const quat4 qa, const quat4 qb )
{
	quat4 q;
	q.x = (qa.x * qb.w) + (qa.w * qb.x) + (qa.y * qb.z) - (qa.z * qb.y);
	q.y = (qa.y * qb.w) + (qa.w * qb.y) + (qa.z * qb.x) - (qa.x * qb.z);
	q.z = (qa.z * qb.w) + (qa.w * qb.z) + (qa.x * qb.y) - (qa.y * qb.x);
	q.w = (qa.w * qb.w) - (qa.x * qb.x) - (qa.y * qb.y) - (qa.z * qb.z);
	return q;
}

inline quat4 quat4MultVec( const quat4 q4, const vector3 v3 )
{
	quat4 q;
	q.x =    (q4.w * v3.x) + (q4.y * v3.z) - (q4.z * v3.y);
	q.y =    (q4.w * v3.y) + (q4.z * v3.x) - (q4.x * v3.z);
	q.z =    (q4.w * v3.z) + (q4.x * v3.y) - (q4.y * v3.x);
	q.w =  - (q4.x * v3.x) - (q4.y * v3.y) - (q4.z * v3.z);
	return q;
}

inline vector3 quat4RotatePoint( const quat4 q, const vector3 v )
{
	quat4 final= q * v * q.GetReverse();
	return vector3( final.x, final.y, final.z );
}

inline quat4 quat4Multiply( const quat4 q1, const quat4 q2 )
{
	quat4 result;
	result.x = q1.w * q2.x + q1.x * q2.w + q1.y * q2.z - q1.z * q2.y;
	result.y = q1.w * q2.y + q1.x * q2.z + q1.y * q2.w - q1.z * q2.x;
	result.z = q1.w * q2.z + q1.x * q2.y + q1.y * q2.x - q1.z * q2.w;
	result.w = q1.w * q2.w + q1.x * q2.x + q1.y * q2.y - q1.z * q2.z;
	return result;
}

inline vector3 quat4RotateVec( const vector3 Vec, const float theta, const float x, const float y, const float z )
{
	float sintheta = sin( theta / 2 );
	quat4 temp(x * sintheta, y * sintheta, z * sintheta, cos( theta / 2 ) );
	quat4 qview( Vec.x, Vec.y, Vec.z, 0.0f );
	quat4 final = quat4Multiply( quat4Multiply( temp, qview ), temp.GetReverse() );
	return vector3( final.x, final.y, final.z );
}

inline quat4 quat4Slerp( const quat4 qa, const quat4 qb, float t )
{
	if (t <= 0.0) return qa; else if (t >= 1.0) return qb;
	quat4 out;
	float cosOmega = qa.Dot(qb);
	float q1w = qb.w, q1x = qb.x, q1y = qb.y, q1z = qb.z;
	if (cosOmega < 0.0f)
	{
		q1w = -q1w, q1x = -q1x, q1y = -q1y, q1z = -q1z;
		cosOmega = -cosOmega;
	}
	float k0, k1;
	if (cosOmega > 0.9999f)
	{
		k0 = 1.0f - t;
		k1 = t;
	}
	else
	{
		float sinOmega = sqrt (1.0f - (cosOmega * cosOmega));
		float omega = atan2 (sinOmega, cosOmega);
		float oneOverSinOmega = 1.0f / sinOmega;
		k0 = sin ((1.0f - t) * omega) * oneOverSinOmega;
		k1 = sin (t * omega) * oneOverSinOmega;
	}
	out.x = (k0 * qa.x) + (k1 * q1x);
	out.y = (k0 * qa.y) + (k1 * q1y);
	out.z = (k0 * qa.z) + (k1 * q1z);
	out.w = (k0 * qa.w) + (k1 * q1w);
	return out;
}

inline quat4 operator * ( const quat4 &lhs, float rhs )
{
	quat4 result( lhs );
	result *= rhs;
	return result;
}

inline quat4 operator * ( float lhs, const quat4 &rhs )
{
	quat4 result( rhs );
	result *= lhs;
	return result;
}

inline quat4 operator * ( const quat4 &lhs, const vector3 &v )
{
	return quat4(
		(lhs.w * v.x) + (lhs.y * v.z) - (lhs.z * v.y),
		(lhs.w * v.y) + (lhs.z * v.x) - (lhs.x * v.z),
		(lhs.w * v.z) + (lhs.x * v.y) - (lhs.y * v.x),
		-(lhs.x * v.x) - (lhs.y * v.y) - (lhs.z * v.z)
	);
}

inline quat4 operator * (const quat4 &lhs, const quat4 &rhs )
{
	return quat4(
		(lhs.x * rhs.w) + (lhs.w * rhs.x) + (lhs.y * rhs.z) - (lhs.z * rhs.y),
		(lhs.y * rhs.w) + (lhs.w * rhs.y) + (lhs.z * rhs.x) - (lhs.x * rhs.z),
		(lhs.z * rhs.w) + (lhs.w * rhs.z) + (lhs.x * rhs.y) - (lhs.y * rhs.x),
		(lhs.w * rhs.w) - (lhs.x * rhs.x) - (lhs.y * rhs.y) - (lhs.z * rhs.z)
	);
}

inline quat4 operator - ( const quat4 &lhs, const quat4 &rhs )
{
	quat4 result(lhs);
	result.x -= rhs.x;
	result.y -= rhs.y;
	result.z -= rhs.z;
	result.w -= rhs.w;
	return result;
}

inline quat4 operator + ( const quat4 &lhs, const quat4 &rhs )
{
	quat4 result(lhs);
	result.x += rhs.x;
	result.y += rhs.y;
	result.z += rhs.z;
	result.w += rhs.w;
	return result;
}

}; // namespace Raytracer
