// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#include "precomp.h"

namespace Raytracer {

wallclock_t STimer;

Node** SceneGraph::m_Node;
unsigned int SceneGraph::m_NCount;
BVHNode* SceneGraph::m_BVHRoot;
int SceneGraph::m_BVHFirst;
	
Node::Node()
{
	m_Prim = 0;
	m_OPrim = 0;
	m_VPool = 0;
	m_PCount = 0;
	m_Mat = matrix();
	m_Builder = 0;
	m_Type = STATIC;
	m_Constructed = false;
	m_Active = true;
}

Node::Node( int a_PCount )
{
	m_Prim = new Primitive*[a_PCount];
	m_OPrim = new Primitive*[a_PCount];
	m_VPool = 0;
	m_Mat = matrix();
	m_Builder = 0;
	m_PCount = 0;
	m_Type = STATIC;
	m_Constructed = false;
	m_Active = true;
}

void Node::Add( Primitive* a_Prim )
{ 
	m_OPrim[m_PCount] = a_Prim;
	m_Prim[m_PCount] = MManager::NewPrimitive();
	Vertex* ov0 = new Vertex(); *ov0 = *a_Prim->GetVertex( 0 );
	Vertex* ov1 = new Vertex(); *ov1 = *a_Prim->GetVertex( 1 );
	Vertex* ov2 = new Vertex(); *ov2 = *a_Prim->GetVertex( 2 );
	m_Prim[m_PCount]->SetMaterial( a_Prim->GetMaterial() );
	m_Prim[m_PCount++]->Init( ov0, ov1, ov2 );
}

Node::Node( char* a_Obj, vector3 a_Pos, float a_Scale )
{
	m_OPrim = 0;
	m_PCount = 0;
	m_VPool = 0;
	Load( a_Obj, a_Scale );
	m_Mat = matrix();
	m_Mat.SetTranslation( a_Pos );
	m_Type = STATIC;
	m_Builder = 0;
	m_Constructed = false;
	m_Active = true;
}

Node::~Node()
{
	delete m_Prim;
	delete m_OPrim;
	delete m_VPool;
	delete m_Builder;
	m_Prim = 0;
	m_OPrim = 0;
	m_VPool = 0;
	m_Builder = 0;
}

void Node::BuildBVH()
{
	if (!m_Builder) 
	{
		if (m_Type == SPECIAL) m_Builder = new AgglomerativeBuilder( this );
		if (m_Type == STATIC) m_Builder = new StaticBuilder( this );
		if ((m_Type == DYNAMIC) || (m_Type == REFITTABLE)) m_Builder = new ThreadedBuilder( this );
	}
	m_Builder->Build();
}

void Node::Refit()
{
	m_Builder->Refit();
}

void Node::Optimize()
{
#ifdef ALTFIRST
	m_Builder->UpdateDirMasks();
#endif
}

void Node::NewFormat()
{
	// m_Builder->NewFormat();
}

void Node::Load( char* a_Obj, float a_Scale )
{
	Log::Message(a_Obj);

	// count faces in file
	FILE* f = fopen( a_Obj, "r" );
	if (!f) Log::Error( "Could not load dynamic object", a_Obj );
	unsigned int fcount = 0, ncount = 0, uvcount = 0, vcount = 0;
	char buffer[256];
	char cmd[32], objname[128];
	while (1)
	{
		fgets( buffer, 250, f );
		if (feof( f )) break;
		sscanf( buffer, "%s", cmd );
		if (!strcmp( cmd, "v" )) vcount++;
		else if (!strcmp( cmd, "vt" )) uvcount++;
		else if (!strcmp( cmd, "vn" )) ncount++;
		else if (!strcmp( cmd, "f" )) fcount++;
	}
	fclose( f );
	// allocate arrays
	unsigned int verts = 0, uvs = 0, normals = 0, currvert = 0;
	m_Prim = new Primitive*[fcount];
	m_OPrim = new Primitive*[fcount];
	Primitive* prims = (Primitive*)MALLOC64( sizeof( Primitive ) * fcount * 2 );
	m_PCount = 0;
	vector3* vert = new vector3[vcount];
	vector3* norm = new vector3[ncount];
	float* tu = new float[uvcount];
	float* tv = new float[uvcount];
	m_VPool = new Vertex[fcount * 6];
	// load object
	int primidx = 0;
	Material* curmat = 0;
	f = fopen( a_Obj, "r" );
	while (1)
	{
		fgets( buffer, 250, f );
		if (feof( f )) break;
		sscanf( buffer, "%s", cmd );
		if (!strcmp( cmd, "v" ))
		{
			// vertex, add to list
			float x, y, z;
			sscanf( buffer, "%s %f %f %f", cmd, &x, &y, &z );
			x *= a_Scale, y *= a_Scale, z *= a_Scale;
			vector3 pos = vector3( x, y, z );
			vert[verts++] = pos;
		}
		else if (!strcmp( cmd, "g" ))
		{
			sscanf( buffer + 2, "%s", objname );
		}
		else if (!strcmp( cmd, "mtllib" ))
		{
			char libname[128];
			sscanf( buffer + 7, "%s", libname );
			char fullname[256];
			strcpy( fullname, "meshes/" );
			strcat( fullname, libname );
			Scene::GetMatManager()->LoadMTL( fullname );
		}
		else if (!strcmp( cmd, "vt" ))
		{
			// texture coordinate
			float u, v;
			sscanf( buffer, "%s %f %f", cmd, &u, &v );
			tu[uvs] = u, tv[uvs++] = -v; // prevent negative uv's
		}
		else if (!strcmp( cmd, "vn" ))
		{
			// vertex normal
			float x, y, z;
			sscanf( buffer, "%s %f %f %f", cmd, &x, &y, &z );
			norm[normals++] = vector3( x, y, z );
		}
		else if (!strcmp( cmd, "usemtl" ))
		{
			// vertex normal
			char matname[128];
			sscanf( buffer + 7, "%s", matname );
			curmat = Scene::GetMatManager()->FindMaterial( matname );
		}
		else if (!strcmp( cmd, "f" ))
		{
			// face
			Vertex* v[3];
			float cu[3], cv[3];
			const Texture* t = curmat->GetTexture();
			unsigned int vnr[9];
			unsigned int vars = sscanf( buffer + 2, "%i/%i/%i %i/%i/%i %i/%i/%i", 
				&vnr[0], &vnr[1], &vnr[2], &vnr[3], &vnr[4], &vnr[5], &vnr[6], &vnr[7], &vnr[8] );
			if (vars < 9) 
			{
				vars = sscanf( buffer + 2, "%i/%i %i/%i %i/%i", &vnr[0], &vnr[2], &vnr[3], &vnr[5], &vnr[6], &vnr[8] );
				if (vars < 6)
				{
					sscanf( buffer + 2, "%i//%i %i//%i %i//%i", &vnr[0], &vnr[2], &vnr[3], &vnr[5], &vnr[6], &vnr[8] );
				}
			}
			for ( unsigned int i = 0; i < 3; i++ )
			{
				v[i] = &m_VPool[currvert++];
				if (t) cu[i] = tu[vnr[i * 3 + 1] - 1], cv[i] = tv[vnr[i * 3 + 1] - 1];
				v[i]->SetNormal( norm[vnr[i * 3 + 2] - 1] );
				v[i]->SetPos( vert[vnr[i * 3] - 1] );
			}
			Primitive* p = m_Prim[m_PCount] = &prims[primidx++];
			Primitive* op = m_OPrim[m_PCount] = &prims[primidx++];
			if (t)
			{
				while ((cu[0] < 0) || (cu[1] < 0) || (cu[2] < 0)) cu[0] += 8, cu[1] += 8, cu[2] += 8;
				while ((cv[0] < 0) || (cv[1] < 0) || (cv[2] < 0)) cv[0] += 8, cv[1] += 8, cv[2] += 8;
				v[0]->SetUV( cu[0] * t->m_Width, cv[0] * t->m_Height );
				v[1]->SetUV( cu[1] * t->m_Width, cv[1] * t->m_Height );
				v[2]->SetUV( cu[2] * t->m_Width, cv[2] * t->m_Height );
			}
			p->Init( v[0], v[1], v[2] );
			Vertex* ov0 = &m_VPool[currvert++]; *ov0 = *p->GetVertex( 0 );
			Vertex* ov1 = &m_VPool[currvert++]; *ov1 = *p->GetVertex( 1 );
			Vertex* ov2 = &m_VPool[currvert++]; *ov2 = *p->GetVertex( 2 );
			op->Init( ov0, ov1, ov2 );
			p->SetMaterial( curmat );
			m_PCount++;
		}
	}
	fclose( f );
	delete vert;
	delete norm;
	delete tu;
	delete tv;
}

void Node::Transform()
{
	matrix transform = m_Mat;
	transform.SetTranslation( vector3( 0, 0, 0 ) );
	for ( int i = 0; i < m_PCount; i++ )
	{
		Primitive* p = m_Prim[i], *op = m_OPrim[i];
		for ( int v = 0; v < 3; v++ ) 
		{
			Vertex* vert = p->m_Vertex[v];
			Vertex* ovrt = op->m_Vertex[v];
			vert->m_Pos = m_Mat.Transform( ovrt->m_Pos );
			vert->m_N = -transform.Transform( ovrt->m_N );
		}
		vector3 e1 = p->m_Vertex[1]->GetPos() - p->m_Vertex[0]->GetPos();
		vector3 e2 = p->m_Vertex[2]->GetPos() - p->m_Vertex[0]->GetPos();
		p->SetNormal( e2.Cross( e1 ) );
		NORMALIZE( p->m_N );
	}
}

void Node::SetMaterial( Material* a_Mat )
{
	for ( int i = 0; i < m_PCount; i++ )
	{
		m_Prim[i]->SetMaterial( a_Mat );
		if (m_OPrim) m_OPrim[i]->SetMaterial( a_Mat );
	}
}

#ifdef MULTIBEAM
void MultiBeam::Transform( matrix& a_Mat )
{
	for ( int i = 0; i < MULTIBEAMDIRS; i++ ) 
	{
		vector3 t = a_Mat.Transform( m_Dir[i] );
		m_Light->SetDirection( i, t );
	}
}
#endif

void Node::Break()
{
	// nothing here
}

void Node::Break(vector3 a_Direction)
{
	// nothing here
}

void Node::SetGravity(bool a_Bool, vector3 a_Vector)
{
	// nothing here
}

Spheres::Spheres( int a_Count )
{
	m_Prim = new Primitive*[a_Count];
	m_OCentre = new vector3[a_Count];
	m_Vert = new Vertex[a_Count * 3];
	m_PCount = 0;
	m_Type = Node::DYNAMIC;
	m_Constructed = false;
	m_Active = true;
}

Spheres::~Spheres()
{
	delete m_Vert;
	delete m_OCentre;
}

void Spheres::SetCentre( int a_Idx, const vector3& a_Centre )
{
	m_Prim[a_Idx]->m_N = a_Centre;
	float r = m_Prim[a_Idx]->m_T.x;
	float x1 = a_Centre.x - r, x2 = a_Centre.x + r;
	float y1 = a_Centre.y - r, y2 = a_Centre.y + r;
	float z1 = a_Centre.z - r, z2 = a_Centre.z + r;
	m_Prim[a_Idx]->m_Vertex[0]->SetPos( vector3( x1, y1, z1 ) );
	m_Prim[a_Idx]->m_Vertex[1]->SetPos( vector3( x2, y2, z1 ) );
	m_Prim[a_Idx]->m_Vertex[2]->SetPos( vector3( x1, y1, z2 ) );
	m_OCentre[a_Idx] = a_Centre;
}

void Spheres::SetRadius( int a_Idx, const float a_Radius ) 
{ 
	m_Prim[a_Idx]->m_T.x = a_Radius; 
	m_Prim[a_Idx]->m_T.y = a_Radius * a_Radius; 
	m_Prim[a_Idx]->m_T.z = 1.0f / a_Radius; 
}

const vector3 Spheres::GetCentre( int a_Idx ) const 
{ 
	return m_Prim[a_Idx]->m_N; 
}

const float Spheres::GetRadius( int a_Idx ) const 
{ 
	return m_Prim[a_Idx]->m_T.x; 
}

const float Spheres::GetSqRadius( int a_Idx ) const 
{ 
	return m_Prim[a_Idx]->m_T.y; 
}

const float Spheres::GetRRadius( int a_Idx ) const 
{ 
	return m_Prim[a_Idx]->m_T.z; 
}

void Spheres::Add( vector3 a_Centre, float a_Radius, Material* a_Mat )
{
	m_Prim[m_PCount] = MManager::NewPrimitive();
	m_Prim[m_PCount]->SetVertex( 0, &m_Vert[m_PCount * 3 + 0] );
	m_Prim[m_PCount]->SetVertex( 1, &m_Vert[m_PCount * 3 + 1] );
	m_Prim[m_PCount]->SetVertex( 2, &m_Vert[m_PCount * 3 + 2] );
	SetRadius( m_PCount, a_Radius );
	SetCentre( m_PCount, a_Centre );
	m_Prim[m_PCount]->SetMaterial( a_Mat );
	m_Prim[m_PCount]->SetType( Primitive::PRIM_SPHERE );
	m_OCentre[m_PCount] = a_Centre;
	m_PCount++;
}

void Spheres::Transform()
{
	for ( int i = 0; i < m_PCount; i++ )
	{
		Primitive* p = m_Prim[i];
		SetCentre( i, m_Mat.Transform( m_OCentre[i] ) );
	}
}

StaticMesh::StaticMesh( int a_PCount )
{
	m_Prim = new Primitive*[a_PCount];
	m_PCount = 0;
	m_Type = Node::STATIC;
	m_Constructed = false;
	m_Active = true;
}

void StaticMesh::Add( Primitive* a_Prim )
{
	m_Prim[m_PCount++] = a_Prim; // assumed to be handled completely by the app
}

Breakable::Breakable()
{
	// nothing here
}

Breakable::Breakable( char* a_Obj, vector3 a_Pos, float a_Scale )
	: m_Broken( false ), m_BlastDirection( vector3( 0, 0, 0 ) )
{
	m_OPrim = 0;
	m_PCount = 0;
	Load( a_Obj, a_Scale );
	m_Mat = matrix();
	m_Mat.SetTranslation( a_Pos );
	// create matrices
	m_Rot = new vector3[16];
	m_DRot = new vector3[16];
	m_Trans = new matrix[16];
	for ( int i = 0; i < 16; i++ )
	{
		m_Rot[i] = vector3( 0, 0, 0 );
		m_DRot[i] = vector3( Rand( 1 ) - 0.5f, Rand( 1 ) - 0.5f, Rand( 1 ) - 0.5f );
		m_DRot[i] = vector3(0,0,0);
		m_Trans[i].Identity();
	}
	m_Type = Node::DYNAMIC;
	m_Constructed = false;
	m_Active = true;
}

Breakable::Breakable( char* a_Obj, vector3 a_Pos, float a_Scale, vector3 a_Direction )
	: m_Broken( false ), m_BlastDirection( a_Direction )
{
	m_OPrim = 0;
	m_PCount = 0;
	Load( a_Obj, a_Scale );
	m_Mat = matrix();
	m_Mat.SetTranslation( a_Pos );
	// create matrices
	m_Rot = new vector3[16];
	m_DRot = new vector3[16];
	m_Trans = new matrix[16];
	for ( int i = 0; i < 16; i++ )
	{
		m_Rot[i] = vector3( 0, 0, 0 );
		m_DRot[i] = vector3( Rand( 1 ) - 0.5f, Rand( 1 ) - 0.5f, Rand( 1 ) - 0.5f );
		m_DRot[i] = vector3(0,0,0);
		m_Trans[i].Identity();
	}
	m_Type = Node::DYNAMIC;
	m_Constructed = false;
	m_Active = true;
}

Breakable::~Breakable()
{
	// nothing here
}

void Breakable::Load( char* a_Obj, float a_Scale )
{
	Node::Load( a_Obj, a_Scale );
	// make all polygons double sided
	Primitive** newprimlist = new Primitive*[m_PCount * 2];
	Primitive** newoprimlist = new Primitive*[m_PCount * 2];
	memcpy( newprimlist, m_Prim, m_PCount * sizeof( Primitive* ) );
	memcpy( newoprimlist, m_OPrim, m_PCount * sizeof( Primitive* ) );
	Primitive* prims = (Primitive*)MALLOC64( sizeof( Primitive ) * m_PCount * 2 );
	delete m_Prim;
	delete m_OPrim;
	m_Prim = newprimlist;
	m_OPrim = newoprimlist;
	int primidx = 0;
	for ( int i = 0; i < m_PCount; i++ )
	{
		Primitive* orig = m_Prim[i];
		vector3 N = orig->m_N;
		Primitive* p = m_Prim[i + m_PCount] = &prims[primidx++];
		Primitive* op = m_OPrim[i + m_PCount] = &prims[primidx++];
		Vertex* v0 = (Vertex*)orig->GetVertex( 0 ), *v1 = (Vertex*)orig->GetVertex( 1 ), *v2 = (Vertex*)orig->GetVertex( 2 );
		p->Init( v2, v1, v0 ); // reversed
		Vertex* ov0 = new Vertex(); *ov0 = *v0;
		Vertex* ov1 = new Vertex(); *ov1 = *v1;
		Vertex* ov2 = new Vertex(); *ov2 = *v2;
		op->Init( ov2, ov1, ov0 );
		p->SetMaterial( orig->GetMaterial() );
	}
	m_Pos = new vector3[m_PCount];
	m_DPos = new vector3[m_PCount];
	Reset();
	m_PCount *= 2;
}

void Breakable::Reset()
{
	for ( int i = 0; i < m_PCount / 2; i++ )
	{
		m_Pos[i] = vector3( 0, 0, 0 );
		vector3 dir = m_Prim[i]->GetVertex( 0 )->GetPos();
		dir.Normalize();
		m_DPos[i] = 0.5 * dir * (Rand( 0.7f ) + 0.3f);
	}
	m_Broken = false;
}

void Breakable::Transform()
{
	if (!m_Broken) 
	{ 
		Node::Transform(); 
		return; 
	}
	// create the 16 transformation matrices (holding orientation)
	matrix mat[16], nmat[16];
	for ( int i = 0; i < 16; i++ )
	{
		mat[i].Identity();
		mat[i].Rotate( vector3( 0, 0, 0 ), m_Rot[i].x, m_Rot[i].y, m_Rot[i].z );
		nmat[i] = mat[i];
		nmat[i].Concatenate( m_Mat );
		nmat[i].SetTranslation( vector3( 0, 0, 0 ) );
		m_Rot[i] += 20 * m_DRot[i];
	}
	// transform the object
	matrix transform = m_Mat;
	transform.SetTranslation( vector3( 0, 0, 0 ) );
	int count = m_PCount / 2;
	for ( int i = 0; i < count; i++ )
	{
		Primitive* p = m_Prim[i], *op = m_OPrim[i];
		Primitive* dp = m_Prim[i + count], *dop = m_OPrim[i + count];
		vector3 basepos = (op->GetVertex( 0 )->GetPos() + op->GetVertex( 1 )->GetPos() + op->GetVertex( 2 )->GetPos()) * 0.3333f;
		for ( int v = 0; v < 3; v++ ) 
		{
			Vertex* vert = p->m_Vertex[v], *dvert = dp->m_Vertex[2 - v];
			Vertex* ovrt = op->m_Vertex[v], *dovrt = dop->m_Vertex[2 - v];
			vert->m_Pos = dvert->m_Pos = mat[i & 15].Transform( ovrt->m_Pos - basepos ) + m_Mat.Transform( ovrt->m_Pos + m_Pos[i] );
			vert->m_N = nmat[i & 15].Transform( ovrt->m_N );
			dvert->m_N = vert->m_N * -1;
		}
		vector3 e1 = p->m_Vertex[1]->GetPos() - p->m_Vertex[0]->GetPos();
		vector3 e2 = p->m_Vertex[2]->GetPos() - p->m_Vertex[0]->GetPos();
		p->SetNormal( e2.Cross( e1 ) );
		NORMALIZE( p->m_N );
		dp->m_N = p->m_N * -1;
		// apply some physics to movement
		vector3 delta = 1.2f * m_DPos[i];
		Primitive* prim = 0;
		vector3 worldpos = (p->GetVertex( 0 )->GetPos() + p->GetVertex( 1 )->GetPos() + p->GetVertex( 2 )->GetPos()) * 0.3333f;
		if ((m_DPos[i].x != 0) || (m_DPos[i].y != 0) || (m_DPos[i].z != 0))
		{
			float maxdist = delta.SqrLength();
			vector3 D = delta.Normalized();
			float dist = Engine::Trace( worldpos + D * 0.001f, D, prim );
			if ((dist * dist) < maxdist)
			{
				// mirror m_DPos[i] in primitive normal
				vector3 N = -prim->m_N;
				m_DPos[i] = m_DPos[i] - 2 * N.Dot( m_DPos[i] ) * N;
				m_Pos[i] += m_DPos[i];
			}
			else m_Pos[i] += delta;
		}
		m_DPos[i] *= 0.98f; // apply friction
		if (m_DPos[i].Length() < 0.01f) m_DPos[i] = vector3( 0, 0, 0 );
		if(m_BGravity) m_DPos[i] += m_VGravity; // apply gravity
	}
	//m_VGravity *= 1.1f;
}

void Breakable::Break()
{
	for(int i=0; i<16; i++) m_DRot[i] = vector3( Rand( 1 ) - 0.5f, Rand( 1 ) - 0.5f, Rand( 1 ) - 0.5f );
	m_Broken = true;

	if( m_BlastDirection == vector3(0,0,0)) return;

	for ( int i = 0; i < m_PCount>>1; i++ )
	{
		vector3 dir;
		dir.x = (Rand( 0.4f ) - 0.2f) + m_BlastDirection.x * (Rand( 0.6f ) + 0.7f);
		dir.y = (Rand( 0.4f ) - 0.2f) + m_BlastDirection.y * (Rand( 0.6f ) + 0.7f);
		dir.z = (Rand( 0.4f ) - 0.2f) + m_BlastDirection.z * (Rand( 0.6f ) + 0.7f);
		m_DPos[i] = dir;
	}
}

void Breakable::Explode()
{
	for(int i=0; i<16; i++)
		m_DRot[i] = vector3( Rand( 1 ) - 0.5f, Rand( 1 ) - 0.5f, Rand( 1 ) - 0.5f );
	m_Broken = true;
	for ( int i = 0; i < m_PCount>>1; i++ )
	{
		vector3 dir = m_DPos[i];
		dir += m_BlastDirection;
		dir.Normalize();
		m_DPos[i] = dir;
	}
}

void Breakable::Break(vector3 a_Direction)
{
	for(int i=0; i<16; i++)
		m_DRot[i] = vector3( Rand( 1 ) - 0.5f, Rand( 1 ) - 0.5f, Rand( 1 ) - 0.5f );
	m_Broken = true;

	if(a_Direction == vector3(0,0,0)) return;
	for ( int i = 0; i < m_PCount>>1; i++ )
	{
		vector3 dir = m_DPos[i];
		dir += a_Direction.Normalized();
		dir.Normalize();
		m_DPos[i] = dir;
	}
}

void Breakable::SetGravity(bool a_Bool, vector3 a_Vector)
{
	m_BGravity=a_Bool;
	m_VGravity=a_Vector;
}

MD2Node::MD2Node( char* a_Obj, vector3 a_Pos, float a_Scale )
{
	m_PCount = 0;
	Load( a_Obj, a_Scale );
	m_Mat = matrix();
	m_Mat.SetTranslation( a_Pos );
	m_First = 0;
	m_Last = 1;
	m_APos = 0;
	m_Type = Node::DYNAMIC;
	m_Constructed = false;
	m_Active = true;
}

void MD2Node::Load( char* a_Obj, float a_Scale )
{
	// read header
	FILE* f = fopen( a_Obj, "rb" );
	if (!f) Log::Error( "Could not load MD2 object", a_Obj );
	fread( &m_Header, 1, sizeof( MD2Header ), f );
	// memory allocation
	m_Skins = (MD2Skin*)malloc( sizeof( MD2Skin ) * m_Header.num_skins );
	m_TCoords = (MD2UV*)malloc( sizeof( MD2UV ) * m_Header.num_st );
	m_Tris = (MD2Tri*)malloc( sizeof( MD2Tri ) * m_Header.num_tris );
	m_Frames = (MD2Frame*)malloc( sizeof( MD2Frame ) * m_Header.num_frames );
	m_GLCmds = (int*)malloc( sizeof( int ) * m_Header.num_glcmds);
	// read model data
	fseek( f, m_Header.offset_skins, SEEK_SET );
	fread( m_Skins, sizeof( MD2Skin ), m_Header.num_skins, f );
	fseek( f, m_Header.offset_st, SEEK_SET );
	fread( m_TCoords, sizeof( MD2UV ), m_Header.num_st, f );
	fseek( f, m_Header.offset_tris, SEEK_SET );
	fread( m_Tris, sizeof( MD2Tri ), m_Header.num_tris, f );
	fseek( f, m_Header.offset_glcmds, SEEK_SET );
	fread( m_GLCmds, sizeof( int ), m_Header.num_glcmds, f );
	// read frames
	fseek ( f, m_Header.offset_frames, SEEK_SET );
	int i;
	MD2Vert* verts = (MD2Vert*)malloc( sizeof( MD2Vert ) * m_Header.num_vertices);
	for ( i = 0; i < m_Header.num_frames; ++i)
	{
		// read frame data
		m_Frames[i].verts = new vector3[m_Header.num_vertices];
		fread( &m_Frames[i].scale, sizeof( vector3 ), 1, f );
		fread( &m_Frames[i].translate, sizeof( vector3 ), 1, f );
		fread( m_Frames[i].name, sizeof (char), 16, f );
		fread( verts, sizeof( MD2Vert ), m_Header.num_vertices, f );
		for ( int j = 0; j < m_Header.num_vertices; j++ )
		{
			float x = (float)verts[j].v[0] / 128 - 1;
			float y = (float)verts[j].v[1] / 128 - 1;
			float z = (float)verts[j].v[2] / 128 - 1;
			m_Frames[i].verts[j] = vector3( x * a_Scale, z * a_Scale, y * a_Scale );
		}
	}
	fclose( f );
	// build the initial mesh
	m_PCount = m_Header.num_tris;
	m_Prim = new Primitive*[m_PCount];
	m_VArray = new Vertex[m_Header.num_vertices];
	for ( i = 0; i < m_Header.num_vertices; i++ ) m_VArray[i].SetPos( m_Frames[0].verts[i] );
	for ( i = 0; i < m_PCount; i++ )
	{
		m_Prim[i] = MManager::NewPrimitive();
		MD2Tri t = m_Tris[i];
		Vertex* v1 = new Vertex();
		Vertex* v2 = new Vertex();
		Vertex* v3 = new Vertex();
		m_Prim[i]->Init( v1, v2, v3 );
	}
}

void MD2Node::SetAnim( char* a_Name )
{
	int len = strlen( a_Name );
	m_First = -1, m_Last = -1;
	bool ffound = false;
	for ( int i = 0; i < m_Header.num_frames; i++ )
	{
		if (!strncmp( m_Frames[i].name, a_Name, len ))
			if (!ffound) ffound = true, m_First = i; else m_Last = i;
	}
	m_APos = 0;
}

int MD2Node::FindFirstFrame( char* a_Name )
{
	int len = strlen( a_Name );
	for ( int i = 0; i < m_Header.num_frames; i++ )
	{
		if (!strncmp( m_Frames[i].name, a_Name, len )) return i;
	}
	return -1;
}

int MD2Node::FindLastFrame( char* a_Name )
{
	int len = strlen( a_Name );
	int first = -1, last = -1;
	bool ffound = false;
	for ( int i = 0; i < m_Header.num_frames; i++ )
	{
		if (!strncmp( m_Frames[i].name, a_Name, len ))
			if (!ffound) ffound = true, first = i; else last = i;
	}
	return last;
}

void MD2Node::Transform()
{
	matrix transform = m_Mat;
	transform.SetTranslation( vector3( 0, 0, 0 ) );
	int i;
	float tperframe = 1.0f / (float)(m_Last - m_First + 1);
	float tinframe = m_APos * (float)(m_Last - m_First + 1);
	tinframe -= (float)((int)tinframe);
	int frame1 = m_First + (int)(m_APos * (float)(m_Last - m_First + 1));
	int frame2 = frame1 + 1;
	if (frame2 > m_Last) frame2 = m_First;
	if (frame1 > m_Last) frame1 = m_First;
	for ( i = 0; i < m_Header.num_vertices; i++ )
	{
		const vector3 v1 = m_Frames[frame1].verts[i];
		const vector3 v2 = m_Frames[frame2].verts[i];
		vector3 final = v1 + (v2 - v1) * tinframe;
		m_VArray[i].SetPos( m_Mat.Transform( final ) );
		// m_VArray[i].m_N = transform.Transform( m_VArray[i].m_ONormal );
	}
	for ( int i = 0; i < m_PCount; i++ )
	{
		Primitive* p = m_Prim[i];
		MD2Tri t = m_Tris[i];
		p->m_Vertex[0]->SetPos( m_VArray[t.vertex[0]].GetPos() );
		p->m_Vertex[1]->SetPos( m_VArray[t.vertex[1]].GetPos() );
		p->m_Vertex[2]->SetPos( m_VArray[t.vertex[2]].GetPos() );
		p->m_Vertex[0]->SetUV( (float)m_TCoords[t.uv[0]].u, 256 - (float)m_TCoords[t.uv[0]].v );
		p->m_Vertex[1]->SetUV( (float)m_TCoords[t.uv[1]].u, 256 - (float)m_TCoords[t.uv[1]].v );
		p->m_Vertex[2]->SetUV( (float)m_TCoords[t.uv[2]].u, 256 - (float)m_TCoords[t.uv[2]].v );
		vector3 e1 = p->m_Vertex[1]->GetPos() - p->m_Vertex[0]->GetPos();
		vector3 e2 = p->m_Vertex[2]->GetPos() - p->m_Vertex[0]->GetPos();
		NORMALIZE( e1 );
		NORMALIZE( e2 );
		vector3 N = e2.Cross( e1 );
		NORMALIZE( N );
		p->SetNormal( N );
		p->m_Vertex[0]->SetNormal( p->m_N );
		p->m_Vertex[1]->SetNormal( p->m_N );
		p->m_Vertex[2]->SetNormal( p->m_N );
	}
}

MD5Model::MD5Model()
{
	m_AnimFirst = NULL;
	m_AnimLast = NULL;
	m_AttachFirst = NULL;
	m_AttachLast = NULL;
	m_AnimCurrent.anim = NULL;
	m_AnimNext.anim = NULL;
	m_BaseSkeleton = NULL;
	m_Skeleton = NULL;
	m_Meshes = NULL;
	m_AttachmentCount = 0;
	m_MatListCount = 0;
	m_MatList = NULL;
	m_Name = new char[64];
	m_Prim = 0;
	m_OPrim = 0;
	m_VPool = 0;
	m_PCount = 0;
	m_Mat = matrix();
	m_Builder = 0;
	m_Type = Node::REFITTABLE;
	m_Constructed = false;
	m_Scale = vector3(1,1,1);
}

MD5Model::~MD5Model()
{
	delete [] m_BaseSkeleton;
	delete [] m_Skeleton;
	if (m_Meshes)
	{
		for (int i = 0; i < m_MeshCount; ++i)
		{
			delete [] m_Meshes[i].Vertices;
			delete [] m_Meshes[i].Weights;
		}	
		delete [] m_Meshes;
	}
	while (m_AnimFirst != NULL)
	{
		MD5Anim* a = m_AnimFirst;
		m_AnimFirst = m_AnimFirst->next;
		for (int i = 0; i < a->framecount; i++) delete [] a->skelframes[i];
		delete [] a->skelframes;
		delete a;
	}
	while (m_AttachFirst != NULL)
	{
		MD5Attachment* a = m_AttachFirst;
		m_AttachFirst = m_AttachFirst->next;
		delete a;
	}
	delete m_MatList;
	delete m_Prim;
	delete m_OPrim;
	delete m_VPool;
	delete m_Builder;
	m_Prim = 0;
	m_OPrim = 0;
	m_VPool = 0;
	m_Builder = 0;
}

void MD5Model::StripQuotes(char* a_Name)
{
	strncpy(a_Name , a_Name + 1, strlen(a_Name));
	a_Name[strlen(a_Name)-1] = 0;
}

void MD5Model::Transform()
{
	matrix transform = m_Mat;
	transform.SetTranslation( vector3( 0, 0, 0 ) );
	for ( int i = 0; i < m_PCount; i++ )
	{
		Primitive* p = m_Prim[i], *op = m_OPrim[i];
		for ( int v = 0; v < 3; v++ ) 
		{
			Vertex* vert = p->m_Vertex[v];
			Vertex* ovrt = op->m_Vertex[v];
			vert->m_Pos = m_Mat.Transform( ovrt->m_Pos * m_Scale );
			vert->m_N = -transform.Transform( ovrt->m_N );
		}
		vector3 e1 = p->m_Vertex[1]->GetPos() - p->m_Vertex[0]->GetPos();
		vector3 e2 = p->m_Vertex[2]->GetPos() - p->m_Vertex[0]->GetPos();
		p->SetNormal( e2.Cross( e1 ) );
		NORMALIZE( p->m_N );
	}
}

void MD5Model::LoadModel(char* a_Filename)
{
	FILE* f;
	fopen_s(&f, a_Filename, "r" );
	if (!f)
	{
		Log::Error("MD5 Model not found: ", a_Filename);
		return;
	}
	m_VertCount = 0;
	int totalprimcount = 0;
	char buffer[256], cmd[128];
	while (!feof(f))
	{
		fgets(buffer, 250, f);
		sscanf(buffer, "%s", cmd);
		if (!_stricmp( cmd, "numverts" ))
		{
			int count;
			sscanf( buffer + 10, "%d",&count);
			m_VertCount += count;
		}
		if (!_stricmp( cmd, "numtris" ))
		{
			int count;
			sscanf( buffer + 9, "%d",&count);
			totalprimcount += count;
		}
	}
	fclose( f );
	int pos = int(strlen(a_Filename))-1;
	while (pos >= 0)
	{
		if (a_Filename[pos]=='/') break;
		pos--;
	}
	if (pos==-1)
	{
		 strncpy(m_Name,a_Filename,strlen(a_Filename)-8);
		 m_Name[strlen(a_Filename)-8] = 0;
	}
	else
	{
		 strncpy(m_Name,&a_Filename[pos+1],strlen(a_Filename)-pos-9);
		 m_Name[strlen(a_Filename)-pos-9] = 0;
	}
	Log::Message("loading MD5 Model: ", m_Name);
	char t[64];
	sprintf(t,"Total Vertices: %d", m_VertCount);
	Log::Message(t);
	sprintf(t,"Total Pritimives: %d", totalprimcount);
	Log::Message(t);
	Primitive* prims = (Primitive*)MALLOC64( sizeof( Primitive ) * totalprimcount * 2 );
	m_Prim = new Primitive*[totalprimcount];
	m_OPrim = new Primitive*[totalprimcount];
	int primidx = 0;
	m_PCount = 0;
	m_VPool = new Vertex[m_VertCount << 1];
	int voffset = 0;
	int curmesh = -1;
	MD5Mesh* m = NULL;
	Texture* tex = NULL;
	int index;
	fopen_s(&f, a_Filename, "r" );
	while (!feof(f))
	{
		fgets(buffer, 250, f);
		cmd[0] = 0;
		sscanf(buffer, "%s", cmd);
		if (!_stricmp( cmd, "numJoints" ))
		{
			sscanf( buffer + 10, "%d", &m_JointCount );
			m_BaseSkeleton = new MD5Joint[m_JointCount];
			m_Skeleton = new MD5Joint[m_JointCount];
			sprintf(t, "Joints: %d", m_JointCount);
			Log::Message(t);
		}
		if (!_stricmp( cmd, "numMeshes" ))
		{
			sscanf( buffer + 10, "%d", &m_MeshCount );
			m_Meshes = new MD5Mesh[m_MeshCount];
			m_MatList = new Material*[m_MeshCount];
			m_MatListCount = m_MeshCount;
			sprintf(t, "Meshes: %d", m_MeshCount);
			Log::Message(t);
		}
		if (!_stricmp( cmd, "joints" ))
		{
			for (int i = 0; i < m_JointCount; i++)
			{
				fgets(buffer, 250, f);
				MD5Joint* j = &m_BaseSkeleton[i]; 
				j->id = i;
				sscanf(buffer+1, "%s %d ( %f %f %f ) ( %f %f %f )",  j->name, &j->parent, &j->pos.x, &j->pos.y, &j->pos.z, &j->orient.x, &j->orient.y, &j->orient.z);
				StripQuotes(j->name);
				j->orient.ComputeW();
				if (j->parent < -1 || j->parent > m_JointCount) Log::Message("Invalid bone parent");
				if ((j->pos.x < -10000) || (j->pos.x > 10000) || (j->pos.y < -10000) || (j->pos.y > 10000) || (j->pos.z < -10000) || (j->pos.z > 10000)) Log::Message("Invalid bone position");
				if ((j->orient.x < -10000) || (j->orient.x > 10000) || (j->orient.y < -10000) || (j->orient.y > 10000) || (j->orient.z < -10000) || (j->orient.z > 10000)) Log::Message("Invalid bone orientation");
			}
		}
		if (!_stricmp( cmd, "mesh" ))
		{
			if (m) voffset += m->VertCount;
			curmesh++;
			m = &m_Meshes[curmesh];
		}
		if (!_stricmp( cmd, "shader" ))
		{				
			char tname[128];
			char fname[256];
			char fcname[256];
			tname[0] = fname[0] = 0;
			sscanf( buffer + 9, "%s", tname );
			if (tname[0])
			{
				pos = int(strlen(tname))-1;
				while (pos >= 0)
				{
					if (tname[pos]=='/' || tname[pos]==92) break;
					pos--;
				}
				if (pos==-1)
				{
					 strncpy(tname,tname,strlen(tname)-1);
					 tname[strlen(tname)-1] = 0;
				}
				else
				{
					 strncpy(tname,&tname[pos+1],strlen(tname)-pos-2);
					 tname[strlen(tname)-pos-2] = 0;
				}
				m->Mat = MManager::NewMaterial();
				m->Mat->Init();
				m->Mat->SetName( tname );
				Color amb  (0.50f, 0.50f, 0.50f);
				m->Mat->SetAmbient(amb);
				Color diff (0.75f, 0.75f, 0.75f);
				m->Mat->SetDiffuse(diff);
				Color spec (0.10f, 0.10f, 0.10f);
				m->Mat->SetSpecular(spec);
				strcpy( fname, "textures/" );
				strcat( fname, tname );
				strcpy( fcname, fname );
				strcat( fcname, "_d.tga" );
				tex = 0;
				if (GetFileAttributes(fcname) != 0xFFFFFFFF) // check for file exists
				{
					tex = MManager::FindTexture( fcname );
					if (!tex)
					{
						tex = MManager::NewTexture();
						tex->Init( fcname );
					}
					m->Mat->SetTexture( tex );
				}
			#ifdef BUMPMAPPING	
				strcpy( fcname, fname );
				strcat( fcname, "_local.tga" );
				if (GetFileAttributes(fcname) != 0xFFFFFFFF) // check for file exists
				{
					Texture* t = MManager::FindTexture( fcname );
					if (!t)
					{
						t = MManager::NewTexture();
						t->Init( fcname );
						t->ConvertToNormalMap();
						m->Mat->SetBumpMap( t );
						tex->Combine(t);
					}
					else m->Mat->SetBumpMap( t );
				}
			#endif
				strcpy( fcname, fname );
				strcat( fcname, "_a.tga" );
				if (GetFileAttributes(fcname) != 0xFFFFFFFF) // check for file exists
				{
					Surface alpha( fname );
					m->Mat->SetAlpha(1);
					Texture* tex = (Texture*)m->Mat->GetTexture();
					int w = tex->GetWidth();
					int h = tex->GetHeight();
					Pixel* buf = (Pixel*)tex->GetBitmap();
					Pixel* src = alpha.GetBuffer();
					for ( int x = 0; x < w; x++ ) for ( int y = 0; y < h; y++ ) buf[x + y * w] = (buf[x + y * w] & 0xffffff) + ((src[x + y * w] & 255) << 24);		
				}
			}
		}
		if (!_stricmp( cmd, "numverts" ))
		{
			sscanf( buffer + 10, "%d",&m->VertCount);
			m->Vertices = new MD5Vertex[m->VertCount];
			sprintf(t, "Vertices: %d", m->VertCount);
		}
		if (!_stricmp( cmd, "numweights" ))
		{
			sscanf( buffer + 12, "%d",&m->WeightCount);
			m->Weights = new MD5Weight[m->WeightCount];
			sprintf(t, "Weights: %d", m->WeightCount);
		}
		if (!_stricmp( cmd, "vert" ))
		{
			sscanf( buffer + 6, "%d", &index); // have to read the index first :(
			m->Vertices[index].v = &m_VPool[voffset+index];
			m->Vertices[index].v->m_N = vector3(0.0f, 0.0f, 0.0f);
			sscanf( buffer + 6, "%d ( %f %f ) %d %d", &index, &m->Vertices[index].v->m_U, &m->Vertices[index].v->m_V, &m->Vertices[index].start, &m->Vertices[index].count);			
			if (index < 0 || voffset+index >= m_VertCount) Log::Message("Vertex: Invalid Index");
			if (m->Vertices[index].v->m_U < 0 || m->Vertices[index].v->m_U > 1 || m->Vertices[index].v->m_V < 0 || m->Vertices[index].v->m_V > 1) Log::Message("Vertex: Invalid UV");
			if (m->Vertices[index].start < 0 || m->Vertices[index].start >= 100000) Log::Message("Vertex: Invalid Start");
			if (m->Vertices[index].count < 0 || m->Vertices[index].count > 9) Log::Message("Vertex: Invalid Vertex Count");
			if (tex) m->Vertices[index].v->SetUV(m->Vertices[index].v->m_U * tex->GetWidth(), m->Vertices[index].v->m_V * tex->GetHeight());
		}
		if (!_stricmp( cmd, "tri" ))
		{
			int iv[3];
			sscanf( buffer + 5, "%d", &index); // have to read the index first :(
			sscanf( buffer + 5, "%d %d %d %d", &index, &iv[2], &iv[1], &iv[0]);
			for (int i=0; i<3; i++){if (iv[i] < 0 || iv[i] >= m_VertCount) Log::Message("Tri: Invalid Index");}
			Primitive* p = m_Prim[m_PCount] = &prims[primidx++];
			Primitive* op = m_OPrim[m_PCount] = &prims[primidx++];
			m_PCount++;
			if (primidx > totalprimcount*2) Log::Message("Primidx out of bounds!");
			if (m_PCount > totalprimcount) Log::Message("Primitive count out of bounds!");
			for (int i=0; i<3; i++){ p->SetVertex(i, m->Vertices[iv[i]].v); }
			Vertex* ov0 = &m_VPool[m_VertCount + voffset + iv[0]]; *ov0 = *p->GetVertex( 0 );
			Vertex* ov1 = &m_VPool[m_VertCount + voffset + iv[1]]; *ov1 = *p->GetVertex( 1 );
			Vertex* ov2 = &m_VPool[m_VertCount + voffset + iv[2]]; *ov2 = *p->GetVertex( 2 );
			op->SetVertex(0, ov0);
			op->SetVertex(1, ov1);
			op->SetVertex(2, ov2);
			p->SetMaterial( m->Mat );
		}
		if (!_stricmp( cmd, "weight" ))
		{
			sscanf( buffer + 8, "%d", &index); // have to read the index first :(
			sscanf( buffer + 8, "%d %d %f ( %f %f %f )", &index, &m->Weights[index].joint, &m->Weights[index].bias, &m->Weights[index].pos.x, &m->Weights[index].pos.y, &m->Weights[index].pos.z);
		}
	}
	fclose( f );
	for ( int n = 0; n < m_MeshCount; n++ )
	{
		m = &m_Meshes[n];
		for ( int i = 0; i < m->VertCount; i++ )
		{
			for ( int j = 0; j < m->Vertices[i].count; j++ )
			{			
				MD5Weight* weight = &m->Weights[m->Vertices[i].start + j];
				MD5Joint* joint = &m_BaseSkeleton[weight->joint];
				m->Vertices[i].v->m_Pos += (joint->pos + quat4RotatePoint(joint->orient, weight->pos)) * weight->bias;
			}
		}
		m_MatList[n] = m->Mat;
	}
	for ( int i = 0; i < m_VertCount; i++ ) m_VPool[m_VertCount+i].m_Pos = m_VPool[i].m_Pos;
	for ( int i = 0; i < m_PCount; i++ )
	{
		Primitive* p = m_Prim[i];
		p->UpdateNormal();
		p->CalcTangents();
		p->SetType(Primitive::PRIM_TRI);
		p->m_Vertex[0]->m_N -= p->GetNormal();
		p->m_Vertex[1]->m_N -= p->GetNormal();
		p->m_Vertex[2]->m_N -= p->GetNormal();
		Primitive* op = m_OPrim[i];
		op->UpdateNormal();
		op->CalcTangents();
		op->SetType(Primitive::PRIM_TRI);
		op->m_Vertex[0]->m_N -= op->GetNormal();
		op->m_Vertex[1]->m_N -= op->GetNormal();
		op->m_Vertex[2]->m_N -= op->GetNormal();
	}
	for (int i=0; i<(m_VertCount << 1); i++) NORMALIZE(m_VPool[i].m_N);
	for (int i = 0; i < m_JointCount; i++)
	{
		m_BaseSkeleton[i].id = i;
		m_Skeleton[i].id = i;
		strcpy(m_Skeleton[i].name, m_BaseSkeleton[i].name);
	}
	Log::Message( "loading Model Completed" );
}

void MD5Model::LoadModelNAnimations(char* a_Model)
{
	LoadModel(a_Model);
	Log::Message( "Searching for Animations" );
	char path[256];
	int pos = int( strlen( a_Model ) ) - 1;
	while (pos >= 0)
	{
		if (a_Model[pos]=='/') break;
		pos--;
	}
	if (pos==-1)
	{
		 strncpy( &path[0],a_Model,strlen( a_Model ) - 8 );
		 path[strlen( a_Model ) - 8] = 0;
	}
	else
	{
		 strncpy( &path[0],a_Model,pos + 1 );
		 path[pos+1] = 0;
	}
	char animfile[512];
	char spath[256];
	strcpy(spath, path);
	strcat(spath, "*.md5anim");
	WIN32_FIND_DATA FindFileData;
	HANDLE hFind = FindFirstFile( spath, &FindFileData );
	do 
	{
		if (hFind != INVALID_HANDLE_VALUE)
		{
			if  (strcmp(FindFileData.cFileName, ".") && strcmp(FindFileData.cFileName, ".."))
			{
				// Add Animation
				strcpy( animfile, path );
				strcat( animfile, FindFileData.cFileName );
				if (GetFileAttributes( animfile ) != FILE_ATTRIBUTE_DIRECTORY) AddAnim( animfile );
			}
		}
	}
	while( FindNextFile( hFind, &FindFileData ) );    
	FindClose( hFind );
	Log::Message( "Finished Loading animations" );
}

void MD5Model::AddAnim(char* a_Filename)
{
	FILE* f;
	fopen_s(&f, a_Filename, "r" );
	if (!f)
	{
		Log::Error("MD5 Model animation not found: ", a_Filename);
		return;
	}
	MD5Anim* anim = new MD5Anim;
	int pos = int(strlen(a_Filename))-1;
	while (pos >= 0)
	{
		if (a_Filename[pos]=='/') break;
		pos--;
	}
	if (pos==-1)
	{
		 strncpy(anim->name,a_Filename,strlen(a_Filename)-8);
		 anim->name[strlen(a_Filename)-8] = 0;
	}
	else
	{
		 strncpy(anim->name,&a_Filename[pos+1],strlen(a_Filename)-pos-9);
		 anim->name[strlen(a_Filename)-pos-9] = 0;
	}
	Log::Message("Animation: ", anim->name);
	m_AnimCount++;
	if (m_AnimFirst == NULL) m_AnimFirst = anim;
	else m_AnimLast->next = anim;
	m_AnimLast = anim;
	anim->next = NULL;
	MD5JointInfo* jointinfos = NULL;
	MD5BaseFrameJoint* baseframe = NULL;
	float* animframedata = NULL;
	int animcomponentcount;
	char buffer[256], cmd[128];
	while (!feof(f))
	{
		fgets(buffer, 250, f);
		cmd[0] = 0;
		sscanf(buffer, "%s", cmd);
		if (!_stricmp( cmd, "numFrames" ))
		{
			sscanf( buffer + 10, "%d",&anim->framecount);
			anim->skelframes = new MD5Joint*[anim->framecount];
			anim->bbox = new MD5BBox[anim->framecount];
		}
		if (!_stricmp( cmd, "numJoints" ))
		{
			sscanf( buffer + 10, "%d",&anim->jointcount);
			for (int i = 0; i < anim->framecount; i++)
			{
				anim->skelframes[i] = new MD5Joint[anim->jointcount];
			}
			jointinfos = new MD5JointInfo[anim->jointcount];
			baseframe = new MD5BaseFrameJoint[anim->jointcount];
		}
		if (!_stricmp( cmd, "frameRate" )) sscanf( buffer + 10, "%d",&anim->framerate);	
		if (!_stricmp( cmd, "numAnimatedComponents" ))
		{
			sscanf( buffer + 22, "%d",&animcomponentcount);
			animframedata = new float[animcomponentcount];
		}
		if (!_stricmp( cmd, "hierarchy" ))
		{
			for ( int i = 0; i < anim->jointcount; i++ )
			{
				fgets( buffer, 250, f );
				MD5JointInfo* j = &jointinfos[i]; 
				sscanf( buffer + 1, "%s %d %d %d", j->name, &j->parent, &j->flags, &j->startindex );
			}
		}
		if (!_stricmp( cmd, "bounds" ))
		{
			for ( int i = 0; i < anim->framecount; i++ )
			{
				fgets( buffer, 250, f );
				MD5BBox* b = &anim->bbox[i]; 
				sscanf(buffer + 1, "( %f %f %f ) ( %f %f %f )", &b->min.x, &b->min.y, &b->min.z, &b->max.x, &b->max.y, &b->max.z );
			}
		}
		if (!_stricmp( cmd, "baseframe" ))
		{
			for ( int i = 0; i < anim->jointcount; i++ )
			{
				fgets( buffer, 250, f );
				MD5BaseFrameJoint* j = &baseframe[i]; 
				sscanf( buffer + 1, "( %f %f %f ) ( %f %f %f )", &j->pos.x, &j->pos.y, &j->pos.z, &j->orient.x, &j->orient.y, &j->orient.z );
			}
		}
		if (!_stricmp( cmd, "frame" ))
		{
			int frameindex, animindex = 0;
			sscanf(buffer+6, "%d", &frameindex);
			float fl[6];
			while (animindex < animcomponentcount)
			{
				fgets( buffer, 250, f );
				int items = sscanf( buffer + 1, "%f %f %f %f %f %f", &fl[0], &fl[1], &fl[2], &fl[3], &fl[4], &fl[5] );
				for ( int j = 0; j < items; j++ )
				{
					animframedata[animindex] = fl[j];
					animindex++;
				}
			}
			BuildFrameSkeleton( jointinfos, baseframe, animframedata, anim->skelframes[frameindex] );
		}
	}
	fclose( f );
	delete animframedata;
	delete [] baseframe;
	delete [] jointinfos;
}

void MD5Model::RemoveAnim(char* a_Name)
{
	MD5Anim* a = m_AnimFirst;
	MD5Anim* prev = NULL;
	while (a)
	{
		if (!_stricmp( a->name, a_Name ))
		{
			if (prev) prev->next = a->next;
			if (a == m_AnimFirst) m_AnimFirst = m_AnimFirst->next;
			if (a == m_AnimLast) m_AnimLast = NULL;	
			for ( int i = 0; i < a->framecount; i++ ) delete [] a->skelframes[i];
			delete [] a->skelframes;
			delete a;
			m_AnimCount--;
			break;
		}
		prev = a;
		a=a->next;
	}
}

void MD5Model::BuildFrameSkeleton( const MD5JointInfo* a_JointInfos, const MD5BaseFrameJoint* a_BaseFrame, const float* AnimFrameData, MD5Joint* a_SkelFrame )
{
	for ( int i = 0; i < m_JointCount; i++ )
	{
		vector3 AnimatedPos = a_BaseFrame[i].pos;
		quat4 AnimatedOrient = a_BaseFrame[i].orient;
		int j = 0;
		if (a_JointInfos[i].flags & 1) // Tx
		{
			AnimatedPos.x = AnimFrameData[a_JointInfos[i].startindex + j];
			j++;
		}
		if (a_JointInfos[i].flags & 2) // Ty
		{
			AnimatedPos.y = AnimFrameData[a_JointInfos[i].startindex + j];
			j++;
		}
		if (a_JointInfos[i].flags & 4) // Tz
		{
			AnimatedPos.z = AnimFrameData[a_JointInfos[i].startindex + j];
			j++;
		}
		if (a_JointInfos[i].flags & 8) // Qx
		{
			AnimatedOrient.x = AnimFrameData[a_JointInfos[i].startindex + j];
			j++;
		}
		if (a_JointInfos[i].flags & 16) // Qy
		{
			AnimatedOrient.y = AnimFrameData[a_JointInfos[i].startindex + j];
			j++;
		}
		if (a_JointInfos[i].flags & 32) // Qz
		{
			AnimatedOrient.z = AnimFrameData[a_JointInfos[i].startindex + j];
			j++;
		}
		AnimatedOrient.ComputeW();
		a_SkelFrame[i].parent = a_JointInfos[i].parent;
		if (a_SkelFrame[i].parent < 0)
		{
			a_SkelFrame[i].pos = AnimatedPos;
			a_SkelFrame[i].orient = AnimatedOrient;
		}
		else
		{
			MD5Joint* ParentJoint = &a_SkelFrame[a_JointInfos[i].parent];
			a_SkelFrame[i].pos = quat4RotatePoint( ParentJoint->orient, AnimatedPos ) + ParentJoint->pos;
			a_SkelFrame[i].orient = ParentJoint->orient.MultQuat( AnimatedOrient );
			a_SkelFrame[i].orient.Normalize();
		}
	}
}

void MD5Model::InterpolateSkeletons( const MD5Joint* a_SkelA, const MD5Joint* a_SkelB, const float Interp )
{
	for ( int i = 0; i < m_JointCount; i++ )
	{
		m_Skeleton[i].parent = a_SkelA[i].parent;
		m_Skeleton[i].pos = a_SkelA[i].pos + Interp * (a_SkelB[i].pos - a_SkelA[i].pos);
		m_Skeleton[i].orient = quat4Slerp( a_SkelA[i].orient, a_SkelB[i].orient, Interp );
	}
}

MD5Joint* MD5Model::GetJointByName( char* a_Name )
{
	for ( int i = 0; i < m_JointCount; i++ ) if (!_stricmp(m_Skeleton[i].name,a_Name)) return &m_Skeleton[i];
	return NULL;
}
void MD5Model::Detach( Node* a_Obj )
{
	MD5Attachment* a = m_AttachFirst;
	MD5Attachment* prev = NULL;
	while (a)
	{
		if (a->obj == a_Obj)
		{
			if (prev) prev->next = a->next;
			if (a == m_AttachFirst) m_AttachFirst = m_AttachFirst->next;
			if (a == m_AttachLast) m_AttachLast = NULL;	
			delete a->m_MatList;
			delete a;
			m_AttachmentCount--;
			RebuildMatList();
			break;
		}
		prev = a;
		a=a->next;
	}
}

void MD5Model::Attach( Node* a_Obj, char* a_Bone, vector3 a_Offset )
{
	MD5Joint* bone = GetJointByName( a_Bone );
	if (bone)
	{
		MD5Attachment* obj = new MD5Attachment();
		obj->bone = bone->id;
		obj->obj = a_Obj;
		obj->obj->SetType( Node::REFITTABLE );
		obj->offset = a_Offset;
		obj->m = a_Obj->GetTransform();
		if (m_AttachFirst == NULL) m_AttachFirst = obj;
		else m_AttachLast->next = obj;
		m_AttachLast = obj;
		obj->next = NULL;
		obj->m_MatList = new Material*[64];
		obj->m_MatListCount = 0;
		for (int i=0; i<obj->obj->GetPrimCount(); i++)
		{
			bool add = true;
			for ( int j = 0; j < obj->m_MatListCount; j++ )
			{
				if (obj->m_MatList[j] == obj->obj->GetPrim(i)->GetMaterial())
				{
					add = false;
					break;
				}
			}
			if (add)
			{
				obj->m_MatList[obj->m_MatListCount] = obj->obj->GetPrim(i)->m_Material;
				obj->m_MatListCount++;
			}
		}
		m_AttachmentCount++;
		RebuildMatList();
	}
}

void MD5Model::RebuildMatList()
{
	delete m_MatList;
	m_MatListCount = m_MeshCount;
	MD5Attachment* atchm = m_AttachFirst;
	while (atchm != NULL)
	{
		m_MatListCount += atchm->m_MatListCount;
		atchm = atchm->next;
	}
	m_MatList = new Material*[m_MatListCount];
	for ( int i = 0; i < m_MeshCount; i++ ) m_MatList[i] = m_Meshes[i].Mat;
	int index = m_MeshCount;
	atchm = m_AttachFirst;
	while (atchm != NULL)
	{
		for ( int i = 0; i < atchm->m_MatListCount; i++ )
		{
			m_MatList[index] = atchm->m_MatList[i];
			index++;
		}
		atchm = atchm->next;
	}
}

void MD5Model::SetColorSceme( Color &a_Ambient, Color &a_Diffuse, Color &a_Specular )
{
	for ( int i = 0; i < m_MeshCount; i++ )
	{
		m_Meshes[i].Mat->SetAmbient( a_Ambient );
		m_Meshes[i].Mat->SetDiffuse( a_Diffuse );
		m_Meshes[i].Mat->SetSpecular( a_Specular );
	}
}
void MD5Model::SetReflection( float a_RefMin, float a_RefMax )
{
	for ( int i = 0; i < m_MeshCount; i++ )
	{
		m_Meshes[i].Mat->SetMinReflection( a_RefMin );
		m_Meshes[i].Mat->SetMaxReflection( a_RefMax );
	}
}
void MD5Model::SetRefraction( float a_Refr, float a_Index )
{
	for ( int i = 0; i < m_MeshCount; i++ )
	{
		m_Meshes[i].Mat->SetRefraction( a_Refr );
		m_Meshes[i].Mat->SetRefrIndex( a_Index );
	}
}

MD5Anim* MD5Model::GetAnimByName( char* a_Name )
{
	MD5Anim* anim = m_AnimFirst;
	while (anim != NULL)
	{
		if (!_stricmp( anim->name, a_Name )) break;
		anim = anim->next;
	}
	return anim;
}

void MD5Model::PlayAnimByName( char* a_Name )
{
	MD5Anim* anim = GetAnimByName( a_Name );
	if (anim) PlayAnim( anim );
}

MD5Anim* MD5Model::GetAnimById( int a_Id )
{
	int counter = 0;
	MD5Anim* anim = m_AnimFirst;
	while (anim != NULL)
	{
		if (counter == a_Id) break;
		counter++;
		anim = anim->next;
	}
	return anim;
}

void MD5Model::PlayAnimById( int a_Id )
{
	MD5Anim* anim = GetAnimById( a_Id );
	if (anim) PlayAnim( anim );
}

void MD5Model::PlayAnim( MD5Anim* a_Anim )
{
	m_AnimCurrent.anim = a_Anim;
	m_AnimCurrent.framecurrent = 0;
	m_AnimCurrent.framenext = 1;
	m_AnimCurrent.lasttime = 0.0f;
	m_AnimCurrent.blend = 1.0f;
}

void MD5Model::Update( float a_DT )
{
	if (m_AnimCurrent.anim)
	{
		if (m_AnimCurrent.anim->framecount > 1)
		{
			m_AnimCurrent.lasttime += a_DT;
			float frametime = 1.0f / m_AnimCurrent.anim->framerate;
			while (m_AnimCurrent.lasttime >= frametime)
			{
				m_AnimCurrent.framecurrent++;
				m_AnimCurrent.framenext++;
				m_AnimCurrent.lasttime -= frametime;
				if (m_AnimCurrent.framenext >= m_AnimCurrent.anim->framecount)
				{
					m_AnimCurrent.framecurrent = 0;
					m_AnimCurrent.framenext = 1;
				}
			}
			InterpolateSkeletons( m_AnimCurrent.anim->skelframes[m_AnimCurrent.framecurrent],
								  m_AnimCurrent.anim->skelframes[m_AnimCurrent.framenext],
								  m_AnimCurrent.lasttime * m_AnimCurrent.anim->framerate );
		}
		else
		{
			m_AnimCurrent.framecurrent = 0;
			m_AnimCurrent.framenext = 0;
			m_AnimCurrent.lasttime = 0.0f;
			m_Skeleton = m_AnimCurrent.anim->skelframes[0];				
		}
		m_BBox = m_AnimCurrent.anim->bbox[m_AnimCurrent.framecurrent];
		m_BBox.min = m_Mat.Transform( m_BBox.min*m_Scale );
		m_BBox.max = m_Mat.Transform( m_BBox.max*m_Scale );
	}
	else
	{
		m_Skeleton = m_BaseSkeleton;
		m_BBox.min = vector3(-1,-1,-1);
		m_BBox.max = vector3(1,1,1);
		m_BBox.min = m_Mat.Transform( m_BBox.min*m_Scale );
		m_BBox.max = m_Mat.Transform( m_BBox.max*m_Scale );
	}
	vector3 offset;
	if (!_stricmp( m_Skeleton[0].name, "origin" )) offset = m_Skeleton[0].pos;
	for ( int n = 0; n < m_MeshCount; n++ )
	{
		MD5Mesh* m = &m_Meshes[n];
		for ( int i = 0; i < m->VertCount; i++ )
		{
			m->Vertices[i].v->m_Pos = -offset;
			for ( int j = 0; j < m->Vertices[i].count; j++ )
			{			
				MD5Weight* weight = &m->Weights[m->Vertices[i].start + j];
				MD5Joint* joint = &m_Skeleton[weight->joint];
				m->Vertices[i].v->m_Pos += (joint->pos + quat4RotatePoint( joint->orient, weight->pos )) * weight->bias;
			}
		}
	}
	for ( int i = 0; i < m_VertCount; i++ ) m_VPool[m_VertCount+i].m_Pos = m_VPool[i].m_Pos;
	for ( int i = 0; i < m_PCount; i++ )
	{
		Primitive* op = m_OPrim[i];
		op->UpdateNormal();
		op->m_Vertex[0]->m_N -= op->GetNormal();
		op->m_Vertex[1]->m_N -= op->GetNormal();
		op->m_Vertex[2]->m_N -= op->GetNormal();
	}
	for (int i=0; i<m_VertCount; i++) NORMALIZE(m_VPool[m_VertCount+i].m_N);
	Transform();
	MD5Attachment* atchm = m_AttachFirst;
	while (atchm != NULL)
	{
		matrix m = m_Mat;
		m.Concatenate( atchm->m );
		m.SetTranslation( m_Mat.Transform(( atchm->offset-offset + m_Skeleton[atchm->bone].pos) * m_Scale ) );
		atchm->obj->SetTransform(m);
		atchm->obj->Transform();
		atchm = atchm->next;
	}
}

SceneGraph::SceneGraph()
{
	m_Node = new Node*[MAXSCENENODES];
	m_NCount = 0;
	m_BVHFirst = 0; // no need to allocate, MManager knows we need up to 512
	m_BVHRoot = 0;
}

SceneGraph::~SceneGraph()
{
	delete m_Node;
}

int SceneGraph::FindBestMatch( BVHNode* A, BVHNode** list, int lsize )
{
	float smallest = 10000000;
	int bestB = 0;
	for ( int i = 0; i < lsize; i++ )
	{
		BVHNode* B = list[i];
		if (B != A)
		{
			vector3 umin( min( A->min.x, B->min.x ), min( A->min.y, B->min.y ), min( A->min.z, B->min.z ) );
			vector3 umax( max( A->max.x, B->max.x ), max( A->max.y, B->max.y ), max( A->max.z, B->max.z ) );
			vector3 usize = umax - umin;
			float surf = usize.x * usize.y + usize.y * usize.z + usize.z * usize.x;
			if (surf < smallest) smallest = surf, bestB = i;
		}
	}
	return bestB;
}

void SceneGraph::BuildTopBVH()
{
	// create an array of the node BVHs for easy access
	BVHNode* node[MAXSCENENODES];
	BVHNode* temp[MAXSCENENODES];
	Node* list[MAXSCENENODES];
	int todo = 0;
	for ( unsigned int i = 0; i < m_NCount; i++ ) if (m_Node[i]->IsActive()) list[todo++] = m_Node[i];
	for ( unsigned int i = 0; i < todo; i++ ) node[i] = &MManager::GetBVHPool()[list[i]->GetBVHRoot()];
	// create root node
	BVHNode* pool = MManager::GetBVHPool();
	int poolidx = 1;
	m_BVHRoot = &pool[m_BVHFirst];
	// BVH construction based on 'Fast Agglomerative Clustering for Rendering', Walter et al.
	int aidx = 0;
	BVHNode* A = node[0];
	int bidx = FindBestMatch( A, node, todo );
	BVHNode* B = node[bidx];
	while (todo > 1)
	{
		int cidx = FindBestMatch( B, node, todo );
		BVHNode* C = node[cidx];
		if (A == C)
		{
			for ( int idx = 0, i = 0; i < todo; i++ ) if ((node[i] != A) && (node[i] != B)) temp[idx++] = node[i];
			memcpy( node, temp, ----todo * sizeof( BVHNode* ) );
			BVHNode* a_parent = &pool[poolidx++];
			BVHNode* b_parent = &pool[poolidx++];
			BVHNode* ab_parent = &pool[poolidx++];
			*a_parent = *A, *b_parent = *B;
			*(__m128*)&ab_parent->min = _mm_min_ps( *(__m128*)&a_parent->min, *(__m128*)&b_parent->min );
			*(__m128*)&ab_parent->max = _mm_max_ps( *(__m128*)&a_parent->max, *(__m128*)&b_parent->max );
			ab_parent->data = 0, ab_parent->left = poolidx - 3;
		#ifdef ALTFIRST
			ab_parent->UpdateDirMasks();
		#endif
			node[todo++] = ab_parent;
		}
		else
		{
			A = B, aidx = bidx;
			B = C, bidx = cidx;
		}
	}
	*m_BVHRoot = *node[0];
}

int SceneGraph::GetPolyCount()
{
	int count = 0;
	for ( unsigned int i = 0; i < m_NCount; i++ ) count += m_Node[i]->GetPrimCount();
	return count;
}

void SceneGraph::Update()
{
	STimer.reset();
	for ( unsigned int i = 0; i < m_NCount; i++ )
	{
		//m_Node[i]->Transform();
		if (!m_Node[i]->IsConstructed())
		{
			m_Node[i]->BuildBVH();
			m_Node[i]->Optimize();
			m_Node[i]->Constructed( true );
			m_Node[i]->NewFormat();
		}
		else
		{
			if (m_Node[i]->GetType() == Node::REFITTABLE ) m_Node[i]->Refit();
			if (m_Node[i]->GetType() == Node::DYNAMIC) m_Node[i]->BuildBVH();
		}
	}
	BuildTopBVH();
	Engine::m_BuildTime = (float)STimer.elapsed();
}

void SceneGraph::DeleteNode( Node* a_Node )
{
	int pos = -1;
	Node* node = 0;
	for ( unsigned int i = 0; i < m_NCount; i++ ) if (m_Node[i] == a_Node) pos = i, node = m_Node[i];
	if (node)
	{	
		m_Node[pos] = m_Node[m_NCount - 1];
		m_NCount--;
		BVHBuilder* builder = node->GetBuilder();
		int firstbvh = builder->GetFirstBVHNode();
		int lastbvh = builder->GetLastBVHNode();
		int firstprim = builder->GetFirstBVHPrim();
		int lastprim = builder->GetLastBVHPrim();
		int noffset = (lastbvh - firstbvh) + 1;
		int poffset = (lastprim - firstprim) + 1;
		MManager::FreeBVHNodes( firstbvh, lastbvh, firstprim, lastprim );
		for ( int i = 0; i < m_NCount; i++ ) if (m_Node[i]->GetBuilder()->GetFirstBVHNode() > firstbvh)
		{
			m_Node[i]->GetBuilder()->ShiftNodes( noffset, poffset );
		}
	}
}

void SceneGraph::Break(vector3 a_Direction)
{
	for ( unsigned int i = 0; i < m_NCount; i++ ) m_Node[i]->Break( a_Direction );
}
void SceneGraph::Break()
{
	for ( unsigned int i = 0; i < m_NCount; i++ ) m_Node[i]->Break();
}
void SceneGraph::SetGravity(bool a_Bool, vector3 a_Vector)
{
	for ( unsigned int i = 0; i < m_NCount; i++ ) m_Node[i]->SetGravity( a_Bool, a_Vector );
}

} // namespace RTGame
