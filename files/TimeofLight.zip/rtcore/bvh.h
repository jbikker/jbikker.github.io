// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#pragma once

#include "common_math.h"
#include "sthread.h"

#pragma warning (disable : 4311)
#pragma warning (disable : 4312)

namespace Raytracer {

class Primitive;
class MManager;
class Scene;

// -----------------------------------------------------------
// BVH node class
// -----------------------------------------------------------

struct BVHNode
{
	// member data access methods
	unsigned int GetAxis() const { return (data >> 29) & 3; }
	unsigned int GetLeft() const { return left & 0x00FFFFFF; }
	unsigned int GetRight() const { return (left & 0x00FFFFFF) + 1; }
	void SetAxis( unsigned int a ) { data = (data & 0x9FFFFFFF) + (a << 29); }
	unsigned int GetTCount() const { return (data & 0x0FFFFFFF); }
	unsigned int GetStart() const { return start; }
	void SetTCount( unsigned int c ) { data = c + (data & 0xF0000000); };
	void SetStart( unsigned int s ) { start = s; }
	bool IsLeaf() const { return ((data & 0xFFFFFFF) != 0); }
	unsigned int GetFirst() const { return (data >> 31); }
	void SetFirst( unsigned int f ) { data = (data & 0x7FFFFFFF) + (f << 31); }
	void SetLeft( unsigned int idx ) { left = (left & 0xFF000000)|idx; }
	void SetDirMask( unsigned int mask ) { left = (left & 0x00FFFFFF) + (mask << 24); }
	unsigned int GetDirMask() const { return left >> 24; }
	void CountLeafs( int& a_Leafs, int& a_Prims, int& a_MaxPrims, int& a_MaxDepth, float& a_Area, float& a_TArea, int& a_Nodes, int a_Depth );
	void UpdateDirMasks();
	// data members
	union
	{
		struct
		{
			vector3 min;
			union
			{
				unsigned int left;  // first child node (inner)
				unsigned int start; // first triangle ID (leaf)
			};
			vector3 max;
			unsigned int data;		// total 32 bytes
		};
		struct
		{
			__m128 min4;
			__m128 max4;
		};
	};
};

// -----------------------------------------------------------
// BVH node class
// -----------------------------------------------------------

struct BinTri
{
	__m128 boxp1, boxp2, centroid;	// 32
	Primitive* prim;				// 4
	int dummy1, dummy2, dummy3;		// 12
};

struct BinStack
{
	__m128 vmin4, vmax4, cmin4, cmax4;
	int first, last, dummy;
	BVHNode* node;
};

struct RefitStack
{
	BVHNode* node, *parent;
};

#define SSE_X	 3
#define SSE_Y	 2
#define SSE_Z    1

// -----------------------------------------------------------
// BVHBuilder abstract base class
// Builds or updates the BVH associated with a scenegraph node
// -----------------------------------------------------------

class Node;
class BVHBuilder
{
	friend class Refitter;
public:
	BVHBuilder() {};
	BVHBuilder( Node* a_Node ) {};
	virtual ~BVHBuilder() {};
	virtual void Build() = 0;
	BVHNode* GetRoot() { return m_Root; }
	int GetRootIdx() { return m_FirstNode; }
	void UpdateDirMasks();
	void Refit();
	void NewFormat();
	int GetFirstBVHNode() { return m_FirstNode; }
	int GetLastBVHNode() { return m_LastNode; }
	int GetFirstBVHPrim() { return m_FirstPrim; }
	int GetLastBVHPrim() { return m_LastPrim; }
	void ShiftNodes( int a_NOffset, int a_POffset );
private:
	void RefitRecurse( BVHNode* a_Node, __m128& a_Min4, __m128& a_Max4 );
protected:
	Node* m_Node;
	int m_PCount;
	BVHNode* m_Pool, *m_Root;
	Primitive** m_Prim;
	int m_FirstNode, m_FirstPrim, m_LastNode, m_LastPrim;
};

}; // namespace Raytracer