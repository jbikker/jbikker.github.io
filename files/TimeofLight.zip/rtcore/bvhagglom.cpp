// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#include "precomp.h"
#include "windows.h"
#include "bvh.h"

namespace Raytracer {

// --------------------------------------------------------------------------
// AgglomerativeBuilder class
// --------------------------------------------------------------------------

AgglomerativeBuilder::AgglomerativeBuilder( Node* a_Node )
{
	m_Node = a_Node;									
	m_PCount = a_Node->GetPrimCount();					
	int allocsize = m_PCount;
#ifdef BVHPRESPLIT
	allocsize = m_PCount + (m_PCount >> 1);
#endif
	m_FirstNode = MManager::AllocBVHNodes( allocsize * 2 );
	m_FirstPrim = MManager::AllocBVHPrims( allocsize );
	m_BTPool = (BinTri*)MALLOC64( sizeof( BinTri ) * allocsize );
	m_Pool = MManager::GetBVHPool();
	m_Root = &m_Pool[m_FirstNode];								
	m_Prim = &MManager::GetBVHPrims()[m_FirstPrim];				
	m_Tri = new BinTri*[allocsize];								
	for ( int i = 0; i < allocsize; i++ ) m_Tri[i] = &m_BTPool[i];
}

AgglomerativeBuilder::~AgglomerativeBuilder()
{
	FREE64( m_BTPool );
	delete m_Tri;
}

Cluster* AgglomerativeBuilder::FindBestMatch( Cluster* m_Cluster, Cluster* a_List )
{
	Cluster* curr = a_List;
	float bestcost = 100000000000;
	Cluster* bestcluster = 0;
	while (curr)
	{
		if (curr != m_Cluster)
		{
			const __m128 vmin = _mm_min_ps( curr->vmin, m_Cluster->vmin ); float* amin = (float*)&vmin;
			const __m128 vmax = _mm_max_ps( curr->vmax, m_Cluster->vmax ); float* amax = (float*)&vmax;
			const float ex = amax[0] - amin[0], ey = amax[1] - amin[1], ez = amax[2] - amin[2];
			const float cost = ex * ey + ey * ez + ez * ex;
			if (cost < bestcost)
			{
				bestcost = cost;
				bestcluster = curr;
			}
		}
		curr = curr->next;
	}
	return bestcluster;
}

void AgglomerativeBuilder::Build()
{
	int starttime = GetTickCount();
	// quick and dirty agglomerative BVH construction
	int allocsize = m_PCount;
#ifdef BVHPRESPLIT
	allocsize = m_PCount + (m_PCount >> 1);
#endif
	memcpy( m_Prim, m_Node->GetPrimArray(), m_PCount * 4 );
	Cluster* cpool = (Cluster*)MALLOC64( ((allocsize * 2) + 1) * sizeof( Cluster ) );
	// determine centroids and aabbs for all triangles
	const __m128 plarge = _mm_set_ps1( 100000 ), nlarge = _mm_set_ps1( -100000 ), half4 = _mm_set_ps1( 0.5f );
	int pidx = 0, splitroom = m_PCount >> 1;
	for ( int r = 0; r < m_PCount; r++ )
	{
		__m128 emin4 = plarge, emax4 = nlarge;
		for ( int j = 0; j < 3; j++ )
		{
			const vector3 pos = m_Prim[r]->GetVertex( j )->GetPos();
			const __m128 pos4 = _mm_set_ps( 0, pos.z, pos.y, pos.x );
			emin4 = _mm_min_ps( emin4, pos4 ), emax4 = _mm_max_ps( emax4, pos4 );
		}
		m_Tri[pidx]->prim = m_Prim[r];
		m_Tri[pidx]->boxp1 = emin4;
		m_Tri[pidx]->boxp2 = emax4;
		m_Tri[pidx]->centroid = _mm_mul_ps( _mm_add_ps( emin4, emax4 ), half4 );
		pidx++;
	#ifdef BVHPRESPLIT
		// pre-split triangles
		BinTri* bstack[64]; int bsidx[64];
		bstack[0] = m_Tri[pidx - 1]; bsidx[0] = pidx - 1;
		int bsptr = 1;
		while (bsptr > 0)
		{
			BinTri* tri1 = bstack[--bsptr];
			BinTri* tri2 = m_Tri[pidx];
			float* emin = (float*)&tri1->boxp1;
			float* emax = (float*)&tri1->boxp2;
			vector3 p1( emin[0], emin[1], emin[2] ), p2( emax[0] - emin[0], emax[1] - emin[1], emax[2] - emin[2] );
			aabb box = aabb::FromPosSize( p1, p2 );
			float sarea = box.area();
			if ((sarea > 90) && (splitroom > 0))
			{
				// split and push both halves on the stack
				int axis = box.LongestSide();
				float centre = (box.GetP1().cell[axis] + box.GetP2().cell[axis]) * 0.5f;
				// emit boxes
				*tri2 = *tri1;
				float* temax = (float*)&tri1->boxp2;
				float* temin = (float*)&tri2->boxp1;
				temax[axis] = temin[axis] = centre;
				tri1->centroid = _mm_mul_ps( _mm_add_ps( tri1->boxp1, tri1->boxp2 ), half4 );
				tri2->centroid = _mm_mul_ps( _mm_add_ps( tri2->boxp1, tri2->boxp2 ), half4 );
				bsptr++;
				bstack[bsptr] = tri2; 
				bsidx[bsptr++] = pidx++;
				splitroom--;
			}
			else m_Tri[bsidx[bsptr]] = tri1;
		}
	#endif
	}
	int cidx = 0, todo = pidx;
	for ( int r = 0; r < pidx; r++ )
	{
		cpool[cidx].cmin = cpool[cidx].cmax = m_Tri[r]->centroid;
		cpool[cidx].prim[0] = m_Tri[r];
		cpool[cidx].prims = 1;
		cpool[cidx].left = cpool[cidx].right = 0;
		cpool[cidx].next = &cpool[cidx + 1];
		cpool[cidx].vmin = m_Tri[r]->boxp1, cpool[cidx].vmax = m_Tri[r]->boxp2;
		if (cidx > 0) cpool[cidx].prev = &cpool[cidx - 1];
		cidx++;
	}
	cpool[cidx - 1].next = cpool[0].prev = 0;
	Cluster* head = &cpool[0];
	Cluster* A = head, *B;
	while (todo > 1)
	{
		B = FindBestMatch( A, head );
		Cluster* C = FindBestMatch( B, head );
		if (A == C)
		{
			// delete A and B
			if (!A->prev) head = A->next; else A->prev->next = A->next;
			if (A->next) A->next->prev = A->prev;
			if (!B->prev) head = B->next; else B->prev->next = B->next;
			if (B->next) B->next->prev = B->prev;
			// insert new cluster
			Cluster* newcluster = &cpool[cidx++];
			newcluster->prims = 0;
			newcluster->left = A;
			newcluster->right = B;
			newcluster->next = head;
			newcluster->prev = 0;
			if (head) head->prev = newcluster;
			newcluster->cmin = _mm_min_ps( A->cmin, B->cmin );
			newcluster->cmax = _mm_max_ps( A->cmax, B->cmax );
			newcluster->vmin = _mm_min_ps( A->vmin, B->vmin );
			newcluster->vmax = _mm_max_ps( A->vmax, B->vmax );
			head = A = newcluster;
			todo--;
		}
		else A = B, B = C;
	}
	int elapsed = GetTickCount() - starttime;
#if 1
	{
		int leafs = 0, prims = 0, maxprims = 0, maxdepth = 0, nodes = 0;
		float area = 0, tarea = 0;
		ClusterTreeStats( A, nodes, leafs, maxdepth, 0 );
		Log::IntValue( "agglomerative build - prims:", m_PCount );
		Log::IntValue( "agglomerative build - leafs:", leafs );
		Log::IntValue( "agglomerative build - nodes:", nodes );
		Log::IntValue( "agglomerative build - depth:", maxdepth );
		Log::IntValue( "agglomerative build - time: ", elapsed / 1000 );
	}
#endif
	// turn the cluster tree into a BVH
	m_PIdx = m_FirstNode;
	m_Root = &m_Pool[m_PIdx++];
	for ( int i = 0; i < 6; i++ )
	{
		Log::IntValue( "optimization pass ", i );
		OptimizeClusters( A );
	#if 1
		{
			int leafs = 0, prims = 0, maxprims = 0, maxdepth = 0, nodes = 0;
			float area = 0, tarea = 0;
			ClusterTreeStats( A, nodes, leafs, maxdepth, 0 );
			Log::IntValue( "agglomerative - leafs:", leafs );
			Log::IntValue( "agglomerative - nodes:", nodes );
			Log::IntValue( "agglomerative - depth:", maxdepth );
		}
	#endif
	}
	CreateBVH( A, m_Root );
	// m_Root->CountLeafs( leafs, prims, maxprims, maxdepth, area, tarea, nodes, 0 );
}

void AgglomerativeBuilder::ClusterTreeStats( Cluster* a_Node, int& a_Nodes, int& a_Leafs, int& a_MaxDepth, int a_Depth )
{
	a_Nodes++;
	if (a_Depth > a_MaxDepth) a_MaxDepth = a_Depth;
	if (a_Node->left) 
	{
		ClusterTreeStats( a_Node->left, a_Nodes, a_Leafs, a_MaxDepth, a_Depth + 1 );
		ClusterTreeStats( a_Node->right, a_Nodes, a_Leafs, a_MaxDepth, a_Depth + 1 );
	}
	else a_Leafs++;
}

static int triidx = 0;
void AgglomerativeBuilder::CreateBVH( Cluster* a_Node, BVHNode* a_Root )
{
	if (a_Node->left)
	{
		// inner node
		int lidx = m_PIdx;
		int ridx = m_PIdx + 1;
		m_PIdx += 2;
		BVHNode* lchild = &m_Pool[lidx];
		BVHNode* rchild = &m_Pool[ridx];
		CreateBVH( a_Node->left, lchild );
		CreateBVH( a_Node->right, rchild );
		*(__m128*)&a_Root->min = _mm_min_ps( *(__m128*)&lchild->min, *(__m128*)&rchild->min );
		*(__m128*)&a_Root->max = _mm_max_ps( *(__m128*)&lchild->max, *(__m128*)&rchild->max );
		a_Root->left = a_Root->data = 0;
		a_Root->SetLeft( lidx );
	}
	else 
	{
		*(__m128*)&a_Root->min = *(__m128*)&a_Node->vmin;
		*(__m128*)&a_Root->max = *(__m128*)&a_Node->vmax;
		a_Root->data = a_Root->left = 0;
		a_Root->SetTCount( a_Node->prims );
		a_Root->SetStart( triidx + m_FirstPrim );
		for ( int i = 0; i < a_Node->prims; i++ ) m_Prim[triidx++] = a_Node->prim[i]->prim;
	}
}

void AgglomerativeBuilder::OptimizeClusters( Cluster* a_Node )
{
	if (a_Node->left)
	{
		if ((a_Node->left->IsLeaf()) && (a_Node->right->IsLeaf()))
		{
			// calculate unified bounding box
			const __m128 amin4 = _mm_min_ps( a_Node->left->vmin, a_Node->right->vmin ); float* amin = (float*)&amin4;
			const __m128 amax4 = _mm_max_ps( a_Node->left->vmax, a_Node->right->vmax ); float* amax = (float*)&amax4;
			const float ex = amax[0] - amin[0], ey = amax[1] - amin[1], ez = amax[2] - amin[2];
			const float area = ex * ey + ey * ez + ez * ex;
			// calculate individual areas
			float* lmin = (float*)&a_Node->left->vmin, *lmax = (float*)&a_Node->left->vmax;
			float* rmin = (float*)&a_Node->right->vmin, *rmax = (float*)&a_Node->right->vmax;
			const float lex = lmax[0] - lmin[0], ley = lmax[1] - lmin[1], lez = lmax[2] - lmin[2];
			const float rex = rmax[0] - rmin[0], rey = rmax[1] - rmin[1], rez = rmax[2] - rmin[2];
			const float larea = lex * ley + ley * lez + lez * lex;
			const float rarea = rex * rey + rey * rez + rez * rex;
			const float lfact = area / larea;
			const float rfact = area / rarea;
			// join if appropriate
			int total = a_Node->left->prims + a_Node->right->prims;
			if ((lfact < 1.05f) && (rfact < 1.05f) && (total < 9))
			{
				for ( int i = 0; i < a_Node->left->prims; i++ ) a_Node->prim[i] = a_Node->left->prim[i];
				for ( int i = 0; i < a_Node->right->prims; i++ ) a_Node->prim[i + a_Node->left->prims] = a_Node->right->prim[i];
				a_Node->prims = total;
				a_Node->left = a_Node->right = 0;
			}
		}
		else
		{
			OptimizeClusters( a_Node->left );
			OptimizeClusters( a_Node->right );
		}
	}
}

}; // namespace Raytracer