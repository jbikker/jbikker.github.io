// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#pragma once

#include "common_math.h"
#include "sthread.h"

namespace Raytracer {

struct BinTri;
struct BVHNode;
class Node;

class StaticBuilder : public BVHBuilder
{
	class BuildThread : public Thread
	{
	public:
		void Init( int a_Thread, int a_PCount, StaticBuilder* a_Builder );
		void SetData( int firstPrim, BinTri** trilist, BVHNode* root, int first, int last, BVHNode* pool, int pidx ); 
		void SetCBox( __m128 min4, __m128 max4 ) { box[0] = min4; box[1] = max4; }
		void SetVBox( __m128 min4, __m128 max4 ) { box[2] = min4; box[3] = max4; }
		void Build();
		void run();
	private:
		__m128* box;
		int m_Thread, m_First, m_Last, m_PIdx, m_FirstPrim;
		BinTri** m_Tri, **m_TTri;
		StaticBuilder* m_Builder;
		BVHNode* m_Root, *m_Pool;
	};
public:
	StaticBuilder( Node* a_Node );
	~StaticBuilder();
	void Build();
protected:
	HANDLE m_Wait[2];
	HANDLE m_Done[2];
private:
	BuildThread m_TBuilder[2];
	BinTri** m_Tri, **m_TTri;
	BinTri* m_BTPool;
};

}; // namespace Raytracer