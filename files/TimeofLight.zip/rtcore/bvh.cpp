// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#include "precomp.h"
#include "windows.h"
#include "bvh.h"

namespace Raytracer {

static const float flt_plus_inf = -logf(0);

void BVHNode::CountLeafs( int& a_Leafs, int& a_Prims, int& a_MaxPrims, int& a_MaxDepth, float& a_Area, float& a_TArea, int& a_Nodes, int a_Depth )
{
	a_Nodes++;
	vector3 size = this->max - this->min;
	aabb bbox = aabb::FromPosSize( this->min, size );
	a_Area += bbox.area();
	if (a_Depth < 10) a_TArea += bbox.area();
	if (a_Depth > a_MaxDepth) a_MaxDepth = a_Depth;
	if (IsLeaf())
	{
		a_Leafs++;
		a_Prims += GetTCount();
		if ((int)GetTCount() > a_MaxPrims) a_MaxPrims = GetTCount();
	}
	else
	{
		BVHNode* lnode = &MManager::GetBVHPool()[GetLeft()];
		BVHNode* rnode = &MManager::GetBVHPool()[GetRight()];
		lnode->CountLeafs( a_Leafs, a_Prims, a_MaxPrims, a_MaxDepth, a_Area, a_TArea, a_Nodes, a_Depth + 1 );
		rnode->CountLeafs( a_Leafs, a_Prims, a_MaxPrims, a_MaxDepth, a_Area, a_TArea, a_Nodes, a_Depth + 1 );
	}
}

void BVHNode::UpdateDirMasks()
{
	BVHNode* pool = MManager::GetBVHPool();
	BVHNode* lnode = &pool[GetLeft()];
	BVHNode* rnode = &pool[GetRight()];
	int mask = 0;
	for( int signmask = 0; signmask < 8; ++signmask )
	{
		// compute bounding box describing the volume of interest
		int front = 0; 
		vector3 intL, intU;
		for( int axis = 0; axis < 3; ++axis )
		{
			if (signmask & (1 << axis))
			{
				intL[axis] = max( lnode->min[axis], rnode->min[axis] );
				intU[axis] = max( lnode->max[axis], rnode->max[axis] );
				front |= (lnode->max[axis] >= rnode->max[axis]) ? 0 : (1 << axis);
			}
			else
			{
				intL[axis] = min( lnode->min[axis], rnode->min[axis] );
				intU[axis] = min( lnode->max[axis], rnode->max[axis] );
				front |= (lnode->min[axis] <= rnode->min[axis]) ? 0 : (1 << axis);
			}
		}
		// intersect the bounding boxes with the volume of interest
		const vector3 leftL( max( lnode->min.x, intL.x ), max( lnode->min.y, intL.y ), max( lnode->min.z, intL.z ) );
		const vector3 leftU( min( lnode->max.x, intU.x ), min( lnode->max.y, intU.y ), min( lnode->max.z, intU.z ) );
		const vector3 rightL( max( rnode->min.x, intL.x ), max( rnode->min.y, intL.y ), max( rnode->min.z, intL.z ) );
		const vector3 rightU( min( rnode->max.x, intU.x ), min( rnode->max.y, intU.y ), min( rnode->max.z, intU.z ) );
		bool lvalid = (leftL.x <= leftU.x && leftL.y <= leftU.y && leftL.z <= leftU.z);
		bool rvalid = (rightL.x <= rightU.x && rightL.y <= rightU.y && rightL.z <= rightU.z);
		// calculate the surface areas of the visible sides
		vector3 dl = leftU - leftL, dr = rightU - rightL;
		float larea = lvalid ? 0 : (dl.x * (dl.y + dl.z) + dl.y * dl.z);
		float rarea = rvalid ? 0 : (dr.x * (dr.y + dr.z) + dr.y * dr.z);
		if (lvalid && rvalid)
		{
			// subtract the occluded surface areas
			const vector3 dimin( min( leftU.x, rightU.x ), min( leftU.y, rightU.y ), min( leftU.z, rightU.z ) );
			const vector3 dimax( max( leftL.x, rightL.x ), max( leftL.y, rightL.y ), max( leftL.z, rightL.z ) );
			const vector3 di = dimin - dimax;
			((front & 0x1) ? larea : rarea) -= max( 0.0f, di.y * di.z );
			((front & 0x2) ? larea : rarea) -= max( 0.0f, di.x * di.z );
			((front & 0x4) ? larea : rarea) -= max( 0.0f, di.x * di.y );
		}
		// pick the node with the larger visible area as the near node
		mask |= (larea >= rarea) ? 0 : (1 << signmask);
	}
	SetDirMask( mask );
}

void BVHBuilder::ShiftNodes( int a_NOffset, int a_POffset )
{
	m_FirstNode -= a_NOffset;
	m_LastNode -= a_NOffset;
	m_FirstPrim -= a_POffset;
	m_LastPrim -= a_POffset;
	for ( int i = m_FirstNode; i <= m_LastNode; i++ )
	{
		BVHNode* node = &m_Pool[i];
		if (node->IsLeaf()) node->SetStart( node->GetStart() - a_POffset );
					   else node->SetLeft( node->GetLeft() - a_NOffset );
	}
	m_Root = &m_Pool[m_FirstNode];
	m_Prim = &MManager::GetBVHPrims()[m_FirstPrim];
}

void BVHBuilder::NewFormat()
{
	/* int count = ((m_LastNode - (m_FirstNode + 1)) + 1) >> 1;
	BVHPair* pair = (BVHPair*)&m_Pool[m_FirstNode + 1]; // skip root
	BVHNode* mono = (BVHNode*)pair;
	for ( int i = 0; i < count; i++ )
	{	
		BVHNode* node1 = &mono[0];
		BVHNode* node2 = &mono[1];
		__m128 XXXX = _mm_set_ps( node1->min.x, node1->max.x, node2->min.x, node2->max.x );
		__m128 YYYY = _mm_set_ps( node1->min.y, node1->max.y, node2->min.y, node2->max.y );
		__m128 ZZZZ = _mm_set_ps( node1->min.z, node1->max.z, node2->min.z, node2->max.z );
		unsigned int start1 = node1->start;
		unsigned int start2 = node2->start;
		unsigned int data1 = node1->data;
		unsigned int data2 = node2->data;
		pair->XXXX = XXXX;
		pair->YYYY = YYYY;
		pair->ZZZZ = ZZZZ;
		pair->start[0] = start1;
		pair->start[1] = start2;
		pair->data[0] = data1;
		pair->data[1] = data2;
		mono += 2;
		pair++;
	} */
}

void BVHBuilder::UpdateDirMasks()
{
	BVHNode* stack[MAXBVHDEPTH];
	int stackptr = 1;
	stack[0] = m_Root;
	while (stackptr)
	{
		BVHNode* node = stack[--stackptr];
		if (!node->IsLeaf())
		{
			BVHNode* lnode = &m_Pool[node->GetLeft()];
			BVHNode* rnode = &m_Pool[node->GetRight()];
			int mask = 0;
			for( int signmask = 0; signmask < 8; ++signmask )
			{
				// compute bounding box describing the volume of interest
				int front = 0; 
				vector3 intL, intU;
				for( int axis = 0; axis < 3; ++axis )
				{
					if (signmask & (1 << axis))
					{
						intL[axis] = max( lnode->min[axis], rnode->min[axis] );
						intU[axis] = max( lnode->max[axis], rnode->max[axis] );
						front |= (lnode->max[axis] >= rnode->max[axis]) ? 0 : (1 << axis);
					}
					else
					{
						intL[axis] = min( lnode->min[axis], rnode->min[axis] );
						intU[axis] = min( lnode->max[axis], rnode->max[axis] );
						front |= (lnode->min[axis] <= rnode->min[axis]) ? 0 : (1 << axis);
					}
				}
				// intersect the bounding boxes with the volume of interest
				const vector3 leftL( max( lnode->min.x, intL.x ), max( lnode->min.y, intL.y ), max( lnode->min.z, intL.z ) );
				const vector3 leftU( min( lnode->max.x, intU.x ), min( lnode->max.y, intU.y ), min( lnode->max.z, intU.z ) );
				const vector3 rightL( max( rnode->min.x, intL.x ), max( rnode->min.y, intL.y ), max( rnode->min.z, intL.z ) );
				const vector3 rightU( min( rnode->max.x, intU.x ), min( rnode->max.y, intU.y ), min( rnode->max.z, intU.z ) );
				bool lvalid = (leftL.x <= leftU.x && leftL.y <= leftU.y && leftL.z <= leftU.z);
				bool rvalid = (rightL.x <= rightU.x && rightL.y <= rightU.y && rightL.z <= rightU.z);
				// calculate the surface areas of the visible sides
				vector3 dl = leftU - leftL, dr = rightU - rightL;
				float larea = lvalid ? 0 : (dl.x * (dl.y + dl.z) + dl.y * dl.z);
				float rarea = rvalid ? 0 : (dr.x * (dr.y + dr.z) + dr.y * dr.z);
				if (lvalid && rvalid)
				{
					// subtract the occluded surface areas
					const vector3 dimin( min( leftU.x, rightU.x ), min( leftU.y, rightU.y ), min( leftU.z, rightU.z ) );
					const vector3 dimax( max( leftL.x, rightL.x ), max( leftL.y, rightL.y ), max( leftL.z, rightL.z ) );
					const vector3 di = dimin - dimax;
					((front & 0x1) ? larea : rarea) -= max( 0.0f, di.y * di.z );
					((front & 0x2) ? larea : rarea) -= max( 0.0f, di.x * di.z );
					((front & 0x4) ? larea : rarea) -= max( 0.0f, di.x * di.y );
				}
				// pick the node with the larger visible area as the near node
				mask |= (larea >= rarea) ? 0 : (1 << signmask);
			}
			node->SetDirMask( mask );
			stack[stackptr++] = rnode;
			stack[stackptr++] = lnode;
		}
	}
}

class Refitter : public Job
{
	friend class BVHBuilder;
public:
	void init( BVHNode* a_Node, BVHBuilder* a_Builder )
	{
		m_Node = a_Node;
		m_Builder = a_Builder;
	}
	void main()
	{
		m_Builder->RefitRecurse( m_Node, vmin4, vmax4 );
	}
private:
	__m128 vmin4, vmax4;
	BVHNode* m_Node;
	BVHBuilder* m_Builder;
};

Refitter refit1;
Refitter refit2;
void BVHBuilder::Refit()
{
#if 1 // doesn't help much, memory bound?
	BVHNode* left = &m_Pool[m_Root->GetLeft()];
	BVHNode* right = &m_Pool[m_Root->GetRight()];
	refit1.init( left, this );
	refit2.init( right, this );
	JobManager* jm = JobManager::GetJobManager();
	jm->AddJob2( &refit1 );
	jm->AddJob2( &refit2 );
	jm->RunJobs();
	const unsigned int tmpstart = m_Root->left, tmpdata = m_Root->data;
	*(__m128*)&m_Root->min = _mm_min_ps( refit1.vmin4, refit2.vmin4 );
	*(__m128*)&m_Root->max = _mm_max_ps( refit1.vmax4, refit2.vmax4 );
	m_Root->left = tmpstart, m_Root->data = tmpdata;
#else
	__m128 a, b;
	RefitRecurse( m_Root, a, b );
#endif
}

void BVHBuilder::RefitRecurse( BVHNode* a_Node, __m128& a_Min4, __m128& a_Max4 )
{
	if (!a_Node->IsLeaf())
	{
		__m128 lmin4, lmax4, rmin4, rmax4;
		RefitRecurse( &m_Pool[a_Node->GetLeft()], lmin4, lmax4 );
		RefitRecurse( &m_Pool[a_Node->GetRight()], rmin4, rmax4 );
		const unsigned int tmpstart = a_Node->left, tmpdata = a_Node->data;
		a_Min4 = *(__m128*)&a_Node->min = _mm_min_ps( lmin4, rmin4 ), a_Max4 = *(__m128*)&a_Node->max = _mm_max_ps( lmax4, rmax4 );
		a_Node->left = tmpstart, a_Node->data = tmpdata;
	}
	else
	{
		const int start = a_Node->GetStart(), count = a_Node->GetTCount();
		a_Min4 = _mm_set_ps1( 10000 ), a_Max4 = _mm_set_ps1( -10000 );
		for ( int i = 0; i < count; i++ )
		{
			Primitive* p = MManager::GetBVHPrims()[start + i]; // may want to do this only if we already know the node has changed
			for ( int j = 0; j < 3; j++ )
			{
				const vector3 pos = p->GetVertex( j )->GetPos();
				const __m128 pos4 = _mm_set_ps( 0, pos.z, pos.y, pos.x );
				a_Min4 = _mm_min_ps( a_Min4, pos4 ), a_Max4 = _mm_max_ps( a_Max4, pos4 );
			}
		}
		const unsigned int tmpstart = a_Node->left, tmpdata = a_Node->data;
		*(__m128*)&a_Node->min = a_Min4, *(__m128*)&a_Node->max = a_Max4;
		a_Node->left = tmpstart, a_Node->data = tmpdata;
	}
}

}; // namespace Raytracer