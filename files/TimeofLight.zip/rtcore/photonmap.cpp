// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#include "precomp.h"

using namespace Raytracer;

#define MINDIST					10			// distance is clamped to this value in irradiance calculations
#define MINCONTR				12			// minimal contribution for a vpl; decrease to skip more vpls

#define ORDERPHOTONS

Cell* PhotonMapper::m_Grid;					// the grid, 128x128x128
Cell** PhotonMapper::m_CList = 0;
int PhotonMapper::m_Filled;
SamplingPoint* PhotonMapper::m_Sample;
int PhotonMapper::m_Total;
vector3* PhotonMapper::m_Dart, *PhotonMapper::m_AmbRay;
unsigned int PhotonMapper::m_Darts, PhotonMapper::m_AmbRays;
vector3* PhotonMapper::m_VPS;
vector3* PhotonMapper::m_VPSN;
vector3* PhotonMapper::m_VPL;
vector3* PhotonMapper::m_VPN;
__m128* PhotonMapper::m_VPcol;
int PhotonMapper::m_NrVPS;
int PhotonMapper::m_NrVPL;
vector3 PhotonMapper::m_EP1, PhotonMapper::m_EP2;
vector3 PhotonMapper::m_ESize;
vector3 PhotonMapper::m_ERSize;
vector3 PhotonMapper::m_ECSize;
vector3 PhotonMapper::m_ERad;
RayPacket* PhotonMapper::m_RP;
IData* PhotonMapper::m_ID;
int PhotonMapper::m_Cores;
float PhotonMapper::m_SampleDist, PhotonMapper::m_SampleSqDist, PhotonMapper::m_SearchDist;
float PhotonMapper::m_SampleDot, PhotonMapper::m_Brightness;
int PhotonMapper::m_Attempts;
float PhotonMapper::m_Sensitivity, PhotonMapper::m_ReciSens, PhotonMapper::m_AORad, PhotonMapper::m_Relative;
char* PhotonMapper::m_DartsFile;
VPLBVHNode* PhotonMapper::m_Root, *PhotonMapper::m_First;
aabb PhotonMapper::m_Extends;
vector3 PhotonMapper::m_Interior[10];
int PhotonMapper::m_Interiors = 0;
Raytracer::Polygon* PhotonMapper::m_Poly = 0;
int PhotonMapper::m_PCount;

extern HANDLE waitpmreq[MAXTHREADS];
extern HANDLE gidone[MAXTHREADS];
extern unsigned int _raydir[8][3][2];
extern unsigned int _masktable[64];

static bool order = false;
static const __m128 _one = _mm_set_ps1( 1.0f ), _half4 = _mm_set_ps1( 0.5f );
static const __m128 _three = _mm_set_ps1( 3.0f ), _zero4 = _mm_set_ps1( 0 );

// calculate accurate square roots of four scalars in an __m128
static __forceinline float fastsqrtf( float v )
{
	const __m128 v1 = _mm_load_ss( &v );
	const __m128 v2 = _mm_rsqrt_ss( v1 );
	float final;
	_mm_store_ss( &final, _mm_mul_ps( v1, v2 ) );
	return final;
}

// calculate accurate reverse square roots of four scalars in an __m128
static __forceinline __m128 fastrsqrt( const __m128 v )
{
	const __m128 nr = _mm_rsqrt_ps( v );
	const __m128 muls = _mm_mul_ps( _mm_mul_ps( v, nr ), nr );
	return _mm_mul_ps( _mm_mul_ps( _half4, nr ), _mm_sub_ps( _three, muls ) );
}

// calculate a reverse square root for a single scalar
static __forceinline float fastrsqrtf( float v )
{
	const __m128 v1 = _mm_load_ss( &v );
	float final;
	_mm_store_ss( &final, _mm_rsqrt_ss( v1 ) );
	return final;
}

#ifdef PHOTONMAPPING

// ---------------------------------------------------------
// INITIALISATION
// ---------------------------------------------------------

// InitStatics: Load the 'darts' sphere and initialize static member variables
void PhotonMapper::InitStatics()
{
	FILE* f = fopen( "darts_18k.dat", "rb" );
	if (!f) Log::Message( "ERROR: darts_18k.dat not found" );
	fread( &m_Darts, 4, 1, f );
	m_Dart = new vector3[m_Darts];
	fread( m_Dart, sizeof( vector3 ), m_Darts, f );
	fclose( f );
	f = fopen( "darts_128.dat", "rb" );
	if (!f) Log::Message( "ERROR: darts_128.dat not found" );
	fread( &m_AmbRays, 4, 1, f );
	m_AmbRay = new vector3[m_AmbRays];
	fread( m_AmbRay, sizeof( vector3 ), m_AmbRays, f );
	fclose( f );
	m_Sample = (SamplingPoint*)MALLOC64( 2000000 * sizeof( SamplingPoint ) );
	const unsigned int size = PHOTONGRIDX * PHOTONGRIDY * PHOTONGRIDZ;
	m_Grid = (Cell*)MALLOC64( size * sizeof( Cell ) );
	for ( int i = 0; i < size; i++ ) m_Grid[i].Init();
	m_Total = 0;
	aabb ext = Scene::GetExtends();
	m_Extends = ext;
	m_EP1 = ext.GetP1() * 1.1f;
	m_EP2 = ext.GetP2() * 1.1f;
	m_ESize = m_EP2 - m_EP1;
	m_ERad = vector3( m_SampleDist * 1.01f, m_SampleDist * 1.01f, m_SampleDist * 1.01f );
	m_ERSize = vector3( PHOTONGRIDX / m_ESize.x, PHOTONGRIDY / m_ESize.y, PHOTONGRIDZ / m_ESize.z );
	m_ECSize = vector3( m_ESize.x / PHOTONGRIDX, m_ESize.y / PHOTONGRIDY, m_ESize.z / PHOTONGRIDZ );
	SYSTEM_INFO sinfo;
	GetSystemInfo( &sinfo );
	m_Cores = sinfo.dwNumberOfProcessors;
	if (m_Cores > MAXTHREADS) m_Cores = MAXTHREADS;
	m_RP = (RayPacket*)MALLOC64( sizeof( RayPacket ) );
	m_ID = (IData*)MALLOC64( sizeof( IData ) );
	// Create 2-way connection between polygon and primitive
	m_PCount = 0;
	for ( int i = 0; i < SceneGraph::GetNodeCount(); i++ ) m_PCount += SceneGraph::GetNode( i )->GetPrimCount();
	m_Poly = new Polygon[m_PCount];
	int current = 0;
	for ( int i = 0; i < SceneGraph::GetNodeCount(); i++ )
	{
		Node* node = SceneGraph::GetNode( i );
		for ( int j = 0; j < node->GetPrimCount(); j++ )
		{
			m_Poly[current].SetOrig( node->Get( j ) );
			node->Get( j )->SetData( current++ );
		}
	}
}

// ResetStatics: Reallocate the grid, used to load a sampling point set after creating and saving it
void PhotonMapper::ResetStatics()
{
	FREE64( m_Sample );
	FREE64( m_Grid );
	m_Sample = (SamplingPoint*)MALLOC64( 2000000 * sizeof( SamplingPoint ) );
	const unsigned int size = PHOTONGRIDX * PHOTONGRIDY * PHOTONGRIDZ;
	m_Grid = (Cell*)MALLOC64( size * sizeof( Cell ) );
	for ( int i = 0; i < size; i++ ) m_Grid[i].Init();
	m_Total = 0;
}

// Init: Initialize thread-specific variables (non-static)
void PhotonMapper::Init( int a_Thread )
{
	m_Thread = a_Thread;
	memcpy( (void*)raydir, _raydir, 192 );
	for ( int i = 0; i < 16; i++ )
	{
		masktable[i * 4 + 3] = (i & 8)?0xffffffff:0;	
		masktable[i * 4 + 2] = (i & 4)?0xffffffff:0;	
		masktable[i * 4 + 1] = (i & 2)?0xffffffff:0;	
		masktable[i * 4 + 0] = (i & 1)?0xffffffff:0;	
	}
}

// ---------------------------------------------------------
// HELPER FUNCTIONS
// ---------------------------------------------------------

// FindOcclusion: Shadow ray query in the scene BVH
void PhotonMapper::FindOcclusion( const vector3& O, const vector3& D, Primitive*& a_Prim, float a_Dist )
{
	BVHStack stack[128];
	const vector3 R( 1.0f / D.x, 1.0f / D.y, 1.0f / D.z );
	unsigned int stackptr = 0;
	BVHNode* node = SceneGraph::GetSceneRoot();
	Primitive** primlist = MManager::GetBVHPrims();
	BVHNode* pool = MManager::GetBVHPool();
	unsigned int quad = ((D.x < 0)?1:0) + ((D.y < 0)?2:0) + ((D.z < 0)?4:0);
	// process root (only 'mono' node)
	uint fidx = (node->GetDirMask() >> quad) & 1;
	BVHNode* nodepair = &pool[node->GetLeft()];
	const __m128 ox4 = _mm_set_ps1( O.x ), oy4 = _mm_set_ps1( O.y ), oz4 = _mm_set_ps1( O.z );
	const __m128 rx4 = _mm_set_ps1( R.x ), ry4 = _mm_set_ps1( R.y ), rz4 = _mm_set_ps1( R.z );
	// process remaining nodes
	while (1)
	{
		const BVHNode* node1 = &nodepair[fidx], *node2 = &nodepair[1 - fidx];
		const __m128 XXXX = _mm_set_ps( node1->min.x, node1->max.x, node2->min.x, node2->max.x );
		const __m128 YYYY = _mm_set_ps( node1->min.y, node1->max.y, node2->min.y, node2->max.y );
		const __m128 ZZZZ = _mm_set_ps( node1->min.z, node1->max.z, node2->min.z, node2->max.z );
		__m128 tmin = _mm_set1_ps( 0.00001f ), tmax = _mm_set_ps1( a_Dist );
		const __m128 tx01 = _mm_mul_ps( _mm_sub_ps( XXXX, ox4 ), rx4 );
		const __m128 tx10 = _mm_shuffle_ps( tx01, tx01, _MM_SHUFFLE( 2, 3, 0, 1 ) );
		tmax = _mm_min_ps( tmax, _mm_max_ps( tx01, tx10 ) );
		tmin = _mm_max_ps( tmin, _mm_min_ps( tx01, tx10 ) );
		const __m128 ty01 = _mm_mul_ps( _mm_sub_ps( YYYY, oy4 ), ry4 );
		const __m128 ty10 = _mm_shuffle_ps( ty01, ty01, _MM_SHUFFLE( 2, 3, 0, 1 ) );
		tmax = _mm_min_ps( tmax, _mm_max_ps( ty01, ty10 ) );
		tmin = _mm_max_ps( tmin, _mm_min_ps( ty01, ty10 ) );
		const __m128 tz01 = _mm_mul_ps( _mm_sub_ps( ZZZZ, oz4 ), rz4 );
		const __m128 tz10 = _mm_shuffle_ps( tz01, tz01, _MM_SHUFFLE( 2, 3, 0, 1 ) );
		tmax = _mm_min_ps( tmax, _mm_max_ps( tz01, tz10 ) );
		tmin = _mm_max_ps( tmin, _mm_min_ps( tz01, tz10 ) );
		const unsigned int result = _mm_movemask_ps( _mm_cmple_ps( tmin, tmax ) );
		if (result & 1)
		{
			BVHNode* node = &nodepair[1 - fidx];
			if (!node->IsLeaf())
			{
				stack[stackptr].fidx = fidx;
				stack[stackptr++].node = &pool[node->GetLeft()];
			}
			else
			{
				const uint start = node->GetStart(), count = node->GetTCount();
				for ( uint i = 0; i < count; ++i ) 
				{
					const Primitive* restrict pr = primlist[start + i];
					if (pr->GetType() == Primitive::PRIM_SPHERE)
					{
						vector3 dst = O - pr->m_N;
						float B = DOT( dst, D ), C = DOT( dst, dst ) - pr->m_T.y;
						float d = B * B - C, dist = -B - sqrtf( d );
						if ((dist >= 0) && (dist < a_Dist)) { a_Prim = (Primitive*)1; return; }
						continue;
					}
					const vector3 ao = pr->m_Vertex[0]->m_Pos - O;
					if ((ao.x * pr->m_N.x + ao.y * pr->m_N.y + ao.z * pr->m_N.z) < 0) continue;
					const vector3 bo = pr->m_Vertex[1]->m_Pos - O, co = pr->m_Vertex[2]->m_Pos - O;
					const vector3 v1c = bo^ao, v2c = ao^co, v0c = co^bo;
					const float nominator = DOT( ao, pr->m_N );
					const float v0d = DOT( v0c, D ), v1d = DOT( v1c, D ), v2d = DOT( v2c, D );
					if ((v0d > 0) && (v1d > 0) && (v2d > 0))
					{
						const float t = nominator * (1.0f / DOT( D, pr->m_N ));
						if ((t < a_Dist) && (t >= 0)) { a_Prim = (Primitive*)1; return; }
					}
				}
			}
		}
		if (result & 4)
		{
			BVHNode* node = &nodepair[fidx];
			if (!node->IsLeaf())
			{
				fidx = (node->GetDirMask() >> quad) & 1;
				nodepair = &pool[node->GetLeft()];
				continue;
			}
			else
			{
				const uint start = node->GetStart(), count = node->GetTCount();
				for ( uint i = 0; i < count; ++i ) 
				{
					const Primitive* restrict pr = primlist[start + i];
					if (pr->GetType() == Primitive::PRIM_SPHERE)
					{
						vector3 dst = O - pr->m_N;
						float B = DOT( dst, D ), C = DOT( dst, dst ) - pr->m_T.y;
						float d = B * B - C, dist = -B - sqrtf( d );
						if ((dist >= 0) && (dist < a_Dist)) { a_Prim = (Primitive*)1; return; }
						continue;
					}
					const vector3 ao = pr->m_Vertex[0]->m_Pos - O;
					if ((ao.x * pr->m_N.x + ao.y * pr->m_N.y + ao.z * pr->m_N.z) < 0) continue;
					const vector3 bo = pr->m_Vertex[1]->m_Pos - O, co = pr->m_Vertex[2]->m_Pos - O;
					const vector3 v1c = bo^ao, v2c = ao^co, v0c = co^bo;
					const float nominator = DOT( ao, pr->m_N );
					const float v0d = DOT( v0c, D ), v1d = DOT( v1c, D ), v2d = DOT( v2c, D );
					if ((v0d > 0) && (v1d > 0) && (v2d > 0))
					{
						const float t = nominator * (1.0f / DOT( D, pr->m_N ));
						if ((t < a_Dist) && (t >= 0)) { a_Prim = (Primitive*)1; return; }
					}
				}
			}
		}
		if (!stackptr) break;
		nodepair = stack[--stackptr].node;
		fidx = stack[stackptr].fidx;
	}
}

// FindNearest: Find nearest intersection of a single ray and the scene BVH
void PhotonMapper::FindNearest( const vector3& O, const vector3& D, Primitive*& a_Prim, float& a_Dist, float& a_U, float& a_V )
{
	BVHStack stack[128];
	const vector3 R( 1.0f / D.x, 1.0f / D.y, 1.0f / D.z );
	unsigned int stackptr = 0;
	BVHNode* node = SceneGraph::GetSceneRoot();
	Primitive** primlist = MManager::GetBVHPrims();
	BVHNode* pool = MManager::GetBVHPool();
	unsigned int quad = ((D.x < 0)?1:0) + ((D.y < 0)?2:0) + ((D.z < 0)?4:0);
	// process root (only 'mono' node)
	uint fidx = (node->GetDirMask() >> quad) & 1;
	BVHNode* nodepair = &pool[node->GetLeft()];
	const __m128 ox4 = _mm_set_ps1( O.x ), oy4 = _mm_set_ps1( O.y ), oz4 = _mm_set_ps1( O.z );
	const __m128 rx4 = _mm_set_ps1( R.x ), ry4 = _mm_set_ps1( R.y ), rz4 = _mm_set_ps1( R.z );
	// process remaining nodes
	while (1)
	{
		const BVHNode* node1 = &nodepair[fidx], *node2 = &nodepair[1 - fidx];
		const __m128 XXXX = _mm_set_ps( node1->min.x, node1->max.x, node2->min.x, node2->max.x );
		const __m128 YYYY = _mm_set_ps( node1->min.y, node1->max.y, node2->min.y, node2->max.y );
		const __m128 ZZZZ = _mm_set_ps( node1->min.z, node1->max.z, node2->min.z, node2->max.z );
		__m128 tmin = _mm_set1_ps( 0.00001f ), tmax = _mm_set_ps1( a_Dist );
		const __m128 tx01 = _mm_mul_ps( _mm_sub_ps( XXXX, ox4 ), rx4 );
		const __m128 tx10 = _mm_shuffle_ps( tx01, tx01, _MM_SHUFFLE( 2, 3, 0, 1 ) );
		tmax = _mm_min_ps( tmax, _mm_max_ps( tx01, tx10 ) );
		tmin = _mm_max_ps( tmin, _mm_min_ps( tx01, tx10 ) );
		const __m128 ty01 = _mm_mul_ps( _mm_sub_ps( YYYY, oy4 ), ry4 );
		const __m128 ty10 = _mm_shuffle_ps( ty01, ty01, _MM_SHUFFLE( 2, 3, 0, 1 ) );
		tmax = _mm_min_ps( tmax, _mm_max_ps( ty01, ty10 ) );
		tmin = _mm_max_ps( tmin, _mm_min_ps( ty01, ty10 ) );
		const __m128 tz01 = _mm_mul_ps( _mm_sub_ps( ZZZZ, oz4 ), rz4 );
		const __m128 tz10 = _mm_shuffle_ps( tz01, tz01, _MM_SHUFFLE( 2, 3, 0, 1 ) );
		tmax = _mm_min_ps( tmax, _mm_max_ps( tz01, tz10 ) );
		tmin = _mm_max_ps( tmin, _mm_min_ps( tz01, tz10 ) );
		const unsigned int result = _mm_movemask_ps( _mm_cmple_ps( tmin, tmax ) );
		if (result & 1)
		{
			BVHNode* node = &nodepair[1 - fidx];
			if (!node->IsLeaf())
			{
				stack[stackptr].fidx = fidx;
				stack[stackptr++].node = &pool[node->GetLeft()];
			}
			else
			{
				const uint start = node->GetStart(), count = node->GetTCount();
				for ( uint i = 0; i < count; ++i ) 
				{
					const Primitive* restrict pr = primlist[start + i];
					if (pr->GetType() == Primitive::PRIM_SPHERE)
					{
						vector3 dst = O - pr->m_N;
						float B = DOT( dst, D ), C = DOT( dst, dst ) - pr->m_T.y;
						float d = B * B - C, dist = -B - sqrtf( d );
						if ((dist >= 0) && (dist < a_Dist)) a_Dist = dist, a_Prim = (Primitive*)pr, a_U = a_V = 0;
						continue;
					}
					const vector3 ao = pr->m_Vertex[0]->m_Pos - O;
					if ((ao.x * pr->m_N.x + ao.y * pr->m_N.y + ao.z * pr->m_N.z) < 0) continue;
					const vector3 bo = pr->m_Vertex[1]->m_Pos - O, co = pr->m_Vertex[2]->m_Pos - O;
					const vector3 v1c = bo^ao, v2c = ao^co, v0c = co^bo;
					const float nominator = DOT( ao, pr->m_N );
					const float v0d = DOT( v0c, D ), v1d = DOT( v1c, D ), v2d = DOT( v2c, D );
					if ((v0d > 0) && (v1d > 0) && (v2d > 0))
					{
						const float t = nominator / DOT( D, pr->m_N );
						if ((t < a_Dist) && (t >= 0)) 
						{ 
							a_Prim = (Primitive*)pr, a_Dist = t;
							const float div = 1.0f / (v0d + v1d + v2d);
							a_U = v2d * div, a_V = v1d * div;
						}
					}
				}
			}
		}
		if (result & 4)
		{
			BVHNode* node = &nodepair[fidx];
			if (!node->IsLeaf())
			{
				fidx = (node->GetDirMask() >> quad) & 1;
				nodepair = &pool[node->GetLeft()];
				continue;
			}
			else
			{
				const uint start = node->GetStart(), count = node->GetTCount();
				for ( uint i = 0; i < count; ++i ) 
				{
					const Primitive* restrict pr = primlist[start + i];
					if (pr->GetType() == Primitive::PRIM_SPHERE)
					{
						vector3 dst = O - pr->m_N;
						float B = DOT( dst, D ), C = DOT( dst, dst ) - pr->m_T.y;
						float d = B * B - C, dist = -B - sqrtf( d );
						if ((dist >= 0) && (dist < a_Dist)) a_Dist = dist, a_Prim = (Primitive*)pr, a_U = a_V = 0;
						continue;
					}
					const vector3 ao = pr->m_Vertex[0]->m_Pos - O;
					if ((ao.x * pr->m_N.x + ao.y * pr->m_N.y + ao.z * pr->m_N.z) < 0) continue;
					const vector3 bo = pr->m_Vertex[1]->m_Pos - O, co = pr->m_Vertex[2]->m_Pos - O;
					const vector3 v1c = bo^ao, v2c = ao^co, v0c = co^bo;
					const float nominator = DOT( ao, pr->m_N );
					const float v0d = DOT( v0c, D ), v1d = DOT( v1c, D ), v2d = DOT( v2c, D );
					if ((v0d > 0) && (v1d > 0) && (v2d > 0))
					{
						const float t = nominator / DOT( D, pr->m_N );
						if ((t < a_Dist) && (t >= 0)) 
						{ 
							a_Prim = (Primitive*)pr, a_Dist = t;
							const float div = 1.0f / (v0d + v1d + v2d);
							a_U = v2d * div, a_V = v1d * div;
						}
					}
				}
			}
		}
		if (!stackptr) break;
		nodepair = stack[--stackptr].node;
		fidx = stack[stackptr].fidx;
	}
}

// ---------------------------------------------------------
// DART SOURCE AND VPL GENERATION
// ---------------------------------------------------------

// CreateDartSources: These sources (or 'particle fountains') produce large amounts
// of darts that are traced with multiple bounces. The vertices of these paths are used
// to create the uniformly distributed set of sampling points that is used in the second
// stage of the algorithm to store the radiance.
void PhotonMapper::CreateDartSources( Light* a_Light )
{
	Log::Message( "entering PhotonMapper::CreateDartSources()" );
	int start = GetTickCount();
	unsigned int bounces = 16, idx = 0, count[4] = { 0, 0, 0, 0 };
	m_VPS = new vector3[m_Darts * (bounces - 12)];
	m_VPSN = new vector3[m_Darts * (bounces - 12)];
	m_NrVPS = 0;
	for ( unsigned int i = 0; i < m_Darts; i++ )
	{
		// find nearest scene intersection
		vector3 vpos = a_Light->GetPos();
		vector3 dir( m_Dart[i].x, m_Dart[i].y, m_Dart[i].z );
		for ( unsigned int bounce = 0; bounce < bounces; bounce++ )
		{
			vpos += dir * 0.0001f;
			Primitive* prim = 0;
			float dist = MAXINTDIST, u, v;
			FindNearest( vpos, dir, prim, dist, u, v );
			if (!prim) break;
			if (bounce > 11)
			{
				bool blockervisible = false;
				vector3 spos = vpos + dist * dir * 0.999f;
				for ( int i = 0; i < m_Interiors; i++ )
				{
					vector3 D = m_Interior[i] - spos;
					float dist = D.Length() * 0.9995f;
					D.Normalize();
					Primitive* p = 0;
					FindOcclusion( spos, D, p, dist );
					if (!p) { blockervisible = true; break; }
				}
				if (!blockervisible)
				{
					m_VPS[m_NrVPS] = spos;
					if (prim->GetType() == Primitive::PRIM_SPHERE) m_VPSN[m_NrVPS++] = (spos - prim->m_N).Normalized();
															  else m_VPSN[m_NrVPS++] = prim->GetNormal( u, v );
					count[bounce - 12]++;
				}
			}
			vpos += dist * dir;
			dir = m_Dart[idx];
			if (++idx == m_Darts) idx = 0;
			if (dir.Dot( prim->m_N ) > 0) dir *= -1;
		}
	}
	int elapsed = GetTickCount() - start;
	Log::IntValue( "Creating dart sources took: (ms) ", elapsed );
	Log::IntValue( "particle fountains created [LEVEL1]: ", count[0] );
	Log::IntValue( "particle fountains created [LEVEL2]: ", count[1] );
	Log::IntValue( "particle fountains created [LEVEL3]: ", count[2] );
	Log::IntValue( "particle fountains created [LEVEL4]: ", count[3] );
	Log::Message( "leaving PhotonMapper::CreateDartSources()" );
}

// CreateVPLs: This method creates the VPLs by tracing particles from the scene lights
// through the scene with one or more bounces. The set of VPLs is calculated only once.
void PhotonMapper::CreateVPLs( Light* a_Light )
{
	Log::Message( "entering PhotonMapper::CreateVPLs()" );
	unsigned idx = 0, bounces = 1, darts = 0;
	FILE* f = fopen( m_DartsFile, "rb" );
	if (!f)
	{
		Log::Write( "ERROR: could not open ", m_DartsFile );
		return;
	}
	fread( &darts, 1, 4, f );
	Log::IntValue( "loaded darts for VPL creation", darts );
	vector3* dart = new vector3[darts];
	fread( dart, darts, sizeof( vector3 ), f );
	m_VPL = new vector3[darts * bounces];
	m_VPN = new vector3[darts * bounces];
	m_VPcol = (__m128*)MALLOC64( sizeof( Color ) * darts * bounces );
	m_NrVPL = 0;
	for ( unsigned int i = 0; i < darts; i++ )
	{
		// find nearest scene intersection
		vector3 vpos = a_Light->GetPos();
		vector3 dir( m_Dart[i].x, m_Dart[i].y, m_Dart[i].z );
		__m128 pcol = a_Light->GetDiffuse().rgba;
		for ( unsigned int bounce = 0; bounce < bounces; bounce++ )
		{
			vpos += dir * 0.0001f;
			Primitive* prim = 0;
			float dist = 10000, u, v;
			FindNearest( vpos, dir, prim, dist, u, v );
			if (!prim) break;
			const __m128 mcol = prim->GetMaterial()->GetPhotonColor();
			pcol = _mm_mul_ps( mcol, pcol );
			vector3 pN;
			if (prim->GetType() == Primitive::PRIM_SPHERE) pN = (m_VPL[m_NrVPL] - prim->m_N).Normalized();
													  else pN = prim->GetNormal( u, v );
			if (dist > 4)
			{
				m_VPL[m_NrVPL] = vpos + dist * dir * 0.999f;
				m_VPN[m_NrVPL] = pN;
				m_VPcol[m_NrVPL] = pcol;
				m_NrVPL++;
			}
			vpos += dist * dir;
			dir = m_Dart[idx];
			if (++idx == m_Darts) idx = 0;
			if (dir.Dot( pN ) > 0) dir *= -1;
		}
	}
	Log::IntValue( "created VPLs: ", m_NrVPL );
	delete dart;
	Log::Message( "leaving PhotonMapper::CreateVPLs()" );
}

// ---------------------------------------------------------
// SAMPLING POINT GRID
// ---------------------------------------------------------

// FindInCell: helper function for ::Occupied
bool PhotonMapper::FindInCell( const unsigned int a_Idx, const vector3& a_Pos, const vector3& a_N )
{
	const unsigned int count = m_Grid[a_Idx].GetSampleCount();
	SamplingPoint** plist = m_Grid[a_Idx].GetSamples();
	for ( unsigned int i = 0; i < count; i++ ) if (!plist[i]->Removed())
	{
		const float dot = plist[i]->N.Dot( a_N ) * 0.25f + 0.75f;
		const float dist = (plist[i]->pos - a_Pos).SqrLength();
		if ((dist < m_SampleSqDist) && (dot > m_SampleDot)) return true;
	}
	return false;
}

// Occupied: Checks if a sampling point with the specified normal can be stored at the specified location
bool PhotonMapper::Occupied( const vector3& a_Pos, const vector3& a_N )
{
	const vector3 gpos = (a_Pos - m_EP1) * m_ERSize;
	const int ix = (int)floor( gpos.x ), iy = (int)floor( gpos.y ), iz = (int)floor( gpos.z );
	return (FindInCell( ix + (iy << PHOTONYSHIFT) + (iz << PHOTONZSHIFT), a_Pos, a_N ));
}

// CheckRadius: Accept a point if there is no point within the specified radius (T2)
bool PhotonMapper::OccupiedRadius( const vector3& a_Pos, const vector3& a_N, const float a_Dist )
{
	float rdist = a_Dist * a_Dist;
	const vector3 gpos = (a_Pos - m_EP1) * m_ERSize;
	const int ix = (int)floor( gpos.x ), iy = (int)floor( gpos.y ), iz = (int)floor( gpos.z );
	const int idx = ix + (iy << PHOTONYSHIFT) + (iz << PHOTONZSHIFT);
	// search grid cell
	const unsigned int count = m_Grid[idx].GetSampleCount();
	SamplingPoint** plist = m_Grid[idx].GetSamples();
	for ( unsigned int i = 0; i < count; i++ ) if (!plist[i]->Removed())
	{
		const float dot = DOT( plist[i]->N, a_N );
		float dist = (plist[i]->pos - a_Pos).SqrLength();
		if ((dist < rdist) && (dot > m_SampleDot)) return true; // reject point
	}
	return false;
}

// AddSample: Create a sampling point and add it to the grid
void PhotonMapper::AddSample( const vector3& a_Pos, const vector3& a_N, const unsigned int a_Flags, const float a_Radius, int a_Idx )
{
	// add to photon array
	m_Sample[m_Total].pos = a_Pos;
	m_Sample[m_Total].N = a_N;
	m_Sample[m_Total].radius = a_Radius;
	m_Sample[m_Total].SetFlags( a_Flags );
	m_Sample[m_Total].SetPolyIdx( a_Idx );
	// add to grid
	const float T2 = a_Radius;
	const vector3 gpos_min = (a_Pos - vector3( T2, T2, T2 ) - m_EP1) * m_ERSize;
	const vector3 gpos_max = (a_Pos + vector3( T2, T2, T2 ) - m_EP1) * m_ERSize;
	const int ixmin = (int)floor( gpos_min.x ), iymin = (int)floor( gpos_min.y ), izmin = (int)floor( gpos_min.z );
	const int ixmax = (int)floor( gpos_max.x ), iymax = (int)floor( gpos_max.y ), izmax = (int)floor( gpos_max.z );
	// add to neighbouring cells if close to edge
	for ( int z = izmin; z <= izmax; z++ ) for ( int y = iymin; y <= iymax; y++ ) for ( int x = ixmin; x <= ixmax; x++ )
	{
		if ((x < 0) || (x == PHOTONGRIDX) || (y < 0) || (y == PHOTONGRIDY) || (z < 0) || (z == PHOTONGRIDZ)) continue;
		m_Grid[x + (y << PHOTONYSHIFT) + (z << PHOTONZSHIFT)].Add( &m_Sample[m_Total] );
	}
	m_Total++;
}

// RemoveSample: Remove a sample from all grid cells
void PhotonMapper::RemoveSample( SamplingPoint* p )
{
	const float srad = p->radius, sqrad = srad * srad;
	const vector3 gpos_min = ((p->pos - vector3( srad, srad, srad )) - m_EP1) * m_ERSize;
	const vector3 gpos_max = ((p->pos + vector3( srad, srad, srad )) - m_EP1) * m_ERSize;
	int ixmin = (int)gpos_min.x, iymin = (int)gpos_min.y, izmin = (int)gpos_min.z;
	int ixmax = (int)gpos_max.x, iymax = (int)gpos_max.y, izmax = (int)gpos_max.z;
	ixmin = max( 0, ixmin ), ixmax = min( PHOTONGRIDX - 1, ixmax );
	iymin = max( 0, iymin ), iymax = min( PHOTONGRIDY - 1, iymax );
	izmin = max( 0, izmin ), izmax = min( PHOTONGRIDZ - 1, izmax );
	for ( int z = izmin; z <= izmax; z++ ) 
	{
		const float zpos = (float)z * m_ECSize.z;
		for ( int y = iymin; y <= iymax; y++ ) 
		{	
			const float ypos = (float)y * m_ECSize.y;
			for ( int x = ixmin; x <= ixmax; x++ )
			{
				vector3 cmin = m_EP1 + vector3( (float)x * m_ECSize.x, ypos, zpos );
				vector3 cmax = cmin + m_ECSize;
				float s, d = 0; 
				for( unsigned int i = 0; i < 3; i++ ) 
				{ 
					if (p->pos.cell[i] < cmin.cell[i]) s = p->pos.cell[i] - cmin.cell[i], d += s * s; 
					else if (p->pos.cell[i] > cmax.cell[i]) s = p->pos.cell[i] - cmax.cell[i], d += s * s; 
				}
				if (d <= sqrad) m_Grid[x + (y << PHOTONYSHIFT) + (z << PHOTONZSHIFT)].Remove( p );
			}
		}
	}
}

// AddSample: Add an existing sampling point to the grid
void PhotonMapper::AddSample( SamplingPoint* p )
{
	const float srad = p->radius, sqrad = srad * srad;
	const vector3 gpos_min = ((p->pos - vector3( srad, srad, srad )) - m_EP1) * m_ERSize;
	const vector3 gpos_max = ((p->pos + vector3( srad, srad, srad )) - m_EP1) * m_ERSize;
	int ixmin = (int)gpos_min.x, iymin = (int)gpos_min.y, izmin = (int)gpos_min.z;
	int ixmax = (int)gpos_max.x, iymax = (int)gpos_max.y, izmax = (int)gpos_max.z;
	ixmin = max( 0, ixmin ), ixmax = min( PHOTONGRIDX - 1, ixmax );
	iymin = max( 0, iymin ), iymax = min( PHOTONGRIDY - 1, iymax );
	izmin = max( 0, izmin ), izmax = min( PHOTONGRIDZ - 1, izmax );
	for ( int z = izmin; z <= izmax; z++ ) 
	{
		const float zpos = (float)z * m_ECSize.z;
		for ( int y = iymin; y <= iymax; y++ ) 
		{	
			const float ypos = (float)y * m_ECSize.y;
			for ( int x = ixmin; x <= ixmax; x++ )
			{
				vector3 cmin = m_EP1 + vector3( (float)x * m_ECSize.x, ypos, zpos );
				vector3 cmax = cmin + m_ECSize;
				float s, d = 0; 
				for( unsigned int i = 0; i < 3; i++ ) 
				{ 
					if (p->pos.cell[i] < cmin.cell[i]) s = p->pos.cell[i] - cmin.cell[i], d += s * s; 
					else if (p->pos.cell[i] > cmax.cell[i]) s = p->pos.cell[i] - cmax.cell[i], d += s * s; 
				}
				if (d <= sqrad) m_Grid[x + (y << PHOTONYSHIFT) + (z << PHOTONZSHIFT)].Add( p );
			}
		}
	}
}

// ---------------------------------------------------------
// SAMPLING POINT CREATION
// ---------------------------------------------------------

// AmbientOcclusion: Calculate ambient occlusion for a sampling point
// used to adapt local density to actual local need
float PhotonMapper::AmbientOcclusion( const vector3& a_Pos, const vector3& a_N )
{
	// determine ambient occlusion for a small disc
	float occ = 0;
	const int samples = m_AmbRays;
	for ( int i = 0; i < samples; i++ )
	{
		vector3 dir = m_AmbRay[i];
		if (DOT( dir, a_N ) > 0) dir *= -1;
		vector3 pos = a_Pos;
		Primitive* prim = 0;
		float dist = m_AORad, u = 0, v = 0;
		FindNearest( pos + dir * 0.001f, dir, prim, dist, u, v );
		occ += dist;
	}
	occ = occ / ((float)samples * m_AORad) - m_Sensitivity;
	occ = MIN( 1, MAX( 0, occ * m_ReciSens ) );
	return occ;
}

// CreateWingedEdges: Create a winged edge structure for a polygon soup
void PhotonMapper::CreateWingedEdges()
{
	Log::Message( "entering PhotonMapper::CreateWingedEdges()" );
	int wstart = GetTickCount();
	// step 1: Make a list of unique vertices
	// ==> Create a NxNxN grid with polygon pointers
	PolyGridCell* grid = new PolyGridCell[64 * 64 * 64];
	for ( int x = 0; x < 64; x++ ) for ( int y = 0; y < 64; y++ ) for ( int z = 0; z < 64; z++ ) grid[x + (y << 6) + (z << 12)].count = 0;
	// ==> Translate every primitive to a new 'polygon' structure
	// ==> For every grid cell, count the number of primitives overlapping it
	int current = 0;
	const float eprx = 64.0f / (m_EP2.x - m_EP1.x);
	const float epry = 64.0f / (m_EP2.y - m_EP1.y);
	const float eprz = 64.0f / (m_EP2.z - m_EP1.z);
	for ( int i = 0; i < SceneGraph::GetNodeCount(); i++ ) 
	{
		Node* node = SceneGraph::GetNode( i );
		for ( int j = 0; j < node->GetPrimCount(); j++ )
		{
			// translate primitive
			m_Poly[current].vert[0] = (Vertex*)m_Poly[current].GetOrig()->GetVertex( 0 );
			m_Poly[current].vert[1] = (Vertex*)m_Poly[current].GetOrig()->GetVertex( 1 );
			m_Poly[current].vert[2] = (Vertex*)m_Poly[current].GetOrig()->GetVertex( 2 );
			for ( int k = 0; k < 3; k++ ) m_Poly[current].neigh[k] = 0;
			// calculate primitive bounds
			vector3 bmin( 10000, 10000, 10000 ), bmax( -10000, -10000, -10000 );
			for ( int k = 0; k < 3; k++ )
			{
				vector3 p = m_Poly[current].vert[k]->GetPos();
				for ( int a = 0; a < 3; a++ )
				{
					if (p.cell[a] < bmin.cell[a]) bmin.cell[a] = p.cell[a];
					if (p.cell[a] > bmax.cell[a]) bmax.cell[a] = p.cell[a];
				}
			}
			// increase count of all overlapped cells
			int x1 = (int)((bmin.x - m_EP1.x) * eprx), x2 = (int)((bmax.x - m_EP1.x) * eprx);
			int y1 = (int)((bmin.y - m_EP1.y) * epry), y2 = (int)((bmax.y - m_EP1.y) * epry);
			int z1 = (int)((bmin.z - m_EP1.z) * eprz), z2 = (int)((bmax.z - m_EP1.z) * eprz);
			for ( int x = x1; x <= x2; x++ ) for ( int y = y1; y <= y2; y++ ) for ( int z = z1; z <= z2; z++ )
				grid[x + (y << 6) + (z << 12)].count++;
			current++;
		}
	}
	// ==> Allocate polygon** for every grid cell
	for ( int x = 0; x < 64; x++ ) for ( int y = 0; y < 64; y++ ) for ( int z = 0; z < 64; z++ )
	{
		const int idx = x + (y << 6) + (z << 12);
		if (grid[idx].count) grid[idx].list = new Polygon*[grid[idx].count]; else grid[idx].list = 0;
		grid[idx].count = 0;
	}
	// ==> Add polygons to grid cells
	for ( int i = 0; i < m_PCount; i++ )
	{
		// calculate primitive bounds
		vector3 bmin( 10000, 10000, 10000 ), bmax( -10000, -10000, -10000 );
		for ( int k = 0; k < 3; k++ )
		{
			const vector3 p = m_Poly[i].vert[k]->GetPos();
			for ( int a = 0; a < 3; a++ )
			{
				if (p.cell[a] < bmin.cell[a]) bmin.cell[a] = p.cell[a];
				if (p.cell[a] > bmax.cell[a]) bmax.cell[a] = p.cell[a];
			}
		}
		// increase count of all overlapped cells
		const int x1 = (int)((bmin.x - m_EP1.x) * eprx), x2 = (int)((bmax.x - m_EP1.x) * eprx);
		const int y1 = (int)((bmin.y - m_EP1.y) * epry), y2 = (int)((bmax.y - m_EP1.y) * epry);
		const int z1 = (int)((bmin.z - m_EP1.z) * eprz), z2 = (int)((bmax.z - m_EP1.z) * eprz);
		for ( int x = x1; x <= x2; x++ ) for ( int y = y1; y <= y2; y++ ) for ( int z = z1; z <= z2; z++ )
		{
			const int idx = x + (y << 6) + (z << 12);
			grid[idx].list[grid[idx].count++] = &m_Poly[i];
		}
	}
	// ==> Create the unique vertex list
	vector3* vlist = new vector3[m_PCount * 3];
	int vcount = 0;
	// ==> Translate polygon vertices to indices in unique vertex list
	for ( int x = 0; x < 64; x++ ) for ( int y = 0; y < 64; y++ ) for ( int z = 0; z < 64; z++ )
	{
		const int idx = x + (y << 6) + (z << 12);
		for ( int i = 0; i < grid[idx].count; i++ )
		{
			Polygon* p = grid[idx].list[i];
			if (!p->IsTranslated())
			{
				for ( int v = 0; v < 3; v++ )
				{
					const vector3 pos = p->vert[v]->GetPos();
					const int bx = (int)((pos.x - m_EP1.x) * eprx);
					const int by = (int)((pos.y - m_EP1.y) * epry);
					const int bz = (int)((pos.z - m_EP1.z) * eprz);
					const int idx2 = bx + (by << 6) + (bz << 12);
					int same = -1;
					// vertex needs to be added if none of the other translated polygons contain the same vertex
					for ( int j = 0; j < grid[idx2].count; j++ )
					{
						Polygon* p2 = grid[idx2].list[j];
						if (!p2->IsTranslated()) continue;
						// p2 contains indices into vlist
						for ( int k = 0; k < 3; k++ )
						{
							const int vidx = p2->idx[k];
							const vector3 pos2 = vlist[vidx];
							if ((pos2.x == pos.x) && (pos2.y == pos.y) && (pos2.z == pos.z)) same = vidx;
						}
					}
					// add to vlist if necessary
					if (same == -1) vlist[vcount] = pos, p->idx[v] = vcount++; else p->idx[v] = same;
				}
				p->Translated();
			}
		}
	}	
	// step 2: Per vertex, make a list of polygons attached to it
	int* pvcount = new int[vcount];
	Polygon*** pvlist = new Polygon**[vcount];
	for ( int i = 0; i < vcount; i++ ) pvcount[i] = 0;
	for ( int i = 0; i < m_PCount; i++ ) for ( int j = 0; j < 3; j++ ) pvcount[m_Poly[i].idx[j]]++;
	for ( int i = 0; i < vcount; i++ ) pvlist[i] = new Polygon*[pvcount[i]], pvcount[i] = 0;
	for ( int i = 0; i < m_PCount; i++ ) for ( int j = 0; j < 3; j++ ) 
	{
		int vidx = m_Poly[i].idx[j];
		pvlist[vidx][pvcount[vidx]++] = &m_Poly[i];
	}
	// step 3: Create the winged edge structure
	for ( int i = 0; i < m_PCount; i++ )
	{
		Polygon* p1 = &m_Poly[i];
		for ( int j = 0; j < 3; j++ )
		{
			int vidx[2] = { p1->idx[j], p1->idx[(j + 1) % 3] };
			for ( int w = 0; w < 2; w++ ) for ( int k = 0; k < pvcount[vidx[w]]; k++ ) if (pvlist[vidx[w]][k] != p1)
			{
				Polygon* p2 = pvlist[vidx[w]][k];
				if (((p2->idx[0] == vidx[0]) || (p2->idx[1] == vidx[0]) || (p2->idx[2] == vidx[0])) &&
					((p2->idx[0] == vidx[1]) || (p2->idx[1] == vidx[1]) || (p2->idx[2] == vidx[1]))) p1->neigh[j] = pvlist[vidx[w]][k];						
			}
		}
	}
	// done
	int elapsed = GetTickCount() - wstart;
	Log::IntValue( "creating winged edge structure took (ms): ", elapsed );
	// clean up
	for ( int x = 0; x < 64; x++ ) for ( int y = 0; y < 64; y++ ) for ( int z = 0; z < 64; z++ ) delete grid[x + (y << 6) + (z << 12)].list;
	delete grid;
	for ( int i = 0; i < vcount; i++ ) delete pvlist[i];
	delete vlist;
	delete pvcount;
	Log::Message( "leaving PhotonMapper::CreateWingedEdges()" );
}

// ValidPos: Check if a point in space is visible from at least 1 vpl
bool PhotonMapper::ValidPos( const vector3& a_Pos, const vector3& a_N )
{	
	// see if this point is not too close to a similar point
	const vector3 gpos = (a_Pos - m_EP1) * m_ERSize;
	const int ix = (int)floor( gpos.x ), iy = (int)floor( gpos.y ), iz = (int)floor( gpos.z );
	Cell* g = &m_Grid[ix + (iy << PHOTONYSHIFT) + (iz << PHOTONZSHIFT)];
	SamplingPoint** sample = g->GetSamples();
	const float T1 = m_SampleDist / m_Relative, T2 = m_SampleDist;
	for ( int i = 0; i < g->GetSampleCount(); i++ )
	{
		vector3 delta = sample[i]->pos - a_Pos;
		float dot = sample[i]->N.Dot( a_N );
		if (dot > m_SampleDot) if (delta.Length() < (T1 * 0.5f)) return false;
	}		
	// see if this point can at least see one vpl (code broken)
	for ( int i = 0; i < m_NrVPS; i += 16 )
	{
		vector3 vpos = m_VPS[i];
		vector3 VN = m_VPSN[i];
		float dot = a_Pos.Dot( VN ) - vpos.Dot( VN );
		if (dot > 0) continue;
		Primitive* p = 0;
		vector3 D = a_Pos - vpos;
		float dist = D.Length() - 0.002f;
		D.Normalize();
		FindOcclusion( vpos + 0.001f * D, D, p, dist );
		if (!p) return true;
	}
	return false;
}

// AddPointsOnEdges: Uses the winged edge structure to create an initial set of points
void PhotonMapper::AddPointsOnEdges()
{
	Log::Message( "entering PhotonMapper::AddPointsOnEdges()" );
	int wstart = GetTickCount();
	int added = 0, invalid = 0;
	const float T1 = m_SampleDist / m_Relative, T2 = m_SampleDist;
	for ( int i = 0; i < m_PCount; i++ )
	{
		Polygon* p = &m_Poly[i];
		Primitive* p1 = p->GetOrig();
		if (p1->GetType() == Primitive::PRIM_SPHERE) continue;
		vector3 N1 = p1->m_N;
		for ( int j = 0; j < 3; j++ ) if (p->neigh[j])
		{
			Primitive* p2 = p->neigh[j]->GetOrig();
			vector3 N2 = p2->m_N;
			float dot = p1->m_N.Dot( p2->m_N );
			if (dot < 0.9f)
			{
				const vector3 pos = p1->GetVertex( j )->GetPos();
				if (ValidPos( pos, p1->m_N )) 
				{
					AddSample( pos, p1->m_N, 0, m_SampleDist, i );
					added++;
				}
				else invalid++;
				vector3 v1 = p1->GetVertex( j )->GetPos();
				vector3 v2 = p1->GetVertex( (j + 1) % 3)->GetPos();
				if ((v1.x + v1.y + v1.z) < (v2.x + v2.y + v2.z))
				{
					vector3 h = v1;
					v1 = v2;
					v2 = h;
				}
				bool convex = ((N2.Dot( p1->GetVertex( (j + 2) % 3 )->GetPos() ) - N2.Dot( p2->GetVertex( 0 )->GetPos() )) > 0);
				if (convex)
				{
					if (dot > m_SampleDot)
					{
						// assume smooth convex edge
						const float T = T2, len = (v2 - v1).Length();
						if (len > (T * 1.3f))
						{
							const int steps = (int)(len / T);
							const float stepsize = 1.0f / (float)(steps + 1);
							const vector3 iN = (N1 + N2).Normalized();
							for ( int s = 1; s <= steps; s++ )
							{
								const vector3 pos = v1 + (float)s * stepsize * (v2 - v1);
								if (ValidPos( pos, iN )) { AddSample( pos, iN, 0, T, i ); added++; } else invalid++;
							}
						}
					}
					else
					{
						// assume sharp convex edge
						const float T = T2, len = (v2 - v1).Length();
						if (len > (T * 1.3f))
						{
							const int steps = (int)(len / T);
							const float stepsize = 1.0f / (float)(steps + 1);
							for ( int s = 1; s <= steps; s++ )
							{
								const vector3 pos = v1 + (float)s * stepsize * (v2 - v1);
								if (ValidPos( pos, N1 )) { AddSample( pos, N1, 0, T, i ); added++; } else invalid++;
								if (ValidPos( pos, N2 )) { AddSample( pos, N2, 0, T, i ); added++; } else invalid++;
							}
						}
					}
				}
				else
				{
					const float T = (T1 + T2) * 0.5f;
					float len = (v2 - v1).Length();
					if (len > (T * 1.3f))
					{
						int steps = (int)(len / T);
						float stepsize = 1.0f / (float)(steps + 1);
						for ( int s = 1; s <= steps; s++ )
						{
							vector3 pos = v1 + (float)s * stepsize * (v2 - v1);
							if (ValidPos( pos, N1 )) 
							{
								AddSample( pos, N1, 0, T, i );
								added++;
							}
							else invalid++;
						}
					}
				}
			}
		}
	}
	Log::IntValue( "added points: ", added );
	Log::IntValue( "invalid points: ", invalid );
	int elapsed = GetTickCount() - wstart;
	Log::IntValue( "edge point creation took (ms): ", elapsed );
	Log::Message( "leaving PhotonMapper::AddPointsOnEdges()" );
}

// CreateSamplingPoints: Create a set of point with a uniform distribution
void PhotonMapper::CreateSamplingPoints( Light* a_Light )
{
	Log::Message( "entering PhotonMapper::CreateSamplingPoints()" );
	CreateWingedEdges();
	AddPointsOnEdges();
	const unsigned int size = PHOTONGRIDX * PHOTONGRIDY * PHOTONGRIDZ; 
	// Fill up space by throwing darts
	Log::Message( "throwing darts" );
	int idx = 0, failed = 0;
	int dtstart = GetTickCount();
	const __m128 m500 = _mm_set_ps1( 500 ), m1 = _mm_set_ps1( 1 ), zero = _mm_set_ps1( 0 );
	BVHStack stack[128];
	unsigned int i = 0;
#if 1
	while (1)
	{
		if (++i == m_NrVPS) i = 0;
		float* rpdx = reinterpret_cast<float*>(m_RP->dx4);
		float* rpdy = reinterpret_cast<float*>(m_RP->dy4);
		float* rpdz = reinterpret_cast<float*>(m_RP->dz4);
		const vector3 N = m_VPSN[i];
		for ( int p = 0; p < 256; p++ )
		{
			rpdx[p] = m_Dart[idx].x, rpdy[p] = m_Dart[idx].y, rpdz[p] = m_Dart[idx].z;
			if (++idx == m_Darts) idx = 0;
			if ((rpdx[p] * N.x + rpdy[p] * N.y + rpdz[p] * N.z) > 0) 
				rpdx[p] = -rpdx[p], rpdy[p] = -rpdy[p], rpdz[p] = -rpdz[p];
		}
		// direction normalize & reciprocal
		for ( int p = 0; p < 64; p++ ) m_RP->CalcReciprocal4( p );
		float* rprdx = reinterpret_cast<float*>(m_RP->rdx4);
		float* rprdy = reinterpret_cast<float*>(m_RP->rdy4);
		float* rprdz = reinterpret_cast<float*>(m_RP->rdz4);
		vector3 O = m_VPS[i];
		for ( int p = 0; p < 256; p++ )
		{
			// find nearest scene intersection
			float dist = 10000, u, v;
			const vector3 R( rprdx[p], rprdy[p], rprdz[p] );
			const vector3 D( rpdx[p], rpdy[p], rpdz[p] );
			unsigned int stackptr = 0;
			BVHNode* node = SceneGraph::GetSceneRoot();
			Primitive** primlist = MManager::GetBVHPrims(), *prim = m_ID->prim[p];
			BVHNode* pool = MManager::GetBVHPool();
			while (1)
			{
				// see if ray intersects current node
				float tmin = 0.00001f, tmax = dist;
				for ( uint axis = 0; axis < 3; ++axis ) 
				{
					const float t0 = (node->min.cell[axis] - O.cell[axis]) * R.cell[axis];
					const float t1 = (node->max.cell[axis] - O.cell[axis]) * R.cell[axis];
					const float nr = (t0 < t1) ? t0 : t1, fr = (t0 < t1) ? t1 : t0;
					tmin = (tmin < nr) ? nr : tmin, tmax = (fr <  tmax) ? fr : tmax;
				}
				if (tmin <= tmax)
				{
					// walk tree
					if (!node->IsLeaf())
					{
						stack[stackptr++].node = &pool[node->GetLeft() + 1];
						node = &pool[node->GetLeft()];
						continue;
					}
					const uint start = node->GetStart(), count = node->GetTCount();
					for ( uint j = 0; j < count; ++j ) 
					{
						const Primitive* restrict pr = primlist[start + j];
						if (pr->GetType() == Primitive::PRIM_SPHERE)
						{
							vector3 dst = O - pr->m_N;
							float B = DOT( dst, D ), C = DOT( dst, dst ) - pr->m_T.y;
							float d = B * B - C, t = -B - sqrtf( d );
							if ((t >= 0) && (t < dist)) dist = t, prim = (Primitive*)pr, u = v = 0;
							continue;
						}
						const vector3 ao = pr->m_Vertex[0]->m_Pos - O;
						if ((ao.x * pr->m_N.x + ao.y * pr->m_N.y + ao.z * pr->m_N.z) < 0) continue;
						const vector3 bo = pr->m_Vertex[1]->m_Pos - O, co = pr->m_Vertex[2]->m_Pos - O;
						const vector3 v1c = bo^ao, v2c = ao^co, v0c = co^bo;
						const float nominator = DOT( ao, pr->m_N );
						const float v0d = DOT( v0c, D ), v1d = DOT( v1c, D ), v2d = DOT( v2c, D );
						if ((v0d > 0) && (v1d > 0) && (v2d > 0))
						{
							const float t = nominator / DOT( D, pr->m_N );
							if ((t < dist) && (t >= 0)) 
							{
								prim = (Primitive*)pr;
								dist = t;
								const float div = 1.0f / (v0d + v1d + v2d);
								u = v2d * div, v = v1d * div;
							}
						}
					}
				}
				if (!stackptr) break;
				node = stack[--stackptr].node;
			}
			reinterpret_cast<float*>(m_ID->dist4)[p] = dist, m_ID->prim[p] = prim, m_ID->u[p] = u, m_ID->v[p] = v;
		}
		const float T1 = m_SampleDist / m_Relative, T2 = m_SampleDist;
		for ( int p = 0; p < 64; p++ )
		{
			for ( int j = 0; j < 4; j++ ) if (reinterpret_cast<float*>(m_ID->dist4)[p * 4 + j] < 500)
			{
				const unsigned int pj = p * 4 + j;
				const float dist = reinterpret_cast<float*>(m_ID->dist4)[pj];
				const vector3 pos( O.x + rpdx[pj] * dist, O.y + rpdy[pj] * dist, O.z + rpdz[pj] * dist );
				bool rejected = false;
				vector3 pN;
				if (m_ID->prim[pj]->GetType() == Primitive::PRIM_SPHERE) pN = (pos - m_ID->prim[pj]->m_N).Normalized();
																	else pN = m_ID->prim[pj]->GetNormal( m_ID->u[pj], m_ID->v[pj] );
				float pdist;
				if (OccupiedRadius( pos, pN, T1 )) rejected = true;			// trivial reject
				else if (!OccupiedRadius( pos, pN, T2 )) 
				{
					rejected = false;	// trivial accept
					pdist = AmbientOcclusion( pos, m_ID->prim[pj]->m_N ); 
				}
				else
				{
					pdist = AmbientOcclusion( pos, m_ID->prim[pj]->m_N ); 
					const float dist = T1 + (T2 - T1) * pdist;
					rejected = OccupiedRadius( pos, pN, dist );
				}
				if (!rejected)
				{
					AddSample( pos, pN, 0, T1 + (T2 - T1) * pdist, m_ID->prim[pj]->GetData() );
					failed = 0;
				}
				else failed++;
			}
		}
		if (failed > m_Attempts) break;
	}
#endif
	Log::IntValue( "dart throwing took (ms) :", GetTickCount() - dtstart );
	// STEP 5: Throw away points that can see interior positions
	Log::Message( "deleting invalid points" );
	Log::IntValue( "interiors: ", m_Interiors );
	int interior = 0;
	for ( i = 0; i < m_Total; i++ ) if (!m_Sample[i].Removed())
	{
		vector3 spos = m_Sample[i].pos;
		for ( int j = 0; j < m_Interiors; j++ )
		{
			vector3 D = spos - m_Interior[j];
			float dist = D.Length() * 0.9995f;
			D.Normalize();
			Primitive* p = 0;
			FindOcclusion( m_Interior[j], D, p, dist );
			if (!p) { m_Sample[i].Remove(); interior++; break; }
		}
	}
	Log::IntValue( "deleted points: ", interior );
	for ( i = 0; i < size; i++ ) m_Grid[i].Optimize();
	// STEP 6: Create a grid with more overlap
	Log::Message( "creating the grid" );
	Cell* oldgrid = m_Grid;
	m_Grid = (Cell*)MALLOC64( size * sizeof( Cell ) );
	for ( int i = 0; i < size; i++ ) m_Grid[i].Init();
	m_ERad = vector3( m_SearchDist, m_SearchDist, m_SearchDist );
	int totalvalid = 0;
	for ( int i = 0; i < m_Total; i++ )
	{
		SamplingPoint* p = &m_Sample[i];
		if (p->Removed()) continue;
		totalvalid++;
		AddSample( p );	
	}
	// summary & store on disk
	Log::IntValue( "final point count:", totalvalid );
	char name[128];
	strcpy( name, Scene::GetSceneName() );
	strcat( name, ".drt" );
	FILE* f = fopen( name, "wb" );
	fwrite( &totalvalid, 4, 1, f );
	// ordered write
	Log::Message( "performing ordered write" );
	for ( int i = 0; i < m_Total; i++ ) m_Sample[i].NotStored();
	for ( int i = 0; i < size; i++ )
	{
		SamplingPoint** plist = m_Grid[i].GetSamples();
		if (!plist) continue;
		unsigned int count = m_Grid[i].GetSampleCount();
		for ( unsigned int j = 0; j < count; j++ ) if ((!plist[j]->Removed()) && (!plist[j]->IsStored()))
		{
			vector3 pos = plist[j]->pos;
			vector3 N = plist[j]->N;
			float radius = plist[j]->radius;
			unsigned int data = plist[j]->PolyIdx();
			fwrite( &pos, 12, 1, f );
			fwrite( &N, 12, 1, f );
			fwrite( &radius, 4, 1, f );
			fwrite( &data, 4, 1, f );
			plist[j]->Stored();
		}
	}
	order = true;
	fclose( f );
	Log::Message( "leaving PhotonMapper::CreateSamplingPoints()" );
}

// LoadSamplingPoints: Load a point set from disk
void PhotonMapper::LoadSamplingPoints()
{
	// load sampling points from file
	m_ERad = vector3( m_SearchDist, m_SearchDist, m_SearchDist );
	char name[128];
	strcpy( name, Scene::GetSceneName() );
	strcat( name, ".drt" );
	FILE* f = fopen( name, "rb" );
	if (!f) 
	{	
		Log::Write( "Error: Sampling point file not found", name );
		return;
	}
	fread( &m_Total, 4, 1, f );
	Log::IntValue( "loading sampling points: ", m_Total );
	int start = GetTickCount();
	for ( int i = 0; i < m_Total; i++ )
	{
		vector3 pos, N;
		float radius;
		unsigned int data;
		fread( &pos, 12, 1, f );
		fread( &N, 12, 1, f );
		fread( &radius, 4, 1, f );
		fread( &data, 4, 1, f );
		m_Sample[i].pos = pos;
		m_Sample[i].N = N;
		m_Sample[i].SetFlags( 0 );
		m_Sample[i].radius = radius * 2;
		m_Sample[i].SetPolyIdx( data );
		AddSample( &m_Sample[i] );
	}	
	int total = 0;
	for ( int z = 0; z < PHOTONGRIDZ; z++ ) for ( int y = 0; y < PHOTONGRIDY; y++ ) for ( int x = 0; x < PHOTONGRIDX; x++ )
	{
		const vector3 cmin = m_EP1 + vector3( (float)x * m_ECSize.x, (float)y * m_ECSize.y, (float)z * m_ECSize.z );
		const vector3 cmax = cmin + m_ECSize;
		const int idx = x + (y << PHOTONYSHIFT) + (z << PHOTONZSHIFT);
		const int count = m_Grid[idx].GetSampleCount();
		if (!count) continue;
		m_Grid[idx].Finalize( cmin, cmax );
		total += m_Grid[idx].GetCentreCount();
	}
	fclose( f );
	Log::IntValue( "sampling points encountered: ", total );
	Log::IntValue( "loading took (ms) : ", GetTickCount() - start );
}

// LinkPointsToPolygons: For the set of polygons used for winged edges, a
// list of points contributing to each polygon is created. This is useful
// for updating points on a dynamic mesh.
void PhotonMapper::LinkPointsToPolygons()
{
	int start = GetTickCount();
	Log::Message( "entering PhotonMapper::LinkPointsToPolygons()" );
	for ( int i = 0; i < m_PCount; i++ ) m_Poly[i].pcount = 0;
	for ( int i = 0; i < m_Total; i++ ) m_Poly[m_Sample[i].PolyIdx()].pcount++;
	for ( int i = 0; i < m_PCount; i++ ) if (m_Poly[i].pcount) 
	{
		if (m_Poly[i].pcount < 500) m_Poly[i].point = (SamplingPoint**)MManager::NewTiny( m_Poly[i].pcount );
							   else m_Poly[i].point = new SamplingPoint*[m_Poly[i].pcount];
	}
	for ( int i = 0; i < m_PCount; i++ ) m_Poly[i].pcount = 0;
	for ( int i = 0; i < m_Total; i++ ) 
	{
		int idx = m_Sample[i].PolyIdx();
		m_Poly[idx].point[m_Poly[idx].pcount++] = &m_Sample[i];
	}
	int elapsed = GetTickCount() - start;
	Log::IntValue( "linking took (ms): ", elapsed );
	Log::Message( "leaving PhotonMapper::LinkPointsToPolygons()" );
}

void PhotonMapper::WhiteOut( Primitive* a_Prim )
{
	Polygon* p = &m_Poly[a_Prim->GetData()];
	for ( int i = 0; i < p->pcount; i++ )
	{
		SamplingPoint* sp = p->point[i];
		sp->GI = _mm_set_ps1( 5120 );
	}
}

// OptimizeGrid: Remove points from cells where they can't contribute
// This happens when a cell does not contain polygons with a normal
// similar to the normal of a point.
void PhotonMapper::OptimizeGrid()
{
	int start = GetTickCount();
	Log::Message( "optimizing grid..." );
	// allocate arrays
	unsigned int* count = new unsigned int[PHOTONGRIDX * PHOTONGRIDY * PHOTONGRIDZ];
	memset( count, 0, PHOTONGRIDX * PHOTONGRIDY * PHOTONGRIDZ * 4 );
	Primitive*** plist = new Primitive**[PHOTONGRIDX * PHOTONGRIDY * PHOTONGRIDZ];
	int maxgrid = max( max( PHOTONGRIDX, PHOTONGRIDY ), PHOTONGRIDZ );
	vector3* nmin = new vector3[maxgrid], *nmax = new vector3[maxgrid];
	// determine node extends
	for ( int n = 0; n < maxgrid; n++ )
	{
		nmin[n] = m_EP1 + (float)n * m_ECSize;
		nmax[n] = nmin[n] + m_ECSize;
		nmin[n] -= vector3( m_SearchDist, m_SearchDist, m_SearchDist );
		nmax[n] += vector3( m_SearchDist, m_SearchDist, m_SearchDist );
	}
	// determine primitive counts per cell
	int total = 0;
	for ( int i = 0; i < SceneGraph::GetNodeCount(); i++ )
	{
		Node* node = SceneGraph::GetNode( i );
		const int prims = node->GetPrimCount();
		for ( int p = 0; p < prims; p++ )
		{
			Primitive* prim = node->Get( p );
			vector3 pmin( 10000, 10000, 10000 ), pmax( -10000, -10000, -10000 );
			for ( int v = 0; v < 3; v++ ) 
			{
				const vector3 pos = prim->GetVertex( v )->GetPos();
				for ( int a = 0; a < 3; a++ )
					pmin.cell[a] = min( pmin.cell[a], pos.cell[a] ),
					pmax.cell[a] = max( pmax.cell[a], pos.cell[a] );
			}
			const vector3 gmin = (pmin - m_EP1) * m_ERSize, gmax = (pmax - m_EP1) * m_ERSize;
			int ixmin = (int)gmin.x, iymin = (int)gmin.y, izmin = (int)gmin.z;
			int ixmax = (int)gmax.x, iymax = (int)gmax.y, izmax = (int)gmax.z;
			ixmin = max( 0, ixmin ), ixmax = min( PHOTONGRIDX - 1, ixmax );
			iymin = max( 0, iymin ), iymax = min( PHOTONGRIDY - 1, iymax );
			izmin = max( 0, izmin ), izmax = min( PHOTONGRIDZ - 1, izmax );
			for ( int z = izmin; z <= izmax; z++ ) for ( int y = iymin; y <= iymax; y++ ) for ( int x = ixmin; x <= ixmax; x++ )
			{	
				// polygon bounding box overlaps this grid cell; see if there really is an intersection
				int left = 0, right = 0;
				vector3 cellp[8] = { vector3( nmin[x].x, nmin[y].y, nmin[z].z ), vector3( nmax[x].x, nmin[y].y, nmin[z].z ),
									 vector3( nmin[x].x, nmax[y].y, nmin[z].z ), vector3( nmax[x].x, nmax[y].y, nmin[z].z ),
									 vector3( nmin[x].x, nmin[y].y, nmax[z].z ), vector3( nmax[x].x, nmin[y].y, nmax[z].z ),
									 vector3( nmin[x].x, nmax[y].y, nmax[z].z ), vector3( nmax[x].x, nmax[y].y, nmax[z].z ) };
				for ( int i = 0; i < 8; i++ )
				{
					float dist = cellp[i].Dot( prim->m_N ) - prim->GetVertex( 0 )->GetPos().Dot( prim->m_N );
					if (dist > 0) right++; else left++;
				}
				if ((left > 0) && (left < 8))
				{
					count[x + (y << PHOTONYSHIFT) + (z << PHOTONZSHIFT)]++;
					total++;
				}
			}
		}
	}
	// create primitive lists for the cells
	Primitive** pool = new Primitive*[total];
	int pidx = 0;
	for ( int z = 0; z < PHOTONGRIDZ; z++ ) for ( int y = 0; y < PHOTONGRIDY; y++ ) for ( int x = 0; x < PHOTONGRIDX; x++ )
	{	
		int idx = x + (y << PHOTONYSHIFT) + (z << PHOTONZSHIFT);
		if (count[idx]) plist[idx] = &pool[pidx], pidx += count[idx], count[idx] = 0;
	}
	for ( int i = 0; i < SceneGraph::GetNodeCount(); i++ )
	{
		Node* node = SceneGraph::GetNode( i );
		const int prims = node->GetPrimCount();
		for ( int p = 0; p < prims; p++ )
		{
			Primitive* prim = node->Get( p );
			vector3 pmin( 10000, 10000, 10000 ), pmax( -10000, -10000, -10000 );
			for ( int v = 0; v < 3; v++ ) 
			{
				const vector3 pos = prim->GetVertex( v )->GetPos();
				for ( int a = 0; a < 3; a++ )
					pmin.cell[a] = min( pmin.cell[a], pos.cell[a] ),
					pmax.cell[a] = max( pmax.cell[a], pos.cell[a] );
			}
			const vector3 gmin = (pmin - m_EP1) * m_ERSize, gmax = (pmax - m_EP1) * m_ERSize;
			int ixmin = (int)gmin.x, iymin = (int)gmin.y, izmin = (int)gmin.z;
			int ixmax = (int)gmax.x, iymax = (int)gmax.y, izmax = (int)gmax.z;
			ixmin = max( 0, ixmin ), ixmax = min( PHOTONGRIDX - 1, ixmax );
			iymin = max( 0, iymin ), iymax = min( PHOTONGRIDY - 1, iymax );
			izmin = max( 0, izmin ), izmax = min( PHOTONGRIDZ - 1, izmax );
			for ( int z = izmin; z <= izmax; z++ ) for ( int y = iymin; y <= iymax; y++ ) for ( int x = ixmin; x <= ixmax; x++ )
			{	
				// polygon bounding box overlaps this grid cell; see if there really is an intersection
				int left = 0, right = 0;
				vector3 cellp[8] = { vector3( nmin[x].x, nmin[y].y, nmin[z].z ), vector3( nmax[x].x, nmin[y].y, nmin[z].z ),
									 vector3( nmin[x].x, nmax[y].y, nmin[z].z ), vector3( nmax[x].x, nmax[y].y, nmin[z].z ),
									 vector3( nmin[x].x, nmin[y].y, nmax[z].z ), vector3( nmax[x].x, nmin[y].y, nmax[z].z ),
									 vector3( nmin[x].x, nmax[y].y, nmax[z].z ), vector3( nmax[x].x, nmax[y].y, nmax[z].z ) };
				for ( int i = 0; i < 8; i++ )
				{
					float dist = cellp[i].Dot( prim->m_N ) - prim->GetVertex( 0 )->GetPos().Dot( prim->m_N );
					if (dist > 0) right++; else left++;
				}
				if ((left > 0) && (left < 8))
				{
					int idx = x + (y << PHOTONYSHIFT) + (z << PHOTONZSHIFT);
					plist[idx][count[idx]++] = prim;
				}
			}
		}
	}
	// see which points can be removed
	int removed = 0, kept = 0;
	for ( int z = 0; z < PHOTONGRIDZ; z++ ) for ( int y = 0; y < PHOTONGRIDY; y++ ) for ( int x = 0; x < PHOTONGRIDX; x++ )
	{
		int idx = x + (y << PHOTONYSHIFT) + (z << PHOTONZSHIFT);
		SamplingPoint** points = m_Grid[idx].GetSamples();
		if (!points) continue;
		unsigned int pcount = m_Grid[idx].GetSampleCount();
		for ( int i = 0; i < pcount; i++ )
		{
			SamplingPoint* point = points[i];
			if (m_Poly[point->PolyIdx()].GetOrig()->GetType() == Primitive::PRIM_SPHERE) continue;
			bool found = false;
			for ( int j = 0; j < count[idx]; j++ ) if (plist[idx][j]->m_N.Dot( point->N ) > 0.5f) { found = true; break; }
			if (!found)
			{
				// remove point from this grid cell
				m_Grid[idx].Remove( i );
				pcount--;
				removed++;
			}
			else kept++;
		}
	}
	// add primitives to cells
	delete count;
	delete nmin;
	delete nmax;
	Log::IntValue( "removed: ", removed );
	Log::IntValue( "not removed: ", kept );
	Log::IntValue( "optimization took (ms) :", GetTickCount() - start );
}

// PrepareDynamics: Move sampling points for dynamic objects to worldspace origin
void PhotonMapper::PrepareDynamics()
{
	for ( int i = 0; i < SceneGraph::GetNodeCount(); i++ )
	{
		Node* node = SceneGraph::GetNode( i );
		if (node->GetType() == Node::STATIC) continue;
		matrix m = node->GetTransform();
		vector3 wpos = m.GetTranslation();
		for ( int j = 0; j < node->GetPrimCount(); j++ )
		{
			Polygon* p = &m_Poly[node->Get( j )->GetData()];
			for ( int k = 0; k < p->pcount; k++ ) p->point[k]->orig = p->point[k]->pos - wpos;
		}
	}
}

// UpdateDynamics: Transform sampling points for dynamic objects
void PhotonMapper::UpdateDynamics()
{
	for ( int i = 0; i < SceneGraph::GetNodeCount(); i++ )
	{
		Node* node = SceneGraph::GetNode( i );
		if (node->GetType() == Node::STATIC) continue;
		matrix m = node->GetTransform();
		for ( int j = 0; j < node->GetPrimCount(); j++ )
		{
			Polygon* p = &m_Poly[node->Get( j )->GetData()];
			for ( int k = 0; k < p->pcount; k++ ) 
			{
				RemoveSample( p->point[k] );
				p->point[k]->pos = m.Transform( p->point[k]->orig );
				AddSample( p->point[k] );
				InitSampleColor( p->point[k] );
			}
		}
	}
}

// ---------------------------------------------------------
// IRRADIANCE CALCULATION
// ---------------------------------------------------------

void PhotonMapper::InitSampleColor( SamplingPoint* p )
{
	__m128 divisor = _mm_set_ps1( (m_Brightness * 2) / (float)m_NrVPL );
	p->GI = _mm_setzero_ps();
	for ( unsigned int j = 0; j < m_NrVPL; j += 2 )
	{
		float sum = 0.0001f;
		Primitive* prim = 0;
		vector3 dir = m_VPL[j] - p->pos;
		float dist = dir.Length() * 0.999f;
		const float angle = -dir.Dot( p->N );
		if (angle > 0)
		{
			const float div = 1.0f / dist;
			dir *= div;
			FindOcclusion( m_VPL[j], dir, prim, dist );
			if (!prim) 
			{
				const float ldist = (dist < MINDIST)?(MINDIST * 0.005f):(dist * 0.005f);
				const float scale = (angle * div) / (ldist * ldist);
				p->GI = _mm_add_ps( p->GI, _mm_mul_ps( _mm_set_ps1( scale ), m_VPcol[j] ) );
			}
		}
	}
	p->GI = _mm_mul_ps( p->GI, divisor );
}

// InitSampleColors: Determine irradiance for sampling points using VPLs
void PhotonMapper::InitSampleColors( int a_First, int a_Last )
{
	m_Sampled = 0, m_SRays = 0, m_Approx = 0, m_BadApprox = 0, m_Coherent = 0, m_InCoherent = 0;
	__m128 divisor = _mm_set_ps1( m_Brightness / (float)m_NrVPL );
	VPLBVHNode** vpl = new VPLBVHNode*[m_NrVPL];
	VPLBVHNode* stack[128];
	CopyVPLBVH();
	for ( int i = a_First; i <= a_Last; i++ )
	{
		SamplingPoint* p = &m_Sample[i];
		const vector3 pos = p->GetPos(), N = p->GetNormal();
		p->GI = _mm_setzero_ps();
		// use the BVH to figure out which VPLs to use
		unsigned int count = 0;
		VPLBVHNode* node = m_LRoot;
		const float maxratio = 0.1f * 0.1f;
		unsigned int sp = 0;
		while (1)
		{
			if (node->left)
			{
				const float lratio = node->left->sqrad * (node->left->pos - pos).SqrLength();
				if (lratio > maxratio) stack[sp++] = node->left; else 
				{
					const vector3 dir = pos - node->left->pos;
					if ((dir.Dot( N ) > 0) && (dir.Dot( node->left->N ) < 0)) vpl[count++] = node->left;
				}
				const float rratio = node->right->sqrad * (node->right->pos - pos).SqrLength();
				if (rratio > maxratio) stack[sp++] = node->right; else 
				{
					const vector3 dir = pos - node->right->pos;
					if ((dir.Dot( N ) > 0) && (dir.Dot( node->right->N ) < 0)) vpl[count++] = node->right;
				}
			}
			else 
			{
				const vector3 dir = pos - node->pos;
				if ((dir.Dot( N ) > 0) && (dir.Dot( node->N ) < 0)) vpl[count++] = node;
			}
			if (!sp) break;
			node = stack[--sp];
		}
		if (count == 0) continue;
		// calculate contribution from remaining vpls
		Primitive* lastocc = 0;
		VPLBVHNode* lastparent = 0;
		float sum = 0.0001f, skipped = 0;
		for ( unsigned int j = 0; j < count; j++ ) 
		{
			vpl[j]->dir = pos - vpl[j]->pos;
			const float angle = -vpl[j]->dir.Dot( vpl[j]->N );
			vpl[j]->scale = 0;
			if (angle > 0)
			{
				vpl[j]->dist = vpl[j]->dir.Length();
				const float div = 1.0f / vpl[j]->dist;
				vpl[j]->dir *= div;
				vpl[j]->dist -= 0.001f;
				const float ldist = (vpl[j]->dist < MINDIST)?(MINDIST * 0.005f):(vpl[j]->dist * 0.005f);
				vpl[j]->scale = (angle * div) / (ldist * ldist);
				sum += vpl[j]->scale * vpl[j]->total;
			}
		}
		const float minval = 0;
		// calculate geometry factor for remaining vpls and sum
		for ( unsigned int j = 0; j < count; j++ )
		{
			if (vpl[j]->scale < minval) skipped += vpl[j]->scale; else if (lastparent == vpl[j]->parent)
			{
				if (!lastocc) p->GI = _mm_add_ps( p->GI, _mm_mul_ps( _mm_set_ps1( vpl[j]->scale ), vpl[j]->sum4 ) );
			}
			else
			{
				Primitive* prim = 0;
				float dist = vpl[j]->dist;
				FindOcclusion( vpl[j]->pos, vpl[j]->dir, prim, dist );
				lastparent = vpl[j]->parent, lastocc = prim;
				if (!prim) p->GI = _mm_add_ps( p->GI, _mm_mul_ps( _mm_set_ps1( vpl[j]->scale ), vpl[j]->sum4 ) );
			}
		}
		// store irradiance
		p->GI = _mm_add_ps( p->GI, _mm_mul_ps( p->GI, _mm_set_ps1( skipped / sum ) ) );
		p->GI = _mm_mul_ps( p->GI, divisor );
		m_Sampled += count;
	}
	delete vpl;
}

class CellShader : public Job
{
public:
	// need to fix:
	// 1. The average point count for a grid cell is 2.3. That makes this code very inefficient.
	// 2. The maximum point count for a grid cell is 384. That overflows a packet.
	// 3. Rays are also traced for points that don't face the light source.
	// IDEA:
	// - Change this code so that it operates on a list of grid cells
	// - Once the number of rays in a packet exceeds 32, trace the packet
	// - Don't add rays for points that don't face the light source.
	// This should dramatically improve performance.
	void init( Light* a_Light, SamplingPoint** a_List, int a_Count )
	{
		m_Light = a_Light;
		m_List = a_List;
		m_Count = a_Count;
	}
	void main()
	{
		int samples = m_Count;
		RayPacket rp;
		IData id;
		rp.packetq = (m_Count + 3) >> 2;
		rp.packetsize = samples;
		rp.offset = 0;
		rp.qoffset = 0;
		const vector3 O = m_Light->GetPos();
		const __m128 Ox4 = _mm_set_ps1( O.x ), Oy4 = _mm_set_ps1( O.y ), Oz4 = _mm_set_ps1( O.z );
		float* dist = (float*)&id.dist4;
		unsigned int* prim = (unsigned int*)&id.prim4, r = 0;
		for ( ; r < samples; r++ )
		{
			vector3 D = m_List[r]->pos - O;
			dist[r] = D.Length();
			D *= (1.0f / dist[r]);
			dist[r] *= 0.9995f;	
			prim[r] = 0;
			rp.SetOrigin( r, O );
			rp.SetDirection( r, D );
			m_List[r]->GI = _mm_setzero_ps();
		}
		// fix rays in last packet
		float* dx = (float*)&rp.dx4;
		float* dy = (float*)&rp.dy4;
		float* dz = (float*)&rp.dz4;
		for ( ; (r & 3); r++ )
		{
			rp.SetOrigin( r, O );
			dx[r] = dx[samples - 1];
			dy[r] = dy[samples - 1];
			dz[r] = dz[samples - 1];
			dist[r] = dist[samples - 1];
			prim[r] = 0;
		}
		// shade
		BVHNode* pool = MManager::GetBVHPool();
		Primitive** prlist = MManager::GetBVHPrims();
		const __m128 small4 = _mm_set_ps1( 0.000001f ), zero = _mm_setzero_ps(), epsilon = _mm_set_ps1( EPSILON );
		const uint offset[16] = { 0, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0 };
		BVHStack stack[MAXBVHDEPTH];
		__m128 masktable4[16];
		memcpy( (void*)masktable4, _masktable, 256 );
		// trace rays to area light as packet
		rp.CalcReciprocals();
		rp.BuildPlanesShadow( O );
		memset( &rp.mask4, 255, sizeof( rp.mask4 ) );
		uint stackptr = 0, first = 0;
		BVHNode* node = SceneGraph::GetSceneRoot();
		unsigned int quad = ((reinterpret_cast<float*>(rp.dx4)[0] < 0)?1:0) + 
							((reinterpret_cast<float*>(rp.dy4)[0] < 0)?2:0) + 
							((reinterpret_cast<float*>(rp.dz4)[0] < 0)?4:0);
		while (1)
		{
			// find first active ray (if any) -  step 1: check if first ray intersects box
			{
				float tmin = 0.00001f, tmax = reinterpret_cast<float*>(id.dist4)[first];
				for ( uint axis = 0; axis < 3; ++axis ) 
				{
					const uint idx = axis * PACKETSIZE + first;
					const float t0 = (node->min.cell[axis] - O.cell[axis]) * reinterpret_cast<float*>(rp.rdx4)[idx];
					const float t1 = (node->max.cell[axis] - O.cell[axis]) * reinterpret_cast<float*>(rp.rdx4)[idx];
					const float nr = (t0 < t1) ? t0 : t1, fr = (t0 < t1) ? t1 : t0;
					tmin = (tmin < nr) ? nr : tmin, tmax = (fr <  tmax) ? fr : tmax;
				}
				if ((tmin <= tmax) && (id.prim[first] == 0)) goto done;
				if (++first > (rp.packetsize - 1)) goto done;
				// step 2: check if frustum misses box
				if (rp.maxis > -1)
				{
					const float* bounds = (float*)node;
					unsigned int* signs = reinterpret_cast<unsigned int*>(rp.signs4);
					const __m128 bx4 = _mm_set_ps( bounds[signs[0]], bounds[signs[1]], bounds[signs[2]], bounds[signs[3]] );
					const __m128 by4 = _mm_set_ps( bounds[signs[4]], bounds[signs[5]], bounds[signs[6]], bounds[signs[7]] );
					const __m128 bz4 = _mm_set_ps( bounds[signs[8]], bounds[signs[9]], bounds[signs[10]], bounds[signs[11]] );
					const __m128 dst4 = DOT128( bx4, by4, bz4, rp.nx4, rp.ny4, rp.nz4 );
					if (_mm_movemask_ps( _mm_cmpgt_ps( dst4, rp.D4 ) ) > 0) { first = rp.packetsize; goto done; }
				}
				// step 3: check all rays
				const uint pfirst = first >> 2;
				first = rp.packetsize;
				const __m128 minx4 = _mm_set_ps1( node->min.x ), maxx4 = _mm_set_ps1( node->max.x );
				const __m128 miny4 = _mm_set_ps1( node->min.y ), maxy4 = _mm_set_ps1( node->max.y );
				const __m128 minz4 = _mm_set_ps1( node->min.z ), maxz4 = _mm_set_ps1( node->max.z );
				for ( uint r = pfirst; r < rp.packetq; ++r ) if (_mm_movemask_ps( id.shadow[r] ) != 15)
				{			
					const __m128 tmin4a = small4, tmax4a = id.dist4[r];
					const __m128 t0a = _mm_mul_ps( _mm_sub_ps( minx4, Ox4 ), rp.rdx4[r] );
					const __m128 t1a = _mm_mul_ps( _mm_sub_ps( maxx4, Ox4 ), rp.rdx4[r] );
					const __m128 nra = _mm_min_ps( t0a, t1a ), fra = _mm_max_ps( t0a, t1a );
					const __m128 tmin4b = _mm_max_ps( tmin4a, nra ), tmax4b = _mm_min_ps( tmax4a, fra );
					const __m128 t0b = _mm_mul_ps( _mm_sub_ps( miny4, Oy4 ), rp.rdy4[r] );
					const __m128 t1b = _mm_mul_ps( _mm_sub_ps( maxy4, Oy4 ), rp.rdy4[r] );
					const __m128 nrb = _mm_min_ps( t0b, t1b ), frb = _mm_max_ps( t0b, t1b );
					const __m128 tmin4c = _mm_max_ps( tmin4b, nrb ), tmax4c = _mm_min_ps( tmax4b, frb );
					const __m128 t0c = _mm_mul_ps( _mm_sub_ps( minz4, Oz4 ), rp.rdz4[r] );
					const __m128 t1c = _mm_mul_ps( _mm_sub_ps( maxz4, Oz4 ), rp.rdz4[r] );
					const __m128 nrc = _mm_min_ps( t0c, t1c ), frc = _mm_max_ps( t0c, t1c );
					const __m128 tmin4d = _mm_max_ps( tmin4c, nrc ), tmax4d = _mm_min_ps( tmax4c, frc );
					const uint ires = _mm_movemask_ps( _mm_andnot_ps( id.shadow[r], _mm_cmple_ps( tmin4d, tmax4d ) ) ); 
					if (ires) { first = r * 4 + offset[ires]; break; }
				}
			}
		done:
			if (first < rp.packetsize)
			{
				if (!node->IsLeaf())
				{
					const uint lidx = (node->GetDirMask() >> quad) & 1;
					stack[stackptr].node = &pool[node->GetLeft() + 1 - lidx];
					stack[stackptr++].first = first;
					node = &pool[node->GetLeft() + lidx];
					continue;
				}
				else
				{
					const uint start = node->GetStart(), count = node->GetTCount();
					for ( uint i = 0; i < count; ++i ) 
					{
						Primitive* pr = prlist[start + i];
					#ifdef SUPPORTSPHERES
						if (pr->GetType() == Primitive::PRIM_SPHERE)
						{
							int pfirst = first >> 2;
							const __m128 dstx4 = _mm_sub_ps( Ox4, _mm_set_ps1( pr->m_N.x ) );
							const __m128 dsty4 = _mm_sub_ps( Oy4, _mm_set_ps1( pr->m_N.y ) );
							const __m128 dstz4 = _mm_sub_ps( Oz4, _mm_set_ps1( pr->m_N.z ) );
							const __m128 sqrad4 = _mm_set_ps1( pr->m_T.y );
							for ( unsigned int r = pfirst; r < rp.packetq; r++ ) if (_mm_movemask_ps( id.shadow[r] ) != 15)
							{
								const __m128 B4 = _mm_add_ps( _mm_add_ps( _mm_mul_ps( dstx4, rp.dx4[r] ), _mm_mul_ps( dsty4, rp.dy4[r] ) ), _mm_mul_ps( dstz4, rp.dz4[r] ) );
								const __m128 C4 = _mm_sub_ps( _mm_add_ps( _mm_add_ps( _mm_mul_ps( dstx4, dstx4 ), _mm_mul_ps( dsty4, dsty4 ) ), _mm_mul_ps( dstz4, dstz4 ) ), sqrad4 );
								const __m128 d4 = _mm_sub_ps( _mm_mul_ps( B4, B4 ), C4 );
								const __m128 dist4 = _mm_sub_ps( _mm_sub_ps( zero, B4 ), _mm_sqrt_ps( d4 ) );
								const __m128 mask4 = _mm_and_ps( _mm_cmpgt_ps( dist4, epsilon ), _mm_cmplt_ps( dist4, id.dist4[r] ) );
								id.shadow[r] = _mm_or_ps( id.shadow[r], mask4 );
							}
							continue;
						}
					#endif
						const vector3 ao = pr->m_Vertex[0]->m_Pos - O;
						if ((ao.x * pr->m_N.x + ao.y * pr->m_N.y + ao.z * pr->m_N.z) < 0) continue;
						const vector3 bo = pr->m_Vertex[1]->m_Pos - O;
						const vector3 co = pr->m_Vertex[2]->m_Pos - O;
						// test against frustum
						if (rp.maxis != -1)
						{
							const __m128 vala = DOT128( rp.nx4, rp.ny4, rp.nz4, _mm_set_ps1( ao.x ), _mm_set_ps1( ao.y ), _mm_set_ps1( ao.z ) );
							const __m128 valb = DOT128( rp.nx4, rp.ny4, rp.nz4, _mm_set_ps1( bo.x ), _mm_set_ps1( bo.y ), _mm_set_ps1( bo.z ) );
							const __m128 valc = DOT128( rp.nx4, rp.ny4, rp.nz4, _mm_set_ps1( co.x ), _mm_set_ps1( co.y ), _mm_set_ps1( co.z ) );
							const uint32 ires = (_mm_movemask_ps( vala ) ^ 15) & (_mm_movemask_ps( valb ) ^ 15) & (_mm_movemask_ps( valc ) ^ 15);
							if (ires) continue;
						}
						const vector3 v0c = co^bo;
						const __m128 v0c4x = broadcastss( &v0c.x ), v0c4y = broadcastss( &v0c.y ), v0c4z = broadcastss( &v0c.z );
						const vector3 v1c = bo^ao;
						const __m128 v1c4x = broadcastss( &v1c.x ), v1c4y = broadcastss( &v1c.y ), v1c4z = broadcastss( &v1c.z );
						const vector3 v2c = ao^co;
						const __m128 v2c4x = broadcastss( &v2c.x ), v2c4y = broadcastss( &v2c.y ), v2c4z = broadcastss( &v2c.z );
						// intersection test
						const __m128 n4x = broadcastss( &pr->m_N.x ), n4y = broadcastss( &pr->m_N.y ), n4z = broadcastss( &pr->m_N.z );
						const __m128 nominator = _mm_set_ps1( pr->m_N.x * ao.x + pr->m_N.y * ao.y + pr->m_N.z * ao.z );
						const uint pfirst = first >> 2;
						for ( uint r = pfirst; r < rp.packetq; ++r ) if (_mm_movemask_ps( id.shadow[r] ) != 15)
						{
							const __m128 v0d = DOT128( v0c4x, v0c4y, v0c4z, rp.dx4[r], rp.dy4[r], rp.dz4[r] );
							const uint32 v0s = _mm_movemask_ps( v0d );
							const __m128 v1d = DOT128( v1c4x, v1c4y, v1c4z, rp.dx4[r], rp.dy4[r], rp.dz4[r] );
							const uint32 v1s = _mm_movemask_ps( v1d );
							const __m128 v2d = DOT128( v2c4x, v2c4y, v2c4z, rp.dx4[r], rp.dy4[r], rp.dz4[r] );
							const uint32 v2s = _mm_movemask_ps( v2d );
							if ((v0s|v1s|v2s) < 15)
							{
								const uint32 tmask = ((v0s^0xf) & (v1s^0xf) & (v2s^0xf));
								const __m128 rdn = DOT128( n4x, n4y, n4z, rp.dx4[r], rp.dy4[r], rp.dz4[r] );
								const __m128 t4 = _mm_mul_ps( nominator, _mm_rcp_ps( rdn ) );
								const __m128 mask4 = _mm_and_ps( masktable4[tmask], _mm_cmple_ps( t4, id.dist4[r] ) );
								id.shadow[r] = _mm_or_ps( id.shadow[r], mask4 );
							}
						}
					}
				}
			}
			if (!stackptr) break;
			node = stack[--stackptr].node, first = stack[stackptr].first;
		}
		for ( int r = 0; r < samples; r++ )
		{
			const vector3 N = m_List[r]->N;
			const float dot = N.x * dx[r] + N.y * dy[r] + N.z * dz[r];
			if ((!id.prim[r]) && (dot > 0))
			// if (dot > 0)
			{
				// light source is visible for this sampling point, add diffuse illumination
				const float dr = ((float*)&id.dist4)[r] * m_Light->GetRRadius();
				const float v1 = (1 - dr) * 0.2f;
				const float v2 = dr * 4;
				const float v3 = 1.0f / (v2 * v2);
				const float att = MAX( 0, (v1 + v3) - 0.0625f );
				const Color add = 180 * dot * att * m_Light->GetDiffuse(); // 180 / samples, if there's more than 1
				m_List[r]->GI = _mm_add_ps( m_List[r]->GI, add.rgba );
			}
		}
	}
private:
	Light* m_Light;
	SamplingPoint** m_List;
	int m_Count;
};

class SoftShader : public Job
{
public:
	void init( int a_First, int a_Last, Light* a_Light, int a_Step, bool a_Temp )
	{
		m_First = a_First;
		m_Last = a_Last;
		m_Light = a_Light;
		m_Step = a_Step;
		m_Temp = a_Temp;
	}
	void main()
	{
		vector3 target = m_Light->GetPos();
		int samples = 32;
		RayPacket rp;
		IData id;
		rp.packetq = 8;
		rp.packetsize = 32;
		rp.offset = 0;
		rp.qoffset = 0;
		float rx[64], ry[64], rz[64];
		float dx = 2.0f / 4.0f, dy = 2.0f / 4.0f, dz = 2.0f / 4.0f;
		int i = 0;
		for ( int x = 0; x < 4; x++ ) for ( int y = 0; y < 4; y++ ) for ( int z = 0; z < 4; z++ )
		{
			rx[i] = -1 + (float)x * dx + Rand( dx );
			ry[i] = -1 + (float)y * dy + Rand( dy );
			rz[i] = -1 + (float)z * dz + Rand( dz );
			i++;
		}
		// shade
		BVHNode* pool = MManager::GetBVHPool();
		Primitive** prlist = MManager::GetBVHPrims();
		const __m128 small4 = _mm_set_ps1( 0.000001f ), zero = _mm_setzero_ps(), epsilon = _mm_set_ps1( EPSILON );
		const uint offset[16] = { 0, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0 };
		BVHStack stack[MAXBVHDEPTH];
		__m128 masktable4[16];
		memcpy( (void*)masktable4, _masktable, 256 );
		const float recisamples = 180.0f / (float)samples;
		SamplingPoint* sample = PhotonMapper::GetSamples();
		for ( int i = m_First; i <= m_Last; i++ )
		{
			memset( &rp.mask4, 255, sizeof( rp.mask4 ) );
			sample[i].GI = sample[i].temp[m_Step] = _mm_setzero_ps();
			const vector3 O = sample[i].pos; // target + rvec;
			const __m128 Ox4 = _mm_set_ps1( O.x ), Oy4 = _mm_set_ps1( O.y ), Oz4 = _mm_set_ps1( O.z );
			float* dist = (float*)&id.dist4;
			unsigned int* prim = (unsigned int*)&id.prim4;
			for ( int j = 0; j < samples; j++ )
			{
				vector3 rvec( rx[j], ry[j], rz[j] );
				vector3 D = (target + rvec) - O; // m_Sample[i].pos - O;
				dist[j] = D.Length();
				const float recid = 1.0f / dist[j];
				dist[j] *= 0.9995f;
				D *= recid;
				prim[j] = 0;
				rp.SetOrigin( j, O );
				rp.SetDirection( j, D );
			}
			// trace rays to area light as packet
			rp.CalcReciprocals();
			rp.BuildPlanesShadow( O );
			uint stackptr = 0, first = 0;
			BVHNode* node = SceneGraph::GetSceneRoot();
			unsigned int quad = ((reinterpret_cast<float*>(rp.dx4)[0] < 0)?1:0) + 
								((reinterpret_cast<float*>(rp.dy4)[0] < 0)?2:0) + 
								((reinterpret_cast<float*>(rp.dz4)[0] < 0)?4:0);
			while (1)
			{
				// find first active ray (if any) -  step 1: check if first ray intersects box
				{
					float tmin = 0.00001f, tmax = reinterpret_cast<float*>(id.dist4)[first];
					for ( uint axis = 0; axis < 3; ++axis ) 
					{
						const uint idx = axis * PACKETSIZE + first;
						const float t0 = (node->min.cell[axis] - O.cell[axis]) * reinterpret_cast<float*>(rp.rdx4)[idx];
						const float t1 = (node->max.cell[axis] - O.cell[axis]) * reinterpret_cast<float*>(rp.rdx4)[idx];
						const float nr = (t0 < t1) ? t0 : t1, fr = (t0 < t1) ? t1 : t0;
						tmin = (tmin < nr) ? nr : tmin, tmax = (fr <  tmax) ? fr : tmax;
					}
					if ((tmin <= tmax) && (id.prim[first] == 0)) goto done;
					if (++first > (rp.packetsize - 1)) goto done;
					// step 2: check if frustum misses box
					if (rp.maxis > -1)
					{
						const float* bounds = (float*)node;
						unsigned int* signs = reinterpret_cast<unsigned int*>(rp.signs4);
						const __m128 bx4 = _mm_set_ps( bounds[signs[0]], bounds[signs[1]], bounds[signs[2]], bounds[signs[3]] );
						const __m128 by4 = _mm_set_ps( bounds[signs[4]], bounds[signs[5]], bounds[signs[6]], bounds[signs[7]] );
						const __m128 bz4 = _mm_set_ps( bounds[signs[8]], bounds[signs[9]], bounds[signs[10]], bounds[signs[11]] );
						const __m128 dst4 = DOT128( bx4, by4, bz4, rp.nx4, rp.ny4, rp.nz4 );
						if (_mm_movemask_ps( _mm_cmpgt_ps( dst4, rp.D4 ) ) > 0) { first = rp.packetsize; goto done; }
					}
					// step 3: check all rays
					const uint pfirst = first >> 2;
					first = rp.packetsize;
					const __m128 minx4 = _mm_set_ps1( node->min.x ), maxx4 = _mm_set_ps1( node->max.x );
					const __m128 miny4 = _mm_set_ps1( node->min.y ), maxy4 = _mm_set_ps1( node->max.y );
					const __m128 minz4 = _mm_set_ps1( node->min.z ), maxz4 = _mm_set_ps1( node->max.z );
					for ( uint r = pfirst; r < rp.packetq; ++r ) if (_mm_movemask_ps( id.shadow[r] ) != 15)
					{			
						const __m128 tmin4a = small4, tmax4a = id.dist4[r];
						const __m128 t0a = _mm_mul_ps( _mm_sub_ps( minx4, Ox4 ), rp.rdx4[r] );
						const __m128 t1a = _mm_mul_ps( _mm_sub_ps( maxx4, Ox4 ), rp.rdx4[r] );
						const __m128 nra = _mm_min_ps( t0a, t1a ), fra = _mm_max_ps( t0a, t1a );
						const __m128 tmin4b = _mm_max_ps( tmin4a, nra ), tmax4b = _mm_min_ps( tmax4a, fra );
						const __m128 t0b = _mm_mul_ps( _mm_sub_ps( miny4, Oy4 ), rp.rdy4[r] );
						const __m128 t1b = _mm_mul_ps( _mm_sub_ps( maxy4, Oy4 ), rp.rdy4[r] );
						const __m128 nrb = _mm_min_ps( t0b, t1b ), frb = _mm_max_ps( t0b, t1b );
						const __m128 tmin4c = _mm_max_ps( tmin4b, nrb ), tmax4c = _mm_min_ps( tmax4b, frb );
						const __m128 t0c = _mm_mul_ps( _mm_sub_ps( minz4, Oz4 ), rp.rdz4[r] );
						const __m128 t1c = _mm_mul_ps( _mm_sub_ps( maxz4, Oz4 ), rp.rdz4[r] );
						const __m128 nrc = _mm_min_ps( t0c, t1c ), frc = _mm_max_ps( t0c, t1c );
						const __m128 tmin4d = _mm_max_ps( tmin4c, nrc ), tmax4d = _mm_min_ps( tmax4c, frc );
						const uint ires = _mm_movemask_ps( _mm_andnot_ps( id.shadow[r], _mm_cmple_ps( tmin4d, tmax4d ) ) ); 
						if (ires) { first = r * 4 + offset[ires]; break; }
					}
				}
			done:
				if (first < rp.packetsize)
				{
					if (!node->IsLeaf())
					{
						const uint lidx = (node->GetDirMask() >> quad) & 1;
						stack[stackptr].node = &pool[node->GetLeft() + 1 - lidx];
						stack[stackptr++].first = first;
						node = &pool[node->GetLeft() + lidx];
						continue;
					}
					else
					{
						const uint start = node->GetStart(), count = node->GetTCount();
						for ( uint i = 0; i < count; ++i ) 
						{
							Primitive* pr = prlist[start + i];
						#ifdef SUPPORTSPHERES
							if (pr->GetType() == Primitive::PRIM_SPHERE)
							{
								int pfirst = first >> 2;
								const __m128 dstx4 = _mm_sub_ps( Ox4, _mm_set_ps1( pr->m_N.x ) );
								const __m128 dsty4 = _mm_sub_ps( Oy4, _mm_set_ps1( pr->m_N.y ) );
								const __m128 dstz4 = _mm_sub_ps( Oz4, _mm_set_ps1( pr->m_N.z ) );
								const __m128 sqrad4 = _mm_set_ps1( pr->m_T.y );
								for ( unsigned int r = pfirst; r < rp.packetq; r++ ) if (_mm_movemask_ps( id.shadow[r] ) != 15)
								{
									const __m128 B4 = _mm_add_ps( _mm_add_ps( _mm_mul_ps( dstx4, rp.dx4[r] ), _mm_mul_ps( dsty4, rp.dy4[r] ) ), _mm_mul_ps( dstz4, rp.dz4[r] ) );
									const __m128 C4 = _mm_sub_ps( _mm_add_ps( _mm_add_ps( _mm_mul_ps( dstx4, dstx4 ), _mm_mul_ps( dsty4, dsty4 ) ), _mm_mul_ps( dstz4, dstz4 ) ), sqrad4 );
									const __m128 d4 = _mm_sub_ps( _mm_mul_ps( B4, B4 ), C4 );
									const __m128 dist4 = _mm_sub_ps( _mm_sub_ps( zero, B4 ), _mm_sqrt_ps( d4 ) );
									const __m128 mask4 = _mm_and_ps( _mm_cmpgt_ps( dist4, epsilon ), _mm_cmplt_ps( dist4, id.dist4[r] ) );
									id.shadow[r] = _mm_or_ps( id.shadow[r], mask4 );
								}
								continue;
							}
						#endif
							const vector3 ao = pr->m_Vertex[0]->m_Pos - O;
							if ((ao.x * pr->m_N.x + ao.y * pr->m_N.y + ao.z * pr->m_N.z) < 0) continue;
							const vector3 bo = pr->m_Vertex[1]->m_Pos - O;
							const vector3 co = pr->m_Vertex[2]->m_Pos - O;
							// test against frustum
							if (rp.maxis != -1)
							{
								const __m128 vala = DOT128( rp.nx4, rp.ny4, rp.nz4, _mm_set_ps1( ao.x ), _mm_set_ps1( ao.y ), _mm_set_ps1( ao.z ) );
								const __m128 valb = DOT128( rp.nx4, rp.ny4, rp.nz4, _mm_set_ps1( bo.x ), _mm_set_ps1( bo.y ), _mm_set_ps1( bo.z ) );
								const __m128 valc = DOT128( rp.nx4, rp.ny4, rp.nz4, _mm_set_ps1( co.x ), _mm_set_ps1( co.y ), _mm_set_ps1( co.z ) );
								const uint32 ires = (_mm_movemask_ps( vala ) ^ 15) & (_mm_movemask_ps( valb ) ^ 15) & (_mm_movemask_ps( valc ) ^ 15);
								if (ires) continue;
							}
							const vector3 v0c = co^bo;
							const __m128 v0c4x = broadcastss( &v0c.x ), v0c4y = broadcastss( &v0c.y ), v0c4z = broadcastss( &v0c.z );
							const vector3 v1c = bo^ao;
							const __m128 v1c4x = broadcastss( &v1c.x ), v1c4y = broadcastss( &v1c.y ), v1c4z = broadcastss( &v1c.z );
							const vector3 v2c = ao^co;
							const __m128 v2c4x = broadcastss( &v2c.x ), v2c4y = broadcastss( &v2c.y ), v2c4z = broadcastss( &v2c.z );
							// intersection test
							const __m128 n4x = broadcastss( &pr->m_N.x ), n4y = broadcastss( &pr->m_N.y ), n4z = broadcastss( &pr->m_N.z );
							const __m128 nominator = _mm_set_ps1( pr->m_N.x * ao.x + pr->m_N.y * ao.y + pr->m_N.z * ao.z );
							const uint pfirst = first >> 2;
							for ( uint r = pfirst; r < rp.packetq; ++r ) if (_mm_movemask_ps( id.shadow[r] ) != 15)
							{
								const __m128 v0d = DOT128( v0c4x, v0c4y, v0c4z, rp.dx4[r], rp.dy4[r], rp.dz4[r] );
								const uint32 v0s = _mm_movemask_ps( v0d );
								const __m128 v1d = DOT128( v1c4x, v1c4y, v1c4z, rp.dx4[r], rp.dy4[r], rp.dz4[r] );
								const uint32 v1s = _mm_movemask_ps( v1d );
								const __m128 v2d = DOT128( v2c4x, v2c4y, v2c4z, rp.dx4[r], rp.dy4[r], rp.dz4[r] );
								const uint32 v2s = _mm_movemask_ps( v2d );
								if ((v0s|v1s|v2s) < 15)
								{
									const uint32 tmask = ((v0s^0xf) & (v1s^0xf) & (v2s^0xf));
									const __m128 rdn = DOT128( n4x, n4y, n4z, rp.dx4[r], rp.dy4[r], rp.dz4[r] );
									const __m128 t4 = _mm_mul_ps( nominator, _mm_rcp_ps( rdn ) );
									const __m128 mask4 = _mm_and_ps( masktable4[tmask], _mm_cmple_ps( t4, id.dist4[r] ) );
									id.shadow[r] = _mm_or_ps( id.shadow[r], mask4 );
								}
							}
						}
					}
				}
				if (!stackptr) break;
				node = stack[--stackptr].node, first = stack[stackptr].first;
			}
			const vector3 N =  sample[i].N;
			const float* dx = (float*)&rp.dx4;
			const float* dy = (float*)&rp.dy4;
			const float* dz = (float*)&rp.dz4;
			if (!m_Temp)
			{
				for ( int r = 0; r < samples; r++ )
				{
					const float dot = -(N.x * dx[r] + N.y * dy[r] + N.z * dz[r]);
					if ((!id.prim[r]) && (dot > 0))
					{
						// light source is visible for this sampling point, add diffuse illumination
						const float dr = ((float*)&id.dist4)[r] * m_Light->GetRRadius();
						const float v1 = (1 - dr) * 0.2f;
						const float v2 = dr * 4;
						const float v3 = 1.0f / (v2 * v2);
						const float att = MAX( 0, (v1 + v3) - 0.0625f );
						const Color add = recisamples * dot * att * m_Light->GetDiffuse();
						sample[i].GI = _mm_add_ps( sample[i].GI, add.rgba );
					}
				}
			}
			else
			{
				for ( int r = 0; r < samples; r++ )
				{
					const float dot = -(N.x * dx[r] + N.y * dy[r] + N.z * dz[r]);
					if ((!id.prim[r]) && (dot > 0))
					{
						// light source is visible for this sampling point, add diffuse illumination
						const float dr = ((float*)&id.dist4)[r] * m_Light->GetRRadius();
						const float v1 = (1 - dr) * 0.2f;
						const float v2 = dr * 4;
						const float v3 = 1.0f / (v2 * v2);
						const float att = MAX( 0, (v1 + v3) - 0.0625f );
						const Color add = recisamples * dot * att * m_Light->GetDiffuse();
						sample[i].temp[m_Step] = _mm_add_ps( sample[i].temp[m_Step], add.rgba );
					}
				}
			}
		}
	}
private:
	int m_First, m_Last, m_Step;
	bool m_Temp;
	Light* m_Light;
};

// ApplyDirectLighting: Store direct illumination in the sampling points (diffuse only)
void PhotonMapper::ApplyDirectLighting( Light* a_Light )
{
	Log::Message( "baking soft shadows..." );
	int start = GetTickCount();
	JobManager* jm = JobManager::GetJobManager();
#if 0
	if (!m_CList)
	{
		int size = PHOTONGRIDX * PHOTONGRIDY * PHOTONGRIDZ;
		int filled = 0;
		int maxfill = 0;
		m_Filled = 0;
		for ( int i = 0; i < size; i++ ) if (m_Grid[i].GetCentreCount()) filled++;
		m_CList = new Cell*[filled];
		for ( int i = 0; i < size; i++ ) 
		{
			int count = m_Grid[i].GetCentreCount();
			if (count) 
			{
				m_CList[m_Filled++] = &m_Grid[i];
				if (count > maxfill) maxfill = count;
			}
		}
		Log::FloatValue( "average point/cell: ", (float)m_Total / (float)m_Filled );
		Log::IntValue( "max point/cell: ", maxfill );
	}
	CellShader st;
	for ( int i = 0; i < m_Filled; i++ )
	{
		st.init( a_Light, m_CList[i]->GetSamples(), m_CList[i]->GetCentreCount() );
		jm->AddJob2( &st );
		jm->RunJobs();			
	}
#else
	SoftShader s1, s2;
	s1.init( 0, m_Total / 2, a_Light, 1, false );
	s2.init( m_Total / 2 + 1, m_Total - 1, a_Light, 1, false );
	jm->AddJob2( &s1 );
	jm->AddJob2( &s2 );
	jm->RunJobs();
#endif
	Log::IntValue( "direct lighting took (ms) :", GetTickCount() - start );
}

// UpdateDirectLighting: Update (part of) the direct lighting
void PhotonMapper::UpdateDirectLighting( Light* a_Light, int a_Step )
{
	SoftShader s1, s2;
	s1.init( 0, m_Total / 2, a_Light, a_Step, true );
	s2.init( m_Total / 2 + 1, m_Total - 1, a_Light, a_Step, true );
	JobManager* jm = JobManager::GetJobManager();
	jm->AddJob2( &s1 );
	jm->AddJob2( &s2 );
	jm->RunJobs();
}

// CombineLighting: Sum the eight intermediate values into a single shading value
void PhotonMapper::CombineLighting()
{
	const __m128 scale = _mm_set_ps1( 0.125f );
	for ( int i = 0; i < m_Total; i++ )
	{
		__m128 total = m_Sample[i].temp[0];
		for ( int j = 1; j < 8; j++ ) total = _mm_add_ps( total, m_Sample[i].temp[j] );
		m_Sample[i].GI = _mm_mul_ps( total, scale );
	}
}

// LoadColors: Load irradiance data from disk
void PhotonMapper::LoadColors()
{
	char name[128];
	strcpy( name, Scene::GetSceneName() );
	strcat( name, ".gi" );
	FILE* f = fopen( name, "rb" );
	const __m128 scale4 = _mm_set_ps( 0, m_Brightness, m_Brightness, m_Brightness );
	if (!f) 
	{	
		Log::Write( "Error: Sampling point color file not found", name );
		return;
	}
	unsigned int count;
	fread( &count, 4, 1, f );
	for ( unsigned int i = 0; i < count; i++ )
	{
		__m128 c;
		fread( &c, 16, 1, f );
		m_Sample[i].GI = _mm_mul_ps( c, scale4 );
	}
	fclose( f );
}

// SaveColors: Save irradiance data to disk
void PhotonMapper::SaveColors()
{
	char name[128];
	strcpy( name, Scene::GetSceneName() );
	strcat( name, ".gi" );
	FILE* f = fopen( name, "wb" );
	unsigned int totalvalid = 0;
	for ( int i = 0; i < m_Total; i++ ) if (!m_Sample[i].Removed()) totalvalid++;
	fwrite( &totalvalid, 4, 1, f );
	const __m128 scale4 = _mm_set_ps( 0, 1.0f / m_Brightness, 1.0f / m_Brightness, 1.0f / m_Brightness );
	if (order)
	{
		// ordered write
		const unsigned int size = PHOTONGRIDX * PHOTONGRIDY * PHOTONGRIDZ;
		for ( int i = 0; i < m_Total; i++ ) m_Sample[i].NotStored();
		for ( int i = 0; i < size; i++ )
		{
			SamplingPoint** plist = m_Grid[i].GetSamples();
			if (!plist) continue;
			unsigned int count = m_Grid[i].GetSampleCount();
			for ( unsigned int j = 0; j < count; j++ ) if ((!plist[j]->Removed()) && (!plist[j]->IsStored()))
			{
				__m128 c = _mm_mul_ps( plist[j]->GI, scale4 );
				fwrite( &c, 16, 1, f );
				plist[j]->Stored();
			}
		}
	}
	else
	{
		for ( int i = 0; i < m_Total; i++ ) if (!m_Sample[i].Removed())
		{
			__m128 c = _mm_mul_ps( m_Sample[i].GI, scale4 );
			fwrite( &c, 16, 1, f );
		}
	}
	fclose( f );
}

// run: Thread entry point
void PhotonMapper::run()
{
	int perthread = m_Total / m_Cores;
	int first = m_Thread * perthread;
	int last = (m_Thread + 1) * perthread;
	InitSampleColors( first, last );
	SetEvent( gidone[m_Thread] );
}

// ---------------------------------------------------------
// VPL HIERARCHY
// ---------------------------------------------------------

// SubDivBVH: actual BVH construction, called by BuildVPLBVH
VPLBVHNode* PhotonMapper::SubDivBVH( VPLBVHNode** list, int first, int last, int axis, int& next )
{
	VPLBVHNode* node = &m_First[next++]; // (VPLBVHNode*)MALLOC64( sizeof( VPLBVHNode ) );
	// sort over axis (quicksort)
	int sp = 0, sl[128], sr[128], start = first, end = last;
	while (1)
	{
		const float pivot = list[start]->pos.cell[axis];
		int left = start + 1, right = end;
		while (left < right)
		{
			if (list[left]->pos.cell[axis] < pivot) left++;
			else { VPLBVHNode* T = list[left]; list[left] = list[right]; list[right--] = T; }
		}
		VPLBVHNode* T = list[--left]; list[left--] = list[start]; list[start] = T;
		if (left > start) sl[sp] = start, sr[sp++] = left;
		if (end > right) sl[sp] = right, sr[sp++] = end;
		if (!sp) break;
		start = sl[--sp], end = sr[sp];
	}
	// create node
	const int pivot = (first + last) >> 1, nextaxis = (axis + 1) % 3;
	VPLBVHNode* left, *right;
	if (first != pivot) left = SubDivBVH( list, first, pivot, nextaxis, next );
				   else left = list[first];
	if ((pivot + 1) != last) right = SubDivBVH( list, pivot + 1, last, nextaxis, next );
						else right = list[pivot + 1];
	node->left = left;
	node->right = right;
	node->sum4 = _mm_add_ps( left->sum4, right->sum4 );
	node->total = node->sum[0] + node->sum[1] + node->sum[2];
	const float m1 = 0.001f + left->sum[0] + left->sum[1] + left->sum[2];
	const float m2 = 0.001f + right->sum[0] + right->sum[1] + right->sum[2];
	const float w1 = m1 / (m1 + m2), w2 = m2 / (m1 + m2);
	const float dotadjust = -left->N.Dot( right->N ) + 2;
	node->sqrad = (left->pos - right->pos).SqrLength() * dotadjust;
	node->N = (left->N * w1) + (right->N * w2);
	node->N.Normalize();
	node->pos = (left->pos * w1) + (right->pos * w2);
	left->parent = right->parent = node;
	// done
	return node;
}

// BuildVPLBVH: Construction of the VPL BVH
void PhotonMapper::BuildVPLBVH()
{
	Log::Message( "entering PhotonMapper::BuildVPLBVH()" );
	// create leaf nodes
	m_First = (VPLBVHNode*)MALLOC64( (m_NrVPL * 2 + 2) * sizeof( VPLBVHNode ) );
	VPLBVHNode** node = new VPLBVHNode*[m_NrVPL * 2 + 2];
	for ( int i = 0; i < m_NrVPL; i++ )
	{
		node[i] = &m_First[i];
		node[i]->pos = m_VPL[i];
		node[i]->N = m_VPN[i];
		node[i]->sum4 = m_VPcol[i];
		node[i]->total = node[i]->sum[0] + node[i]->sum[1] + node[i]->sum[2];
		node[i]->left = node[i]->right = 0;
		node[i]->sqrad = 0;
	}
	// subdivide
	int axis = 0;
	int first = 0, last = m_NrVPL - 1;
	int next = m_NrVPL;
	m_Root = SubDivBVH( node, 0, m_NrVPL - 1, 0, next );
	unsigned int leafs = 0, nodes = 0;
	Log::Message( "leaving PhotonMapper::BuildVPLBVH()" );
}

// CopyVPLBVH: Create a copy of the VPL BVH; each thread needs a copy
void PhotonMapper::CopyVPLBVH()
{
	m_LFirst = (VPLBVHNode*)MALLOC64( (m_NrVPL * 2 + 2) * sizeof( VPLBVHNode ) );
	memcpy( m_LFirst, m_First, (m_NrVPL * 2 + 2) * sizeof( VPLBVHNode ) );
	for ( int i = 0; i < (m_NrVPL * 2 + 2 ); i++ ) 
	{
		if (m_LFirst[i].left) 
		{
			m_LFirst[i].ileft -= (unsigned int)m_First;
			m_LFirst[i].ileft += (unsigned int)m_LFirst;
		}
		if (m_LFirst[i].right) 
		{
			m_LFirst[i].iright -= (unsigned int)m_First;
			m_LFirst[i].iright += (unsigned int)m_LFirst;
		}
		m_LFirst[i].parent -= (unsigned int)m_First;
		m_LFirst[i].parent += (unsigned int)m_LFirst;
	}
	m_LRoot = m_LFirst + (m_Root - m_First);
}

#endif