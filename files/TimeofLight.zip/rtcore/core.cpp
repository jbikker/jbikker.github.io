// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#include "precomp.h"

#pragma warning ( disable : 4068 )

using namespace Raytracer;

Surface* GetSurface();

static MManager mmanager;
static LBVHMManager bvhmman;
static Scene scene;
static SceneGraph scenegraph;
static Log applog( "applog.txt" );

_declspec(align(16)) 
static LineTracer LT[MAXTHREADS];
static Engine engine;
static const __m128 _half4 = _mm_set_ps1( 0.5f );
static const __m128 _three = _mm_set_ps1( 3.0f );
unsigned int _masktable[64];
unsigned int _raydir[8][3][2];

Pixel* m_Final = 0, *m_Surf = 0;
Pixel* m_BDest = 0, *m_Dest = 0;
uint Engine::m_Width, Engine::m_Height, Engine::m_Pitch;
vector3 Engine::m_P1, Engine::m_P2, Engine::m_P3, Engine::m_P4;
vector3 Engine::m_Origin, Engine::m_DX, Engine::m_DY;
RayPacket Engine::m_Template;
uint Engine::m_Cores;
uint Engine::m_Counter1, Engine::m_Counter2, Engine::m_Counter3;
float Engine::m_SetupTime = 0, Engine::m_RenderTime = 0, Engine::m_AATime = 0, Engine::m_PostProcTime = 0;
float Engine::m_BuildTime = 0, Engine::m_LoopTime = 0, Engine::m_PostTime = 0;
bool Engine::m_ShowPCount = false;
#ifdef PHOTONMAPPING
bool Engine::m_Photons = false, Engine::m_GIDots = false, Engine::m_GIVoronoi = false;
#else
bool Engine::m_Photons = false;
#endif
bool Engine::m_HDRBlur = false;
uint Engine::m_AATreshold = 128;
uint Engine::m_RaysCast, Engine::m_Intersections;
uint Engine::m_Leafs, Engine::m_NCInts, Engine::m_AARaysCast;
uint Engine::m_GITicks;

char* Log::m_File;

Camera Scene::m_Camera;
char* Scene::m_Name;
aabb Scene::m_Extends;
vector3 Scene::m_CamPos, Scene::m_CamTarget;
vector3 Scene::m_CamRot;
Light** Scene::m_Light;
LBVH* Scene::m_LBVH;
MatManager* Scene::m_MatMan;
bool Scene::m_Fullscreen, Scene::m_Fog, Scene::m_GI, Scene::m_GIpoints, Scene::m_GIcolors;
uint Scene::m_Quality, Scene::m_Lights, Scene::m_State;
__m128 Scene::m_FogTop4, Scene::m_FogDensity4;
Color Scene::m_FogColor, Scene::m_Ambient;
float Scene::m_FogTop, Scene::m_FogDensity;
Primitive* Scene::m_Dome;
float Scene::m_SDScale;

// thread synchronisation
static HANDLE waitforgo[MAXTHREADS];	// wait for 'go' signal (event)
static HANDLE waitfordone[MAXTHREADS];	// wait for 'ready' signal (event)
HANDLE gidone[MAXTHREADS];				// wait for gi done signal (event)
HANDLE waitpmreq[MAXTHREADS];			// wait for photon mapper 'go' signal (event)
static HANDLE mutex;					// mutex for reading task data
static HANDLE countlock;				// mutex for locking active thread counter
static volatile LONG waiting = 0;

// timing
static wallclock_t RTimer;
double wallclock_t::inv_freq; 

__forceinline __int64 GetClockTicks()
{
#ifdef _WIN64
	__int64 clock = 1;
#else
	__int64 clock = 0;
	__asm
	{
		rdtsc
		mov	dword ptr[clock], eax
		mov	dword ptr[clock + 4], edx
	}
#endif
	return clock;
}

static __forceinline float hormin( const __m128 v )
{
   const __m128 res1 = _mm_min_ps( v, swaphalves( v ) );
   const __m128 res2 = _mm_min_ps( res1, reverse( res1 ) );
   const float* res = (const float*)&res2;
   return res[0];
}

static __forceinline float hormax( const __m128 v )
{
   const __m128 res1 = _mm_max_ps( v, swaphalves( v ) );
   const __m128 res2 = _mm_max_ps( res1, reverse( res1 ) );
   const float* res = (const float*)&res2;
   return res[0];
}

static __forceinline __m128 fastrsqrt( const __m128 v )
{
	const __m128 nr = _mm_rsqrt_ps( v );
	const __m128 muls = _mm_mul_ps( _mm_mul_ps( v, nr ), nr );
	return _mm_mul_ps( _mm_mul_ps( _half4, nr ), _mm_sub_ps( _three, muls ) );
}

static __forceinline const __m128 _mm_exp_ps( const __m128& e )
{
    const __m128 x2 = _mm_mul_ps( e, e );
    const __m128 term1 = _mm_add_ps( _mm_set1_ps( 0.496879224f ), _mm_mul_ps( _mm_set1_ps( 0.190809553f ), e ) );
    const __m128 term2 = _mm_add_ps( _mm_set1_ps( 1.0f ), e );
    return _mm_add_ps( term2, _mm_mul_ps( x2, term1 ) );
}

Engine::Engine()
{
	SYSTEM_INFO sinfo;
	GetSystemInfo( &sinfo );
	m_Cores = sinfo.dwNumberOfProcessors;
	if (m_Cores > MAXTHREADS) m_Cores = MAXTHREADS;
	uint i;
	// masktable
	for ( i = 0; i < 16; i++ )
	{
		_masktable[i * 4 + 3] = (i & 8)?0xffffffff:0;	
		_masktable[i * 4 + 2] = (i & 4)?0xffffffff:0;	
		_masktable[i * 4 + 1] = (i & 2)?0xffffffff:0;	
		_masktable[i * 4 + 0] = (i & 1)?0xffffffff:0;	
	}
	for ( i = 0; i < 8; i++ )
	{
		const unsigned int rdx = i & 1;
		const unsigned int rdy = (i >> 1) & 1;
		const unsigned int rdz = (i >> 2) & 1;
		_raydir[i][0][0] = rdx, _raydir[i][0][1] = rdx ^ 1;
		_raydir[i][1][0] = rdy, _raydir[i][1][1] = rdy ^ 1;
		_raydir[i][2][0] = rdz, _raydir[i][2][1] = rdz ^ 1;
	}
	// create events & mutex
	for ( i = 0; i < m_Cores; i++ )
	{
		waitforgo[i] = CreateEvent( NULL, FALSE, FALSE, NULL );
		waitpmreq[i] = CreateEvent( NULL, FALSE, FALSE, NULL );
		waitfordone[i] = CreateEvent( NULL, FALSE, FALSE, NULL );
		gidone[i] = CreateEvent( NULL, FALSE, FALSE, NULL );
	}
	mutex = CreateMutex( NULL, FALSE, NULL );
	countlock = CreateMutex( NULL, FALSE, NULL );
	// create and start worker threads
	for ( i = 0; i < m_Cores; i++ )
	{
		LT[i].Init( i );
		LT[i].setPriority( Thread::P_ABOVE_NORMAL );
		if (i < (m_Cores - 1)) LT[i].start();
	}
	RTimer.init();
	JobManager::CreateJobManager( 2 );
}

Engine::~Engine()
{
	for ( uint i = 0; i < m_Cores; i++ ) 
	{
		TerminateThread( LT[i].handle(), 0 );
		CloseHandle( LT[i].handle() );
	}
	CloseHandle( mutex );
	CloseHandle( countlock );
}

// -----------------------------------------------------------
// Engine::SetTarget
// Sets the render target canvas
// -----------------------------------------------------------
void Engine::SetTarget( Pixel* a_Dest, uint a_Width, uint a_Height, uint a_Pitch  )
{
	// set pixel buffer address & size
	m_Final = a_Dest;
	m_Width = a_Width;
	m_Height = a_Height;
	m_Pitch = a_Pitch;
	if (!m_Dest) 
	{
		unsigned long addr = (unsigned long)(char*)(new Pixel[4 * (m_Pitch * (m_Height + 4)) + 8]);
		addr = ((addr + 32) & (0xffffffff - 31)) + m_Pitch * 4 * 2;
		m_Dest = (Pixel*)addr;
		m_BDest = (Pixel*)(addr + 4 * m_Pitch * (m_Height + 4));
		m_Final = a_Dest;
	}
}

// -----------------------------------------------------------
// RayPacket::Normalize
// Normalize and reciprocals
// -----------------------------------------------------------
void RayPacket::Normalize( uint r )
{
	const __m128 rlen = fastrsqrt( _mm_add_ps( _mm_add_ps( _mm_mul_ps( dx4[r], dx4[r] ), 
		_mm_mul_ps( dy4[r], dy4[r] ) ), _mm_mul_ps( dz4[r], dz4[r] ) ) );
	dx4[r] = _mm_mul_ps( dx4[r], rlen );
	dy4[r] = _mm_mul_ps( dy4[r], rlen );
	dz4[r] = _mm_mul_ps( dz4[r], rlen );
	rdx4[r] = safercp( dx4[r] );
	rdy4[r] = safercp( dy4[r] );
	rdz4[r] = safercp( dz4[r] );
}

// -----------------------------------------------------------
// RayPacket::FindDominantAxis
// Construct a frustum for this packet
// -----------------------------------------------------------
void RayPacket::FindDominantAxis()
{
	maxis = 0;
	const uint moda[8] = { 0, 1, 2, 0, 1, 2, 0, 1 };
	float* dcell = reinterpret_cast<float*>(&dx4);
	if (fabs( dcell[1 * PACKETSIZE] ) > fabs( dcell[0] )) maxis = 1;
	if (fabs( dcell[2 * PACKETSIZE] ) > fabs( dcell[maxis * PACKETSIZE] )) maxis = 2;
	for ( uint a = 0; a < 3; a++ )
	{
		const uint maxabsdirsign = (dcell[maxis * PACKETSIZE] < 0) << 31;
		const __m128i idirsign4 = _mm_set_epi32( maxabsdirsign, maxabsdirsign, maxabsdirsign, maxabsdirsign );
		__m128 result = _mm_cmplt_ps( dx4[0], dx4[0] );
		for ( uint r = 0; r < packetq; ++r ) result = _mm_or_ps( result, _mm_and_ps( mask4[r], _mm_xor_ps( *(const __m128*)reinterpret_cast<const __m128*>(&idirsign4), dx4[maxis * PACKETQ + r] ) ) );
		if (_mm_movemask_ps( result ) == 0) { maxdir = maxabsdirsign; return; }
		maxis = moda[maxis + 1];
	}
	maxis = -1;
}

// -----------------------------------------------------------
// RayPacket::FindDominantAxisGeneric
// Construct a frustum for this packet
// -----------------------------------------------------------
void RayPacket::FindDominantAxisGeneric()
{
	maxis = 0;
	const uint moda[8] = { 0, 1, 2, 0, 1, 2, 0, 1 };
	float* dcell = reinterpret_cast<float*>(&dx4);
	if (fabs( dcell[1 * PACKETSIZE + offset] ) > fabs( dcell[offset] )) maxis = 1;
	if (fabs( dcell[2 * PACKETSIZE + offset] ) > fabs( dcell[maxis * PACKETSIZE + offset] )) maxis = 2;
	const uint qo = qoffset;
	for ( uint a = 0; a < 3; a++ )
	{
		uint maxabsdirsign = (dcell[maxis * PACKETSIZE + offset] < 0) << 31;
		const __m128i idirsign4 = _mm_set_epi32( maxabsdirsign, maxabsdirsign, maxabsdirsign, maxabsdirsign );
		__m128 result = _mm_cmplt_ps( dx4[qo], dx4[qo] );
		for ( uint r = 0; r < packetq; ++r ) result = _mm_or_ps( result, _mm_and_ps( mask4[r + qo], _mm_xor_ps( *(const __m128*)reinterpret_cast<const __m128*>(&idirsign4), dx4[maxis * PACKETQ + qo + r] ) ) );
		if (_mm_movemask_ps( result ) == 0) { maxdir = maxabsdirsign; return; }
		maxis = moda[maxis + 1];
	}
	maxis = -1;
}

// -----------------------------------------------------------
// RayPacket::BuildPlanesShadow
// Construct a frustum for a shadow packet
// -----------------------------------------------------------
void RayPacket::BuildPlanesShadow( const vector3& a_Origin )
{
	const uint mod3_1[6] = { 1, 2, 0, 1, 2, 0 };
	const uint mod3_2[6] = { 2, 0, 1, 2, 0, 1 };
	FindDominantAxis();
	if (maxis < 0) return;
	const sint a = maxis;
	const sint u = mod3_1[a], v = mod3_2[a];
	// find maximum and minimum slopes
	__m128 minuslope4 = _mm_set_ps1( 10000 );
	__m128 minvslope4 = _mm_set_ps1( 10000 );
	__m128 maxuslope4 = _mm_set_ps1( -10000 );
	__m128 maxvslope4 = _mm_set_ps1( -10000 );
	for ( uint r = 0; r < packetq; r++ )
	{
		const __m128 da4 = rdx4[a * PACKETQ + r];
		const __m128 uslope4 = _mm_mul_ps( dx4[u * PACKETQ + r + qoffset], da4 );
		const __m128 vslope4 = _mm_mul_ps( dx4[v * PACKETQ + r + qoffset], da4 );
		minuslope4 = _mm_min_ps( minuslope4, uslope4 );
		maxuslope4 = _mm_max_ps( maxuslope4, uslope4 );
		minvslope4 = _mm_min_ps( minvslope4, vslope4 );
		maxvslope4 = _mm_max_ps( maxvslope4, vslope4 );
	}
	const float* minuslp = (float*)&minuslope4, *minvslp = (float*)&minvslope4;
	const float* maxuslp = (float*)&maxuslope4, *maxvslp = (float*)&maxvslope4;
	float minuslope = minuslp[0], maxuslope = maxuslp[0];
	float minvslope = minvslp[0], maxvslope = maxvslp[0];
	for ( uint r = 1; r < 4; r++ )
	{
		minuslope = MIN( minuslope, minuslp[r] );
		minvslope = MIN( minvslope, minvslp[r] );
		maxuslope = MAX( maxuslope, maxuslp[r] );
		maxvslope = MAX( maxvslope, maxvslp[r] );
	}
	// flip if major dir is negative
	float* nc = reinterpret_cast<float*>(&nx4);
	nc[a * 4 + 0] =  minuslope; nc[u * 4 + 0] = -1; nc[v * 4 + 0] = 0;
	nc[a * 4 + 1] =  minvslope; nc[v * 4 + 1] = -1; nc[u * 4 + 1] = 0;
	nc[a * 4 + 2] = -maxuslope; nc[u * 4 + 2] =  1; nc[v * 4 + 2] = 0;
	nc[a * 4 + 3] = -maxvslope; nc[v * 4 + 3] =  1; nc[u * 4 + 3] = 0;
	if (maxdir) 
	{
		__m128 minus1 = _mm_set_ps1( -1.0f );
		nx4 = _mm_mul_ps( nx4, minus1 ), ny4 = _mm_mul_ps( ny4, minus1 ), nz4 = _mm_mul_ps( nz4, minus1 );
		cdx4 = _mm_mul_ps( cdx4, minus1 ), cdy4 = _mm_mul_ps( cdy4, minus1 ), cdz4 = _mm_mul_ps( cdz4, minus1 );
	}
	// plane origins and signs
	D4 = DOT128( nx4, ny4, nz4, _mm_set_ps1( a_Origin.x ), _mm_set_ps1( a_Origin.y ), _mm_set_ps1( a_Origin.z ) );
	UpdateCornerSigns();
	// build corner rays
	__m128* cdc4 = &cdx4;
	cdc4[a] = _mm_set_ps1( 1.0f );
	cdc4[u] = _mm_set_ps( minuslope, maxuslope, maxuslope, minuslope );
	cdc4[v] = _mm_set_ps( minvslope, minvslope, maxvslope, maxvslope );
}

// -----------------------------------------------------------
// RayPacket::BuildPlanesShadowGeneric
// Construct a frustum for a shadow packet after a bounce
// -----------------------------------------------------------
void RayPacket::BuildPlanesShadowGeneric( const vector3& a_Origin, RayPacket* a_RP )
{
	const uint mod3_1[6] = { 1, 2, 0, 1, 2, 0 };
	const uint mod3_2[6] = { 2, 0, 1, 2, 0, 1 };
	FindDominantAxisGeneric();
	if (maxis < 0) return;
	const sint a = maxis;
	const uint u = mod3_1[a], v = mod3_2[a];
	// find maximum and minimum slopes
	float minuslope = 10000, maxuslope = -10000, minvslope = 10000, maxvslope = -10000;
	float* dcell = reinterpret_cast<float*>(&dx4);
	for ( uint r = 0; r < a_RP->packetq; r++ ) if (reinterpret_cast<unsigned int*>(a_RP->mask4)[r + offset])
	{
		const float da = reinterpret_cast<float*>(rdx4)[a * PACKETSIZE + r + offset];
		const float uslope = dcell[u * PACKETSIZE + r + offset] * da;
		const float vslope = dcell[v * PACKETSIZE + r + offset] * da;
		if (uslope < minuslope) minuslope = uslope;
		if (uslope > maxuslope) maxuslope = uslope;
		if (vslope < minvslope) minvslope = vslope;
		if (vslope > maxvslope) maxvslope = vslope;
	}
	// flip if major dir is negative
	float* nc = reinterpret_cast<float*>(&nx4);
	nc[a * 4 + 0] =  minuslope; nc[u * 4 + 0] = -1; nc[v * 4 + 0] = 0;
	nc[a * 4 + 1] =  minvslope; nc[v * 4 + 1] = -1; nc[u * 4 + 1] = 0;
	nc[a * 4 + 2] = -maxuslope; nc[u * 4 + 2] =  1; nc[v * 4 + 2] = 0;
	nc[a * 4 + 3] = -maxvslope; nc[v * 4 + 3] =  1; nc[u * 4 + 3] = 0;
	if (maxdir) 
	{
		__m128 minus1 = _mm_set_ps1( -1.0f );
		nx4 = _mm_mul_ps( nx4, minus1 ), ny4 = _mm_mul_ps( ny4, minus1 ), nz4 = _mm_mul_ps( nz4, minus1 );
		cdx4 = _mm_mul_ps( cdx4, minus1 ), cdy4 = _mm_mul_ps( cdy4, minus1 ), cdz4 = _mm_mul_ps( cdz4, minus1 );
	}
	// plane origins and signs
	D4 = DOT128( nx4, ny4, nz4, _mm_set_ps1( a_Origin.x ), _mm_set_ps1( a_Origin.y ), _mm_set_ps1( a_Origin.z ) );
	UpdateCornerSigns();
	// build corner rays
	__m128* cdc4 = &cdx4;
	cdc4[a] = _mm_set_ps1( 1.0f );
	cdc4[u] = _mm_set_ps( minuslope, maxuslope, maxuslope, minuslope );
	cdc4[v] = _mm_set_ps( minvslope, minvslope, maxvslope, maxvslope );
}

// -----------------------------------------------------------
// LineTracer::Init
// Initialize worker thread
// -----------------------------------------------------------
void LineTracer::Init( uint thread )
{
	_mm_setcsr( _mm_getcsr() | (1 << 15) | (1 << 6) ); // thanks Ram Nalla
	m_Thread = thread;
	SetThreadIdealProcessor( handle(), m_Thread );
	memcpy( (void*)masktable4, _masktable, 256 );
	const uint offset[16] = { 0, 0, 1, 0, 2, 0, 1, 0, 3, 0, 1, 0, 2, 0, 1, 0 };
	memcpy( m_Offset, offset, 16 * sizeof( uint ) );
}

// -----------------------------------------------------------
// LineTracer::GetColorAtIP
// Determines the color of a pixel at the intersection point
// -----------------------------------------------------------
void LineTracer::GetColorAtIP()
{
	const __m128i iz4 = _mm_set_epi32( 0, 0, 0, 0 );
	const __m128 min32k = _mm_set_ps1( -32767.0f );
	const __m128 div32k = _mm_set_ps1( 1.0f / 32767.0f );
	const __m128i ione4 = _mm_set_epi32( 1, 1, 1, 1 );
	const __m128 scalep4 = _mm_set_ps1( m_SDScale );
	const __m128 scalem4 = _mm_set_ps1( -m_SDScale );
	const sint start = m_RP->offset, end = m_RP->offset + m_RP->packetq;
	sint r = start << 2, i, j;
	for ( i = start; i < end; ++i, r += 4 ) if (_mm_movemask_ps( m_RP->mask4[i] ))
	{
		if ((m_ID->prim[r] == m_ID->prim[r + 1]) && (m_ID->prim[r + 1] == m_ID->prim[r + 2]) &&
			(m_ID->prim[r + 2] == m_ID->prim[r + 3]))
		{
			// four rays hit the same primitive
			const Primitive* p = m_ID->prim[r];
			const Material* m = p->GetMaterial();
			const Texture* t = m->GetTexture();
			if (t)
			{
				// textured primitive
				const float* hdr = t->GetHDRData();
				if (hdr)
				{
					// hdr texture: skybox?
					__m128 u4, v4;
					if (m_ID->prim[r] == m_Dome)
					{
						// yes, skybox, calculate uvs based on directions in packet
						const float* pdz = (float*)&m_RP->dz4[i];
						union { __m128 r4; float r[4]; };
						__m128 piscale = _mm_set_ps1( 1 / PI );
						r[0] = acosf( pdz[0] );
						r[1] = acosf( pdz[1] );
						r[2] = acosf( pdz[2] );
						r[3] = acosf( pdz[3] );
						r4 = _mm_mul_ps( piscale, _mm_mul_ps( r4, fastrsqrt( _mm_add_ps( _mm_mul_ps( m_RP->dx4[i], m_RP->dx4[i] ), _mm_mul_ps( m_RP->dy4[i], m_RP->dy4[i] ) ) ) ) );
						u4 = _mm_mul_ps( _mm_add_ps( _mm_mul_ps( m_RP->dx4[i], r4 ), one ), scalep4 );
						v4 = _mm_mul_ps( _mm_sub_ps( _mm_mul_ps( m_RP->dy4[i], r4 ), one ), scalem4 );
					}
					else
					{
						// not the skybox
						const Vertex* vert0 = p->m_Vertex[0], *vert1 = p->m_Vertex[1], *vert2 = p->m_Vertex[2];
						const float u1 = vert0->GetU(), v1 = vert0->GetV();
						const float u2 = vert1->GetU(), v2 = vert1->GetV();
						const float u3 = vert2->GetU(), v3 = vert2->GetV();
						const __m128 u1_4 = broadcastss( &u1 ), u2_4 = broadcastss( &u2 ), u3_4 = broadcastss( &u3 );
						const __m128 v1_4 = broadcastss( &v1 ), v2_4 = broadcastss( &v2 ), v3_4 = broadcastss( &v3 );
						// start uv calculation
						u4 = _mm_add_ps( u1_4, _mm_add_ps( _mm_mul_ps( m_ID->u4[i], _mm_sub_ps( u2_4, u1_4 ) ), _mm_mul_ps( m_ID->v4[i], _mm_sub_ps( u3_4, u1_4 ) ) ) );
						v4 = _mm_add_ps( v1_4, _mm_add_ps( _mm_mul_ps( m_ID->u4[i], _mm_sub_ps( v2_4, v1_4 ) ), _mm_mul_ps( m_ID->v4[i], _mm_sub_ps( v3_4, v1_4 ) ) ) );
					}
					// start calculation of int coords of texels
					const __m128i iu4 = _mm_cvttps_epi32( u4 ), iv4 = _mm_cvttps_epi32( v4 );
					const __m128i itu1_4 = _mm_and_si128( iu4, t->m_HMask4 ), itv1_4 = _mm_and_si128( iv4, t->m_VMask4 );
					const __m128i itu2_4 = _mm_and_si128( _mm_add_epi32( itu1_4, ione4 ), t->m_HMask4 );
					const __m128i itv2_4 = _mm_and_si128( _mm_add_epi32( itv1_4, ione4 ), t->m_VMask4 );
					const int* tu1 = (int*)&itu1_4, *tv1 = (int*)&itv1_4, *tu2 = (int*)&itu2_4, *tv2 = (int*)&itv2_4;
					// calculate fractional bits
					const __m128 fracu4 = _mm_sub_ps( u4, _mm_cvtepi32_ps( iu4 ) );
					const __m128 fracv4 = _mm_sub_ps( v4, _mm_cvtepi32_ps( iv4 ) );
					// get the first pixels ahead
					const uint shft = t->m_HShift;
					const __m128 wa4 = _mm_sub_ps( one, fracv4 ), wb4 = _mm_sub_ps( one, fracu4 );
					const float* fracu = (float*)&fracu4, *fracv = (float*)&fracv4;
					const float* wa = (float*)&wa4, *wb = (float*)&wb4;
					// fetch data
					const __m128 rrrr1 = _mm_set_ps( t->m_HDR[(tu2[3] + (tv2[3] << shft)) * 3 + 0], t->m_HDR[(tu2[2] + (tv2[2] << shft)) * 3 + 0],
													 t->m_HDR[(tu2[1] + (tv2[1] << shft)) * 3 + 0], t->m_HDR[(tu2[0] + (tv2[0] << shft)) * 3 + 0] );
					const __m128 gggg1 = _mm_set_ps( t->m_HDR[(tu2[3] + (tv2[3] << shft)) * 3 + 1], t->m_HDR[(tu2[2] + (tv2[2] << shft)) * 3 + 1],
													 t->m_HDR[(tu2[1] + (tv2[1] << shft)) * 3 + 1], t->m_HDR[(tu2[0] + (tv2[0] << shft)) * 3 + 1] );
					const __m128 bbbb1 = _mm_set_ps( t->m_HDR[(tu2[3] + (tv2[3] << shft)) * 3 + 2], t->m_HDR[(tu2[2] + (tv2[2] << shft)) * 3 + 2],
													 t->m_HDR[(tu2[1] + (tv2[1] << shft)) * 3 + 2], t->m_HDR[(tu2[0] + (tv2[0] << shft)) * 3 + 2] );
					const __m128 rrrr2 = _mm_set_ps( t->m_HDR[(tu1[3] + (tv2[3] << shft)) * 3 + 0], t->m_HDR[(tu1[2] + (tv2[2] << shft)) * 3 + 0],
													 t->m_HDR[(tu1[1] + (tv2[1] << shft)) * 3 + 0], t->m_HDR[(tu1[0] + (tv2[0] << shft)) * 3 + 0] );
					const __m128 gggg2 = _mm_set_ps( t->m_HDR[(tu1[3] + (tv2[3] << shft)) * 3 + 1], t->m_HDR[(tu1[2] + (tv2[2] << shft)) * 3 + 1],
													 t->m_HDR[(tu1[1] + (tv2[1] << shft)) * 3 + 1], t->m_HDR[(tu1[0] + (tv2[0] << shft)) * 3 + 1] );
					const __m128 bbbb2 = _mm_set_ps( t->m_HDR[(tu1[3] + (tv2[3] << shft)) * 3 + 2], t->m_HDR[(tu1[2] + (tv2[2] << shft)) * 3 + 2],
													 t->m_HDR[(tu1[1] + (tv2[1] << shft)) * 3 + 2], t->m_HDR[(tu1[0] + (tv2[0] << shft)) * 3 + 2] );
					const __m128 rrrr3 = _mm_set_ps( t->m_HDR[(tu2[3] + (tv1[3] << shft)) * 3 + 0], t->m_HDR[(tu2[2] + (tv1[2] << shft)) * 3 + 0],
													 t->m_HDR[(tu2[1] + (tv1[1] << shft)) * 3 + 0], t->m_HDR[(tu2[0] + (tv1[0] << shft)) * 3 + 0] );
					const __m128 gggg3 = _mm_set_ps( t->m_HDR[(tu2[3] + (tv1[3] << shft)) * 3 + 1], t->m_HDR[(tu2[2] + (tv1[2] << shft)) * 3 + 1],
													 t->m_HDR[(tu2[1] + (tv1[1] << shft)) * 3 + 1], t->m_HDR[(tu2[0] + (tv1[0] << shft)) * 3 + 1] );
					const __m128 bbbb3 = _mm_set_ps( t->m_HDR[(tu2[3] + (tv1[3] << shft)) * 3 + 2], t->m_HDR[(tu2[2] + (tv1[2] << shft)) * 3 + 2],
													 t->m_HDR[(tu2[1] + (tv1[1] << shft)) * 3 + 2], t->m_HDR[(tu2[0] + (tv1[0] << shft)) * 3 + 2] );
					const __m128 rrrr4 = _mm_set_ps( t->m_HDR[(tu1[3] + (tv1[3] << shft)) * 3 + 0], t->m_HDR[(tu1[2] + (tv1[2] << shft)) * 3 + 0],
													 t->m_HDR[(tu1[1] + (tv1[1] << shft)) * 3 + 0], t->m_HDR[(tu1[0] + (tv1[0] << shft)) * 3 + 0] );
					const __m128 gggg4 = _mm_set_ps( t->m_HDR[(tu1[3] + (tv1[3] << shft)) * 3 + 1], t->m_HDR[(tu1[2] + (tv1[2] << shft)) * 3 + 1],
													 t->m_HDR[(tu1[1] + (tv1[1] << shft)) * 3 + 1], t->m_HDR[(tu1[0] + (tv1[0] << shft)) * 3 + 1] );
					const __m128 bbbb4 = _mm_set_ps( t->m_HDR[(tu1[3] + (tv1[3] << shft)) * 3 + 2], t->m_HDR[(tu1[2] + (tv1[2] << shft)) * 3 + 2],
													 t->m_HDR[(tu1[1] + (tv1[1] << shft)) * 3 + 2], t->m_HDR[(tu1[0] + (tv1[0] << shft)) * 3 + 2] );
					// bilinear filtering on color data
					const __m128 w4 = _mm_mul_ps( _mm_sub_ps( one, fracu4 ), _mm_sub_ps( one, fracv4 ) );
					const __m128 w3 = _mm_mul_ps( fracu4, _mm_sub_ps( one, fracv4 ) );
					const __m128 w2 = _mm_mul_ps( _mm_sub_ps( one, fracu4 ), fracv4 );
					const __m128 w1 = _mm_mul_ps( fracu4, fracv4 );
					// store data
					m_ID->colip[r + 0].rgba = _mm_add_ps( _mm_add_ps( _mm_mul_ps( rrrr1, w1 ), _mm_mul_ps( rrrr2, w2 ) ),
											  _mm_add_ps( _mm_mul_ps( rrrr3, w3 ), _mm_mul_ps( rrrr4, w4 ) ) );
					m_ID->colip[r + 1].rgba = _mm_add_ps( _mm_add_ps( _mm_mul_ps( gggg1, w1 ), _mm_mul_ps( gggg2, w2 ) ),
											  _mm_add_ps( _mm_mul_ps( gggg3, w3 ), _mm_mul_ps( gggg4, w4 ) ) );
					m_ID->colip[r + 2].rgba = _mm_add_ps( _mm_add_ps( _mm_mul_ps( bbbb1, w1 ), _mm_mul_ps( bbbb2, w2 ) ),
											  _mm_add_ps( _mm_mul_ps( bbbb3, w3 ), _mm_mul_ps( bbbb4, w4 ) ) );
				}
				else
				{
					const Texture* b = m->GetBumpMap();
					if (b)
					{
						// texture + normalmap
						const Vertex* vert0 = p->m_Vertex[0], *vert1 = p->m_Vertex[1], *vert2 = p->m_Vertex[2];
						const float u1 = vert0->GetU(), v1 = vert0->GetV();
						const float u2 = vert1->GetU(), v2 = vert1->GetV();
						const float u3 = vert2->GetU(), v3 = vert2->GetV();
						const __m128 u1_4 = broadcastss( &u1 ), u2_4 = broadcastss( &u2 ), u3_4 = broadcastss( &u3 );
						const __m128 v1_4 = broadcastss( &v1 ), v2_4 = broadcastss( &v2 ), v3_4 = broadcastss( &v3 );
						// start uv calculation
						const __m128 u4 = _mm_add_ps( u1_4, _mm_add_ps( _mm_mul_ps( m_ID->u4[i], _mm_sub_ps( u2_4, u1_4 ) ), _mm_mul_ps( m_ID->v4[i], _mm_sub_ps( u3_4, u1_4 ) ) ) );
						const __m128 v4 = _mm_add_ps( v1_4, _mm_add_ps( _mm_mul_ps( m_ID->u4[i], _mm_sub_ps( v2_4, v1_4 ) ), _mm_mul_ps( m_ID->v4[i], _mm_sub_ps( v3_4, v1_4 ) ) ) );
						// start calculation of int coords of texels
						const __m128i iu4 = _mm_cvttps_epi32( u4 ), iv4 = _mm_cvttps_epi32( v4 );
						const __m128i itu1_4 = _mm_and_si128( iu4, t->m_HMask4 ), itv1_4 = _mm_and_si128( iv4, t->m_VMask4 );
						const __m128i itu2_4 = _mm_and_si128( _mm_add_epi32( itu1_4, ione4 ), t->m_HMask4 );
						const __m128i itv2_4 = _mm_and_si128( _mm_add_epi32( itv1_4, ione4 ), t->m_VMask4 );
						const int* tu1 = (int*)&itu1_4, *tv1 = (int*)&itv1_4, *tu2 = (int*)&itu2_4, *tv2 = (int*)&itv2_4;
						// calculate fractional bits
						const __m128 fracu4 = _mm_sub_ps( u4, _mm_cvtepi32_ps( iu4 ) );
						const __m128 fracv4 = _mm_sub_ps( v4, _mm_cvtepi32_ps( iv4 ) );
						// get the first pixels ahead
						const uint shft = t->m_HShift;
						const __m128 wa4 = _mm_sub_ps( one, fracv4 ), wb4 = _mm_sub_ps( one, fracu4 );
						const float* fracu = (float*)&fracu4, *fracv = (float*)&fracv4;
						const float* wa = (float*)&wa4, *wb = (float*)&wb4;
						// fetch data
						const __m128i pixel1 = _mm_set_epi32( t->m_TN32[tu2[0] * 2 + (tv2[0] << shft)], t->m_TN32[tu1[0] * 2 + (tv2[0] << shft)],
															  t->m_TN32[tu2[0] * 2 + (tv1[0] << shft)], t->m_TN32[tu1[0] * 2 + (tv1[0] << shft)] );
						const __m128i pixel2 = _mm_set_epi32( t->m_TN32[tu2[1] * 2 + (tv2[1] << shft)], t->m_TN32[tu1[1] * 2 + (tv2[1] << shft)],
															  t->m_TN32[tu2[1] * 2 + (tv1[1] << shft)], t->m_TN32[tu1[1] * 2 + (tv1[1] << shft)] );
						const __m128i pixel3 = _mm_set_epi32( t->m_TN32[tu2[2] * 2 + (tv2[2] << shft)], t->m_TN32[tu1[2] * 2 + (tv2[2] << shft)],
															  t->m_TN32[tu2[2] * 2 + (tv1[2] << shft)], t->m_TN32[tu1[2] * 2 + (tv1[2] << shft)] );
						const __m128i pixel4 = _mm_set_epi32( t->m_TN32[tu2[3] * 2 + (tv2[3] << shft)], t->m_TN32[tu1[3] * 2 + (tv2[3] << shft)],
															  t->m_TN32[tu2[3] * 2 + (tv1[3] << shft)], t->m_TN32[tu1[3] * 2 + (tv1[3] << shft)] );
						// format conversion
						const __m128i temp1a = _mm_unpacklo_epi8( pixel1, pixel2 ), temp1b = _mm_unpackhi_epi8( pixel1, pixel2 );
						const __m128i temp2a = _mm_unpacklo_epi8( pixel3, pixel4 ), temp2b = _mm_unpackhi_epi8( pixel3, pixel4 );
						const __m128i temp3a = _mm_unpacklo_epi16( temp1a, temp2a ), temp3b = _mm_unpackhi_epi16( temp1a, temp2a );
						const __m128i temp4a = _mm_unpacklo_epi16( temp1b, temp2b ), temp4b = _mm_unpackhi_epi16( temp1b, temp2b );
						// data is now in aaaa, rrrr, gggg, bbbb format but still in 8bit per component
						const __m128i temp5a = _mm_unpacklo_epi8( temp3a, iz4 ), temp5b = _mm_unpackhi_epi8( temp3a, iz4 );
						const __m128i temp6a = _mm_unpacklo_epi8( temp3b, iz4 ), temp6b = _mm_unpackhi_epi8( temp3b, iz4 );
						const __m128i temp7a = _mm_unpacklo_epi8( temp4a, iz4 ), temp7b = _mm_unpackhi_epi8( temp4a, iz4 );
						const __m128i temp8a = _mm_unpacklo_epi8( temp4b, iz4 ), temp8b = _mm_unpackhi_epi8( temp4b, iz4 );
						// convert data to final floating point representation
						const __m128 pixel1r = _mm_cvtepi32_ps( _mm_unpacklo_epi16( temp8b, iz4 ) ); // RRRR for W1
						const __m128 pixel1g = _mm_cvtepi32_ps( _mm_unpackhi_epi16( temp8a, iz4 ) ); // GGGG for W1
						const __m128 pixel1b = _mm_cvtepi32_ps( _mm_unpacklo_epi16( temp8a, iz4 ) ); // BBBB for W1
						const __m128 pixel2r = _mm_cvtepi32_ps( _mm_unpacklo_epi16( temp7b, iz4 ) ); // RRRR for W2
						const __m128 pixel2g = _mm_cvtepi32_ps( _mm_unpackhi_epi16( temp7a, iz4 ) ); // GGGG for W2
						const __m128 pixel2b = _mm_cvtepi32_ps( _mm_unpacklo_epi16( temp7a, iz4 ) ); // BBBB for W2
						const __m128 pixel3r = _mm_cvtepi32_ps( _mm_unpacklo_epi16( temp6b, iz4 ) ); // RRRR for W3
						const __m128 pixel3g = _mm_cvtepi32_ps( _mm_unpackhi_epi16( temp6a, iz4 ) ); // GGGG for W3
						const __m128 pixel3b = _mm_cvtepi32_ps( _mm_unpacklo_epi16( temp6a, iz4 ) ); // BBBB for W3
						const __m128 pixel4r = _mm_cvtepi32_ps( _mm_unpacklo_epi16( temp5b, iz4 ) ); // RRRR for W4
						const __m128 pixel4g = _mm_cvtepi32_ps( _mm_unpackhi_epi16( temp5a, iz4 ) ); // GGGG for W4
						const __m128 pixel4b = _mm_cvtepi32_ps( _mm_unpacklo_epi16( temp5a, iz4 ) ); // BBBB for W4
					#ifdef ALPHABLENDING
						const __m128 pixel1a = _mm_cvtepi32_ps( _mm_unpackhi_epi16( temp8b, iz4 ) ); // AAAA for W1
						const __m128 pixel2a = _mm_cvtepi32_ps( _mm_unpackhi_epi16( temp7b, iz4 ) ); // AAAA for W2
						const __m128 pixel3a = _mm_cvtepi32_ps( _mm_unpackhi_epi16( temp6b, iz4 ) ); // AAAA for W2
						const __m128 pixel4a = _mm_cvtepi32_ps( _mm_unpackhi_epi16( temp5b, iz4 ) ); // AAAA for W2
					#endif
						// bilinear filtering on color data
						const __m128 w4 = _mm_mul_ps( _mm_sub_ps( one, fracu4 ), _mm_sub_ps( one, fracv4 ) );
						const __m128 w3 = _mm_mul_ps( fracu4, _mm_sub_ps( one, fracv4 ) );
						const __m128 w2 = _mm_mul_ps( _mm_sub_ps( one, fracu4 ), fracv4 );
						const __m128 w1 = _mm_mul_ps( fracu4, fracv4 );
						// store color data for shading
						m_ID->colip[r + 0].rgba = _mm_add_ps( _mm_add_ps( _mm_mul_ps( pixel1r, w1 ), _mm_mul_ps( pixel2r, w2 ) ),
												  _mm_add_ps( _mm_mul_ps( pixel3r, w3 ), _mm_mul_ps( pixel4r, w4 ) ) );
						m_ID->colip[r + 1].rgba = _mm_add_ps( _mm_add_ps( _mm_mul_ps( pixel1g, w1 ), _mm_mul_ps( pixel2g, w2 ) ),
												  _mm_add_ps( _mm_mul_ps( pixel3g, w3 ), _mm_mul_ps( pixel4g, w4 ) ) );
						m_ID->colip[r + 2].rgba = _mm_add_ps( _mm_add_ps( _mm_mul_ps( pixel1b, w1 ), _mm_mul_ps( pixel2b, w2 ) ),
												  _mm_add_ps( _mm_mul_ps( pixel3b, w3 ), _mm_mul_ps( pixel4b, w4 ) ) );
					#ifdef ALPHABLENDING
						m_ID->colip[r + 3].rgba = _mm_add_ps( _mm_add_ps( _mm_mul_ps( pixel1a, w1 ), _mm_mul_ps( pixel2a, w2 ) ),
												  _mm_add_ps( _mm_mul_ps( pixel3a, w3 ), _mm_mul_ps( pixel4a, w4 ) ) );
					#endif					
						// normal mapping						  
						const __m128i pixel8 = _mm_set_epi32( t->m_TN32[tu1[0] * 2 + 1 + (tv1[0] << shft)], t->m_TN32[tu1[1] * 2 + 1 + (tv1[1] << shft)],
															  t->m_TN32[tu1[2] * 2 + 1 + (tv1[2] << shft)], t->m_TN32[tu1[3] * 2 + 1 + (tv1[3] << shft)] );
						const __m128i pixel7 = _mm_set_epi32( t->m_TN32[tu2[0] * 2 + 1 + (tv1[0] << shft)], t->m_TN32[tu2[1] * 2 + 1 + (tv1[1] << shft)],
															  t->m_TN32[tu2[2] * 2 + 1 + (tv1[2] << shft)], t->m_TN32[tu2[3] * 2 + 1 + (tv1[3] << shft)] );
						const __m128i pixel6 = _mm_set_epi32( t->m_TN32[tu1[0] * 2 + 1 + (tv2[0] << shft)], t->m_TN32[tu1[1] * 2 + 1 + (tv2[1] << shft)],
															  t->m_TN32[tu1[2] * 2 + 1 + (tv2[2] << shft)], t->m_TN32[tu1[3] * 2 + 1 + (tv2[3] << shft)] );
						const __m128i pixel5 = _mm_set_epi32( t->m_TN32[tu2[0] * 2 + 1 + (tv2[0] << shft)], t->m_TN32[tu2[1] * 2 + 1 + (tv2[1] << shft)],
															  t->m_TN32[tu2[2] * 2 + 1 + (tv2[2] << shft)], t->m_TN32[tu2[3] * 2 + 1 + (tv2[3] << shft)] );
						// determine bcc0_1 through bcc4_2
						const __m128i sf1n = _mm_shufflelo_epi16( _mm_shufflehi_epi16( pixel8, 141 ), 141 );
						const __m128 v1n = _mm_cvtepi32_ps( _mm_unpackhi_epi16( sf1n, iz4 ) );
						const __m128 v2n = _mm_cvtepi32_ps( _mm_unpacklo_epi16( sf1n, iz4 ) );
						const __m128 bcc1_1 = _mm_shuffle_ps( v1n, v2n, 17 ), bcc1_2 = _mm_shuffle_ps( v1n, v2n, 187 );
						const __m128i sf2n = _mm_shufflelo_epi16( _mm_shufflehi_epi16( pixel7, 141 ), 141 );
						const __m128 v3n = _mm_cvtepi32_ps( _mm_unpackhi_epi16( sf2n, iz4 ) );
						const __m128 v4n = _mm_cvtepi32_ps( _mm_unpacklo_epi16( sf2n, iz4 ) );
						const __m128 bcc2_1 = _mm_shuffle_ps( v3n, v4n, 17 ), bcc2_2 = _mm_shuffle_ps( v3n, v4n, 187 );
						const __m128i sf3n = _mm_shufflelo_epi16( _mm_shufflehi_epi16( pixel6, 141 ), 141 );
						const __m128 v5n = _mm_cvtepi32_ps( _mm_unpackhi_epi16( sf3n, iz4 ) );
						const __m128 v6n = _mm_cvtepi32_ps( _mm_unpacklo_epi16( sf3n, iz4 ) );
						const __m128 bcc3_1 = _mm_shuffle_ps( v5n, v6n, 17 ), bcc3_2 = _mm_shuffle_ps( v5n, v6n, 187 );
						const __m128i sf4n = _mm_shufflelo_epi16( _mm_shufflehi_epi16( pixel5, 141 ), 141 );
						const __m128 v7n = _mm_cvtepi32_ps( _mm_unpackhi_epi16( sf4n, iz4 ) );
						const __m128 v8n = _mm_cvtepi32_ps( _mm_unpacklo_epi16( sf4n, iz4 ) );
						const __m128 bcc4_1 = _mm_shuffle_ps( v7n, v8n, 17 ), bcc4_2 = _mm_shuffle_ps( v7n, v8n, 187 );
						PREFETCH( &m_ID->N4[r] );
						const __m128 vx = _mm_mul_ps( div32k, _mm_add_ps( min32k, _mm_add_ps( _mm_mul_ps( wa4, _mm_add_ps( 
										  _mm_mul_ps( wb4, bcc1_2 ), _mm_mul_ps( fracu4, bcc2_2 ) ) ),
										  _mm_mul_ps( fracv4, _mm_add_ps( _mm_mul_ps( wb4, bcc3_2 ), _mm_mul_ps( fracu4, bcc4_2 ) ) ) ) ) );
						const __m128 vz = _mm_mul_ps( div32k, _mm_add_ps( min32k, _mm_add_ps( _mm_mul_ps( wa4, _mm_add_ps( 
										  _mm_mul_ps( wb4, bcc1_1 ), _mm_mul_ps( fracu4, bcc2_1 ) ) ),
										  _mm_mul_ps( fracv4, _mm_add_ps( _mm_mul_ps( wb4, bcc3_1 ), _mm_mul_ps( fracu4, bcc4_1 ) ) ) ) ) );
					#ifdef INTERPNORMALS
						const vector3 N1 = p->m_Vertex[0]->GetNormal(), N2 = p->m_Vertex[1]->GetNormal(), N3 = p->m_Vertex[2]->GetNormal();
						const __m128 N1x = _mm_set_ps1( N1.x ), N1y = _mm_set_ps1( N1.y ), N1z = _mm_set_ps1( N1.z );
						const __m128 N2x = _mm_set_ps1( N2.x ), N2y = _mm_set_ps1( N2.y ), N2z = _mm_set_ps1( N2.z );
						const __m128 N3x = _mm_set_ps1( N3.x ), N3y = _mm_set_ps1( N3.y ), N3z = _mm_set_ps1( N3.z );
						const __m128 Nx = _mm_add_ps( N1x, _mm_add_ps( _mm_mul_ps( m_ID->u4[i], _mm_sub_ps( N2x, N1x ) ), 
										  _mm_mul_ps( m_ID->v4[i], _mm_sub_ps( N3x, N1x ) ) ) );
						const __m128 Ny = _mm_add_ps( N1y, _mm_add_ps( _mm_mul_ps( m_ID->u4[i], _mm_sub_ps( N2y, N1y ) ), 
										  _mm_mul_ps( m_ID->v4[i], _mm_sub_ps( N3y, N1y ) ) ) );
						const __m128 Nz = _mm_add_ps( N1z, _mm_add_ps( _mm_mul_ps( m_ID->u4[i], _mm_sub_ps( N2z, N1z ) ), 
										  _mm_mul_ps( m_ID->v4[i], _mm_sub_ps( N3z, N1z ) ) ) );
					#else				
						const __m128 Nx = _mm_set_ps1( p->m_N.x );
						const __m128 Ny = _mm_set_ps1( p->m_N.y );
						const __m128 Nz = _mm_set_ps1( p->m_N.z );
					#endif
					#ifdef PHOTONMAPPING
						m_ID->PN4[r + 0] = Nx;
						m_ID->PN4[r + 1] = Ny;
						m_ID->PN4[r + 2] = Nz;
					#endif
						const __m128 tx = _mm_add_ps( _mm_add_ps( Nx, _mm_mul_ps( _mm_set_ps1( p->m_T.x ), vx ) ),
										  _mm_mul_ps( _mm_set_ps1( p->m_B.x ), vz ) );
						const __m128 ty = _mm_add_ps( _mm_add_ps( Ny, _mm_mul_ps( _mm_set_ps1( p->m_T.y ), vx ) ),
										  _mm_mul_ps( _mm_set_ps1( p->m_B.y ), vz ) );
						const __m128 tz = _mm_add_ps( _mm_add_ps( Nz, _mm_mul_ps( _mm_set_ps1( p->m_T.z ), vx ) ),
										  _mm_mul_ps( _mm_set_ps1( p->m_B.z ), vz ) );
						__m128 ilen4 = _mm_rsqrt_ps( DOT128( tx, ty, tz, tx, ty, tz ) );
						m_ID->N4[r + 0] = _mm_mul_ps( tx, ilen4 );
						m_ID->N4[r + 1] = _mm_mul_ps( ty, ilen4 );
						m_ID->N4[r + 2] = _mm_mul_ps( tz, ilen4 );
					}
					else
					{
						// texture without normal map
						const Vertex* vert0 = p->m_Vertex[0], *vert1 = p->m_Vertex[1], *vert2 = p->m_Vertex[2];
						const float u1 = vert0->GetU(), v1 = vert0->GetV();
						const float u2 = vert1->GetU(), v2 = vert1->GetV();
						const float u3 = vert2->GetU(), v3 = vert2->GetV();
						const __m128 u1_4 = broadcastss( &u1 ), u2_4 = broadcastss( &u2 ), u3_4 = broadcastss( &u3 );
						const __m128 v1_4 = broadcastss( &v1 ), v2_4 = broadcastss( &v2 ), v3_4 = broadcastss( &v3 );
						// start uv calculation
						const __m128 u4 = _mm_add_ps( u1_4, _mm_add_ps( _mm_mul_ps( m_ID->u4[i], _mm_sub_ps( u2_4, u1_4 ) ), _mm_mul_ps( m_ID->v4[i], _mm_sub_ps( u3_4, u1_4 ) ) ) );
						const __m128 v4 = _mm_add_ps( v1_4, _mm_add_ps( _mm_mul_ps( m_ID->u4[i], _mm_sub_ps( v2_4, v1_4 ) ), _mm_mul_ps( m_ID->v4[i], _mm_sub_ps( v3_4, v1_4 ) ) ) );
						// start calculation of int coords of texels
						const __m128i iu4 = _mm_cvttps_epi32( u4 ), iv4 = _mm_cvttps_epi32( v4 );
						const __m128i itu1_4 = _mm_and_si128( iu4, t->m_HMask4 ), itv1_4 = _mm_and_si128( iv4, t->m_VMask4 );
						const __m128i itu2_4 = _mm_and_si128( _mm_add_epi32( itu1_4, ione4 ), t->m_HMask4 );
						const __m128i itv2_4 = _mm_and_si128( _mm_add_epi32( itv1_4, ione4 ), t->m_VMask4 );
						const int* tu1 = (int*)&itu1_4, *tv1 = (int*)&itv1_4, *tu2 = (int*)&itu2_4, *tv2 = (int*)&itv2_4;
						// calculate fractional bits
						const __m128 fracu4 = _mm_sub_ps( u4, _mm_cvtepi32_ps( iu4 ) );
						const __m128 fracv4 = _mm_sub_ps( v4, _mm_cvtepi32_ps( iv4 ) );
						const uint shft = t->m_HShift;
						// fetch data
						const __m128i pixel1 = _mm_set_epi32( t->m_B32[tu2[0] + (tv2[0] << shft)], t->m_B32[tu1[0] + (tv2[0] << shft)],
															  t->m_B32[tu2[0] + (tv1[0] << shft)], t->m_B32[tu1[0] + (tv1[0] << shft)] );
						const __m128i pixel2 = _mm_set_epi32( t->m_B32[tu2[1] + (tv2[1] << shft)], t->m_B32[tu1[1] + (tv2[1] << shft)],
															  t->m_B32[tu2[1] + (tv1[1] << shft)], t->m_B32[tu1[1] + (tv1[1] << shft)] );
						const __m128i pixel3 = _mm_set_epi32( t->m_B32[tu2[2] + (tv2[2] << shft)], t->m_B32[tu1[2] + (tv2[2] << shft)],
															  t->m_B32[tu2[2] + (tv1[2] << shft)], t->m_B32[tu1[2] + (tv1[2] << shft)] );
						const __m128i pixel4 = _mm_set_epi32( t->m_B32[tu2[3] + (tv2[3] << shft)], t->m_B32[tu1[3] + (tv2[3] << shft)],
															  t->m_B32[tu2[3] + (tv1[3] << shft)], t->m_B32[tu1[3] + (tv1[3] << shft)] );
						// format conversion
						const __m128i temp1a = _mm_unpacklo_epi8( pixel1, pixel2 ), temp1b = _mm_unpackhi_epi8( pixel1, pixel2 );
						const __m128i temp2a = _mm_unpacklo_epi8( pixel3, pixel4 ), temp2b = _mm_unpackhi_epi8( pixel3, pixel4 );
						const __m128i temp3a = _mm_unpacklo_epi16( temp1a, temp2a ), temp3b = _mm_unpackhi_epi16( temp1a, temp2a );
						const __m128i temp4a = _mm_unpacklo_epi16( temp1b, temp2b ), temp4b = _mm_unpackhi_epi16( temp1b, temp2b );
						// data is now in aaaa, rrrr, gggg, bbbb format but still in 8bit per component
						const __m128i temp5a = _mm_unpacklo_epi8( temp3a, iz4 ), temp5b = _mm_unpackhi_epi8( temp3a, iz4 );
						const __m128i temp6a = _mm_unpacklo_epi8( temp3b, iz4 ), temp6b = _mm_unpackhi_epi8( temp3b, iz4 );
						const __m128i temp7a = _mm_unpacklo_epi8( temp4a, iz4 ), temp7b = _mm_unpackhi_epi8( temp4a, iz4 );
						const __m128i temp8a = _mm_unpacklo_epi8( temp4b, iz4 ), temp8b = _mm_unpackhi_epi8( temp4b, iz4 );
						// convert data to final floating point representation
						const __m128 pixel1r = _mm_cvtepi32_ps( _mm_unpacklo_epi16( temp8b, iz4 ) ); // RRRR for W1
						const __m128 pixel1g = _mm_cvtepi32_ps( _mm_unpackhi_epi16( temp8a, iz4 ) ); // GGGG for W1
						const __m128 pixel1b = _mm_cvtepi32_ps( _mm_unpacklo_epi16( temp8a, iz4 ) ); // BBBB for W1
						const __m128 pixel2r = _mm_cvtepi32_ps( _mm_unpacklo_epi16( temp7b, iz4 ) ); // RRRR for W2
						const __m128 pixel2g = _mm_cvtepi32_ps( _mm_unpackhi_epi16( temp7a, iz4 ) ); // GGGG for W2
						const __m128 pixel2b = _mm_cvtepi32_ps( _mm_unpacklo_epi16( temp7a, iz4 ) ); // BBBB for W2
						const __m128 pixel3r = _mm_cvtepi32_ps( _mm_unpacklo_epi16( temp6b, iz4 ) ); // RRRR for W3
						const __m128 pixel3g = _mm_cvtepi32_ps( _mm_unpackhi_epi16( temp6a, iz4 ) ); // GGGG for W3
						const __m128 pixel3b = _mm_cvtepi32_ps( _mm_unpacklo_epi16( temp6a, iz4 ) ); // BBBB for W3
						const __m128 pixel4r = _mm_cvtepi32_ps( _mm_unpacklo_epi16( temp5b, iz4 ) ); // RRRR for W4
						const __m128 pixel4g = _mm_cvtepi32_ps( _mm_unpackhi_epi16( temp5a, iz4 ) ); // GGGG for W4
						const __m128 pixel4b = _mm_cvtepi32_ps( _mm_unpacklo_epi16( temp5a, iz4 ) ); // BBBB for W4
					#ifdef ALPHABLENDING
						const __m128 pixel1a = _mm_cvtepi32_ps( _mm_unpackhi_epi16( temp8b, iz4 ) ); // AAAA for W1
						const __m128 pixel2a = _mm_cvtepi32_ps( _mm_unpackhi_epi16( temp7b, iz4 ) ); // AAAA for W2
						const __m128 pixel3a = _mm_cvtepi32_ps( _mm_unpackhi_epi16( temp6b, iz4 ) ); // AAAA for W2
						const __m128 pixel4a = _mm_cvtepi32_ps( _mm_unpackhi_epi16( temp5b, iz4 ) ); // AAAA for W2
					#endif
						// bilinear filtering on integer data
						const __m128 w4 = _mm_mul_ps( _mm_sub_ps( one, fracu4 ), _mm_sub_ps( one, fracv4 ) );
						const __m128 w3 = _mm_mul_ps( fracu4, _mm_sub_ps( one, fracv4 ) );
						const __m128 w2 = _mm_mul_ps( _mm_sub_ps( one, fracu4 ), fracv4 );
						const __m128 w1 = _mm_mul_ps( fracu4, fracv4 );
						// store integer color data for shading
						m_ID->colip[r + 0].rgba = _mm_add_ps( _mm_add_ps( _mm_mul_ps( pixel1r, w1 ), _mm_mul_ps( pixel2r, w2 ) ),
												  _mm_add_ps( _mm_mul_ps( pixel3r, w3 ), _mm_mul_ps( pixel4r, w4 ) ) );
						m_ID->colip[r + 1].rgba = _mm_add_ps( _mm_add_ps( _mm_mul_ps( pixel1g, w1 ), _mm_mul_ps( pixel2g, w2 ) ),
												  _mm_add_ps( _mm_mul_ps( pixel3g, w3 ), _mm_mul_ps( pixel4g, w4 ) ) );
						m_ID->colip[r + 2].rgba = _mm_add_ps( _mm_add_ps( _mm_mul_ps( pixel1b, w1 ), _mm_mul_ps( pixel2b, w2 ) ),
												  _mm_add_ps( _mm_mul_ps( pixel3b, w3 ), _mm_mul_ps( pixel4b, w4 ) ) );
					#ifdef ALPHABLENDING
						m_ID->colip[r + 3].rgba = _mm_add_ps( _mm_add_ps( _mm_mul_ps( pixel1a, w1 ), _mm_mul_ps( pixel2a, w2 ) ),
												  _mm_add_ps( _mm_mul_ps( pixel3a, w3 ), _mm_mul_ps( pixel4a, w4 ) ) );
					#endif					
					#ifndef INTERPNORMALS
						const vector3 N = p->m_N;
						m_ID->N4[r + 0] = _mm_set_ps1( N.x );
						m_ID->N4[r + 1] = _mm_set_ps1( N.y );
						m_ID->N4[r + 2] = _mm_set_ps1( N.z );
					#else
						const vector3 N1 = p->m_Vertex[0]->GetNormal(), N2 = p->m_Vertex[1]->GetNormal(), N3 = p->m_Vertex[2]->GetNormal();
						const __m128 N1x = _mm_set_ps1( N1.x ), N1y = _mm_set_ps1( N1.y ), N1z = _mm_set_ps1( N1.z );
						const __m128 N2x = _mm_set_ps1( N2.x ), N2y = _mm_set_ps1( N2.y ), N2z = _mm_set_ps1( N2.z );
						const __m128 N3x = _mm_set_ps1( N3.x ), N3y = _mm_set_ps1( N3.y ), N3z = _mm_set_ps1( N3.z );
						m_ID->N4[r + 0] = _mm_add_ps( N1x, _mm_add_ps( _mm_mul_ps( m_ID->u4[i], _mm_sub_ps( N2x, N1x ) ), 
										  _mm_mul_ps( m_ID->v4[i], _mm_sub_ps( N3x, N1x ) ) ) );
						m_ID->N4[r + 1] = _mm_add_ps( N1y, _mm_add_ps( _mm_mul_ps( m_ID->u4[i], _mm_sub_ps( N2y, N1y ) ), 
										  _mm_mul_ps( m_ID->v4[i], _mm_sub_ps( N3y, N1y ) ) ) );
						m_ID->N4[r + 2] = _mm_add_ps( N1z, _mm_add_ps( _mm_mul_ps( m_ID->u4[i], _mm_sub_ps( N2z, N1z ) ), 
										  _mm_mul_ps( m_ID->v4[i], _mm_sub_ps( N3z, N1z ) ) ) );
					#endif
					#ifdef PHOTONMAPPING
						m_ID->PN4[r + 0] = m_ID->N4[r + 0];
						m_ID->PN4[r + 1] = m_ID->N4[r + 1];
						m_ID->PN4[r + 2] = m_ID->N4[r + 2];
					#endif
					}
				}
			}
			else 
			{
				// untextured
			#ifndef INTERPNORMALS
				const vector3 N = p->m_N;
				m_ID->N4[r + 0] = _mm_set_ps1( N.x );
				m_ID->N4[r + 1] = _mm_set_ps1( N.y );
				m_ID->N4[r + 2] = _mm_set_ps1( N.z );
			#else
			#ifdef SUPPORTSPHERES
				if (p->GetType() == Primitive::PRIM_SPHERE)
				{
					const __m128 cx4 = _mm_set_ps1( p->m_N.x );
					const __m128 cy4 = _mm_set_ps1( p->m_N.y );
					const __m128 cz4 = _mm_set_ps1( p->m_N.z );
					const __m128 rrad4 = _mm_set_ps1( p->m_T.z );
					m_ID->N4[r + 0] = _mm_mul_ps( rrad4, _mm_sub_ps( cx4, _mm_add_ps( m_RP->ox4[i], _mm_mul_ps( m_RP->dx4[i], m_ID->dist4[i] ) ) ) );
					m_ID->N4[r + 1] = _mm_mul_ps( rrad4, _mm_sub_ps( cy4, _mm_add_ps( m_RP->oy4[i], _mm_mul_ps( m_RP->dy4[i], m_ID->dist4[i] ) ) ) );
					m_ID->N4[r + 2] = _mm_mul_ps( rrad4, _mm_sub_ps( cz4, _mm_add_ps( m_RP->oz4[i], _mm_mul_ps( m_RP->dz4[i], m_ID->dist4[i] ) ) ) );
				}
				else
			#endif
				{
					const vector3 N1 = p->m_Vertex[0]->GetNormal(), N2 = p->m_Vertex[1]->GetNormal(), N3 = p->m_Vertex[2]->GetNormal();
					const __m128 N1x = _mm_set_ps1( N1.x ), N1y = _mm_set_ps1( N1.y ), N1z = _mm_set_ps1( N1.z );
					const __m128 N2x = _mm_set_ps1( N2.x ), N2y = _mm_set_ps1( N2.y ), N2z = _mm_set_ps1( N2.z );
					const __m128 N3x = _mm_set_ps1( N3.x ), N3y = _mm_set_ps1( N3.y ), N3z = _mm_set_ps1( N3.z );
					m_ID->N4[r + 0] = _mm_add_ps( N1x, _mm_add_ps( _mm_mul_ps( m_ID->u4[i], _mm_sub_ps( N2x, N1x ) ), 
									  _mm_mul_ps( m_ID->v4[i], _mm_sub_ps( N3x, N1x ) ) ) );
					m_ID->N4[r + 1] = _mm_add_ps( N1y, _mm_add_ps( _mm_mul_ps( m_ID->u4[i], _mm_sub_ps( N2y, N1y ) ), 
									  _mm_mul_ps( m_ID->v4[i], _mm_sub_ps( N3y, N1y ) ) ) );
					m_ID->N4[r + 2] = _mm_add_ps( N1z, _mm_add_ps( _mm_mul_ps( m_ID->u4[i], _mm_sub_ps( N2z, N1z ) ), 
									  _mm_mul_ps( m_ID->v4[i], _mm_sub_ps( N3z, N1z ) ) ) );
				}
			#endif
			#ifdef PHOTONMAPPING
				m_ID->PN4[r + 0] = m_ID->N4[r + 0];
				m_ID->PN4[r + 1] = m_ID->N4[r + 1];
				m_ID->PN4[r + 2] = m_ID->N4[r + 2];
			#endif
				const __m128 scaleup = _mm_set_ps1( 256.0f );
				m_ID->colip[r + 0].rgba = _mm_mul_ps( scaleup, p->GetMaterial()->GetAmbientRed4() );
				m_ID->colip[r + 1].rgba = _mm_mul_ps( scaleup, p->GetMaterial()->GetAmbientGreen4() );
				m_ID->colip[r + 2].rgba = _mm_mul_ps( scaleup, p->GetMaterial()->GetAmbientBlue4() );
			}
		}
		else 
		{
			for ( j = 0; j < 4; ++j, ++r ) if (reinterpret_cast<unsigned int*>(m_RP->mask4)[r])
			{
				// rays do not hit the same primitive
				const Material* m = m_ID->prim[r]->GetMaterial();
				const Texture* t = m->GetTexture();
				const Primitive* p = m_ID->prim[r];
				if (t)
				{
					const float* hdr = t->GetHDRData();
					if (hdr)
					{
						float u, v;
						if (p == m_Dome)
						{
							// skybox, calculate uvs based on directions in packet
							const float* pdx = (float*)m_RP->dx4;
							const float* pdy = (float*)m_RP->dy4;
							const float* pdz = (float*)m_RP->dz4;
							const float dist = (1 / PI) * acosf( pdz[r] ) / sqrtf( pdx[r] * pdx[r] + pdy[r] * pdy[r] );
							u = ((pdx[r] * dist) + 1) * m_SDScale;
							v = ((pdy[r] * dist) - 1) * -m_SDScale;
						}
						else
						{
							// hdr texture
							const Vertex* vert0 = p->GetVertex( 0 ), *vert1 = p->GetVertex( 1 ), *vert2 = p->GetVertex( 2 );
							const float u1 = vert0->GetU(), v1 = vert0->GetV();
							const float u2 = vert1->GetU(), v2 = vert1->GetV();
							const float u3 = vert2->GetU(), v3 = vert2->GetV();
							const float u = u1 + m_ID->u[r] * (u2 - u1) + m_ID->v[r] * (u3 - u1);
							const float v = v1 + m_ID->u[r] * (v2 - v1) + m_ID->v[r] * (v3 - v1);
						}
						const int _u1 = ((int)u) & t->m_HMask, _v1 = ((int)v) & t->m_VMask;
						const int _u2 = (_u1 + 1) & t->m_HMask, _v2 = (_v1 + 1) & t->m_VMask;
						const float fracu = u - _floor( u ), fracv = v - _floor( v );
						const uint cidx = r & 0xffc;
						const float w1 = fracu * fracv;
						const float w2 = (1 - fracu) * fracv;
						const float w3 = fracu * (1 - fracv);
						const float w4 = (1 - fracu) * (1 - fracv);
						m_ID->colip[cidx + 0].cell[r & 3] = w1 * t->m_HDR[(_u1 + (_v1 << t->m_HShift)) * 3 + 0] + w2 * t->m_HDR[(_u2 + (_v1 << t->m_HShift)) * 3 + 0] +
															w3 * t->m_HDR[(_u1 + (_v2 << t->m_HShift)) * 3 + 0] + w4 * t->m_HDR[(_u2 + (_v2 << t->m_HShift)) * 3 + 0];
						m_ID->colip[cidx + 1].cell[r & 3] = w1 * t->m_HDR[(_u1 + (_v1 << t->m_HShift)) * 3 + 1] + w2 * t->m_HDR[(_u2 + (_v1 << t->m_HShift)) * 3 + 1] +
															w3 * t->m_HDR[(_u1 + (_v2 << t->m_HShift)) * 3 + 1] + w4 * t->m_HDR[(_u2 + (_v2 << t->m_HShift)) * 3 + 1];
						m_ID->colip[cidx + 2].cell[r & 3] = w1 * t->m_HDR[(_u1 + (_v1 << t->m_HShift)) * 3 + 2] + w2 * t->m_HDR[(_u2 + (_v1 << t->m_HShift)) * 3 + 2] +
															w3 * t->m_HDR[(_u1 + (_v2 << t->m_HShift)) * 3 + 2] + w4 * t->m_HDR[(_u2 + (_v2 << t->m_HShift)) * 3 + 2];
					}
					else
					{
						// textured primitive
						const Vertex* vert0 = p->GetVertex( 0 ), *vert1 = p->GetVertex( 1 ), *vert2 = p->GetVertex( 2 );
						const float u1 = vert0->GetU(), v1 = vert0->GetV();
						const float u2 = vert1->GetU(), v2 = vert1->GetV();
						const float u3 = vert2->GetU(), v3 = vert2->GetV();
						const float u = u1 + m_ID->u[r] * (u2 - u1) + m_ID->v[r] * (u3 - u1);
						const float v = v1 + m_ID->u[r] * (v2 - v1) + m_ID->v[r] * (v3 - v1);
						const int _u1 = ((int)u) & t->m_HMask, _v1 = ((int)v) & t->m_VMask;
						const int _u2 = (_u1 + 1) & t->m_HMask, _v2 = (_v1 + 1) & t->m_VMask;
						const float fracu = u - _floor( u ), fracv = v - _floor( v );
						const Texture* b = m->GetBumpMap();
						if (b)
						{
							// texture with normal map
							const __m128i pixel4 = _mm_set_epi32( t->m_TN32[_u1 * 2 + (_v1 << t->m_HShift)], t->m_TN32[_u2 * 2 + (_v1 << t->m_HShift)],
																  t->m_TN32[_u1 * 2 + (_v2 << t->m_HShift)], t->m_TN32[_u2 * 2 + (_v2 << t->m_HShift)] );
							// bilinear filter
							const __m128i rb4 = _mm_unpacklo_epi8( pixel4, iz4 ), ag4 = _mm_unpackhi_epi8( pixel4, iz4 );
							const __m128 pa4 = _mm_mul_ps( _mm_cvtepi32_ps( _mm_unpacklo_epi16( rb4, iz4 ) ), _mm_set_ps1( fracu * fracv ) );
							const __m128 pb4 = _mm_mul_ps( _mm_cvtepi32_ps( _mm_unpackhi_epi16( rb4, iz4 ) ), _mm_set_ps1( (1 - fracu) * fracv ) );
							const __m128 pc4 = _mm_mul_ps( _mm_cvtepi32_ps( _mm_unpacklo_epi16( ag4, iz4 ) ), _mm_set_ps1( fracu * (1 - fracv) ) );
							const __m128 pd4 = _mm_mul_ps( _mm_cvtepi32_ps( _mm_unpackhi_epi16( ag4, iz4 ) ), _mm_set_ps1( (1 - fracu) * (1 - fracv) ) );
							const float* pa = (const float*)reinterpret_cast<const float*>(&pa4);
							const float* pb = (const float*)reinterpret_cast<const float*>(&pb4);
							const float* pc = (const float*)reinterpret_cast<const float*>(&pc4);
							const float* pd = (const float*)reinterpret_cast<const float*>(&pd4);
							const uint cidx = r & 0xffc;
							m_ID->colip[cidx + 0].cell[r & 3] = pa[2] + pb[2] + pc[2] + pd[2];
							m_ID->colip[cidx + 1].cell[r & 3] = pa[1] + pb[1] + pc[1] + pd[1];
							m_ID->colip[cidx + 2].cell[r & 3] = pa[0] + pb[0] + pc[0] + pd[0];
						#ifdef ALPHABLENDING
							m_ID->colip[cidx + 3].cell[r & 3] = pa[3] + pb[3] + pc[3] + pd[3];
						#endif
							// normal map
							const __m128i bdata = _mm_set_epi32( t->m_TN32[_u2 * 2 + 1 + (_v2 << t->m_HShift)], t->m_TN32[_u1 * 2 + 1 + (_v2 << t->m_HShift)],
																 t->m_TN32[_u2 * 2 + 1 + (_v1 << t->m_HShift)], t->m_TN32[_u1 * 2 + 1 + (_v1 << t->m_HShift)] );
							const __m128 f4[2] = { _mm_cvtepi32_ps( _mm_unpackhi_epi16( bdata, iz4 ) ), _mm_cvtepi32_ps( _mm_unpacklo_epi16( bdata, iz4 ) ) };
							const float* f = (const float*)reinterpret_cast<const float*>(f4);
							const float _fracv = 1 - fracv, _fracu = 1 - fracu;
							const float NCb = (1.0f / 32767.0f) * (-32767.0f + _fracv * (_fracu * f[4] + fracu * f[6]) + fracv * (_fracu * f[0] + fracu * f[2]));
							const float NCg = (1.0f / 32767.0f) * (-32767.0f + _fracv * (_fracu * f[5] + fracu * f[7]) + fracv * (_fracu * f[1] + fracu * f[3]));
						#ifdef INTERPNORMALS
							const vector3 PN = p->GetNormal( m_ID->u[r], m_ID->v[r] );
							const vector3 N = PN + p->m_T * NCb + p->m_B * NCg;
						#else
							const vector3 N = p->m_N + p->m_T * NCb + p->m_B * NCg;
						#endif
							const uint idx = ((r >> 2) << 4) + (r & 3);
							const float l = 1.0f / _sqrt( N.x * N.x + N.y * N.y + N.z * N.z );
							const vector3 NN( N.x * l, N.y * l, N.z * l );
							m_ID->SetNormal( idx, NN );
						#ifdef PHOTONMAPPING
							m_ID->SetPrimNormal( idx, PN );
						#endif
						}
						else
						{
							// texture without normal map
							const __m128i pixel4 = _mm_set_epi32( t->m_B32[_u1 + (_v1 << t->m_HShift)], t->m_B32[_u2 + (_v1 << t->m_HShift)],
																  t->m_B32[_u1 + (_v2 << t->m_HShift)], t->m_B32[_u2 + (_v2 << t->m_HShift)] );
							// bilinear filter
							const __m128i rb4 = _mm_unpacklo_epi8( pixel4, iz4 ), ag4 = _mm_unpackhi_epi8( pixel4, iz4 );
							const __m128 pa4 = _mm_mul_ps( _mm_cvtepi32_ps( _mm_unpacklo_epi16( rb4, iz4 ) ), _mm_set_ps1( fracu * fracv ) );
							const __m128 pb4 = _mm_mul_ps( _mm_cvtepi32_ps( _mm_unpackhi_epi16( rb4, iz4 ) ), _mm_set_ps1( (1 - fracu) * fracv ) );
							const __m128 pc4 = _mm_mul_ps( _mm_cvtepi32_ps( _mm_unpacklo_epi16( ag4, iz4 ) ), _mm_set_ps1( fracu * (1 - fracv) ) );
							const __m128 pd4 = _mm_mul_ps( _mm_cvtepi32_ps( _mm_unpackhi_epi16( ag4, iz4 ) ), _mm_set_ps1( (1 - fracu) * (1 - fracv) ) );
							const float* pa = (const float*)reinterpret_cast<const float*>(&pa4);
							const float* pb = (const float*)reinterpret_cast<const float*>(&pb4);
							const float* pc = (const float*)reinterpret_cast<const float*>(&pc4);
							const float* pd = (const float*)reinterpret_cast<const float*>(&pd4);
							const uint cidx = r & 0xffc;
							m_ID->colip[cidx + 0].cell[r & 3] = pa[2] + pb[2] + pc[2] + pd[2];
							m_ID->colip[cidx + 1].cell[r & 3] = pa[1] + pb[1] + pc[1] + pd[1];
							m_ID->colip[cidx + 2].cell[r & 3] = pa[0] + pb[0] + pc[0] + pd[0];
						#ifdef ALPHABLENDING
							m_ID->colip[cidx + 3].cell[r & 3] = pa[3] + pb[3] + pc[3] + pd[3];
						#endif
							// no normal map
						#ifdef INTERPNORMALS
							const vector3 N = p->GetNormal( m_ID->u[r], m_ID->v[r] );
						#else
							const vector3 N = p->m_N;
						#endif
							const uint idx = ((r >> 2) << 4) + (r & 3);
							m_ID->SetNormal( idx, N );
						#ifdef PHOTONMAPPING
							m_ID->SetPrimNormal( idx, N );
						#endif
						}
					}
				}
				else 
				{
					// no texture
					Color amb = m->GetAmbient();
					const uint cidx = r & 1020;
					m_ID->colip[cidx + 0].cell[r & 3] = amb.r * 256;
					m_ID->colip[cidx + 1].cell[r & 3] = amb.g * 256;
					m_ID->colip[cidx + 2].cell[r & 3] = amb.b * 256;
				#ifdef INTERPNORMALS
				#ifdef SUPPORTSPHERES
					vector3 N;
					if (p->GetType() == Primitive::PRIM_SPHERE)
					{
						const vector3 D( reinterpret_cast<float*>(&m_RP->dx4)[r], reinterpret_cast<float*>(&m_RP->dy4)[r], reinterpret_cast<float*>(&m_RP->dz4)[r] );
						const vector3 O( reinterpret_cast<float*>(&m_RP->ox4)[r], reinterpret_cast<float*>(&m_RP->oy4)[r], reinterpret_cast<float*>(&m_RP->oz4)[r] );
						const vector3 I = O + reinterpret_cast<float*>(m_ID->dist4)[r] * D;
						N = (p->m_N - I) * p->m_T.z;
					}
					else
					{
						N = p->GetNormal( m_ID->u[r], m_ID->v[r] );
					}
				#else
					const vector3 N = p->GetNormal( m_ID->u[r], m_ID->v[r] );
				#endif
				#else
					const vector3 N = p->m_N;
				#endif
					const uint idx = ((r >> 2) << 4) + (r & 3);
					m_ID->SetNormal( idx, N );
				#ifdef PHOTONMAPPING
					m_ID->SetPrimNormal( idx, N );
				#endif
				}
			}
			r -= 4;
		}
	}
}

// -----------------------------------------------------------
// LineTracer::ApplyLights()
// Determines local illumination and calculates final pixel
// -----------------------------------------------------------
void LineTracer::ApplyLights()
{
	__m128 addc4[PACKETQ * 4]; 
	float* addc = (float*)&addc4;
	Light* larray[MAXLIGHTS];
	// determine bounding box of a tile of pixels
	__m128 ix[PACKETQ], iy[PACKETQ], iz[PACKETQ];
	// const uint start = m_RP->qoffset, end = m_RP->qoffset + m_RP->packetq;
	const __m128 v1 = _mm_set_ps1( 10000 ), v2 = _mm_set_ps1( -10000 );
	__m128 minx4 = v1, maxx4 = v2, miny4 = v1, maxy4 = v2, minz4 = v1, maxz4 = v2;
	for ( uint r = 0; r < m_RP->packetq; r++ ) if (_mm_movemask_ps( m_RP->mask4[r] ))
	{
		ix[r] = _mm_add_ps( m_RP->ox4[r], _mm_mul_ps( m_RP->dx4[r], m_ID->dist4[r] ) );
		iy[r] = _mm_add_ps( m_RP->oy4[r], _mm_mul_ps( m_RP->dy4[r], m_ID->dist4[r] ) );
		iz[r] = _mm_add_ps( m_RP->oz4[r], _mm_mul_ps( m_RP->dz4[r], m_ID->dist4[r] ) );
		minx4 = _mm_min_ps( minx4, ix[r] ); maxx4 = _mm_max_ps( maxx4, ix[r] );
		miny4 = _mm_min_ps( miny4, iy[r] ); maxy4 = _mm_max_ps( maxy4, iy[r] );
		minz4 = _mm_min_ps( minz4, iz[r] ); maxz4 = _mm_max_ps( maxz4, iz[r] );
	}
	const vector3 _min( hormin( minx4 ), hormin( miny4 ), hormin( minz4 ) );
	const vector3 _max( hormax( maxx4 ), hormax( maxy4 ), hormax( maxz4 ) );
	// look for relevant lights
	const uint lcount = Scene::GetLightBVH()->Traverse( larray, _min, _max );
	const __m128 val1 = _mm_set_ps1( 0.249f );
	const __m128 val2 = _mm_set_ps1( 0.5f );
	const __m128 fifty4 = _mm_set_ps1( 50.0f );
	const __m128 two4 = _mm_set_ps1( 2.0f );
	// apply ambient lighting
	unsigned int samemat[PACKETQ];
	memset( samemat, 255, PACKETQ * 4 );
	for ( uint p1 = 0, r = 0; p1 < m_RP->packetq; ++p1, r+= 4 ) if (_mm_movemask_ps( m_RP->mask4[p1] ))
	{
#ifdef SHOWNORMALS
	__m128 upscale4 = _mm_set_ps1( 128.0f );
	__m128 one4 = _mm_set_ps1( 1.0f );
	addc4[p1 * 4 + 0] = _mm_mul_ps( upscale4, _mm_add_ps( one4, m_ID->N4[p1 * 4 + 0] ) );
	addc4[p1 * 4 + 1] = _mm_mul_ps( upscale4, _mm_add_ps( one4, m_ID->N4[p1 * 4 + 1] ) );
	addc4[p1 * 4 + 2] = _mm_mul_ps( upscale4, _mm_add_ps( one4, m_ID->N4[p1 * 4 + 2] ) );
#else
	#ifdef PHOTONMAPPING
		if ((Scene::m_GI) && (m_Photons))
		{
			const Material* m1 = m_ID->prim[r + 0]->GetMaterial(), *m2 = m_ID->prim[r + 1]->GetMaterial();
			const Material* m3 = m_ID->prim[r + 2]->GetMaterial(), *m4 = m_ID->prim[r + 3]->GetMaterial();
			if ((m1 == m2) && (m2 == m3) && (m3 == m4))
			{
				addc4[p1 * 4 + 0] = m1->GetEmissiveRed4();
				addc4[p1 * 4 + 1] = m1->GetEmissiveGreen4();
				addc4[p1 * 4 + 2] = m1->GetEmissiveBlue4();
			}
			else
			{
				const __m128 upscale4 = _mm_set_ps1( 256.0f );
				addc4[p1 * 4 + 0] = _mm_mul_ps( upscale4, _mm_set_ps( m4->GetEmissive().r, m3->GetEmissive().r, m2->GetEmissive().r, m1->GetEmissive().r ) );
				addc4[p1 * 4 + 1] = _mm_mul_ps( upscale4, _mm_set_ps( m4->GetEmissive().g, m3->GetEmissive().g, m2->GetEmissive().g, m1->GetEmissive().g ) );
				addc4[p1 * 4 + 2] = _mm_mul_ps( upscale4, _mm_set_ps( m4->GetEmissive().b, m3->GetEmissive().b, m2->GetEmissive().b, m1->GetEmissive().b ) );
				samemat[p1] = 0;
			}
		}
		else
	#endif
		{
			const Material* m1 = m_ID->prim[r + 0]->GetMaterial(), *m2 = m_ID->prim[r + 1]->GetMaterial();
		#ifdef DIRECTIONALAMBIENT
			const __m128 Nx4 = m_ID->N4[p1 * 4];
			const __m128 Ny4 = m_ID->N4[p1 * 4 + 1];
			const __m128 Nz4 = m_ID->N4[p1 * 4 + 2];
			__m128 ldx4 = ix[p1];
			__m128 ldy4 = iy[p1];
			__m128 ldz4 = iz[p1];
			__m128 len4 = _mm_rsqrt_ps( _mm_add_ps( _mm_add_ps( _mm_mul_ps( ldx4, ldx4 ), _mm_mul_ps( ldy4, ldy4 ) ), _mm_mul_ps( ldz4, ldz4 ) ) );
			ldx4 = _mm_mul_ps( ldx4, len4 );		
			ldy4 = _mm_mul_ps( ldy4, len4 );		
			ldz4 = _mm_mul_ps( ldz4, len4 );		
			const __m128 ddot4 = _mm_add_ps( _mm_add_ps( _mm_mul_ps( ldx4, Nx4 ), _mm_mul_ps( ldy4, Ny4 ) ), _mm_mul_ps( ldz4, Nz4 ) );
			const __m128 scale4 = _mm_add_ps( val2, _mm_mul_ps( _mm_add_ps( ddot4, one ), val1 ) ); // 0.5 .. 1.0
		#endif
			const Material* m3 = m_ID->prim[r + 2]->GetMaterial(), *m4 = m_ID->prim[r + 3]->GetMaterial();
			if ((m1 == m2) && (m2 == m3) && (m3 == m4))
			{
				const __m128 ambientR4 = _mm_mul_ps( m_AmbientR4, m1->GetAmbientRed4() );
				const __m128 ambientG4 = _mm_mul_ps( m_AmbientG4, m1->GetAmbientGreen4() );
				const __m128 ambientB4 = _mm_mul_ps( m_AmbientB4, m1->GetAmbientBlue4() );
			#ifdef DIRECTIONALAMBIENT
				addc4[p1 * 4 + 0] = _mm_add_ps( _mm_mul_ps( m_ID->colip[r + 0].rgba, _mm_mul_ps( ambientR4, scale4 ) ), m1->GetEmissiveRed4() );
				addc4[p1 * 4 + 1] = _mm_add_ps( _mm_mul_ps( m_ID->colip[r + 1].rgba, _mm_mul_ps( ambientG4, scale4 ) ), m1->GetEmissiveGreen4() );
				addc4[p1 * 4 + 2] = _mm_add_ps( _mm_mul_ps( m_ID->colip[r + 2].rgba, _mm_mul_ps( ambientB4, scale4 ) ), m1->GetEmissiveBlue4() );
			#else
				addc4[p1 * 4 + 0] = _mm_add_ps( _mm_mul_ps( m_ID->colip[r + 0].rgba, ambientR4 ), m1->GetEmissiveRed4() );
				addc4[p1 * 4 + 1] = _mm_add_ps( _mm_mul_ps( m_ID->colip[r + 1].rgba, ambientG4 ), m1->GetEmissiveGreen4() );
				addc4[p1 * 4 + 2] = _mm_add_ps( _mm_mul_ps( m_ID->colip[r + 2].rgba, ambientB4 ), m1->GetEmissiveBlue4() );
			#endif
			}
			else
			{
				const __m128 upscale4 = _mm_set_ps1( 256.0f );
				const __m128 ambR4 = _mm_mul_ps( m_AmbientR4, _mm_set_ps( m4->GetAmbient().r, m3->GetAmbient().r, m2->GetAmbient().r, m1->GetAmbient().r ) );
				const __m128 ambG4 = _mm_mul_ps( m_AmbientG4, _mm_set_ps( m4->GetAmbient().g, m3->GetAmbient().g, m2->GetAmbient().g, m1->GetAmbient().g ) );
				const __m128 ambB4 = _mm_mul_ps( m_AmbientB4, _mm_set_ps( m4->GetAmbient().b, m3->GetAmbient().b, m2->GetAmbient().b, m1->GetAmbient().b ) );
				const __m128 emmR4 = _mm_mul_ps( upscale4, _mm_set_ps( m4->GetEmissive().r, m3->GetEmissive().r, m2->GetEmissive().r, m1->GetEmissive().r ) );
				const __m128 emmG4 = _mm_mul_ps( upscale4, _mm_set_ps( m4->GetEmissive().g, m3->GetEmissive().g, m2->GetEmissive().g, m1->GetEmissive().g ) );
				const __m128 emmB4 = _mm_mul_ps( upscale4, _mm_set_ps( m4->GetEmissive().b, m3->GetEmissive().b, m2->GetEmissive().b, m1->GetEmissive().b ) );
			#ifdef DIRECTIONALAMBIENT
				addc4[p1 * 4 + 0] = _mm_add_ps( _mm_mul_ps( m_ID->colip[r + 0].rgba, _mm_mul_ps( ambR4, scale4 ) ), emmR4 );
				addc4[p1 * 4 + 1] = _mm_add_ps( _mm_mul_ps( m_ID->colip[r + 1].rgba, _mm_mul_ps( ambG4, scale4 ) ), emmG4 );
				addc4[p1 * 4 + 2] = _mm_add_ps( _mm_mul_ps( m_ID->colip[r + 2].rgba, _mm_mul_ps( ambB4, scale4 ) ), emmB4 );
			#else
				addc4[p1 * 4 + 0] = _mm_add_ps( _mm_mul_ps( m_ID->colip[r + 0].rgba, ambR4 ), emmR4 );
				addc4[p1 * 4 + 1] = _mm_add_ps( _mm_mul_ps( m_ID->colip[r + 1].rgba, ambG4 ), emmG4 );
				addc4[p1 * 4 + 2] = _mm_add_ps( _mm_mul_ps( m_ID->colip[r + 2].rgba, ambB4 ), emmB4 );
			#endif
				samemat[p1] = 0;
			}
		}
	}
	// process relevant lights
	const __m128 _four4 = _mm_set_ps1( 4.0f ), _schl1 = _mm_set_ps1( 0.2f ), _schl2 = _mm_set_ps1( 0.0625f );
	for ( uint n = 0; n < lcount; ++n )
	{
		uint r = m_RP->offset;
		const Light* l = larray[n];
		PrepShadowPacket( *l );
		if (1) // (!((Scene::m_GI) && (m_Photons))) 
		{
			if (l->Shadows()) DoShadowRays( *l );
			const __m128 rr4 = l->GetRRadius4();
		#ifdef SPOTLIGHTS
			const __m128 w4 = l->GetWidth4(), ws4 = l->GetSpotSize4();
		#endif
			for ( uint p1 = 0; p1 < m_RP->packetq; ++p1, r += 4 ) if (_mm_movemask_ps( m_RP->mask4[p1] ))
			{
				__m128 sdot4 = _mm_setzero_ps(), lmask;
				// initial mask
			#ifdef SPOTLIGHTS
			#ifdef MULTIBEAM
				if (l->IsMultiBeam())
				{
					sdot4 = _mm_setzero_ps();
					for ( uint i = 0; i < MULTIBEAMDIRS; i++ )
					{
						const __m128 dot4 = DOT128( l->mdx4[i], l->mdy4[i], l->mdz4[i], m_LRP.dx4[p1], m_LRP.dy4[p1], m_LRP.dz4[p1] );
						sdot4 = _mm_max_ps( dot4, sdot4 );
					}
				}
				else sdot4 = DOT128( l->dx4, l->dy4, l->dz4, m_LRP.dx4[p1], m_LRP.dy4[p1], m_LRP.dz4[p1] );
				lmask = _mm_and_ps( _mm_cmpge_ps( sdot4, w4 ), _mm_and_ps( _mm_cmple_ps( m_LID.dist4[p1], l->GetRadius4() ), _mm_cmpeq_ps( m_LID.shadow[p1], zero ) ) );
			#else
				sdot4 = _mm_add_ps( _mm_add_ps( _mm_mul_ps( l->dx4, m_LRP.dx4[p1] ), 
									_mm_mul_ps( l->dy4, m_LRP.dy4[p1] ) ), _mm_mul_ps( l->dz4, m_LRP.dz4[p1] ) );
				lmask = _mm_and_ps( _mm_cmpge_ps( sdt4[p1], w4 ), _mm_and_ps( _mm_cmple_ps( m_LID.dist4[p1], l->GetRadius4() ), _mm_cmpeq_ps( m_LID.shadow[p1], zero ) ) );
			#endif
			#else
				lmask = _mm_and_ps( _mm_cmple_ps( m_LID.dist4[p1], l->GetRadius4() ), _mm_cmpeq_ps( m_LID.shadow[p1], zero ) );
			#endif
				// calculate beam intensity
				if (_mm_movemask_ps( lmask ))
				{
					const Material* m1 = m_ID->prim[r + 0]->GetMaterial(), *m2 = m_ID->prim[r + 1]->GetMaterial();
					const Material* m3 = m_ID->prim[r + 2]->GetMaterial(), *m4 = m_ID->prim[r + 3]->GetMaterial();
					const __m128 Nx4 = m_ID->N4[p1 * 4], Ny4 = m_ID->N4[p1 * 4 + 1], Nz4 = m_ID->N4[p1 * 4 + 2];
					__m128 diffR4, diffG4, diffB4, specR4, specG4, specB4;
					if (samemat[p1])
					{
						diffR4 = _mm_mul_ps( m1->GetDiffuseRed4(), l->GetDiffuseRed4() );
						diffG4 = _mm_mul_ps( m1->GetDiffuseGreen4(), l->GetDiffuseGreen4() );
						diffB4 = _mm_mul_ps( m1->GetDiffuseBlue4(), l->GetDiffuseBlue4() );
						specR4 = _mm_mul_ps( m1->GetSpecularRed4(), l->GetSpecularRed4() );
						specG4 = _mm_mul_ps( m1->GetSpecularGreen4(), l->GetSpecularGreen4() );
						specB4 = _mm_mul_ps( m1->GetSpecularBlue4(), l->GetSpecularBlue4() );
					}
					else
					{
						diffR4 = _mm_mul_ps( _mm_set_ps( m4->GetDiffuse().r, m3->GetDiffuse().r, m2->GetDiffuse().r, m1->GetDiffuse().r ), l->GetDiffuseRed4() );
						diffG4 = _mm_mul_ps( _mm_set_ps( m4->GetDiffuse().g, m3->GetDiffuse().g, m2->GetDiffuse().g, m1->GetDiffuse().g ), l->GetDiffuseGreen4() );
						diffB4 = _mm_mul_ps( _mm_set_ps( m4->GetDiffuse().b, m3->GetDiffuse().b, m2->GetDiffuse().b, m1->GetDiffuse().b ), l->GetDiffuseBlue4() );
						specR4 = _mm_mul_ps( _mm_set_ps( m4->GetSpecular().r, m3->GetSpecular().r, m2->GetSpecular().r, m1->GetSpecular().r ), l->GetSpecularRed4() );
						specG4 = _mm_mul_ps( _mm_set_ps( m4->GetSpecular().g, m3->GetSpecular().g, m2->GetSpecular().g, m1->GetSpecular().g ), l->GetSpecularGreen4() );
						specB4 = _mm_mul_ps( _mm_set_ps( m4->GetSpecular().b, m3->GetSpecular().b, m2->GetSpecular().b, m1->GetSpecular().b ), l->GetSpecularBlue4() );
					}
					// attenuation
					const __m128 dr4 = _mm_mul_ps( m_LID.dist4[p1], rr4 );
					const __m128 v1 = _mm_mul_ps( _mm_sub_ps( one, dr4 ), _schl1 );
					const __m128 v2 = _mm_mul_ps( dr4, _four4 );
					const __m128 v3 = _mm_rcp_ps( _mm_mul_ps( v2, v2 ) );
				#ifndef SPOTLIGHTS
					const __m128 att4 = _mm_and_ps( lmask, _mm_max_ps( zero, _mm_sub_ps( _mm_add_ps( v1, v3 ), _schl2 ) ) );
				#else
					const __m128 bint4 = _mm_min_ps( one, _mm_mul_ps( _mm_sub_ps( sdot4, w4 ), _mm_rcp_ps( _mm_sub_ps( ws4, w4 ) ) ) );
					const __m128 att4 = _mm_max_ps( zero, _mm_mul_ps( bint4, _mm_max_ps( zero, _mm_sub_ps( _mm_add_ps( v1, v3 ), _schl2 ) ) ) );
				#endif
					// prepare shading data
					const __m128 ddot4 = _mm_mul_ps( two4, _mm_add_ps( _mm_add_ps( _mm_mul_ps( m_RP->dx4[p1], Nx4 ), 
										 _mm_mul_ps( m_RP->dy4[p1], Ny4 ) ), _mm_mul_ps( m_RP->dz4[p1], Nz4 ) ) );
					const __m128 Rx4 = _mm_sub_ps( _mm_mul_ps( ddot4, Nx4 ), m_RP->dx4[p1] );
					const __m128 Ry4 = _mm_sub_ps( _mm_mul_ps( ddot4, Ny4 ), m_RP->dy4[p1] );
					const __m128 Rz4 = _mm_sub_ps( _mm_mul_ps( ddot4, Nz4 ), m_RP->dz4[p1] );
					const __m128 d2t4 = _mm_max_ps( zero, _mm_add_ps( _mm_add_ps( _mm_mul_ps( m_LRP.dx4[p1], Rx4 ), 
										_mm_mul_ps( m_LRP.dy4[p1], Ry4 ) ), _mm_mul_ps( m_LRP.dz4[p1], Rz4 ) ) );
					const __m128 dot4 = _mm_max_ps( zero, _mm_add_ps( _mm_add_ps( _mm_mul_ps( m_LRP.dx4[p1], Nx4 ), 
										_mm_mul_ps( m_LRP.dy4[p1], Ny4 ) ), _mm_mul_ps( m_LRP.dz4[p1], Nz4 ) ) );
					// diffuse
					const __m128 adot4 = _mm_and_ps( lmask, _mm_mul_ps( dot4, att4 ) ); // NOTE: Mask should not be needed, but it is!?
					// specular
					const __m128 reci = _mm_and_ps( lmask, _mm_mul_ps( att4, _mm_div_ps( d2t4, _mm_add_ps( _mm_sub_ps( fifty4, _mm_mul_ps( fifty4, d2t4 ) ), d2t4 ) ) ) );
					addc4[p1 * 4 + 0] = _mm_add_ps( _mm_mul_ps( _mm_add_ps( _mm_mul_ps( adot4, diffR4 ), 
										_mm_mul_ps( reci, specR4 ) ), m_ID->colip[r + 0].rgba ), addc4[p1 * 4 + 0] );
					addc4[p1 * 4 + 1] = _mm_add_ps( _mm_mul_ps( _mm_add_ps( _mm_mul_ps( adot4, diffG4 ), 
										_mm_mul_ps( reci, specG4 ) ), m_ID->colip[r + 1].rgba ), addc4[p1 * 4 + 1] );
					addc4[p1 * 4 + 2] = _mm_add_ps( _mm_mul_ps( _mm_add_ps( _mm_mul_ps( adot4, diffB4 ), 
										_mm_mul_ps( reci, specB4 ) ), m_ID->colip[r + 2].rgba ), addc4[p1 * 4 + 2] );
				}
			}
		}
		else
		{
			const __m128 rr4 = l->GetRRadius4();
			for ( uint p1 = 0; p1 < m_RP->packetq; ++p1, r += 4 ) if (_mm_movemask_ps( m_RP->mask4[p1] ))
			{
				__m128 sdot4 = _mm_setzero_ps(), lmask;
				lmask = _mm_cmple_ps( m_LID.dist4[p1], l->GetRadius4() );
				if (_mm_movemask_ps( lmask ))
				{
					const Material* m1 = m_ID->prim[r + 0]->GetMaterial(), *m2 = m_ID->prim[r + 1]->GetMaterial();
					const Material* m3 = m_ID->prim[r + 2]->GetMaterial(), *m4 = m_ID->prim[r + 3]->GetMaterial();
					const __m128 Nx4 = m_ID->N4[p1 * 4], Ny4 = m_ID->N4[p1 * 4 + 1], Nz4 = m_ID->N4[p1 * 4 + 2];
					__m128 specR4, specG4, specB4;
					if (samemat[p1])
					{
						specR4 = _mm_mul_ps( m1->GetSpecularRed4(), l->GetSpecularRed4() );
						specG4 = _mm_mul_ps( m1->GetSpecularGreen4(), l->GetSpecularGreen4() );
						specB4 = _mm_mul_ps( m1->GetSpecularBlue4(), l->GetSpecularBlue4() );
					}
					else
					{
						specR4 = _mm_mul_ps( _mm_set_ps( m4->GetSpecular().r, m3->GetSpecular().r, m2->GetSpecular().r, m1->GetSpecular().r ), l->GetSpecularRed4() );
						specG4 = _mm_mul_ps( _mm_set_ps( m4->GetSpecular().g, m3->GetSpecular().g, m2->GetSpecular().g, m1->GetSpecular().g ), l->GetSpecularGreen4() );
						specB4 = _mm_mul_ps( _mm_set_ps( m4->GetSpecular().b, m3->GetSpecular().b, m2->GetSpecular().b, m1->GetSpecular().b ), l->GetSpecularBlue4() );
					}
					// attenuation
					const __m128 dr4 = _mm_mul_ps( m_LID.dist4[p1], rr4 );
					const __m128 v1 = _mm_mul_ps( _mm_sub_ps( one, dr4 ), _schl1 );
					const __m128 v2 = _mm_mul_ps( dr4, _four4 );
					const __m128 v3 = _mm_rcp_ps( _mm_mul_ps( v2, v2 ) );
					const __m128 att4 = _mm_and_ps( lmask, _mm_max_ps( zero, _mm_sub_ps( _mm_add_ps( v1, v3 ), _schl2 ) ) );
					// prepare shading data
					const __m128 ddot4 = _mm_mul_ps( two4, _mm_add_ps( _mm_add_ps( _mm_mul_ps( m_RP->dx4[p1], Nx4 ), 
										 _mm_mul_ps( m_RP->dy4[p1], Ny4 ) ), _mm_mul_ps( m_RP->dz4[p1], Nz4 ) ) );
					const __m128 Rx4 = _mm_sub_ps( _mm_mul_ps( ddot4, Nx4 ), m_RP->dx4[p1] );
					const __m128 Ry4 = _mm_sub_ps( _mm_mul_ps( ddot4, Ny4 ), m_RP->dy4[p1] );
					const __m128 Rz4 = _mm_sub_ps( _mm_mul_ps( ddot4, Nz4 ), m_RP->dz4[p1] );
					const __m128 d2t4 = _mm_max_ps( zero, _mm_add_ps( _mm_add_ps( _mm_mul_ps( m_LRP.dx4[p1], Rx4 ), 
										_mm_mul_ps( m_LRP.dy4[p1], Ry4 ) ), _mm_mul_ps( m_LRP.dz4[p1], Rz4 ) ) );
					// specular
					const __m128 reci = _mm_mul_ps( att4, _mm_div_ps( d2t4, _mm_add_ps( _mm_sub_ps( fifty4, _mm_mul_ps( fifty4, d2t4 ) ), d2t4 ) ) );
					addc4[p1 * 4 + 0] = _mm_add_ps( _mm_mul_ps( _mm_mul_ps( reci, specR4 ), m_ID->colip[r + 0].rgba ), addc4[p1 * 4 + 0] );
					addc4[p1 * 4 + 1] = _mm_add_ps( _mm_mul_ps( _mm_mul_ps( reci, specG4 ), m_ID->colip[r + 1].rgba ), addc4[p1 * 4 + 1] );
					addc4[p1 * 4 + 2] = _mm_add_ps( _mm_mul_ps( _mm_mul_ps( reci, specB4 ), m_ID->colip[r + 2].rgba ), addc4[p1 * 4 + 2] );
				}
			}
		}
#endif
	}
	// unswizzle
	const __m128 minthree = m_FogTop4;
	const __m128 density = m_FogDensity4;
#ifdef PHOTONMAPPING
	const Cell* grid = PhotonMapper::GetSampleGrid();
	const __m128 searchrad4 = _mm_set_ps1( m_SampleDist );
#endif
	for ( uint p1 = 0, r = 0; p1 < m_RP->packetq; ++p1, r += 4 ) if (_mm_movemask_ps( m_RP->mask4[p1] ))
	{
	#ifdef PHOTONMAPPING
			const Material* m1 = m_ID->prim[p1 * 4 + 0]->GetMaterial();
			const Material* m2 = m_ID->prim[p1 * 4 + 1]->GetMaterial();
			const Material* m3 = m_ID->prim[p1 * 4 + 2]->GetMaterial();
			const Material* m4 = m_ID->prim[p1 * 4 + 3]->GetMaterial();
	#endif
	#ifdef FLOORFOG
		if (m_Fog)
		{
			// apply fog (Rutger's new way)
			const __m128 minthree = m_FogTop4;
			const __m128 density = m_FogDensity4;
			const __m128 diry = _mm_rcp_ps( m_RP->dy4[p1] );
			const __m128 iszero = _mm_cmpgt_ps( epsilon, _mm_max_ps( m_RP->dy4[p1], _mm_sub_ps( zero, m_RP->dy4[p1] ) ) );
			const __m128 v1 = _mm_max_ps( zero, _mm_sub_ps( minthree, m_RP->oy4[p1] ) );
			const __m128 v2 = _mm_max_ps( zero, _mm_sub_ps( minthree, iy[p1] ) );
			const __m128 v3 = _mm_sub_ps( _mm_mul_ps( v1, diry ), _mm_mul_ps( v2, diry ) );
			const __m128 fog4b = _mm_or_ps( _mm_and_ps( m_RP->mask4[p1], _mm_min_ps( one, _mm_mul_ps( _mm_or_ps( _mm_andnot_ps( iszero, 
					v3 ), _mm_and_ps( _mm_cmple_ps( iy[p1], minthree ), 
					_mm_and_ps( iszero, m_ID->dist4[p1] ) ) ), density ) ) ), _mm_andnot_ps( m_RP->mask4[p1], zero ) );
			const __m128 fog4c = _mm_sub_ps( one, fog4b );
			addc4[p1 * 4 + 0] = _mm_add_ps( _mm_mul_ps( fog4b, m_FogColorr4 ), _mm_mul_ps( addc4[p1 * 4 + 0], fog4c ) );
			addc4[p1 * 4 + 1] = _mm_add_ps( _mm_mul_ps( fog4b, m_FogColorg4 ), _mm_mul_ps( addc4[p1 * 4 + 1], fog4c ) );
			addc4[p1 * 4 + 2] = _mm_add_ps( _mm_mul_ps( fog4b, m_FogColorb4 ), _mm_mul_ps( addc4[p1 * 4 + 2], fog4c ) );
		}
	#endif
	#ifdef PHOTONMAPPING
		if ((Scene::m_GI) && (m_Photons)) 
		{
			// ApplyPhotonMap( reinterpret_cast<__m128*>(addc4 + p1 * 4), p1, ix, iy, iz );
			const __m128 gx4 = _mm_mul_ps( m_ExtRSizex4, _mm_sub_ps( ix[p1], m_ExtP1x4 ) );
			const __m128 gy4 = _mm_mul_ps( m_ExtRSizey4, _mm_sub_ps( iy[p1], m_ExtP1y4 ) );
			const __m128 gz4 = _mm_mul_ps( m_ExtRSizez4, _mm_sub_ps( iz[p1], m_ExtP1z4 ) );
			const __m128i igx4 = _mm_add_epi32( _mm_add_epi32( _mm_cvtps_epi32( _mm_sub_ps( gx4, half4 ) ),
				   _mm_slli_epi32( _mm_cvtps_epi32( _mm_sub_ps( gy4, half4 ) ), PHOTONYSHIFT ) ),
				   _mm_slli_epi32( _mm_cvtps_epi32( _mm_sub_ps( gz4, half4 ) ), PHOTONZSHIFT ) );
			const int* igx = (const int*)reinterpret_cast<const int*>(&igx4);
			const __m128 ndist4 = _mm_add_ps( _mm_add_ps( _mm_mul_ps( m_ID->PN4[p1 * 4 + 0], ix[p1] ), _mm_mul_ps( m_ID->PN4[p1 * 4 + 1], iy[p1] ) ), _mm_mul_ps( m_ID->PN4[p1 * 4 + 2], iz[p1] ) );
			const float* ndist = (const float*)reinterpret_cast<const float*>(&ndist4);
			if (!(m_GIVoronoi || m_GIDots))
			{
				if ((m1 == m2) && (m2 == m3) && (m3 == m4) &&
					(fabs( ndist[1] - ndist[0] ) < 1) && (fabs( ndist[2] - ndist[1] ) < 1) && (fabs( ndist[3] - ndist[2] ) < 1))
				{
					const float NX = *(float*)&m_ID->PN4[p1 * 4 + 0], NY = *(float*)&m_ID->PN4[p1 * 4 + 1], NZ = *(float*)&m_ID->PN4[p1 * 4 + 2];
					const float px = ((float*)ix)[p1 * 4], py = ((float*)iy)[p1 * 4], pz = ((float*)iz)[p1 * 4];
					const Cell* restrict c = &grid[igx[0] & (127 + (127 << 7) + (127 << 14))];
					const uint count = c->GetSampleCount();
					__m128 gi4 = zero;
					float totalscale = 0.0001f;
					const SamplingPoint** plist = (const SamplingPoint**)c->GetSamples();
					for ( uint j = 0; j < count; j++ )
					{
						const float dx = plist[j]->pos.x - px, dy = plist[j]->pos.y - py, dz = plist[j]->pos.z - pz;
						const float dist = dx * dx + dy * dy + dz * dz;
						if (dist < (plist[j]->radius * plist[j]->radius))
						{
							const __m128 pgi = plist[j]->GI;
							const float dot = NX * plist[j]->N.x + NY * plist[j]->N.y + NZ * plist[j]->N.z; // is a full dot product really needed?
							if (dot > m_SampleDot)
							{
								const __m128 dist4 = _mm_set_ps1( dist );
								const __m128 scale4 = _mm_sub_ps( _mm_set_ps1( plist[j]->radius ), _mm_mul_ps( dist4, _mm_rsqrt_ps( dist4 ) ) );
								const __m128 scale4a = _mm_mul_ps( _mm_mul_ps( scale4, scale4 ), _mm_set_ps1( (dot - m_SampleDot) * 3.0f ) );
								totalscale += *reinterpret_cast<const float*>(&scale4a);
								gi4 = _mm_add_ps( gi4, _mm_mul_ps( scale4a, pgi ) );
							}
						}
					}
					const __m128 invscale4 = _mm_mul_ps( _mm_set_ps1( 0.003f ), _mm_rcp_ps( _mm_set_ps1( totalscale ) ) );
					float* gi = (float*)&gi4;
					addc4[p1 * 4 + 0] = _mm_add_ps( addc4[p1 * 4 + 0], _mm_mul_ps( _mm_mul_ps( m_ID->colip[p1 * 4 + 0].rgba, invscale4 ), _mm_set_ps1( gi[2] ) ) ); // rrrr
					addc4[p1 * 4 + 1] = _mm_add_ps( addc4[p1 * 4 + 1], _mm_mul_ps( _mm_mul_ps( m_ID->colip[p1 * 4 + 1].rgba, invscale4 ), _mm_set_ps1( gi[1] ) ) ); // gggg
					addc4[p1 * 4 + 2] = _mm_add_ps( addc4[p1 * 4 + 2], _mm_mul_ps( _mm_mul_ps( m_ID->colip[p1 * 4 + 2].rgba, invscale4 ), _mm_set_ps1( gi[0] ) ) ); // bbbb
				}
				else
				{
					const __m128 Nx4 = m_ID->PN4[p1 * 4 + 0]; float* Nx = (float*)&Nx4;
					const __m128 Ny4 = m_ID->PN4[p1 * 4 + 1]; float* Ny = (float*)&Ny4;
					const __m128 Nz4 = m_ID->PN4[p1 * 4 + 2]; float* Nz = (float*)&Nz4;
					union { __m128 totalscale4; float totalscale[4]; };
					totalscale4 = _mm_set_ps1( 0.0001f );
					__m128 gi4[4];
					gi4[0] = gi4[1] = gi4[2] = gi4[3] = _mm_setzero_ps();
					for ( int i = 0; i < 4; i++ )
					{
						const float NX = Nx[i], NY = Ny[i], NZ = Nz[i];
						const float px = ((float*)ix)[p1 * 4 + i], py = ((float*)iy)[p1 * 4 + i], pz = ((float*)iz)[p1 * 4 + i];
						const Cell* restrict c = &grid[igx[i] & (127 + (127 << 7) + (127 << 14))];
						const uint count = c->GetSampleCount();
						const SamplingPoint** plist = (const SamplingPoint**)c->GetSamples();
						for ( uint j = 0; j < count; j++ )
						{
							const float dx = plist[j]->pos.x - px, dy = plist[j]->pos.y - py, dz = plist[j]->pos.z - pz;
							const float dist = dx * dx + dy * dy + dz * dz;
							if (dist < (plist[j]->radius * plist[j]->radius))
							{
								const __m128 pgi = plist[j]->GI;
								const float dot = NX * plist[j]->N.x + NY * plist[j]->N.y + NZ * plist[j]->N.z; // perhaps scale this by dist?
								if (dot > m_SampleDot)
								{
									const __m128 dist4 = _mm_set_ps1( dist );
									const __m128 scale4 = _mm_sub_ps( _mm_set_ps1( plist[j]->radius ), _mm_mul_ps( dist4, _mm_rsqrt_ps( dist4 ) ) );
									const __m128 scale4a = _mm_mul_ps( _mm_mul_ps( scale4, scale4 ), _mm_set_ps1( (dot - m_SampleDot) * 3.0f ) );
									totalscale[i] += *reinterpret_cast<const float*>(&scale4a);
									gi4[i] = _mm_add_ps( gi4[i], _mm_mul_ps( scale4a, pgi ) );
								}
							}
						}
					}
					const __m128 invscale4 = _mm_mul_ps( _mm_set_ps1( 0.003f ), _mm_rcp_ps( totalscale4 ) );
					float* gi = reinterpret_cast<float*>(&gi4);
					addc4[p1 * 4 + 0] = _mm_add_ps( addc4[p1 * 4 + 0], _mm_mul_ps( _mm_mul_ps( m_ID->colip[p1 * 4 + 0].rgba, invscale4 ), _mm_set_ps( gi[14], gi[10], gi[6], gi[2] ) ) );
					addc4[p1 * 4 + 1] = _mm_add_ps( addc4[p1 * 4 + 1], _mm_mul_ps( _mm_mul_ps( m_ID->colip[p1 * 4 + 1].rgba, invscale4 ), _mm_set_ps( gi[13], gi[9], gi[5], gi[1] ) ) );
					addc4[p1 * 4 + 2] = _mm_add_ps( addc4[p1 * 4 + 2], _mm_mul_ps( _mm_mul_ps( m_ID->colip[p1 * 4 + 2].rgba, invscale4 ), _mm_set_ps( gi[12], gi[8], gi[4], gi[0] ) ) );
				}
			}
			else
			{
				const __m128 Nx4 = m_ID->PN4[p1 * 4 + 0]; float* Nx = (float*)&Nx4;
				const __m128 Ny4 = m_ID->PN4[p1 * 4 + 1]; float* Ny = (float*)&Ny4;
				const __m128 Nz4 = m_ID->PN4[p1 * 4 + 2]; float* Nz = (float*)&Nz4;
				union { __m128 totalscale4; float totalscale[4]; };
				totalscale4 = _mm_set_ps1( 0.0001f );
				__m128 gi4[4];
				gi4[0] = gi4[1] = gi4[2] = gi4[3] = _mm_setzero_ps();
				for ( int i = 0; i < 4; i++ )
				{
					const float NX = Nx[i], NY = Ny[i], NZ = Nz[i];
					const float px = ((float*)ix)[p1 * 4 + i], py = ((float*)iy)[p1 * 4 + i], pz = ((float*)iz)[p1 * 4 + i];
					const Cell* restrict c = &grid[igx[i] & (127 + (127 << 7) + (127 << 14))];
					const uint count = c->GetSampleCount();
					const SamplingPoint** plist = (const SamplingPoint**)c->GetSamples();
					if (m_GIDots)
					{
						for ( uint j = 0; j < count; j++ )
						{
							m_Counter1++;
							const float dx = plist[j]->pos.x - px, dy = plist[j]->pos.y - py, dz = plist[j]->pos.z - pz;
							const float dist = dx * dx + dy * dy + dz * dz;
							const float dot = NX * plist[j]->N.x + NY * plist[j]->N.y + NZ * plist[j]->N.z; // is a full dot product really needed?
							// debug dots
							if (dist >= m_SampleSqDist) m_Counter2++;
							if (dot <= m_SampleDot) m_Counter3++;
							if ((dist < 0.02f) && (dot > m_SampleDot)) gi4[i] = _mm_set_ps1( 0.01f );
							if ((dist < 0.0015f) && (dot > m_SampleDot)) gi4[i] = _mm_set_ps1( 0.02f );
						}
					}
					else if (m_GIVoronoi)
					{
						float bestdist = MAXINTDIST;
						for ( uint j = 0; j < count; j++ )
						{
							const float dx = plist[j]->pos.x - px, dy = plist[j]->pos.y - py, dz = plist[j]->pos.z - pz;
							const float dist = dx * dx + dy * dy + dz * dz;
							const float dot = NX * plist[j]->N.x + NY * plist[j]->N.y + NZ * plist[j]->N.z; // is a full dot product really needed?
							if ((dist < bestdist) && (dot > m_SampleDot)) gi4[i] = _mm_mul_ps( _mm_set_ps1( 2 ), plist[j]->GI ), bestdist = dist;
						}
						totalscale4 = _mm_set_ps1( 1.0f );
					}
					else
					{
						for ( uint j = 0; j < count; j++ )
						{
							const float dx = plist[j]->pos.x - px, dy = plist[j]->pos.y - py, dz = plist[j]->pos.z - pz;
							const float dist = dx * dx + dy * dy + dz * dz;
							if (dist < (plist[j]->radius * plist[j]->radius))
							{
								const __m128 pgi = plist[j]->GI;
								const float dot = NX * plist[j]->N.x + NY * plist[j]->N.y + NZ * plist[j]->N.z; // perhaps scale this by dist?
								m_Counter1++;								// total number of points considered
								if (dist >= m_SampleSqDist) m_Counter2++;	// considered points out of range
								if (dot <= m_SampleDot) m_Counter3++;		// considered point has bad normal
								if (dot > m_SampleDot)
								{
									const __m128 dist4 = _mm_set_ps1( dist );
									const __m128 scale4 = _mm_sub_ps( _mm_set_ps1( plist[j]->radius ), _mm_mul_ps( dist4, _mm_rsqrt_ps( dist4 ) ) );
									const __m128 scale4a = _mm_mul_ps( _mm_mul_ps( scale4, scale4 ), _mm_set_ps1( (dot - m_SampleDot) * 3.0f ) );
									totalscale[i] += *reinterpret_cast<const float*>(&scale4a);
									gi4[i] = _mm_add_ps( gi4[i], _mm_mul_ps( scale4a, pgi ) );
								}
							}
						}
					}
				}
				const __m128 invscale4 = _mm_mul_ps( _mm_set_ps1( 0.003f ), _mm_rcp_ps( totalscale4 ) );
				float* gi = reinterpret_cast<float*>(&gi4);
				addc4[p1 * 4 + 0] = _mm_add_ps( addc4[p1 * 4 + 0], _mm_mul_ps( _mm_mul_ps( m_ID->colip[p1 * 4 + 0].rgba, invscale4 ), _mm_set_ps( gi[14], gi[10], gi[6], gi[2] ) ) );
				addc4[p1 * 4 + 1] = _mm_add_ps( addc4[p1 * 4 + 1], _mm_mul_ps( _mm_mul_ps( m_ID->colip[p1 * 4 + 1].rgba, invscale4 ), _mm_set_ps( gi[13], gi[9], gi[5], gi[1] ) ) );
				addc4[p1 * 4 + 2] = _mm_add_ps( addc4[p1 * 4 + 2], _mm_mul_ps( _mm_mul_ps( m_ID->colip[p1 * 4 + 2].rgba, invscale4 ), _mm_set_ps( gi[12], gi[8], gi[4], gi[0] ) ) );
			}
		}
	#endif
		const __m128 t0e = _mm_unpacklo_ps( addc4[p1 * 4 + 2], addc4[p1 * 4 + 1] ), t2e = _mm_unpackhi_ps( addc4[p1 * 4 + 2], addc4[p1 * 4 + 1] );
		const __m128 t1e = _mm_unpacklo_ps( addc4[p1 * 4 + 0], addc4[p1 * 4 + 0] ), t3e = _mm_unpackhi_ps( addc4[p1 * 4 + 0], addc4[p1 * 4 + 0] );
		m_ID->color[r + 0].rgba = _mm_movelh_ps( t0e, t1e ); // TODO: Inefficient for refl
		m_ID->color[r + 1].rgba = _mm_movehl_ps( t1e, t0e );
		m_ID->color[r + 2].rgba = _mm_movelh_ps( t2e, t3e );
		m_ID->color[r + 3].rgba = _mm_movehl_ps( t3e, t2e );
	}
}

// -----------------------------------------------------------
// LineTracer::FindFirstShadow
// Find the first active ray
// -----------------------------------------------------------
void LineTracer::FindFirstShadow( uint& a_First, const BVHNode& a_Node )
{
	// step 1: check if first ray intersects box
	float tmin = 0.00001f, tmax = reinterpret_cast<float*>(m_LID.dist4)[a_First];
	for ( uint axis = 0; axis < 3; ++axis ) 
	{
		const uint idx = axis * PACKETSIZE + a_First;
		const float t0 = (a_Node.min.cell[axis] - m_LOrigin.cell[axis]) * reinterpret_cast<float*>(m_LRP.rdx4)[idx];
		const float t1 = (a_Node.max.cell[axis] - m_LOrigin.cell[axis]) * reinterpret_cast<float*>(m_LRP.rdx4)[idx];
		const float nr = (t0 < t1) ? t0 : t1, fr = (t0 < t1) ? t1 : t0;
		tmin = (tmin < nr) ? nr : tmin, tmax = (fr <  tmax) ? fr : tmax;
	}
	if ((tmin <= tmax) && (m_LID.prim[a_First] == 0)) return;
	if (++a_First > (m_LRP.packetsize - 1)) return;
	// step 2: check if frustum misses box
	if (m_LRP.maxis > -1)
	{
		const float* bounds = (float*)&a_Node;
		unsigned int* signs = reinterpret_cast<unsigned int*>(m_LRP.signs4);
		const __m128 bx4 = _mm_set_ps( bounds[signs[0]], bounds[signs[1]], bounds[signs[2]], bounds[signs[3]] );
		const __m128 by4 = _mm_set_ps( bounds[signs[4]], bounds[signs[5]], bounds[signs[6]], bounds[signs[7]] );
		const __m128 bz4 = _mm_set_ps( bounds[signs[8]], bounds[signs[9]], bounds[signs[10]], bounds[signs[11]] );
		const __m128 dst4 = DOT128( bx4, by4, bz4, m_LRP.nx4, m_LRP.ny4, m_LRP.nz4 );
		if (_mm_movemask_ps( _mm_cmpgt_ps( dst4, m_LRP.D4 ) ) > 0) { a_First = m_LRP.packetsize; return; }
	}
	// step 3: check all rays
	const uint pfirst = a_First >> 2;
	a_First = m_LRP.packetsize;
	const __m128 minx4 = _mm_set_ps1( a_Node.min.x ), maxx4 = _mm_set_ps1( a_Node.max.x );
	const __m128 miny4 = _mm_set_ps1( a_Node.min.y ), maxy4 = _mm_set_ps1( a_Node.max.y );
	const __m128 minz4 = _mm_set_ps1( a_Node.min.z ), maxz4 = _mm_set_ps1( a_Node.max.z );
	const __m128 OX4 = m_LRP.ox4[0], OY4 = m_LRP.oy4[0], OZ4 = m_LRP.oz4[0];
	for ( uint r = pfirst; r < m_LRP.packetq; ++r ) if (_mm_movemask_ps( m_LID.shadow[r] ) != 15)
	{			
		const __m128 tmin4a = small4, tmax4a = m_LID.dist4[r];
		const __m128 t0a = _mm_mul_ps( _mm_sub_ps( minx4, OX4 ), m_LRP.rdx4[r] );
		const __m128 t1a = _mm_mul_ps( _mm_sub_ps( maxx4, OX4 ), m_LRP.rdx4[r] );
		const __m128 nra = _mm_min_ps( t0a, t1a ), fra = _mm_max_ps( t0a, t1a );
		const __m128 tmin4b = _mm_max_ps( tmin4a, nra ), tmax4b = _mm_min_ps( tmax4a, fra );
		const __m128 t0b = _mm_mul_ps( _mm_sub_ps( miny4, OY4 ), m_LRP.rdy4[r] );
		const __m128 t1b = _mm_mul_ps( _mm_sub_ps( maxy4, OY4 ), m_LRP.rdy4[r] );
		const __m128 nrb = _mm_min_ps( t0b, t1b ), frb = _mm_max_ps( t0b, t1b );
		const __m128 tmin4c = _mm_max_ps( tmin4b, nrb ), tmax4c = _mm_min_ps( tmax4b, frb );
		const __m128 t0c = _mm_mul_ps( _mm_sub_ps( minz4, OZ4 ), m_LRP.rdz4[r] );
		const __m128 t1c = _mm_mul_ps( _mm_sub_ps( maxz4, OZ4 ), m_LRP.rdz4[r] );
		const __m128 nrc = _mm_min_ps( t0c, t1c ), frc = _mm_max_ps( t0c, t1c );
		const __m128 tmin4d = _mm_max_ps( tmin4c, nrc ), tmax4d = _mm_min_ps( tmax4c, frc );
		const uint ires = _mm_movemask_ps( _mm_andnot_ps( m_LID.shadow[r], _mm_cmple_ps( tmin4d, tmax4d ) ) ); 
		if (ires) { a_First = r * 4 + m_Offset[ires]; break; }
	}
}

// -----------------------------------------------------------
// LineTracer::FindFirstShadowGeneric
// Find the first active ray
// -----------------------------------------------------------
void LineTracer::FindFirstShadowGeneric( uint& a_First, const BVHNode& a_Node )
{
	// step 1: check if first ray intersects box
	const uint o = m_LRP.offset, qo = m_LRP.qoffset;
	float tmin = 0.00001f, tmax = reinterpret_cast<float*>(m_LID.dist4)[a_First + o];
	for ( uint axis = 0; axis < 3; ++axis ) 
	{
		const uint idx = axis * PACKETSIZE + a_First + o;
		const float t0 = (a_Node.min.cell[axis] - m_LOrigin.cell[axis]) * reinterpret_cast<float*>(m_LRP.rdx4)[idx];
		const float t1 = (a_Node.max.cell[axis] - m_LOrigin.cell[axis]) * reinterpret_cast<float*>(m_LRP.rdx4)[idx];
		const float nr = (t0 < t1) ? t0 : t1, fr = (t0 < t1) ? t1 : t0;
		tmin = (tmin < nr) ? nr : tmin, tmax = (fr <  tmax) ? fr : tmax;
	}
	if (tmin <= tmax && m_LID.prim[a_First + o] == 0) return;
	if (++a_First > (m_LRP.packetsize - 1)) return;
	// step 2: check if frustum misses box
	if (m_LRP.maxis > -1)
	{
		const float* bounds = (float*)&a_Node;
		unsigned int* signs = reinterpret_cast<unsigned int*>(m_LRP.signs4);
		const __m128 bx4 = _mm_set_ps( bounds[signs[0]], bounds[signs[1]], bounds[signs[2]], bounds[signs[3]] );
		const __m128 by4 = _mm_set_ps( bounds[signs[4]], bounds[signs[5]], bounds[signs[6]], bounds[signs[7]] );
		const __m128 bz4 = _mm_set_ps( bounds[signs[8]], bounds[signs[9]], bounds[signs[10]], bounds[signs[11]] );
		const __m128 dst4 = DOT128( bx4, by4, bz4, m_LRP.nx4, m_LRP.ny4, m_LRP.nz4 );
		if (_mm_movemask_ps( _mm_cmpgt_ps( dst4, m_LRP.D4 ) ) > 0) { a_First = m_LRP.packetsize; return; }
	}
	// step 3: check all rays
	const uint pfirst = a_First >> 2;
	a_First = m_LRP.packetsize;
	const __m128 minx4 = _mm_set_ps1( a_Node.min.x ), maxx4 = _mm_set_ps1( a_Node.max.x );
	const __m128 miny4 = _mm_set_ps1( a_Node.min.y ), maxy4 = _mm_set_ps1( a_Node.max.y );
	const __m128 minz4 = _mm_set_ps1( a_Node.min.z ), maxz4 = _mm_set_ps1( a_Node.max.z );
	const __m128 OX4 = m_LRP.ox4[0], OY4 = m_LRP.oy4[0], OZ4 = m_LRP.oz4[0];
	for ( uint r = pfirst; r < m_LRP.packetq; ++r ) if (_mm_movemask_ps( m_LID.shadow[r + qo] ) != 15)
	{			
		const __m128 tmin4a = small4, tmax4a = m_LID.dist4[r + qo];
		const __m128 t0a = _mm_mul_ps( _mm_sub_ps( minx4, OX4 ), m_LRP.rdx4[r + qo] );
		const __m128 t1a = _mm_mul_ps( _mm_sub_ps( maxx4, OX4 ), m_LRP.rdx4[r + qo] );
		const __m128 nra = _mm_min_ps( t0a, t1a ), fra = _mm_max_ps( t0a, t1a );
		const __m128 tmin4b = _mm_max_ps( tmin4a, nra ), tmax4b = _mm_min_ps( tmax4a, fra );
		const __m128 t0b = _mm_mul_ps( _mm_sub_ps( miny4, OY4 ), m_LRP.rdy4[r + qo] );
		const __m128 t1b = _mm_mul_ps( _mm_sub_ps( maxy4, OY4 ), m_LRP.rdy4[r + qo] );
		const __m128 nrb = _mm_min_ps( t0b, t1b ), frb = _mm_max_ps( t0b, t1b );
		const __m128 tmin4c = _mm_max_ps( tmin4b, nrb ), tmax4c = _mm_min_ps( tmax4b, frb );
		const __m128 t0c = _mm_mul_ps( _mm_sub_ps( minz4, OZ4 ), m_LRP.rdz4[r + qo] );
		const __m128 t1c = _mm_mul_ps( _mm_sub_ps( maxz4, OZ4 ), m_LRP.rdz4[r + qo] );
		const __m128 nrc = _mm_min_ps( t0c, t1c ), frc = _mm_max_ps( t0c, t1c );
		const __m128 tmin4d = _mm_max_ps( tmin4c, nrc ), tmax4d = _mm_min_ps( tmax4c, frc );
		const uint ires = _mm_movemask_ps( _mm_andnot_ps( m_LID.shadow[r + qo], _mm_cmple_ps( tmin4d, tmax4d ) ) ); 
		if (ires) { a_First = r * 4 + m_Offset[ires]; break; }
	}
}

// -----------------------------------------------------------
// LineTracer::IntersectPrimary
// Check a triangle
// -----------------------------------------------------------
void LineTracer::IntersectPrimary( const uint a_First, const Primitive& a_Prim )
{
#ifdef SUPPORTSPHERES
	if (a_Prim.GetType() == Primitive::PRIM_SPHERE)
	{
		int pfirst = a_First >> 2;
		const __m128 dstx4 = _mm_sub_ps( m_Ox4, _mm_set_ps1( a_Prim.m_N.x ) );
		const __m128 dsty4 = _mm_sub_ps( m_Oy4, _mm_set_ps1( a_Prim.m_N.y ) );
		const __m128 dstz4 = _mm_sub_ps( m_Oz4, _mm_set_ps1( a_Prim.m_N.z ) );
		const __m128 sqrad4 = _mm_set_ps1( a_Prim.m_T.y );
		const __m128i prim4 = _mm_set1_epi32( (uint)&a_Prim );
		for ( unsigned int r = pfirst; r < m_RP->packetq; r++ )
		{
			const __m128 B4 = _mm_add_ps( _mm_add_ps( _mm_mul_ps( dstx4, m_RP->dx4[r] ), _mm_mul_ps( dsty4, m_RP->dy4[r] ) ), _mm_mul_ps( dstz4, m_RP->dz4[r] ) );
			const __m128 C4 = _mm_sub_ps( _mm_add_ps( _mm_add_ps( _mm_mul_ps( dstx4, dstx4 ), _mm_mul_ps( dsty4, dsty4 ) ), _mm_mul_ps( dstz4, dstz4 ) ), sqrad4 );
			const __m128 d4 = _mm_sub_ps( _mm_mul_ps( B4, B4 ), C4 );
			const __m128 dist4 = _mm_sub_ps( _mm_sub_ps( zero, B4 ), _mm_sqrt_ps( d4 ) );
			const __m128 mask4 = _mm_and_ps( _mm_cmpgt_ps( dist4, epsilon ), _mm_cmplt_ps( dist4, m_ID->dist4[r] ) );
			const __m128i* imask4 = (const __m128i*)reinterpret_cast<const __m128*>(&mask4);
			m_ID->dist4[r] = _mm_or_ps( _mm_andnot_ps( mask4, m_ID->dist4[r] ), _mm_and_ps( mask4, dist4 ) );
			m_ID->prim4[r] = _mm_or_si128( _mm_andnot_si128( *imask4, m_ID->prim4[r] ), _mm_and_si128( *imask4, prim4 ) );
		}
		return;
	}
#endif
	const vector3 ao = a_Prim.m_Vertex[0]->m_Pos - m_Origin;
	if ((ao.x * a_Prim.m_N.x + ao.y * a_Prim.m_N.y + ao.z * a_Prim.m_N.z) < 0) return;
	const vector3 bo = a_Prim.m_Vertex[1]->m_Pos - m_Origin;
	const vector3 co = a_Prim.m_Vertex[2]->m_Pos - m_Origin;
	// test against frustum
	if (m_RP->maxis != -1)
	{
		const __m128 vala = DOT128( m_RP->nx4, m_RP->ny4, m_RP->nz4, _mm_set_ps1( ao.x ), _mm_set_ps1( ao.y ), _mm_set_ps1( ao.z ) );
		const __m128 valb = DOT128( m_RP->nx4, m_RP->ny4, m_RP->nz4, _mm_set_ps1( bo.x ), _mm_set_ps1( bo.y ), _mm_set_ps1( bo.z ) );
		const __m128 valc = DOT128( m_RP->nx4, m_RP->ny4, m_RP->nz4, _mm_set_ps1( co.x ), _mm_set_ps1( co.y ), _mm_set_ps1( co.z ) );
		const uint32 ires = (_mm_movemask_ps( vala ) ^ 15) & (_mm_movemask_ps( valb ) ^ 15) & (_mm_movemask_ps( valc ) ^ 15);
		if (ires) return;
	}
	const vector3 v0c = co^bo;
	const __m128 v0c4x = broadcastss( &v0c.x ), v0c4y = broadcastss( &v0c.y ), v0c4z = broadcastss( &v0c.z );
	const vector3 v1c = bo^ao;
	const __m128 v1c4x = broadcastss( &v1c.x ), v1c4y = broadcastss( &v1c.y ), v1c4z = broadcastss( &v1c.z );
	const vector3 v2c = ao^co;
	const __m128 v2c4x = broadcastss( &v2c.x ), v2c4y = broadcastss( &v2c.y ), v2c4z = broadcastss( &v2c.z );
#ifdef GATHERSTATS
	m_NCInts++;
#endif
	if (m_RP->packetq == PACKETQ)
	{
		// half-plane 1
		bool active[4] = { true, true, true, true };
		const float dist1a = DOT( ao, m_RP->hn1 ), dist2a = DOT( bo, m_RP->hn1 ), dist3a = DOT( co, m_RP->hn1 );
		if ((dist1a >= 0) && (dist2a >= 0) && (dist3a >= 0)) active[0] = active[1] = false;
		if ((dist1a <= 0) && (dist2a <= 0) && (dist3a <= 0)) active[2] = active[3] = false;
		// half-plane 2
		const float dist1b = DOT( ao, m_RP->hn2 ), dist2b = DOT( bo, m_RP->hn2 ), dist3b = DOT( co, m_RP->hn2 );
		if ((dist1b >= 0) && (dist2b >= 0) && (dist3b >= 0)) active[1] = active[3] = false;
		if ((dist1b <= 0) && (dist2b <= 0) && (dist3b <= 0)) active[0] = active[2] = false;
		// intersection test
		const __m128 n4x = broadcastss( &a_Prim.m_N.x ), n4y = broadcastss( &a_Prim.m_N.y ), n4z = broadcastss( &a_Prim.m_N.z );
		const __m128 nominator = _mm_set_ps1( a_Prim.m_N.x * ao.x + a_Prim.m_N.y * ao.y + a_Prim.m_N.z * ao.z );
		uint pfirst = a_First >> 2;
		const __m128i prim4 = _mm_set1_epi32( (uint)&a_Prim );
		for ( uint q = 0; q < 4; q++ ) if (active[q])
		{
			if (pfirst >= ((q + 1) * 16)) continue;
			if (pfirst < (q * 16)) pfirst = q * 16;
			const uint plast = q * 16 + 16;
			for ( uint r = pfirst; r < plast; ++r )
			{
				const __m128 v0d = DOT128( v0c4x, v0c4y, v0c4z, m_RP->dx4[r], m_RP->dy4[r], m_RP->dz4[r] );
				const uint v0s = _mm_movemask_ps( v0d );
				const __m128 v1d = DOT128( v1c4x, v1c4y, v1c4z, m_RP->dx4[r], m_RP->dy4[r], m_RP->dz4[r] );
				const uint v1s = _mm_movemask_ps( v1d );
				const __m128 v2d = DOT128( v2c4x, v2c4y, v2c4z, m_RP->dx4[r], m_RP->dy4[r], m_RP->dz4[r] );
				const uint v2s = _mm_movemask_ps( v2d );
				if ((v0s|v1s|v2s) < 15)
				{
					const __m128 rdn = DOT128( n4x, n4y, n4z, m_RP->dx4[r], m_RP->dy4[r], m_RP->dz4[r] );
					const uint tmask = ((v0s^0xf) & (v1s^0xf) & (v2s^0xf));
					const __m128 t4 = _mm_mul_ps( nominator, fastrcp( rdn ) );
					const __m128 mask4 = _mm_and_ps( masktable4[tmask], _mm_cmple_ps( t4, m_ID->dist4[r] ) );
					if (_mm_movemask_ps( mask4 ))
					{
						m_ID->dist4[r] = _mm_or_ps( _mm_andnot_ps( mask4, m_ID->dist4[r] ), _mm_and_ps( mask4, t4 ) );
					#ifndef MINIMALSHADING
					#ifdef _WIN64
						uint32 imask = _mm_movemask_ps( mask4 );
						if (imask & 1) m_ID->prim[r * 4 + 0] = (Primitive*)a_Prim;
						if (imask & 2) m_ID->prim[r * 4 + 1] = (Primitive*)a_Prim;
						if (imask & 4) m_ID->prim[r * 4 + 2] = (Primitive*)a_Prim;
						if (imask & 8) m_ID->prim[r * 4 + 3] = (Primitive*)a_Prim;
					#else
						m_ID->prim4[r] = _mm_or_si128( _mm_andnot_si128( *reinterpret_cast<const __m128i*>(&mask4), m_ID->prim4[r] ), 
													   _mm_and_si128( *reinterpret_cast<const __m128i*>(&mask4), prim4 ) );
					#endif
						const __m128 v0l = _mm_rcp_ps( _mm_add_ps( _mm_add_ps( v0d, v1d ), v2d ) );
						const __m128 u4 = _mm_mul_ps( v2d, v0l ), v4 = _mm_mul_ps( v1d, v0l );
						m_ID->u4[r] = _mm_or_ps( _mm_andnot_ps( mask4, m_ID->u4[r] ), _mm_and_ps( mask4, u4 ) );
						m_ID->v4[r] = _mm_or_ps( _mm_andnot_ps( mask4, m_ID->v4[r] ), _mm_and_ps( mask4, v4 ) );
					#endif
					}
				}
			}
		}
	}
	else
	{
		// intersection test
		uint pfirst = a_First >> 2;
		const __m128 n4x = broadcastss( &a_Prim.m_N.x ), n4y = broadcastss( &a_Prim.m_N.y ), n4z = broadcastss( &a_Prim.m_N.z );
		const __m128 nominator = _mm_set_ps1( a_Prim.m_N.x * ao.x + a_Prim.m_N.y * ao.y + a_Prim.m_N.z * ao.z );
		const __m128i prim4 = _mm_set1_epi32( (uint)&a_Prim );
		for ( uint r = pfirst; r < m_RP->packetq; ++r )
		{
			const __m128 v0d = DOT128( v0c4x, v0c4y, v0c4z, m_RP->dx4[r], m_RP->dy4[r], m_RP->dz4[r] );
			const uint32 v0s = _mm_movemask_ps( v0d );
			const __m128 v1d = DOT128( v1c4x, v1c4y, v1c4z, m_RP->dx4[r], m_RP->dy4[r], m_RP->dz4[r] );
			const uint32 v1s = _mm_movemask_ps( v1d );
			const __m128 v2d = DOT128( v2c4x, v2c4y, v2c4z, m_RP->dx4[r], m_RP->dy4[r], m_RP->dz4[r] );
			const uint32 v2s = _mm_movemask_ps( v2d );
			if ((v0s|v1s|v2s) < 15)
			{
				const __m128 rdn = DOT128( n4x, n4y, n4z, m_RP->dx4[r], m_RP->dy4[r], m_RP->dz4[r] );
				const uint32 tmask = ((v0s^0xf) & (v1s^0xf) & (v2s^0xf));
				const __m128 t4 = _mm_mul_ps( nominator, fastrcp( rdn ) );
				const __m128 mask4 = _mm_and_ps( masktable4[tmask], _mm_cmple_ps( t4, m_ID->dist4[r] ) );
				if (_mm_movemask_ps( mask4 ))
				{
					m_ID->dist4[r] = _mm_or_ps( _mm_andnot_ps( mask4, m_ID->dist4[r] ), _mm_and_ps( mask4, t4 ) );
				#ifndef MINIMALSHADING
				#ifdef _WIN64
					uint32 imask32 = _mm_movemask_ps( mask4 );
					if (imask32 & 1) m_ID->prim[r * 4 + 0] = (Primitive*)a_Prim;
					if (imask32 & 2) m_ID->prim[r * 4 + 1] = (Primitive*)a_Prim;
					if (imask32 & 4) m_ID->prim[r * 4 + 2] = (Primitive*)a_Prim;
					if (imask32 & 8) m_ID->prim[r * 4 + 3] = (Primitive*)a_Prim;
				#else
					m_ID->prim4[r] = _mm_or_si128( _mm_andnot_si128( *reinterpret_cast<const __m128i*>(&mask4), m_ID->prim4[r] ), _mm_and_si128( *reinterpret_cast<const __m128i*>(&mask4), prim4 ) );
				#endif
					const __m128 v0l = _mm_rcp_ps( _mm_add_ps( _mm_add_ps( v0d, v1d ), v2d ) );
					const __m128 u4 = _mm_mul_ps( v2d, v0l ), v4 = _mm_mul_ps( v1d, v0l );
					m_ID->u4[r] = _mm_or_ps( _mm_andnot_ps( mask4, m_ID->u4[r] ), _mm_and_ps( mask4, u4 ) );
					m_ID->v4[r] = _mm_or_ps( _mm_andnot_ps( mask4, m_ID->v4[r] ), _mm_and_ps( mask4, v4 ) );
				#endif
				}
			}
		}
	}
}

// -----------------------------------------------------------
// LineTracer::IntersectShadow
// Check a triangle
// -----------------------------------------------------------
void LineTracer::IntersectShadow( const uint a_First, const Primitive& a_Prim )
{
#ifdef SUPPORTSPHERES
	if (a_Prim.GetType() == Primitive::PRIM_SPHERE)
	{
		int pfirst = a_First >> 2;
		const __m128 dstx4 = _mm_sub_ps( m_LRP.ox4[0], _mm_set_ps1( a_Prim.m_N.x ) );
		const __m128 dsty4 = _mm_sub_ps( m_LRP.oy4[0], _mm_set_ps1( a_Prim.m_N.y ) );
		const __m128 dstz4 = _mm_sub_ps( m_LRP.oz4[0], _mm_set_ps1( a_Prim.m_N.z ) );
		const __m128 sqrad4 = _mm_set_ps1( a_Prim.m_T.y );
		for ( unsigned int r = pfirst; r < m_LRP.packetq; r++ ) if (_mm_movemask_ps( m_LID.shadow[r] ) != 15)
		{
			const __m128 B4 = _mm_add_ps( _mm_add_ps( _mm_mul_ps( dstx4, m_LRP.dx4[r] ), _mm_mul_ps( dsty4, m_LRP.dy4[r] ) ), _mm_mul_ps( dstz4, m_LRP.dz4[r] ) );
			const __m128 C4 = _mm_sub_ps( _mm_add_ps( _mm_add_ps( _mm_mul_ps( dstx4, dstx4 ), _mm_mul_ps( dsty4, dsty4 ) ), _mm_mul_ps( dstz4, dstz4 ) ), sqrad4 );
			const __m128 d4 = _mm_sub_ps( _mm_mul_ps( B4, B4 ), C4 );
			const __m128 dist4 = _mm_sub_ps( _mm_sub_ps( zero, B4 ), _mm_sqrt_ps( d4 ) );
			const __m128 mask4 = _mm_and_ps( _mm_cmpgt_ps( dist4, epsilon ), _mm_cmplt_ps( dist4, m_LID.dist4[r] ) );
			m_LID.shadow[r] = _mm_or_ps( m_LID.shadow[r], mask4 );
		}
		return;
	}
#endif
	const vector3 ao = a_Prim.m_Vertex[0]->m_Pos - m_LOrigin;
	if ((ao.x * a_Prim.m_N.x + ao.y * a_Prim.m_N.y + ao.z * a_Prim.m_N.z) < 0) return;
	const vector3 bo = a_Prim.m_Vertex[1]->m_Pos - m_LOrigin;
	const vector3 co = a_Prim.m_Vertex[2]->m_Pos - m_LOrigin;
	// test against frustum
	if (m_LRP.maxis != -1)
	{
		const __m128 vala = DOT128( m_LRP.nx4, m_LRP.ny4, m_LRP.nz4, _mm_set_ps1( ao.x ), _mm_set_ps1( ao.y ), _mm_set_ps1( ao.z ) );
		const __m128 valb = DOT128( m_LRP.nx4, m_LRP.ny4, m_LRP.nz4, _mm_set_ps1( bo.x ), _mm_set_ps1( bo.y ), _mm_set_ps1( bo.z ) );
		const __m128 valc = DOT128( m_LRP.nx4, m_LRP.ny4, m_LRP.nz4, _mm_set_ps1( co.x ), _mm_set_ps1( co.y ), _mm_set_ps1( co.z ) );
		const uint32 ires = (_mm_movemask_ps( vala ) ^ 15) & (_mm_movemask_ps( valb ) ^ 15) & (_mm_movemask_ps( valc ) ^ 15);
		if (ires) return;
	}
	const vector3 v0c = co^bo;
	const __m128 v0c4x = broadcastss( &v0c.x ), v0c4y = broadcastss( &v0c.y ), v0c4z = broadcastss( &v0c.z );
	const vector3 v1c = bo^ao;
	const __m128 v1c4x = broadcastss( &v1c.x ), v1c4y = broadcastss( &v1c.y ), v1c4z = broadcastss( &v1c.z );
	const vector3 v2c = ao^co;
	const __m128 v2c4x = broadcastss( &v2c.x ), v2c4y = broadcastss( &v2c.y ), v2c4z = broadcastss( &v2c.z );
#ifdef GATHERSTATS
	m_NCInts++;
#endif
	// intersection test
	const __m128 n4x = broadcastss( &a_Prim.m_N.x ), n4y = broadcastss( &a_Prim.m_N.y ), n4z = broadcastss( &a_Prim.m_N.z );
	const __m128 nominator = _mm_set_ps1( a_Prim.m_N.x * ao.x + a_Prim.m_N.y * ao.y + a_Prim.m_N.z * ao.z );
	uint pfirst = a_First >> 2;
	for ( uint r = pfirst; r < m_LRP.packetq; ++r ) if (_mm_movemask_ps( m_LID.shadow[r] ) != 15)
	{
		const __m128 v0d = DOT128( v0c4x, v0c4y, v0c4z, m_LRP.dx4[r], m_LRP.dy4[r], m_LRP.dz4[r] );
		const uint32 v0s = _mm_movemask_ps( v0d );
		const __m128 v1d = DOT128( v1c4x, v1c4y, v1c4z, m_LRP.dx4[r], m_LRP.dy4[r], m_LRP.dz4[r] );
		const uint32 v1s = _mm_movemask_ps( v1d );
		const __m128 v2d = DOT128( v2c4x, v2c4y, v2c4z, m_LRP.dx4[r], m_LRP.dy4[r], m_LRP.dz4[r] );
		const uint32 v2s = _mm_movemask_ps( v2d );
		if ((v0s|v1s|v2s) < 15)
		{
			const uint32 tmask = ((v0s^0xf) & (v1s^0xf) & (v2s^0xf));
			const __m128 rdn = DOT128( n4x, n4y, n4z, m_LRP.dx4[r], m_LRP.dy4[r], m_LRP.dz4[r] );
			const __m128 t4 = _mm_mul_ps( nominator, _mm_rcp_ps( rdn ) );
			const __m128 mask4 = _mm_and_ps( masktable4[tmask], _mm_cmple_ps( t4, m_LID.dist4[r] ) );
			m_LID.shadow[r] = _mm_or_ps( m_LID.shadow[r], mask4 );
		}
	}
}

// -----------------------------------------------------------
// LineTracer::IntersectShadowGeneric
// Check a triangle
// -----------------------------------------------------------
void LineTracer::IntersectShadowGeneric( const uint a_First, const Primitive& a_Prim )
{
#ifdef SUPPORTSPHERES
	if (a_Prim.GetType() == Primitive::PRIM_SPHERE)
	{
		for ( unsigned int r = a_First; r < m_LRP.packetsize; r++ ) if (!m_LID.prim[r])
		{
			vector3 D( reinterpret_cast<float*>(m_LRP.dx4)[r], reinterpret_cast<float*>(m_LRP.dy4)[r], reinterpret_cast<float*>(m_LRP.dz4)[r] );
			vector3 dst = m_LOrigin - a_Prim.m_N;
			float B = DOT( dst, D );
			float C = DOT( dst, dst ) - a_Prim.m_T.y;
			float d = B * B - C;
			float dist = -B - sqrtf( d );
			if ((dist > 0) && (dist < reinterpret_cast<float*>(m_LID.dist4)[r])) m_LID.prim[r] = (Primitive*)0xffffffff;
		}
		return;
	}
#endif	
	const vector3 ao = a_Prim.m_Vertex[0]->m_Pos - m_LOrigin;
	if ((ao.x * a_Prim.m_N.x + ao.y * a_Prim.m_N.y + ao.z * a_Prim.m_N.z) < 0) return;
	const vector3 bo = a_Prim.m_Vertex[1]->m_Pos - m_LOrigin;
	const vector3 co = a_Prim.m_Vertex[2]->m_Pos - m_LOrigin;
	// test against frustum
	if (m_LRP.maxis != -1)
	{
		const __m128 vala = DOT128( m_LRP.nx4, m_LRP.ny4, m_LRP.nz4, _mm_set_ps1( ao.x ), _mm_set_ps1( ao.y ), _mm_set_ps1( ao.z ) );
		const __m128 valb = DOT128( m_LRP.nx4, m_LRP.ny4, m_LRP.nz4, _mm_set_ps1( bo.x ), _mm_set_ps1( bo.y ), _mm_set_ps1( bo.z ) );
		const __m128 valc = DOT128( m_LRP.nx4, m_LRP.ny4, m_LRP.nz4, _mm_set_ps1( co.x ), _mm_set_ps1( co.y ), _mm_set_ps1( co.z ) );
		const uint32 ires = (_mm_movemask_ps( vala ) ^ 15) & (_mm_movemask_ps( valb ) ^ 15) & (_mm_movemask_ps( valc ) ^ 15);
		if (ires) return;
	}
	const vector3 v0c = co^bo;
	const __m128 v0c4x = broadcastss( &v0c.x ), v0c4y = broadcastss( &v0c.y ), v0c4z = broadcastss( &v0c.z );
	const vector3 v1c = bo^ao;
	const __m128 v1c4x = broadcastss( &v1c.x ), v1c4y = broadcastss( &v1c.y ), v1c4z = broadcastss( &v1c.z );
	const vector3 v2c = ao^co;
	const __m128 v2c4x = broadcastss( &v2c.x ), v2c4y = broadcastss( &v2c.y ), v2c4z = broadcastss( &v2c.z );
#ifdef GATHERSTATS
	m_NCInts++;
#endif
	// intersection test
	const __m128 n4x = broadcastss( &a_Prim.m_N.x ), n4y = broadcastss( &a_Prim.m_N.y ), n4z = broadcastss( &a_Prim.m_N.z );
	const __m128 nominator = _mm_set_ps1( a_Prim.m_N.x * ao.x + a_Prim.m_N.y * ao.y + a_Prim.m_N.z * ao.z );
	uint pfirst = a_First >> 2;
	const uint qo = m_LRP.qoffset;
	for ( uint r = pfirst; r < m_LRP.packetq; ++r ) if (_mm_movemask_ps( m_LID.shadow[r + qo] ) != 15)
	{
		const uint ro = r + qo;
		const __m128 v0d = DOT128( v0c4x, v0c4y, v0c4z, m_LRP.dx4[ro], m_LRP.dy4[ro], m_LRP.dz4[ro] );
		const uint32 v0s = _mm_movemask_ps( v0d );
		const __m128 v1d = DOT128( v1c4x, v1c4y, v1c4z, m_LRP.dx4[ro], m_LRP.dy4[ro], m_LRP.dz4[ro] );
		const uint32 v1s = _mm_movemask_ps( v1d );
		const __m128 v2d = DOT128( v2c4x, v2c4y, v2c4z, m_LRP.dx4[ro], m_LRP.dy4[ro], m_LRP.dz4[ro] );
		const uint32 v2s = _mm_movemask_ps( v2d );
		if ((v0s|v1s|v2s) < 15)
		{
			const uint32 tmask = ((v0s^0xf) & (v1s^0xf) & (v2s^0xf));
			const __m128 rdn = DOT128( n4x, n4y, n4z, m_LRP.dx4[ro], m_LRP.dy4[ro], m_LRP.dz4[ro] );
			const __m128 t4 = _mm_mul_ps( nominator, _mm_rcp_ps( rdn ) );
			const __m128 mask4 = _mm_and_ps( masktable4[tmask], _mm_cmple_ps( t4, m_LID.dist4[ro] ) );
			m_LID.shadow[ro] = _mm_or_ps( m_LID.shadow[ro], mask4 );
		}
	}
}

// -----------------------------------------------------------
// LineTracer::PrepShadowPacket
// Prepare packet for shadow tracing
// -----------------------------------------------------------
void LineTracer::PrepShadowPacket( const Light& a_Light )
{
	// prepare packet 
	const __m128 tenth4 = _mm_set_ps1( 0.9995f ); 
	const __m128 ones = _mm_cmpeq_ps( tenth4, tenth4 ); 
	if (a_Light.Shadows())
	{
	#ifdef GATHERSTATS
		m_Rays += m_RP->packetsize; 
	#endif
		m_LOrigin = a_Light.GetPos(); 
		const uint qo = m_RP->qoffset;
		m_LRP.SetOrigin4( 0, a_Light.cx4, a_Light.cy4, a_Light.cz4 );
		for ( uint r = 0; r < m_RP->packetq; ++r ) if (_mm_movemask_ps( m_RP->mask4[r + qo])) 
		{ 
			const uint ro = r + qo;
			m_LRP.dx4[ro] = _mm_sub_ps( _mm_add_ps( m_RP->ox4[ro], _mm_mul_ps( m_RP->dx4[ro], m_ID->dist4[ro] ) ), a_Light.cx4 ); 
			m_LRP.dy4[ro] = _mm_sub_ps( _mm_add_ps( m_RP->oy4[ro], _mm_mul_ps( m_RP->dy4[ro], m_ID->dist4[ro] ) ), a_Light.cy4 ); 
			m_LRP.dz4[ro] = _mm_sub_ps( _mm_add_ps( m_RP->oz4[ro], _mm_mul_ps( m_RP->dz4[ro], m_ID->dist4[ro] ) ), a_Light.cz4 ); 
		#ifdef SUPPORTSPHERES
			const __m128 v1 = fastrsqrt( _mm_add_ps( _mm_add_ps( _mm_mul_ps( m_LRP.dx4[ro], m_LRP.dx4[ro] ), _mm_mul_ps( m_LRP.dy4[ro], m_LRP.dy4[ro] ) ), _mm_mul_ps( m_LRP.dz4[ro], m_LRP.dz4[ro] ) ) ); 
		#else
			const __m128 v1 = _mm_rsqrt_ps( _mm_add_ps( _mm_add_ps( _mm_mul_ps( m_LRP.dx4[ro], m_LRP.dx4[ro] ), _mm_mul_ps( m_LRP.dy4[ro], m_LRP.dy4[ro] ) ), _mm_mul_ps( m_LRP.dz4[ro], m_LRP.dz4[ro] ) ) ); 
		#endif
			m_LID.dist4[ro] = _mm_mul_ps( fastrcp( v1 ), tenth4 ); 
			m_LRP.ScaleDirection4( r + qo, v1 ); 
			m_LRP.CalcReciprocal4( r + qo ); 
			m_LID.shadow[ro] = _mm_or_ps( _mm_cmpge_ps(m_LID.dist4[ro], a_Light.GetRadius4()) , _mm_andnot_ps( m_RP->mask4[ro], ones )); 
		} 
		else m_LID.shadow[r + qo] = ones; 
	#ifndef ALTFIRST
		m_LRP.UpdateSigns();
	#endif
	}
	else
	{
		const uint qo = m_RP->qoffset;
		for ( uint r = 0; r < m_RP->packetq; ++r ) if (_mm_movemask_ps( m_RP->mask4[r + qo])) 
		{ 
			const uint ro = r + qo;
			m_LRP.dx4[ro] = _mm_sub_ps( _mm_add_ps( m_RP->ox4[ro], _mm_mul_ps( m_RP->dx4[ro], m_ID->dist4[ro] ) ), a_Light.cx4 ); 
			m_LRP.dy4[ro] = _mm_sub_ps( _mm_add_ps( m_RP->oy4[ro], _mm_mul_ps( m_RP->dy4[ro], m_ID->dist4[ro] ) ), a_Light.cy4 ); 
			m_LRP.dz4[ro] = _mm_sub_ps( _mm_add_ps( m_RP->oz4[ro], _mm_mul_ps( m_RP->dz4[ro], m_ID->dist4[ro] ) ), a_Light.cz4 ); 
			const __m128 v1 = _mm_rsqrt_ps( _mm_add_ps( _mm_add_ps( _mm_mul_ps( m_LRP.dx4[ro], m_LRP.dx4[ro] ), _mm_mul_ps( m_LRP.dy4[ro], m_LRP.dy4[ro] ) ), _mm_mul_ps( m_LRP.dz4[ro], m_LRP.dz4[ro] ) ) ); 
			m_LID.dist4[ro] = _mm_sub_ps( fastrcp( v1 ), tenth4 ); 
			m_LRP.ScaleDirection4( r + qo, v1 ); 
			m_LID.shadow[ro] = _mm_or_ps( _mm_cmpge_ps(m_LID.dist4[ro], a_Light.GetRadius4()) , _mm_andnot_ps( m_RP->mask4[ro], ones )); 
		} 
		else m_LID.shadow[r + qo] = ones; 
	}
}

// -----------------------------------------------------------
// LineTracer::DoShadowRays
// Geometry factor
// -----------------------------------------------------------
void LineTracer::DoShadowRays( const Light& a_Light )
{
	// prepare packet 
#ifdef GATHERSTATS
	m_Rays += m_RP->packetsize; 
#endif
	m_LOrigin = a_Light.GetPos(); 
#ifndef ALTFIRST
	m_LRP.UpdateSigns();
#else
	// calculate quadrant
	unsigned int quad = ((reinterpret_cast<float*>(m_LRP.dx4)[0] < 0)?1:0) + 
						((reinterpret_cast<float*>(m_LRP.dy4)[0] < 0)?2:0) + 
						((reinterpret_cast<float*>(m_LRP.dz4)[0] < 0)?4:0);
#endif
	// traverse
	m_LRP.packetq = m_RP->packetq, m_LRP.packetsize = m_RP->packetsize;
	m_LRP.offset = m_LRP.qoffset = 0;
	m_LRP.BuildPlanesShadow( m_LOrigin );
	uint stackptr = 0, first = 0;
	BVHNode* node = SceneGraph::GetSceneRoot();		// TODO: make this thread-local
	BVHNode* pool = MManager::GetBVHPool();			// TODO: make this thread-local
	Primitive** prim = MManager::GetBVHPrims();		// TODO: make this thread-local
	while (1)
	{
		// find first active ray (if any)
		FindFirstShadow( first, *node );
		if (first < m_LRP.packetsize)
		{
			// process results
			if (!node->IsLeaf())
			{
			#ifndef ALTFIRST
				const uint lidx = m_LRP.sign[first + (node->GetAxis() << (PACKETSHFT * 2))] ^ (node->data >> 31);
			#else
				const uint lidx = (node->GetDirMask() >> quad) & 1;
			#endif
				m_Stack[stackptr].node = &pool[node->GetLeft() + 1 - lidx];
				m_Stack[stackptr++].first = first;
				node = &pool[node->GetLeft() + lidx];
				continue;
			}
			else
			{
				// intersect
				const uint start = node->GetStart(), count = node->GetTCount();
				for ( uint i = 0; i < count; ++i )
				{
					Primitive* pr = prim[start + i];
					if (pr->GetMaterial()->CastsShadow()) IntersectShadow( first, *pr );
				}
			#ifdef GATHERSTATS
				m_Leafs++, m_Ints += count;
			#endif
			}
		}
		if (!stackptr) break;
		node = m_Stack[--stackptr].node, first = m_Stack[stackptr].first;
	}
}

// -----------------------------------------------------------
// RayPacket::BuildPlanesGeneric
// Construct a frustum for reflected and refracted rays
// -----------------------------------------------------------
void RayPacket::BuildPlanesGeneric()
{   
	FindDominantAxisGeneric();
	if (maxis < 0) return;
	const uint a = maxis;
	const uint u = (a + 1) % 3, v = (a + 2) % 3;
	// find maximum and minimum slopes
	float minuslope = 10000, maxuslope = -10000, minvslope = 10000, maxvslope = -10000;
	const uint o = offset;
	float* dcell = reinterpret_cast<float*>(&dx4);
	for ( uint r = 0; r < packetsize; ++r ) if (reinterpret_cast<unsigned int*>(mask4)[r + o])
	{
		const float da = reinterpret_cast<float*>(rdx4)[a * PACKETSIZE + r + o];
		const float uslope = dcell[u * PACKETSIZE + r + o] * da;
		const float vslope = dcell[v * PACKETSIZE + r + o] * da;
		if (uslope < minuslope) minuslope = uslope;
		if (uslope > maxuslope) maxuslope = uslope;
		if (vslope < minvslope) minvslope = vslope;
		if (vslope > maxvslope) maxvslope = vslope;
	}
	// flip if major dir is negative
	float* nc = reinterpret_cast<float*>(&nx4);
	nc[a * 4 + 0] =  minuslope; nc[u * 4 + 0] = -1; nc[v * 4 + 0] = 0;
	nc[a * 4 + 1] =  minvslope; nc[v * 4 + 1] = -1; nc[u * 4 + 1] = 0;
	nc[a * 4 + 2] = -maxuslope; nc[u * 4 + 2] =  1; nc[v * 4 + 2] = 0;
	nc[a * 4 + 3] = -maxvslope; nc[v * 4 + 3] =  1; nc[u * 4 + 3] = 0;
	if (maxdir) 
	{
		__m128 minus1 = _mm_set_ps1( -1.0f );
		nx4 = _mm_mul_ps( nx4, minus1 ), ny4 = _mm_mul_ps( ny4, minus1 ), nz4 = _mm_mul_ps( nz4, minus1 );
		cdx4 = _mm_mul_ps( cdx4, minus1 ), cdy4 = _mm_mul_ps( cdy4, minus1 ), cdz4 = _mm_mul_ps( cdz4, minus1 );
	}
	// plane origins and signs
	D4 = _mm_set_ps1( -100000.0f );
	for ( uint r = 0; r < packetsize; r++ ) if (reinterpret_cast<unsigned int*>(mask4)[r + o])
	{
		const __m128 dist = DOT128( nx4, ny4, nz4, _mm_set_ps1( reinterpret_cast<float*>(ox4)[r + o] ), 
												   _mm_set_ps1( reinterpret_cast<float*>(oy4)[r + o] ), 
												   _mm_set_ps1( reinterpret_cast<float*>(oz4)[r + o] ) );
		D4 = _mm_max_ps( dist, D4 );
	}
	UpdateCornerSigns();
	// build corner rays
	__m128* cdc4 = &cdx4;
	cdc4[a] = _mm_set_ps1( 1.0f );
	cdc4[u] = _mm_set_ps( minuslope, maxuslope, maxuslope, minuslope );
	cdc4[v] = _mm_set_ps( minvslope, minvslope, maxvslope, maxvslope );
}

// -----------------------------------------------------------
// LineTracer::FindFirstGeneric
// Find the first active ray
// -----------------------------------------------------------
void LineTracer::FindFirstGeneric( uint& a_First, const BVHNode& a_Node )
{
	// step 1: check if first ray intersects box
	float tmin = 0.00001f, tmax = reinterpret_cast<float*>(m_ID->dist4)[a_First + m_RP->offset];
	const uint qo = m_RP->qoffset, o = m_RP->offset;
	for ( uint axis = 0; axis < 3; ++axis ) 
	{
		const uint idx = axis * PACKETSIZE + a_First + o;
		const float t0 = (a_Node.min.cell[axis] - reinterpret_cast<float*>(m_RP->ox4)[idx]) * reinterpret_cast<float*>(m_RP->rdx4)[idx];
		const float t1 = (a_Node.max.cell[axis] - reinterpret_cast<float*>(m_RP->ox4)[idx]) * reinterpret_cast<float*>(m_RP->rdx4)[idx];
		const float nr = (t0 < t1) ? t0 : t1, fr = (t0 < t1) ? t1 : t0;
		tmin = (tmin < nr) ? nr : tmin, tmax = (fr <  tmax) ? fr : tmax;
	}
	if (tmin <= tmax) return;
	if (++a_First > (m_RP->packetsize - 1)) return;
	// step 2: check if frustum misses box
	if (m_RP->maxis > -1)
	{
		const float* bounds = (float*)&a_Node;
		unsigned int* signs = reinterpret_cast<unsigned int*>(m_RP->signs4);
		const __m128 bx4 = _mm_set_ps( bounds[signs[0]], bounds[signs[1]], bounds[signs[2]], bounds[signs[3]] );
		const __m128 by4 = _mm_set_ps( bounds[signs[4]], bounds[signs[5]], bounds[signs[6]], bounds[signs[7]] );
		const __m128 bz4 = _mm_set_ps( bounds[signs[8]], bounds[signs[9]], bounds[signs[10]], bounds[signs[11]] );
		const __m128 dst4 = DOT128( bx4, by4, bz4, m_RP->nx4, m_RP->ny4, m_RP->nz4 );
		if (_mm_movemask_ps( _mm_cmpgt_ps( dst4, m_RP->D4 ) ) > 0) { a_First = m_RP->packetsize; return; }
	}
	// step 3: check all rays
	const uint pfirst = a_First >> 2;
	a_First = m_RP->packetsize;
	const __m128 minx4 = _mm_set_ps1( a_Node.min.x ), maxx4 = _mm_set_ps1( a_Node.max.x );
	const __m128 miny4 = _mm_set_ps1( a_Node.min.y ), maxy4 = _mm_set_ps1( a_Node.max.y );
	const __m128 minz4 = _mm_set_ps1( a_Node.min.z ), maxz4 = _mm_set_ps1( a_Node.max.z );
	for ( uint r = pfirst; r < m_RP->packetq; ++r ) if (_mm_movemask_ps( m_RP->mask4[r + qo] ))
	{			
		const __m128 tmin4a = small4, tmax4a = m_ID->dist4[r + qo];
		const __m128 t0a = _mm_mul_ps( _mm_sub_ps( minx4, m_RP->ox4[r + qo] ), m_RP->rdx4[r + qo] );
		const __m128 t1a = _mm_mul_ps( _mm_sub_ps( maxx4, m_RP->ox4[r + qo] ), m_RP->rdx4[r + qo] );
		const __m128 nra = _mm_min_ps( t0a, t1a ), fra = _mm_max_ps( t0a, t1a );
		const __m128 tmin4b = _mm_max_ps( tmin4a, nra ), tmax4b = _mm_min_ps( tmax4a, fra );
		const __m128 t0b = _mm_mul_ps( _mm_sub_ps( miny4, m_RP->oy4[r + qo] ), m_RP->rdy4[r + qo] );
		const __m128 t1b = _mm_mul_ps( _mm_sub_ps( maxy4, m_RP->oy4[r + qo] ), m_RP->rdy4[r + qo] );
		const __m128 nrb = _mm_min_ps( t0b, t1b ), frb = _mm_max_ps( t0b, t1b );
		const __m128 tmin4c = _mm_max_ps( tmin4b, nrb ), tmax4c = _mm_min_ps( tmax4b, frb );
		const __m128 t0c = _mm_mul_ps( _mm_sub_ps( minz4, m_RP->oz4[r + qo] ), m_RP->rdz4[r + qo] );
		const __m128 t1c = _mm_mul_ps( _mm_sub_ps( maxz4, m_RP->oz4[r + qo] ), m_RP->rdz4[r + qo] );
		const __m128 nrc = _mm_min_ps( t0c, t1c ), frc = _mm_max_ps( t0c, t1c );
		const __m128 tmin4d = _mm_max_ps( tmin4c, nrc ), tmax4d = _mm_min_ps( tmax4c, frc );
		const unsigned int ires = _mm_movemask_ps( _mm_and_ps( m_RP->mask4[r + qo], _mm_cmple_ps( tmin4d, tmax4d ) ) );
		if (ires) { a_First = r * 4 + m_Offset[ires]; break; }
	}
	while ((!reinterpret_cast<unsigned int*>(m_RP->mask4)[a_First + o]) && (a_First < m_RP->packetsize)) a_First++;
}

// ----------------------------------------------------------- 
// LineTracer::UpdateGenericSubmask 
// Prepares the submask (by Shadow007)
// ----------------------------------------------------------- 
void LineTracer::UpdateGenericSubmask( uint& a_First, const BVHNode& a_Node ) 
{ 
	uint r = a_First >> 2; 
	// Masking out the rays that do not touch the node 
	const __m128 minx4 = _mm_set_ps1( a_Node.min.x ), maxx4 = _mm_set_ps1( a_Node.max.x ); 
	const __m128 miny4 = _mm_set_ps1( a_Node.min.y ), maxy4 = _mm_set_ps1( a_Node.max.y ); 
	const __m128 minz4 = _mm_set_ps1( a_Node.min.z ), maxz4 = _mm_set_ps1( a_Node.max.z ); 
	const uint qo = m_RP->qoffset; 
	for ( ; r < m_RP->packetq; ++r ) if (_mm_movemask_ps( m_RP->mask4[r + qo] )) 
	{          
		const __m128 tmin4a = small4, tmax4a = m_ID->dist4[r + qo]; 
		const __m128 t0a = _mm_mul_ps( _mm_sub_ps( minx4, m_RP->ox4[r + qo] ), m_RP->rdx4[r + qo] ); 
		const __m128 t1a = _mm_mul_ps( _mm_sub_ps( maxx4, m_RP->ox4[r + qo] ), m_RP->rdx4[r + qo] ); 
		const __m128 nra = _mm_min_ps( t0a, t1a ), fra = _mm_max_ps( t0a, t1a ); 
		const __m128 tmin4b = _mm_max_ps( tmin4a, nra ), tmax4b = _mm_min_ps( tmax4a, fra ); 
		const __m128 t0b = _mm_mul_ps( _mm_sub_ps( miny4, m_RP->oy4[r + qo] ), m_RP->rdy4[r + qo] ); 
		const __m128 t1b = _mm_mul_ps( _mm_sub_ps( maxy4, m_RP->oy4[r + qo] ), m_RP->rdy4[r + qo] ); 
		const __m128 nrb = _mm_min_ps( t0b, t1b ), frb = _mm_max_ps( t0b, t1b ); 
		const __m128 tmin4c = _mm_max_ps( tmin4b, nrb ), tmax4c = _mm_min_ps( tmax4b, frb ); 
		const __m128 t0c = _mm_mul_ps( _mm_sub_ps( minz4, m_RP->oz4[r + qo] ), m_RP->rdz4[r + qo] ); 
		const __m128 t1c = _mm_mul_ps( _mm_sub_ps( maxz4, m_RP->oz4[r + qo] ), m_RP->rdz4[r + qo] ); 
		const __m128 nrc = _mm_min_ps( t0c, t1c ), frc = _mm_max_ps( t0c, t1c ); 
		const __m128 tmin4d = _mm_max_ps( tmin4c, nrc ), tmax4d = _mm_min_ps( tmax4c, frc ); 
		m_RP->submask4[r] = _mm_and_ps( m_RP->mask4[r + qo], _mm_cmple_ps( tmin4d, tmax4d )); 
	} 
	else m_RP->submask4[r] = m_RP->mask4[r + qo]; 
} 

// ----------------------------------------------------------- 
// LineTracer::IntersectGeneric  New 
// Check a triangle 
// ----------------------------------------------------------- 
void LineTracer::IntersectGeneric( const uint a_First, const Primitive& a_Prim ) 
{ 
#ifdef SUPPORTSPHERES
	if (a_Prim.GetType() == Primitive::PRIM_SPHERE)
	{
	#if 1
		const int pfirst = a_First;
		const int plast = a_First + m_RP->packetsize;
		const int qo = m_RP->qoffset;
		const __m128 cx4 = _mm_set_ps1( a_Prim.m_N.x );
		const __m128 cy4 = _mm_set_ps1( a_Prim.m_N.y );
		const __m128 cz4 = _mm_set_ps1( a_Prim.m_N.z );
		const __m128 sqrad4 = _mm_set_ps1( a_Prim.m_T.y );
		const __m128i prim4 = _mm_set1_epi32( (uint)&a_Prim );
		for ( unsigned int r = pfirst; r < m_RP->packetq; r++ )
		{
			const __m128 dstx4 = _mm_sub_ps( m_RP->ox4[r + qo], cx4 );
			const __m128 dsty4 = _mm_sub_ps( m_RP->oy4[r + qo], cy4 );
			const __m128 dstz4 = _mm_sub_ps( m_RP->oz4[r + qo], cz4 );
			const __m128 B4 = _mm_add_ps( _mm_add_ps( _mm_mul_ps( dstx4, m_RP->dx4[r + qo] ), _mm_mul_ps( dsty4, m_RP->dy4[r + qo] ) ), _mm_mul_ps( dstz4, m_RP->dz4[r + qo] ) );
			const __m128 C4 = _mm_sub_ps( _mm_add_ps( _mm_add_ps( _mm_mul_ps( dstx4, dstx4 ), _mm_mul_ps( dsty4, dsty4 ) ), _mm_mul_ps( dstz4, dstz4 ) ), sqrad4 );
			const __m128 d4 = _mm_sub_ps( _mm_mul_ps( B4, B4 ), C4 );
			const __m128 dist4 = _mm_sub_ps( _mm_sub_ps( zero, B4 ), _mm_sqrt_ps( d4 ) );
			const __m128 mask4 = _mm_and_ps( m_RP->submask4[r], _mm_and_ps( _mm_cmpgt_ps( dist4, epsilon ), _mm_cmplt_ps( dist4, m_ID->dist4[r + qo] ) ) );
			m_ID->dist4[r + qo] = _mm_or_ps( _mm_andnot_ps( mask4, m_ID->dist4[r + qo] ), _mm_and_ps( mask4, dist4 ) );
			m_ID->prim4[r + qo] = _mm_or_si128( _mm_andnot_si128( *reinterpret_cast<const __m128i*>(&mask4), m_ID->prim4[r + qo] ), 
												_mm_and_si128( *reinterpret_cast<const __m128i*>(&mask4), prim4 ) );
		}
	#else
		int pfirst = a_First;
		int plast = a_First + m_RP->packetsize;
		int o = m_RP->offset;
		for ( int r = pfirst; r < plast; r++ )
		{
			vector3 O( m_RP->ox[r + o], m_RP->oy[r + o], m_RP->oz[r + o] );
			vector3 D( m_RP->dx[r + o], m_RP->dy[r + o], m_RP->dz[r + o] );
			vector3 dst = O - a_Prim.GetCentre();
			float B = DOT( dst, D );
			float C = DOT( dst, dst ) - a_Prim.GetSqRadius();
			float d = B * B - C;
			float dist = -B - sqrtf( d );
			if ((dist > EPSILON) && (dist < m_ID->dist[r + o])) 
			{
				m_ID->dist[r + o] = dist;
				m_ID->prim[r + o] = (Primitive*)&a_Prim;
			}
		}
	#endif
		return;
	}
#endif
	// pleucker intersection test: precalculations 
	const __m128 V0x = _mm_set_ps1( a_Prim.m_Vertex[0]->GetPos().x ); 
	const __m128 V0y = _mm_set_ps1( a_Prim.m_Vertex[0]->GetPos().y ); 
	const __m128 V0z = _mm_set_ps1( a_Prim.m_Vertex[0]->GetPos().z ); 
	const __m128 V1x = _mm_set_ps1( a_Prim.m_Vertex[1]->GetPos().x ); 
	const __m128 V1y = _mm_set_ps1( a_Prim.m_Vertex[1]->GetPos().y ); 
	const __m128 V1z = _mm_set_ps1( a_Prim.m_Vertex[1]->GetPos().z ); 
	const __m128 V2x = _mm_set_ps1( a_Prim.m_Vertex[2]->GetPos().x ); 
	const __m128 V2y = _mm_set_ps1( a_Prim.m_Vertex[2]->GetPos().y ); 
	const __m128 V2z = _mm_set_ps1( a_Prim.m_Vertex[2]->GetPos().z ); 
	// test against frustum 
	if (m_RP->maxis > -1) 
	{ 
		const __m128 dist1 = DOT128( V0x, V0y, V0z, m_RP->nx4, m_RP->ny4, m_RP->nz4 ); 
		const __m128 dist2 = DOT128( V1x, V1y, V1z, m_RP->nx4, m_RP->ny4, m_RP->nz4 ); 
		const __m128 dist3 = DOT128( V2x, V2y, V2z, m_RP->nx4, m_RP->ny4, m_RP->nz4 ); 
		const __m128 res1 = _mm_and_ps( _mm_and_ps( _mm_cmpgt_ps( dist1, m_RP->D4 ), _mm_cmpgt_ps( dist2, m_RP->D4 ) ), _mm_cmpgt_ps( dist3, m_RP->D4 ) ); 
		if (_mm_movemask_ps( res1 )) return; 
	} 
	// prepare intersection data 
	__m128 aox[PACKETQ], aoy[PACKETQ], aoz[PACKETQ]; 
	uint r; 
	const uint qo = m_RP->qoffset; 
	const __m128 n4x = broadcastss( &a_Prim.m_N.x ), n4y = broadcastss( &a_Prim.m_N.y ), n4z = broadcastss( &a_Prim.m_N.z ); 
	uint valid = 0; 
	uint pfirst = a_First >> 2; 
	__m128 dot4[PACKETQ]; 
	__m128 localmask[PACKETQ]; 
	for ( r = pfirst; r < m_RP->packetq; ++r ) if (_mm_movemask_ps( m_RP->submask4[r] ) ) 
	{ 
		aox[r] = _mm_sub_ps( V0x, m_RP->ox4[r + qo] ); 
		aoy[r] = _mm_sub_ps( V0y, m_RP->oy4[r + qo] ); 
		aoz[r] = _mm_sub_ps( V0z, m_RP->oz4[r + qo] ); 
		dot4[r] = DOT128( n4x, n4y, n4z, aox[r], aoy[r], aoz[r] ); 
		localmask[r] = _mm_and_ps( m_RP->submask4[r], _mm_cmpge_ps( dot4[r], zero ) ); 
		valid |= _mm_movemask_ps( localmask[r] ); 
	} 
	else localmask[r] = zero; 
	if (valid == 0) return; 
	// intersection test 
	const __m128i prim4 = _mm_set1_epi32( (unsigned int)&a_Prim ); 
	for ( r = pfirst; r < m_RP->packetq; ++r ) if (_mm_movemask_ps( localmask[r] )) 
	{ 
		const __m128 box = _mm_sub_ps( V1x, m_RP->ox4[r + qo] ); 
		const __m128 boy = _mm_sub_ps( V1y, m_RP->oy4[r + qo] ); 
		const __m128 boz = _mm_sub_ps( V1z, m_RP->oz4[r + qo] ); 
		const __m128 cox = _mm_sub_ps( V2x, m_RP->ox4[r + qo] ); 
		const __m128 coy = _mm_sub_ps( V2y, m_RP->oy4[r + qo] ); 
		const __m128 coz = _mm_sub_ps( V2z, m_RP->oz4[r + qo] ); 
		const __m128 v0c4x = _mm_sub_ps( _mm_mul_ps( coy   , boz    ), _mm_mul_ps( coz   , boy    ) ); 
		const __m128 v0c4y = _mm_sub_ps( _mm_mul_ps( coz   , box    ), _mm_mul_ps( cox   , boz    ) ); 
		const __m128 v0c4z = _mm_sub_ps( _mm_mul_ps( cox   , boy    ), _mm_mul_ps( coy   , box    ) ); 
		const __m128 v1c4x = _mm_sub_ps( _mm_mul_ps( boy   , aoz[r] ), _mm_mul_ps( boz   , aoy[r] ) ); 
		const __m128 v1c4y = _mm_sub_ps( _mm_mul_ps( boz   , aox[r] ), _mm_mul_ps( box   , aoz[r] ) ); 
		const __m128 v1c4z = _mm_sub_ps( _mm_mul_ps( box   , aoy[r] ), _mm_mul_ps( boy   , aox[r] ) ); 
		const __m128 v2c4x = _mm_sub_ps( _mm_mul_ps( aoy[r], coz    ), _mm_mul_ps( aoz[r], coy    ) ); 
		const __m128 v2c4y = _mm_sub_ps( _mm_mul_ps( aoz[r], cox    ), _mm_mul_ps( aox[r], coz    ) ); 
		const __m128 v2c4z = _mm_sub_ps( _mm_mul_ps( aox[r], coy    ), _mm_mul_ps( aoy[r], cox    ) ); 
		const __m128 v0d = DOT128( v0c4x, v0c4y, v0c4z, m_RP->dx4[r + qo], m_RP->dy4[r + qo], m_RP->dz4[r + qo] ); 
		const uint32 v0s = _mm_movemask_ps( v0d ); 
		const __m128 v1d = DOT128( v1c4x, v1c4y, v1c4z, m_RP->dx4[r + qo], m_RP->dy4[r + qo], m_RP->dz4[r + qo] ); 
		const uint32 v1s = _mm_movemask_ps( v1d ); 
		const __m128 v2d = DOT128( v2c4x, v2c4y, v2c4z, m_RP->dx4[r + qo], m_RP->dy4[r + qo], m_RP->dz4[r + qo] ); 
		const uint32 v2s = _mm_movemask_ps( v2d ); 
		if ((v0s|v1s|v2s) < 15) 
		{ 
			const __m128 nominator = dot4[r]; 
			const uint32 tmask = (v0s & v1s & v2s) | ((v0s^0xf) & (v1s^0xf) & (v2s^0xf)); 
			const __m128 rdn = DOT128( n4x, n4y, n4z, m_RP->dx4[r + qo], m_RP->dy4[r + qo], m_RP->dz4[r + qo] ); 
			const __m128 t4 = _mm_mul_ps( nominator, fastrcp( rdn ) ); 
			const __m128 finalmask = _mm_and_ps( _mm_cmpge_ps( t4, zero ), _mm_and_ps( localmask[r], _mm_and_ps( _mm_cmple_ps( t4, m_ID->dist4[r + qo] ), masktable4[tmask] ) ) ); 
			m_ID->dist4[r + qo] = _mm_or_ps( _mm_andnot_ps( finalmask, m_ID->dist4[r + qo] ), _mm_and_ps( finalmask, t4 ) ); 
		#ifdef _WIN64
			uint32 imask32 = _mm_movemask_ps( finalmask );
			if (imask32 & 1) m_ID->prim[(r + qo) * 4 + 0] = (Primitive*)pr;
			if (imask32 & 2) m_ID->prim[(r + qo) * 4 + 1] = (Primitive*)pr;
			if (imask32 & 4) m_ID->prim[(r + qo) * 4 + 2] = (Primitive*)pr;
			if (imask32 & 8) m_ID->prim[(r + qo) * 4 + 3] = (Primitive*)pr;
		#else
			m_ID->prim4[r + qo] = _mm_or_si128( _mm_andnot_si128( *reinterpret_cast<const __m128i*>(&finalmask), m_ID->prim4[r + qo] ), 
											    _mm_and_si128( *reinterpret_cast<const __m128i*>(&finalmask), prim4 ) ); 
		#endif
			const __m128 v0l = fastrcp( _mm_add_ps( _mm_add_ps( v0d, v1d ), v2d ) ); 
			const __m128 u = _mm_mul_ps( v2d, v0l ), v = _mm_mul_ps( v1d, v0l ); 
			m_ID->u4[r + qo] = _mm_or_ps( _mm_andnot_ps( finalmask, m_ID->u4[r + qo] ), _mm_and_ps( finalmask, u ) ); 
			m_ID->v4[r + qo] = _mm_or_ps( _mm_andnot_ps( finalmask, m_ID->v4[r + qo] ), _mm_and_ps( finalmask, v ) ); 
		} 
	#ifdef GATHERSTATS
		m_Ints += 4; 
	#endif
	} 
} 

// -----------------------------------------------------------
// LineTracer::DoAlphaBlending
// Perform alpha blending
// -----------------------------------------------------------
void LineTracer::DoAlphaBlending( uint a_Depth )
{
	uint alpha = 0, r;
	union { __m128 alphamask4[PACKETQ]; unsigned int alphamask[PACKETSIZE]; };
	union { __m128 alphaval4[PACKETQ]; float alphaval[PACKETSIZE]; };
	memset( alphamask, 0, PACKETSIZE * 4 );
	for ( r = 0; r < m_RP->packetsize; r++ ) 
	{
		if ((m_ID->prim[r]->GetMaterial()->GetAlpha()) && (reinterpret_cast<unsigned int*>(m_RP->mask4)[r]))
		{
			// need an extra test here: cull pixels that have 255 in the alpha channel.
			alphamask[r] = 0xffffffff;
			alphaval[r] = m_ID->colip[((r >> 2) << 2) + 3].cell[r & 3] * (1.0f / 256.0f);
			alpha++;
		}
	}
	if (!alpha) return;
	// we have alpha blended pixels
	__m128 ocol[PACKETSIZE];
	memcpy( ocol, m_ID->color, PACKETSIZE * 16 );
	memcpy( m_RPsec, m_RP, sizeof( RayPacket ) );
	memcpy( m_IDsec, m_ID, sizeof( IData ) );
	RayPacket* ORP = m_RP;
	IData* OID = m_ID;
	m_RP = &m_RPsec[0];
	m_ID = &m_IDsec[0];
#ifdef GATHERSTATS
	m_Rays += alpha;
#endif
	for ( uint p = 0; p < m_RP->packetq; p++ )
	{
		m_RP->mask4[p] = alphamask4[p];
		__m128 dist4 = _mm_add_ps( m_ID->dist4[p], epsilon );
		m_RP->ox4[p] = _mm_add_ps( m_RP->ox4[p], _mm_mul_ps( dist4, m_RP->dx4[p] ) );
		m_RP->oy4[p] = _mm_add_ps( m_RP->oy4[p], _mm_mul_ps( dist4, m_RP->dy4[p] ) );
		m_RP->oz4[p] = _mm_add_ps( m_RP->oz4[p], _mm_mul_ps( dist4, m_RP->dz4[p] ) );
		m_ID->dist4[p] = thousand;
	}
	// trace
#ifdef ALTFIRST
	// calculate quadrant
	unsigned int quad = ((reinterpret_cast<float*>(m_RP->dx4)[0] < 0)?1:0) + 
						((reinterpret_cast<float*>(m_RP->dy4)[0] < 0)?2:0) + 
						((reinterpret_cast<float*>(m_RP->dz4)[0] < 0)?4:0);
#endif
	uint stackptr = 0, first = 0;
	BVHNode* node = SceneGraph::GetSceneRoot();
	Primitive** prim = MManager::GetBVHPrims();
	BVHNode* pool = MManager::GetBVHPool();
	m_RP->BuildPlanesGeneric();
	while (1)
	{
		FindFirstGeneric( first, *node );
		if (first < m_RP->packetsize)
		{
			if (!node->IsLeaf())
			{
				const uint lidx = (node->GetDirMask() >> quad) & 1;
				m_Stack[stackptr].node = &pool[node->GetLeft() + 1 - lidx];
				m_Stack[stackptr++].first = first;
				node = &pool[node->GetLeft() + lidx];
				continue;
			}
			else
			{
				const uint start = node->GetStart(), count = node->GetTCount();
				UpdateGenericSubmask( first, *node ); 
				for ( uint i = 0; i < count; i++ ) IntersectGeneric( first, *prim[start + i] );
			#ifdef GATHERSTATS
				m_Leafs++, m_Ints += count;
			#endif
			}
		}
		if (!stackptr) break;
		node = m_Stack[--stackptr].node;
		first = m_Stack[stackptr].first;
	}
	// shading
	GetColorAtIP();
	ApplyLights();
	// m_Depth = 0;
	if (a_Depth < 1) 
	{
		DoAlphaBlending( a_Depth + 1 );
	#ifdef REFRACTIONS
		DoRefractions( a_Depth + 1 );
	#endif
	#ifdef REFLECTIONS
		DoReflections( a_Depth + 1 );
	#endif
	}
	for ( r = 0; r < m_RP->packetsize; r++ ) 
	{
		if (alphamask[r])
		{
			__m128 a1 = _mm_mul_ps( m_ID->color[r].rgba, _mm_set_ps1( 1 - alphaval[r] ) );
			__m128 a2 = _mm_mul_ps( ocol[r], _mm_set_ps1( alphaval[r] ) );
			OID->color[r].rgba = _mm_add_ps( a1, a2 );
		}
	}
	m_RP = ORP;
	m_ID = OID;
}

// -----------------------------------------------------------
// LineTracer::DoReflections
// Calculate reflection
// -----------------------------------------------------------
void LineTracer::DoReflections( uint a_Depth )
{
	uint reflections = 0, r;
	__m128 refmask4[PACKETQ]; unsigned int* refmask = reinterpret_cast<unsigned int*>(refmask4);
	__m128 refval4[PACKETQ]; float* refval = reinterpret_cast<float*>(refval4);
	memset( refmask, 0, PACKETSIZE * 4 );
	for ( r = 0; r < m_RP->packetsize; r++ ) 
	{
		if ((m_ID->prim[r]->GetMaterial()->GetMaxReflection() > 0) && (reinterpret_cast<unsigned int*>(m_RP->mask4)[r]))
		{
			refmask[r] = 0xffffffff;
			reflections++;
		}
	}
	if (!reflections) return;
	// we have reflections
	memset( m_RPsec[a_Depth].mask4, 0, PACKETQ * 16 );
	RayPacket* ORP = m_RP;
	IData* OID = m_ID;
	m_RP = &m_RPsec[a_Depth];
	m_RP->packetsize = ORP->packetsize;
	m_RP->packetq = ORP->packetq;
	m_ID = &m_IDsec[a_Depth];
#ifdef GATHERSTATS
	m_Rays += reflections;
#endif
	m_RP->StartAtIntersection( *ORP, *OID );
	r = 0;
	for ( uint p = 0; p < m_RP->packetq; p++ )
	{
		const unsigned int mask = _mm_movemask_ps( refmask4[p] );
		m_RP->mask4[p] = refmask4[p];
		bool samemat = (OID->prim[r]->GetMaterial() == OID->prim[r + 1]->GetMaterial()) &&
					   (OID->prim[r + 1]->GetMaterial() == OID->prim[r + 2]->GetMaterial()) &&
					   (OID->prim[r + 2]->GetMaterial() == OID->prim[r + 3]->GetMaterial()) &&
					   (mask == 15);
		if (samemat)
		{
			const __m128 Nx4 = OID->N4[r], Ny4 = OID->N4[r + 1], Nz4 = OID->N4[r + 2];
			const __m128 dot4 = _mm_add_ps( _mm_add_ps( _mm_mul_ps( ORP->dx4[p], Nx4 ), 
								_mm_mul_ps( ORP->dy4[p], Ny4 ) ), _mm_mul_ps( ORP->dz4[p], Nz4 ) );
			const __m128 dot24 = _mm_mul_ps( two, dot4 );
			m_RP->dx4[p] = _mm_sub_ps( ORP->dx4[p], _mm_mul_ps( dot24, Nx4 ) );
			m_RP->dy4[p] = _mm_sub_ps( ORP->dy4[p], _mm_mul_ps( dot24, Ny4 ) );
			m_RP->dz4[p] = _mm_sub_ps( ORP->dz4[p], _mm_mul_ps( dot24, Nz4 ) );
			// calculate reflection intensity
			Material* mat = (Material*)OID->prim[r]->GetMaterial();
			const __m128 rmin4 = mat->GetMinReflection4();
			const __m128 rmax4 = mat->GetMaxReflection4();
			const __m128 dot45a = _mm_sub_ps( one, dot4 );
			const __m128 dot45b = _mm_mul_ps( dot45a, dot45a );
			const __m128 dot45c = _mm_max_ps( zero, _mm_mul_ps( _mm_mul_ps( dot45b, dot45b ), dot45a ) );
			refval4[p] = _mm_add_ps( rmin4, _mm_mul_ps( _mm_sub_ps( rmax4, rmin4 ), _mm_mul_ps( _mm_sub_ps( one, rmin4 ), dot45c ) ) );
			r += 4;
		}
		else
		{
			for ( uint p1 = 0; p1 < 4; p1++, r++ ) if (refmask[r])
			{
				const uint idx = ((r >> 2) << 4) + (r & 3);
				const vector3 N( OID->N[idx], OID->N[idx + 4], OID->N[idx + 8] );
				const float dot = reinterpret_cast<float*>(ORP->dx4)[r] * N.x + reinterpret_cast<float*>(ORP->dy4)[r] * N.y + reinterpret_cast<float*>(ORP->dz4)[r] * N.z;
				const vector3 R = vector3( reinterpret_cast<float*>(ORP->dx4)[r] - 2 * dot * N.x, 
										   reinterpret_cast<float*>(ORP->dy4)[r] - 2 * dot * N.y, 
										   reinterpret_cast<float*>(ORP->dz4)[r] - 2 * dot * N.z );
				reinterpret_cast<float*>(m_RP->dx4)[r] = R.x, 
				reinterpret_cast<float*>(m_RP->dy4)[r] = R.y, 
				reinterpret_cast<float*>(m_RP->dz4)[r] = R.z;
				// calculate reflection intensity
				Material* mat = (Material*)OID->prim[r]->GetMaterial();
				const float rmin = mat->GetMinReflection();
				const float rmax = mat->GetMaxReflection();
				const float mdt = max( 0, 1 - dot );
				const float sqd = mdt * mdt;
				const float sqdd = sqd * sqd;
				refval[r] = rmin + (1 - rmin) * (sqdd * mdt) * (rmax - rmin);
			}
		}
	}
	m_RP->CalcReciprocals();
	m_RP->MoveOriginAway( epsilon );
#ifndef ALTFIRST
	m_RP->UpdateSigns();
#else
	// calculate quadrant
	unsigned int quad = ((reinterpret_cast<float*>(m_RP->dx4)[0] < 0)?1:0) + 
						((reinterpret_cast<float*>(m_RP->dy4)[0] < 0)?2:0) + 
						((reinterpret_cast<float*>(m_RP->dz4)[0] < 0)?4:0);
#endif	
	for ( r = 0; r < m_RP->packetq; ++r ) m_ID->dist4[r] = thousand;
	// process in four chunks
	uint chunks;
	if (1) // m_RP->packetq == PACKETQ)
	{
		chunks = 4;
		m_RP->packetq = 16;
		m_RP->packetsize = 64;
	}
	else
	{
		chunks = 1;
		m_RP->packetq = ORP->packetq;
		m_RP->packetsize = ORP->packetsize;
	}
	for ( uint q = 0; q < chunks; q++ )
	{
		m_RP->qoffset = q * 16;
		m_RP->offset = q * 64;
		m_RP->BuildPlanesGeneric();
		uint stackptr = 0, first = 0;
		BVHNode* node = SceneGraph::GetSceneRoot();
		Primitive** prim = MManager::GetBVHPrims();
		BVHNode* pool = MManager::GetBVHPool();
		while (1)
		{
			FindFirstGeneric( first, *node );
			if (first < m_RP->packetsize)
			{
				if (!node->IsLeaf())
				{
				#ifndef ALTFIRST
					const uint aoffset = node->GetAxis() * PACKETSIZE + m_RP->offset;
					const uint lidx = m_RP->sign[first + aoffset] ^ node->GetFirst();
				#else
					const uint lidx = (node->GetDirMask() >> quad) & 1;
				#endif
					m_Stack[stackptr].node = &pool[node->GetLeft() + 1 - lidx];
					m_Stack[stackptr++].first = first;
					node = &pool[node->GetLeft() + lidx];
					continue;
				}
				else
				{
					const uint start = node->GetStart(), count = node->GetTCount();
					UpdateGenericSubmask( first, *node ); 
					for ( uint i = 0; i < count; i++ )
					{
						const Primitive* restrict pr = prim[start + i];
						IntersectGeneric( first, *pr );
					}
				#ifdef GATHERSTATS
					m_Leafs++, m_Ints += count;
				#endif
				}
			}
			if (!stackptr) break;
			node = m_Stack[--stackptr].node;
			first = m_Stack[stackptr].first;
		}
	}
	if (m_Dome)
	{
		const __m128 dist4 = _mm_set_ps1( SKYDOMERADIUS );
		for ( unsigned int r = 0; r < 64; r++ )
		{
			const __m128 mask4 = _mm_cmplt_ps( dist4, m_ID->dist4[r] );
			const __m128i* imask4 = (const __m128i*)reinterpret_cast<const __m128*>(&mask4);
			m_ID->prim4[r] = _mm_or_si128( _mm_andnot_si128( *imask4, m_ID->prim4[r] ), _mm_and_si128( *imask4, m_Dome4 ) );
		}
	}
	m_RP->offset = ORP->offset;
	m_RP->qoffset = ORP->qoffset;
	m_RP->packetq = ORP->packetq;
	m_RP->packetsize = ORP->packetsize;
	for ( int i = 0; i < PACKETSIZE; i++ ) 
	{
		reinterpret_cast<unsigned int*>(m_LRP.mask4)[i] = refmask[i];
		if (refmask[i]) 
		{
			reinterpret_cast<float*>(m_LID.dist4)[i] = MAXINTDIST;
			m_LID.prim[i] = 0;
		}
		else
		{
			m_LID.prim[i] = (Primitive*)0xffffffff;
			reinterpret_cast<float*>(m_LID.dist4)[i] = 0;
		}
	}
	GetColorAtIP();
	ApplyLights();
	// one level of recursion
	if (a_Depth == 0)
	{
 	#ifdef ALPHABLENDING
		DoAlphaBlending( a_Depth + 1 );
	#endif
	#ifdef REFRACTIONS
		DoRefractions( a_Depth + 1 );
	#endif
	#ifdef REFLECTIONS
		DoReflections( a_Depth + 1 );
	#endif
	}
	// process results
	for ( uint r = 0; r < PACKETSIZE; r++ ) if (refmask[r]) 
	{
		OID->color[r].rgba = _mm_add_ps( OID->color[r].rgba, _mm_mul_ps( _mm_set_ps1( refval[r] ), m_ID->color[r].rgba ) );
	}
	// restore to normal operation
	m_RP = ORP;
	m_ID = OID;
}

// -----------------------------------------------------------
// LineTracer::DoRefractions
// Calculate refraction
// -----------------------------------------------------------
void LineTracer::DoRefractions( uint a_Depth )
{
	uint refractions = 0, r;
	__m128 refmask4[PACKETQ]; unsigned int* refmask = reinterpret_cast<unsigned int*>(refmask4);
	__m128 refval4[PACKETQ]; float* refval = reinterpret_cast<float*>(refval4);
	memset( refmask, 0, PACKETSIZE * 4 );
	for ( r = 0; r < m_RP->packetsize; r++ ) 
	{
		if ((m_ID->prim[r]->GetMaterial()->GetRefraction() > 0) && (reinterpret_cast<unsigned int*>(m_RP->mask4)[r]))
		{
			refmask[r] = 0xffffffff;
			refractions++;
		}
	}
	if (!refractions) return;
	// we have reflections
	memset( m_RPsec[a_Depth].mask4, 0, PACKETQ * 16 );
	RayPacket* ORP = m_RP;
	IData* OID = m_ID;
	m_RP = &m_RPsec[a_Depth];
	m_RP->packetsize = ORP->packetsize;
	m_RP->packetq = ORP->packetq;
	m_ID = &m_IDsec[a_Depth];
#ifdef GATHERSTATS
	m_Rays += refractions;
#endif
	m_RP->StartAtIntersection( *ORP, *OID );
	r = 0;
	for ( uint p = 0; p < m_RP->packetq; p++ )
	{
		m_RP->mask4[p] = refmask4[p];
		if (_mm_movemask_ps( refmask4[p] ) == 15)
		{
			const __m128 n4 = OID->prim[r]->GetMaterial()->GetRefrIndex4();
			const __m128 Nx4 = OID->N4[r], Ny4 = OID->N4[r + 1], Nz4 = OID->N4[r + 2];
			const __m128 cosI4 = _mm_add_ps( _mm_add_ps( _mm_mul_ps( ORP->dx4[p], Nx4 ), 
								 _mm_mul_ps( ORP->dy4[p], Ny4 ) ), _mm_mul_ps( ORP->dz4[p], Nz4 ) );
			const __m128 cosT4 = _mm_sub_ps( one, _mm_mul_ps( _mm_mul_ps( n4, n4 ), _mm_sub_ps( one, _mm_mul_ps( cosI4, cosI4 ) ) ) );
			const __m128 term4 = _mm_sub_ps( _mm_mul_ps( n4, cosI4 ), _mm_sqrt_ps( cosT4 ) );
			const __m128 Tx4 = _mm_sub_ps( _mm_mul_ps( n4, ORP->dx4[p] ), _mm_mul_ps( Nx4, ( term4 ) ) );
			const __m128 Ty4 = _mm_sub_ps( _mm_mul_ps( n4, ORP->dy4[p] ), _mm_mul_ps( Ny4, ( term4 ) ) );
			const __m128 Tz4 = _mm_sub_ps( _mm_mul_ps( n4, ORP->dz4[p] ), _mm_mul_ps( Nz4, ( term4 ) ) );
			const __m128 ilen4 = _mm_rsqrt_ps( _mm_add_ps( _mm_add_ps( _mm_mul_ps( Tx4, Tx4 ), _mm_mul_ps( Ty4, Ty4 ) ), 
								 _mm_mul_ps( Tz4, Tz4 ) ) );
			m_RP->dx4[p] = _mm_mul_ps( Tx4, ilen4 );
			m_RP->dy4[p] = _mm_mul_ps( Ty4, ilen4 );
			m_RP->dz4[p] = _mm_mul_ps( Tz4, ilen4 );
			refval4[p] = _mm_set_ps1( OID->prim[r]->GetMaterial()->GetRefraction() );
			r += 4;
		}
		else
		{
			for ( uint p1 = 0; p1 < 4; p1++, ++r ) if (refmask[r])
			{
				const uint idx = ((r >> 2) << 4) + (r & 3);
				const vector3 N( OID->N[idx], OID->N[idx + 4], OID->N[idx + 8] );
				const float n = OID->prim[r]->GetMaterial()->GetRefrIndex();
				const vector3 D = vector3( reinterpret_cast<float*>(ORP->dx4)[r], 
										   reinterpret_cast<float*>(ORP->dy4)[r], 
										   reinterpret_cast<float*>(ORP->dz4)[r] );
				const float cosI = DOT( N, D );
				float cosT2 = 1.0f - n * n * (1.0f - cosI * cosI);
				vector3 T = (n * D) - (n * cosI - sqrtf( cosT2 )) * N;
				NORMALIZE( T );
				reinterpret_cast<float*>(m_RP->dx4)[r] = T.x;
				reinterpret_cast<float*>(m_RP->dy4)[r] = T.y;
				reinterpret_cast<float*>(m_RP->dz4)[r] = T.z;
				refval[r] = OID->prim[r]->GetMaterial()->GetRefraction();
			}
		}
	}
	m_RP->CalcReciprocals();
	m_RP->MoveOriginAway( epsilon );
#ifndef ALTFIRST
	m_RP->UpdateSigns();
#else
	// calculate quadrant
	unsigned int quad = ((reinterpret_cast<float*>(m_RP->dx4)[0] < 0)?1:0) + 
						((reinterpret_cast<float*>(m_RP->dy4)[0] < 0)?2:0) + 
						((reinterpret_cast<float*>(m_RP->dz4)[0] < 0)?4:0);
#endif	
	for ( r = 0; r < m_RP->packetq; ++r ) m_ID->dist4[r] = thousand;
	// process in four chunks
	uint chunks;
	if (1) //m_RP->packetq == PACKETQ)
	{
		chunks = 4;
		m_RP->packetq = 16;
		m_RP->packetsize = 64;
	}
	else
	{
		chunks = 1;
		m_RP->packetq = ORP->packetq;
		m_RP->packetsize = ORP->packetsize;
	}
	for ( uint q = 0; q < chunks; q++ )
	{
		m_RP->qoffset = q * 16;
		m_RP->offset = q * 64;
		m_RP->BuildPlanesGeneric();
		uint stackptr = 0, first = 0;
		BVHNode* node = SceneGraph::GetSceneRoot();
		Primitive** prim = MManager::GetBVHPrims();
		BVHNode* pool = MManager::GetBVHPool();
		while (1)
		{
			FindFirstGeneric( first, *node );
			if (first < m_RP->packetsize)
			{
				if (!node->IsLeaf())
				{
				#ifndef ALTFIRST
					const uint aoffset = node->GetAxis() * PACKETSIZE + m_RP->offset;
					const uint lidx = m_RP->sign[first + aoffset] ^ node->GetFirst();
				#else
					const uint lidx = (node->GetDirMask() >> quad) & 1;
				#endif
					m_Stack[stackptr].node = &pool[node->GetLeft() + 1 - lidx];
					m_Stack[stackptr++].first = first;
					node = &pool[node->GetLeft() + lidx];
					continue;
				}
				else
				{
					const uint start = node->GetStart(), count = node->GetTCount();
					UpdateGenericSubmask( first, *node ); 
					for ( uint i = 0; i < count; i++ )
					{
						const Primitive* restrict pr = prim[start + i];
						IntersectGeneric( first, *pr );
					}
				#ifdef GATHERSTATS
					m_Leafs++, m_Ints += count;
				#endif
				}
			}
			if (!stackptr) break;
			node = m_Stack[--stackptr].node;
			first = m_Stack[stackptr].first;
		}
	}
	if (m_Dome)
	{
		const __m128 dist4 = _mm_set_ps1( SKYDOMERADIUS );
		for ( unsigned int r = 0; r < m_RP->packetq; r++ )
		{
			const __m128 mask4 = _mm_cmplt_ps( dist4, m_ID->dist4[r] );
			const __m128i* imask4 = (const __m128i*)reinterpret_cast<const __m128*>(&mask4);
			m_ID->prim4[r] = _mm_or_si128( _mm_andnot_si128( *imask4, m_ID->prim4[r] ), _mm_and_si128( *imask4, m_Dome4 ) );
		}
	}
	m_RP->offset = ORP->offset;
	m_RP->qoffset = ORP->qoffset;
	m_RP->packetq = ORP->packetq;
	m_RP->packetsize = ORP->packetsize;
	GetColorAtIP();
	ApplyLights();
	// one level of recursion
	if (a_Depth == 0)
	{
	#ifdef ALPHABLENDING
		DoAlphaBlending( a_Depth + 1 );
	#endif
	#ifdef REFRACTIONS
		DoRefractions( a_Depth + 1 );
	#endif
	#ifdef REFLECTIONS
		DoReflections( a_Depth + 1 );
	#endif
	}
	// process results
	for ( uint r = 0; r < PACKETSIZE; r++ ) if (refmask[r]) 
	{
		// apply beer's law
		const Color absorbance = OID->prim[r]->GetMaterial()->GetAbsorbance() * -(reinterpret_cast<float*>(m_ID->dist4)[r]);
		const __m128 a4 = _mm_set_ps( 0, expf( absorbance.r ), expf( absorbance.g ), expf( absorbance.b ) );
		OID->color[r].rgba = _mm_add_ps( OID->color[r].rgba, _mm_mul_ps( a4, _mm_mul_ps( _mm_set_ps1( refval[r] ), m_ID->color[r].rgba ) ) );
	}
	// restore to normal operation
	m_RP = ORP;
	m_ID = OID;
}

// -----------------------------------------------------------
// LineTracer::TraceAARays
// Render a packet of AA rays
// -----------------------------------------------------------
void LineTracer::TraceAARays()
{
#ifdef GATHERSTATS
	m_Rays += m_RP->packetsize;
#endif
	// actual tracing
	for ( uint r = 0; r < m_RP->packetq; r++ ) 
	{
		m_RP->Normalize( r );
		m_ID->dist4[r] = thousand;
	}
	m_RP->BuildPlanesGeneric();
#ifdef ALTFIRST
	// calculate quadrant
	unsigned int quad = ((reinterpret_cast<float*>(m_RP->dx4)[0] < 0)?1:0) + 
						((reinterpret_cast<float*>(m_RP->dy4)[0] < 0)?2:0) + 
						((reinterpret_cast<float*>(m_RP->dz4)[0] < 0)?4:0);
#endif
	// traverse
	uint stackptr = 0, first = 0;
	BVHNode* node = SceneGraph::GetSceneRoot();
	Primitive** prim = MManager::GetBVHPrims();
	BVHNode* pool = MManager::GetBVHPool();
	while (1)
	{
		// find first active ray (if any)
		FindFirstGeneric( first, *node );
		if (first < m_RP->packetsize)
		{
			// process results
			if (!node->IsLeaf())
			{
			#ifndef ALTFIRST
				const uint lidx = m_RP->sign[first + (node->GetAxis() << (PACKETSHFT * 2))] ^ node->GetFirst();
			#else
				const uint lidx = (node->GetDirMask() >> quad) & 1;
			#endif
				m_Stack[stackptr].node = &pool[node->GetLeft() + 1 - lidx];
				m_Stack[stackptr++].first = first;
				node = &pool[node->GetLeft() + lidx];
				continue;
			}
			else
			{
				// intersect
				const uint start = node->GetStart(), count = node->GetTCount();
				UpdateGenericSubmask( first, *node ); 
				for ( uint i = 0; i < count; i++ ) IntersectGeneric( first, *prim[start + i] );
			#ifdef GATHERSTATS
				m_Leafs++, m_Ints += count;
			#endif
			}
		}
		if (!stackptr) break;
		node = m_Stack[--stackptr].node;
		first = m_Stack[stackptr].first;
	}
	GetColorAtIP();
	ApplyLights();
	m_Depth = 0;
#ifdef ALPHABLENDING
	DoAlphaBlending( 0 );
#endif
#ifdef REFRACTIONS
	DoRefractions( 0 );
#endif
#ifdef REFLECTIONS
	DoReflections( 0 );
#endif
	// process results
	for ( uint r = 0, t = 0; t < m_RP->packetq; t++, r += 4 )
	{
		const __m128 final4 = _mm_mul_ps( _mm_set_ps1( 0.25f ), _mm_add_ps( _mm_add_ps( m_ID->color[t * 4 + 0].rgba, m_ID->color[t * 4 + 1].rgba ), _mm_add_ps( m_ID->color[t * 4 + 2].rgba, m_ID->color[t * 4 + 3].rgba ) ) );
		const float* final = (const float*)reinterpret_cast<const float*>(&final4);
		const unsigned int red = MIN( 255, (int)final[2] );
		const unsigned int green = MIN( 255, (int)final[1] );
		const unsigned int blue = MIN( 255, (int)final[0] );
		m_Buffer[m_ID->addr[r]] = (red << 16) + (green << 8) + blue;
	}
}

// -----------------------------------------------------------
// LineTracer::TileAA
// Anti-aliasing for a tile
// ways to improve this:
// 1. Increase tile size; this will reduce chances that packets will not be full, since only the last generated packet
//    for a tile contains empty space. Problem: Growing the tile size to 64x64 will reduce the available resolutions,
//    even 640x480 isn't possible anymore.
// 2. Determine the set of AA rays, then split in packets that minimize the area of their screen-space bounding box.
//    This may be an expensive heuristic...
// CHECK: A full packet will get split in four for reflections / refractions, but this doesn't make sense... Use a
//        different test in those methods to see if this is an AA packet (currently: if (packetq == PACKETQ) ).
// We may need a better way to handle resolutions not dividable by 32. 800x600 cannot be supported in full-screen,
// currently. Perhaps render to the nearest (smaller) res that does work? Would already improve matters. It would also
// be nice if we could render to 512x384, for instance.
// -----------------------------------------------------------
void LineTracer::TileAA( const uint tx, const uint ty )
{
	Pixel* src = m_Buffer;
	uint disco[256];
	memset( disco, 0, 256 * sizeof( uint ) );
	// detect discontinuities
	for ( uint y = 0; y < 15; y++ )
	{
		for ( uint x = 0; x < 15; x++ )
		{
			const int p1r = (src[x] >> 16) & 255, p1g = (src[x] >> 8) & 255, p1b = src[x] & 255;
			const int p2r = (src[x + 1] >> 16) & 255, p2g = (src[x + 1] >> 8) & 255, p2b = src[x + 1] & 255;
			const int p3r = (src[x + 16] >> 16) & 255, p3g = (src[x + 16] >> 8) & 255, p3b = src[x + 16] & 255;
			const int diff1 = MAX( p1r - p2r, p2r - p1r ) + MAX( p1g - p2g, p2g - p1g ) + MAX( p1b - p2b, p2b - p1b );
			const int diff2 = MAX( p1r - p3r, p3r - p1r ) + MAX( p1g - p3g, p3g - p1g ) + MAX( p1b - p3b, p3b - p1b );
			if (diff1 > m_AATreshold) disco[x + (y << 4)] = disco[x + 1 + (y << 4)] = 1;
			if (diff2 > m_AATreshold) disco[x + (y << 4)] = disco[x + ((y + 1) << 4)] = 1;
		}
		src += 16;
	}
	for ( uint x = 0; x < 15; x++ )
	{
		const int p1r = (src[x] >> 16) & 255, p1g = (src[x] >> 8) & 255, p1b = src[x] & 255;
		const int p2r = (src[x + 1] >> 16) & 255, p2g = (src[x + 1] >> 8) & 255, p2b = src[x + 1] & 255;
		const int diff1 = MAX( p1r - p2r, p2r - p1r ) + MAX( p1g - p2g, p2g - p1g ) + MAX( p1b - p2b, p2b - p1b );
		if (diff1 > m_AATreshold) disco[x + (15 << 4)] = disco[x + 1 + (15 << 4)] = 1;
	}
	// trace AA rays
	const float ftx = PACKETW * (float)tx, fty = PACKETH * (float)ty;
	uint rayidx = 0;
	m_RP = &m_RPp;
	m_ID = &m_IDp;
	m_RP->qoffset = 0;
	m_RP->offset = 0;
	for ( uint y = 0; y < 16; y++ )
	{
		float fx = ftx - 0.3f;
		const float fy = (fty + (float)y) - 0.3f;
		for ( uint x = 0; x < 16; x++, fx += 1.0f )
		{
			if (disco[x + (y << 4)])
			{
				// spawn AA rays
				m_ID->addr[rayidx] = x + (y << 4);
				for ( uint h = 0; h < 2; h++ ) for ( uint v = 0; v < 2; v++ )
				{
					reinterpret_cast<float*>(m_RP->dx4)[rayidx] = reinterpret_cast<float*>(m_Template.dx4)[0] + m_DX.x * (fx + h * 0.6f) + m_DY.x * (fy + v * 0.6f) - m_Origin.x;
					reinterpret_cast<float*>(m_RP->dy4)[rayidx] = reinterpret_cast<float*>(m_Template.dy4)[0] + m_DX.y * (fx + h * 0.6f) + m_DY.y * (fy + v * 0.6f) - m_Origin.y;
					reinterpret_cast<float*>(m_RP->dz4)[rayidx] = reinterpret_cast<float*>(m_Template.dz4)[0] + m_DX.z * (fx + h * 0.6f) + m_DY.z * (fy + v * 0.6f) - m_Origin.z;
					reinterpret_cast<unsigned int*>(m_RP->mask4)[rayidx] = 0xffffffff;
					if (++rayidx == 256)
					{
						const uint qrayidx = rayidx >> 2;
						m_RP->packetsize = rayidx;
						m_RP->packetq = qrayidx;
						TraceAARays();
						rayidx = 0;
					}
				}
			}
		}
	}
	if (rayidx > 0)
	{
		// trace packet
		const uint qrayidx = rayidx >> 2;
		m_RP->packetsize = rayidx;
		m_RP->packetq = qrayidx;
		TraceAARays();
	}
}

// -----------------------------------------------------------
// LineTracer::PreparePacket
// Prepare a primary packet
// -----------------------------------------------------------
void LineTracer::PreparePacket( const uint tx, const uint ty )
{
	// setup rays for primary packet
	const float ftx = PACKETW * (float)tx, fty = PACKETH * (float)ty;
	const __m128 deltax4 = _mm_set_ps1( m_DX.x * ftx + m_DY.x * fty - m_Origin.x );
	const __m128 deltay4 = _mm_set_ps1( m_DX.y * ftx + m_DY.y * fty - m_Origin.y );
	const __m128 deltaz4 = _mm_set_ps1( m_DX.z * ftx + m_DY.z * fty - m_Origin.z );
	for ( uint i = 0; i < m_RP->packetq; ++i )
	{
		m_RP->dx4[i] = _mm_add_ps( m_RP->dx4[i], deltax4 );
		m_RP->dy4[i] = _mm_add_ps( m_RP->dy4[i], deltay4 );
		m_RP->dz4[i] = _mm_add_ps( m_RP->dz4[i], deltaz4 );
		m_RP->Normalize( i );
	}
	const __m128 dx4 = _mm_add_ps( m_RP->cdx4, deltax4 );
	const __m128 dy4 = _mm_add_ps( m_RP->cdy4, deltay4 );
	const __m128 dz4 = _mm_add_ps( m_RP->cdz4, deltaz4 );
	const __m128 rlen = fastrsqrt( _mm_add_ps( _mm_add_ps( _mm_mul_ps( dx4, dx4 ), _mm_mul_ps( dy4, dy4 ) ), _mm_mul_ps( dz4, dz4 ) ) );
	m_RP->cdx4 = _mm_mul_ps( dx4, rlen );
	m_RP->cdy4 = _mm_mul_ps( dy4, rlen );
	m_RP->cdz4 = _mm_mul_ps( dz4, rlen );
#ifndef ALTFIRST
	m_RP->UpdateSigns();
#endif
	// setup bounding planes (hack version)
	float* cdx = reinterpret_cast<float*>(&m_RP->cdx4);
	float* cdy = reinterpret_cast<float*>(&m_RP->cdy4);
	float* cdz = reinterpret_cast<float*>(&m_RP->cdz4);
	const vector3 e1( cdx[0], cdy[0], cdz[0] ), e2( cdx[1], cdy[1], cdz[1] ); 
	const vector3 e3( cdx[2], cdy[2], cdz[2] ), e4( cdx[3], cdy[3], cdz[3] ); 
#ifdef LEGACYFLIP
	const vector3 N[4] = { e2.Cross( e1 ), e3.Cross( e2 ), e4.Cross( e3 ), e1.Cross( e4 ) };
#else
	const vector3 N[4] = { e1.Cross( e2 ), e2.Cross( e3 ), e3.Cross( e4 ), e4.Cross( e1 ) };
#endif
	m_RP->nx4 = _mm_set_ps( N[0].x, N[1].x, N[2].x, N[3].x );
	m_RP->ny4 = _mm_set_ps( N[0].y, N[1].y, N[2].y, N[3].y );
	m_RP->nz4 = _mm_set_ps( N[0].z, N[1].z, N[2].z, N[3].z );
	m_RP->hn1 = vector3( 0.5f * (N[2].x - N[0].x), 0.5f * (N[2].y - N[0].y), 0.5f * (N[2].z - N[0].z) );
	m_RP->hn2 = vector3( 0.5f * (N[3].x - N[1].x), 0.5f * (N[3].y - N[1].y), 0.5f * (N[3].z - N[1].z) );
	// plane origins and signs
	m_RP->D4 = DOT128( m_Ox4, m_Oy4, m_Oz4, m_RP->nx4, m_RP->ny4, m_RP->nz4 );
	m_RP->UpdateCornerSigns();
}

// -----------------------------------------------------------
// LineTracer::FindFirstPrimary
// Find the first active ray
// -----------------------------------------------------------
void LineTracer::FindFirstPrimary( uint& a_First, const BVHNode& a_Node )
{
	float tmin = 0.00001f, tmax = reinterpret_cast<float*>(m_IDp.dist4)[a_First];
	for ( uint axis = 0; axis < 3; ++axis ) 
	{
		const uint idx = axis * PACKETSIZE + a_First;
		const float t0 = (a_Node.min.cell[axis] - reinterpret_cast<float*>(m_RPp.ox4)[axis * PACKETSIZE]) * reinterpret_cast<float*>(m_RPp.rdx4)[idx];
		const float t1 = (a_Node.max.cell[axis] - reinterpret_cast<float*>(m_RPp.ox4)[axis * PACKETSIZE]) * reinterpret_cast<float*>(m_RPp.rdx4)[idx];
		const float nr = (t0 < t1) ? t0 : t1, fr = (t0 < t1) ? t1 : t0;
		tmin = (tmin < nr) ? nr : tmin, tmax = (fr <  tmax) ? fr : tmax;
	}
	if (tmin <= tmax) return;
	if (++a_First == PACKETSIZE) return;
	// step 2: check if frustum misses box
	const unsigned int* signs = reinterpret_cast<const unsigned int*>(m_RPp.signs4);
	const float* bounds = (const float*)&a_Node;
	const __m128 bx4 = _mm_set_ps( bounds[signs[0]], bounds[signs[1]], bounds[signs[2]], bounds[signs[3]] );
	const __m128 by4 = _mm_set_ps( bounds[signs[4]], bounds[signs[5]], bounds[signs[6]], bounds[signs[7]] );
	const __m128 bz4 = _mm_set_ps( bounds[signs[8]], bounds[signs[9]], bounds[signs[10]], bounds[signs[11]] );
	const __m128 dst4 = DOT128( bx4, by4, bz4, m_RPp.nx4, m_RPp.ny4, m_RPp.nz4 );
	if (_mm_movemask_ps( _mm_cmpgt_ps( dst4, m_RPp.D4 ) )) { a_First = PACKETSIZE; return; }
	// step 3: check all rays
	const uint pfirst = a_First >> 2;
	a_First = PACKETSIZE;
	const __m128 minx4 = _mm_set_ps1( a_Node.min.x ), maxx4 = _mm_set_ps1( a_Node.max.x );
	const __m128 miny4 = _mm_set_ps1( a_Node.min.y ), maxy4 = _mm_set_ps1( a_Node.max.y );
	const __m128 minz4 = _mm_set_ps1( a_Node.min.z ), maxz4 = _mm_set_ps1( a_Node.max.z );
	const __m128 OX4 = m_RPp.ox4[0], OY4 = m_RPp.oy4[0], OZ4 = m_RPp.oz4[0];
	for ( uint r = pfirst; r < PACKETQ; ++r )
	{			
		__m128 tmin4a = small4, tmax4a = m_IDp.dist4[r];
		const __m128 t0a = _mm_mul_ps( _mm_sub_ps( minx4, OX4 ), m_RPp.rdx4[r] );
		const __m128 t1a = _mm_mul_ps( _mm_sub_ps( maxx4, OX4 ), m_RPp.rdx4[r] );
		const __m128 nra = _mm_min_ps( t0a, t1a ), fra = _mm_max_ps( t0a, t1a );
		tmin4a = _mm_max_ps( tmin4a, nra ), tmax4a = _mm_min_ps( tmax4a, fra );
		const __m128 t0b = _mm_mul_ps( _mm_sub_ps( miny4, OY4 ), m_RPp.rdy4[r] );
		const __m128 t1b = _mm_mul_ps( _mm_sub_ps( maxy4, OY4 ), m_RPp.rdy4[r] );
		const __m128 nrb = _mm_min_ps( t0b, t1b ), frb = _mm_max_ps( t0b, t1b );
		tmin4a = _mm_max_ps( tmin4a, nrb ), tmax4a = _mm_min_ps( tmax4a, frb );
		const __m128 t0c = _mm_mul_ps( _mm_sub_ps( minz4, OZ4 ), m_RPp.rdz4[r] );
		const __m128 t1c = _mm_mul_ps( _mm_sub_ps( maxz4, OZ4 ), m_RPp.rdz4[r] );
		const __m128 nrc = _mm_min_ps( t0c, t1c ), frc = _mm_max_ps( t0c, t1c );
		tmin4a = _mm_max_ps( tmin4a, nrc ), tmax4a = _mm_min_ps( tmax4a, frc );
		const uint ires = _mm_movemask_ps( _mm_cmple_ps( tmin4a, tmax4a ) );
		if (ires) { a_First = r * 4 + m_Offset[ires]; break; }
	}
}

#if 0

// -----------------------------------------------------------
// LineTracer::FindFirstPrimaryEx
// Find the first active ray for a pair of nodes
// -----------------------------------------------------------
const uint LineTracer::CheckFirstPrimary( const uint a_First, BVHNode* a_Pair, uint a_FIdx ) const
{
	const BVHNode* node1 = &a_Pair[a_FIdx];
	const BVHNode* node2 = &a_Pair[1 - a_FIdx];
	// prepare Jeroen's intersection data
	const __m128 XXXX = _mm_set_ps( node1->min.x, node1->max.x, node2->min.x, node2->max.x );
	const __m128 YYYY = _mm_set_ps( node1->min.y, node1->max.y, node2->min.y, node2->max.y );
	const __m128 ZZZZ = _mm_set_ps( node1->min.z, node1->max.z, node2->min.z, node2->max.z );
	const float* dist = reinterpret_cast<const float*>(&m_IDp.dist4[0]);
	__m128 tmin = _mm_set1_ps( 0.00001f ), tmax = _mm_set_ps1( dist[a_First] );
	const float* rdx = reinterpret_cast<const float*>(&m_RPp.rdx4[0]);
	const float* rdy = reinterpret_cast<const float*>(&m_RPp.rdy4[0]);
	const float* rdz = reinterpret_cast<const float*>(&m_RPp.rdz4[0]);
	const __m128 tx01 = _mm_mul_ps( _mm_sub_ps( XXXX, m_Ox4 ), _mm_set_ps1( rdx[a_First] ) );
	const __m128 tx10 = _mm_shuffle_ps( tx01, tx01, _MM_SHUFFLE( 2, 3, 0, 1 ) );
	tmax = _mm_min_ps( tmax, _mm_max_ps( tx01, tx10 ) );
	tmin = _mm_max_ps( tmin, _mm_min_ps( tx01, tx10 ) );
	const __m128 ty01 = _mm_mul_ps( _mm_sub_ps( YYYY, m_Oy4 ), _mm_set_ps1( rdy[a_First] ) );
	const __m128 ty10 = _mm_shuffle_ps( ty01, ty01, _MM_SHUFFLE( 2, 3, 0, 1 ) );
	tmax = _mm_min_ps( tmax, _mm_max_ps( ty01, ty10 ) );
	tmin = _mm_max_ps( tmin, _mm_min_ps( ty01, ty10 ) );
	const __m128 tz01 = _mm_mul_ps( _mm_sub_ps( ZZZZ, m_Oz4 ), _mm_set_ps1( rdz[a_First] ) );
	const __m128 tz10 = _mm_shuffle_ps( tz01, tz01, _MM_SHUFFLE( 2, 3, 0, 1 ) );
	tmax = _mm_min_ps( tmax, _mm_max_ps( tz01, tz10 ) );
	tmin = _mm_max_ps( tmin, _mm_min_ps( tz01, tz10 ) );
	return _mm_movemask_ps( _mm_cmple_ps( tmin, tmax ) );
}

void LineTracer::FindFirstPrimaryEx( uint& a_First, const BVHNode* a_Node ) const
{
	if (++a_First == PACKETSIZE) return;
	// step 2: check if frustum misses box
	const unsigned int* signs = (const unsigned int*)&m_RPp.signs4;
	const float* bounds = (const float*)a_Node;
	const __m128 bx4 = _mm_set_ps( bounds[signs[0]], bounds[signs[1]], bounds[signs[2]], bounds[signs[3]] );
	const __m128 by4 = _mm_set_ps( bounds[signs[4]], bounds[signs[5]], bounds[signs[6]], bounds[signs[7]] );
	const __m128 bz4 = _mm_set_ps( bounds[signs[8]], bounds[signs[9]], bounds[signs[10]], bounds[signs[11]] );
	const __m128 dst4 = DOT128( bx4, by4, bz4, m_RPp.nx4, m_RPp.ny4, m_RPp.nz4 );
	if (_mm_movemask_ps( _mm_cmpgt_ps( dst4, m_RPp.D4 ) )) { a_First = PACKETSIZE; return; }
	// step 3: check all rays
	const uint pfirst = a_First >> 2;
	a_First = PACKETSIZE;
	const __m128 minx4 = _mm_set_ps1( a_Node->min.x ), maxx4 = _mm_set_ps1( a_Node->max.x );
	const __m128 miny4 = _mm_set_ps1( a_Node->min.y ), maxy4 = _mm_set_ps1( a_Node->max.y );
	const __m128 minz4 = _mm_set_ps1( a_Node->min.z ), maxz4 = _mm_set_ps1( a_Node->max.z );
	const __m128 OX4 = m_RPp.ox4[0], OY4 = m_RPp.oy4[0], OZ4 = m_RPp.oz4[0];
	for ( uint r = pfirst; r < PACKETQ; ++r )
	{			
		__m128 tmin4a = small4, tmax4a = m_IDp.dist4[r];
		const __m128 t0a = _mm_mul_ps( _mm_sub_ps( minx4, OX4 ), m_RPp.rdx4[r] );
		const __m128 t1a = _mm_mul_ps( _mm_sub_ps( maxx4, OX4 ), m_RPp.rdx4[r] );
		const __m128 nra = _mm_min_ps( t0a, t1a ), fra = _mm_max_ps( t0a, t1a );
		tmin4a = _mm_max_ps( tmin4a, nra ), tmax4a = _mm_min_ps( tmax4a, fra );
		const __m128 t0b = _mm_mul_ps( _mm_sub_ps( miny4, OY4 ), m_RPp.rdy4[r] );
		const __m128 t1b = _mm_mul_ps( _mm_sub_ps( maxy4, OY4 ), m_RPp.rdy4[r] );
		const __m128 nrb = _mm_min_ps( t0b, t1b ), frb = _mm_max_ps( t0b, t1b );
		tmin4a = _mm_max_ps( tmin4a, nrb ), tmax4a = _mm_min_ps( tmax4a, frb );
		const __m128 t0c = _mm_mul_ps( _mm_sub_ps( minz4, OZ4 ), m_RPp.rdz4[r] );
		const __m128 t1c = _mm_mul_ps( _mm_sub_ps( maxz4, OZ4 ), m_RPp.rdz4[r] );
		const __m128 nrc = _mm_min_ps( t0c, t1c ), frc = _mm_max_ps( t0c, t1c );
		tmin4a = _mm_max_ps( tmin4a, nrc ), tmax4a = _mm_min_ps( tmax4a, frc );
		const uint ires = _mm_movemask_ps( _mm_cmple_ps( tmin4a, tmax4a ) );
		if (ires) { a_First = r * 4 + m_Offset[ires]; break; }
	}
}

// -----------------------------------------------------------
// LineTracer::RenderTile
// Execute a task
// -----------------------------------------------------------
void LineTracer::RenderTile( const uint tx, const uint ty )
{
	// prepare packet
	m_RP = &m_RPp, m_ID = &m_IDp;
	memcpy( m_RP->ox4, &m_Template.ox4, 12 * PACKETSIZE );
	memcpy( &m_RP->cdx4, &m_Template.cdx4, 3 * 4 * 4 );
	memcpy( m_RP->addr, &m_Template.addr, 4 * PACKETSIZE );
	memcpy( m_RP->dx4, &m_Template.dx4, 12 * PACKETQ * 4 );
	m_RP->offset = m_RP->qoffset = 0, m_RP->packetsize = 256, m_RP->packetq = 64;
	PreparePacket( tx, ty );
	const unsigned int quad = ((reinterpret_cast<float*>(m_RP->dx4)[0] < 0)?1:0) + 
							  ((reinterpret_cast<float*>(m_RP->dy4)[0] < 0)?2:0) + 
							  ((reinterpret_cast<float*>(m_RP->dz4)[0] < 0)?4:0);
	for ( uint r = 0; r < PACKETQ; ++r ) m_ID->dist4[r] = thousand;
	uint stackptr = 0, first = 0;
	BVHNode* root = SceneGraph::GetSceneRoot(), *nodepair = 0, *pool = MManager::GetBVHPool();
	Primitive** prim = MManager::GetBVHPrims();
	// process root (only 'mono' node)
	uint fidx = (root->GetDirMask() >> quad) & 1;
	nodepair = &pool[root->GetLeft()]; // if fidx == 0 then traverse nodepair[0] first, otherwise nodepair[1]
	// process remaining nodes
	while (1)
	{
		// put [1] on the stack
		uint rfirst = first;
	#if 1
		const int result = CheckFirstPrimary( first, nodepair, fidx );
		if (!(result & 4)) FindFirstPrimaryEx( first, &nodepair[fidx] );
		if (!(result & 1)) FindFirstPrimaryEx( rfirst, &nodepair[1 - fidx] );
	#else
		FindFirstPrimary( rfirst, nodepair[1 - fidx] );
		FindFirstPrimary( first, nodepair[fidx] );
	#endif
		if (rfirst < m_RP->packetsize)
		{	
			const BVHNode* node = &nodepair[1 - fidx];
			if (!node->IsLeaf())
			{
				m_Stack[stackptr].node = &pool[node->GetLeft()];
				m_Stack[stackptr].fidx = (node->GetDirMask() >> quad) & 1;
				m_Stack[stackptr++].first = rfirst;
			}
			else // intersect
			{
				const uint start = node->GetStart(), count = node->GetTCount();
				for ( uint i = 0; i < count; i++ ) IntersectPrimary( rfirst, *prim[start + i] );
			}
		}
		if (first < m_RP->packetsize)
		{
			const BVHNode* node = &nodepair[fidx];
			if (!node->IsLeaf())
			{
				fidx = (node->GetDirMask() >> quad) & 1;
				nodepair = &pool[node->GetLeft()];
				continue;
			}
			else // intersect
			{
				const uint start = node->GetStart(), count = node->GetTCount();
				for ( uint i = 0; i < count; i++ ) IntersectPrimary( first, *prim[start + i] );
			}
		}
		if (!stackptr) break;
		nodepair = m_Stack[--stackptr].node;
		fidx = m_Stack[stackptr].fidx;
		first = m_Stack[stackptr].first;
	}
	for ( unsigned int i = 0; i < PACKETQ; i++ )
	{
		const __m128i dist4 = _mm_cvtps_epi32( m_ID->dist4[i] );
		const unsigned int* dist = (const unsigned int*)reinterpret_cast<const unsigned int*>(&dist4);
		m_Buffer[m_RP->addr[(i << 2)]] = dist[0], m_Buffer[m_RP->addr[(i << 2) + 1]] = dist[1];
		m_Buffer[m_RP->addr[(i << 2) + 2]] = dist[2], m_Buffer[m_RP->addr[(i << 2) + 3]] = dist[3];
	}
}

#else

// -----------------------------------------------------------
// LineTracer::RenderTile
// Execute a task
// -----------------------------------------------------------
void LineTracer::RenderTile( const uint tx, const uint ty )
{
	// prepare packet
#ifdef TILETIMING
	wallclock_t timer;
	timer.reset();
#endif
#ifdef GATHERSTATS
	m_Rays += PACKETSIZE;
#endif
	m_RP = &m_RPp;
	m_ID = &m_IDp;
	memcpy( m_RP->ox4, &m_Template.ox4, 12 * PACKETSIZE );
	memcpy( &m_RP->cdx4, &m_Template.cdx4, 3 * 4 * 4 );
	memcpy( m_RP->addr, &m_Template.addr, 4 * PACKETSIZE );
	memcpy( m_RP->dx4, &m_Template.dx4, 12 * PACKETQ * 4 );
	m_RP->offset = m_RP->qoffset = 0;
	m_RP->packetsize = 256;
	m_RP->packetq = 64;
	PreparePacket( tx, ty );
#ifdef ALTFIRST
	// calculate quadrant
	unsigned int quad = ((reinterpret_cast<float*>(m_RP->dx4)[0] < 0)?1:0) + 
						((reinterpret_cast<float*>(m_RP->dy4)[0] < 0)?2:0) + 
						((reinterpret_cast<float*>(m_RP->dz4)[0] < 0)?4:0);
#endif
	// trace packet
	for ( uint r = 0; r < PACKETQ; ++r ) m_ID->dist4[r] = thousand;
#ifndef MINIMALSHADING
	memset( m_RP->mask4, 255, PACKETQ * 16 );
	memset( m_LRP.mask4, 255, PACKETQ * 16 );
	memset( m_RPsec[0].mask4, 255, PACKETQ * 16 );
	memset( m_RPsec[1].mask4, 255, PACKETQ * 16 );
#endif
	uint stackptr = 0, first = 0;
	BVHNode* node = SceneGraph::GetSceneRoot();
	Primitive** prim = MManager::GetBVHPrims();
	BVHNode* pool = MManager::GetBVHPool();
	while (1)
	{
		// see if any ray intersects the current node
		FindFirstPrimary( first, *node );
		if (first < m_RP->packetsize)
		{
			// process results
			if (!node->IsLeaf())
			{
			#ifndef ALTFIRST
				const uint lidx = m_RP->sign[first + (node->GetAxis() << (PACKETSHFT * 2))] ^ node->GetFirst();
			#else
				const uint lidx = (node->GetDirMask() >> quad) & 1;
			#endif
				m_Stack[stackptr].node = &pool[node->GetLeft() + 1 - lidx];
				m_Stack[stackptr++].first = first;
				node = &pool[node->GetLeft() + lidx];
				continue;
			}
			else
			{
				// intersect
				const uint start = node->GetStart(), count = node->GetTCount();
				for ( uint i = 0; i < count; i++ ) IntersectPrimary( first, *prim[start + i] );
			#ifdef GATHERSTATS
				m_Leafs++, m_Ints += count;
			#endif
			}
		}
		if (!stackptr) break;
		node = m_Stack[--stackptr].node;
		first = m_Stack[stackptr].first;
	}
	// intersect skydome
	if (m_Dome)
	{
		const __m128 dist4 = _mm_set_ps1( SKYDOMERADIUS );
		for ( unsigned int r = 0; r < m_RP->packetq; r++ )
		{
			const __m128 mask4 = _mm_cmplt_ps( dist4, m_ID->dist4[r] );
			const __m128i* imask4 = (const __m128i*)reinterpret_cast<const __m128*>(&mask4);
			m_ID->prim4[r] = _mm_or_si128( _mm_andnot_si128( *imask4, m_ID->prim4[r] ), _mm_and_si128( *imask4, m_Dome4 ) );
		}
	}
	// shading
#ifdef MINIMALSHADING
	for ( unsigned int i = 0, r = 0; i < PACKETQ; i++, r += 4 )
	{
		__m128i dist4 = _mm_cvtps_epi32( m_ID->dist4[i] );
		unsigned int* dist = (unsigned int*)reinterpret_cast<unsigned int*>(&dist4);
		m_Buffer[m_RP->addr[r]] = dist[0];
		m_Buffer[m_RP->addr[r + 1]] = dist[1];
		m_Buffer[m_RP->addr[r + 2]] = dist[2];
		m_Buffer[m_RP->addr[r + 3]] = dist[3];
	}
#else
	GetColorAtIP();
	ApplyLights();
	m_Depth = 0;
#ifdef ALPHABLENDING
	DoAlphaBlending( 0 );
#endif
#ifdef REFRACTIONS
	DoRefractions( 0 );
#endif
#ifdef REFLECTIONS
	DoReflections( 0 );
#endif
	__m128 maxc4 = _mm_set_ps1( 255.0f );
	for ( unsigned int i = 0, r = 0; i < PACKETQ; i++, r += 4 )
	{
		const __m128i t0 = _mm_cvtps_epi32( _mm_min_ps( m_ID->color[r].rgba, maxc4 ) );
		const __m128i t1 = _mm_cvtps_epi32( _mm_min_ps( m_ID->color[r + 1].rgba, maxc4 ) );
		const __m128i t2 = _mm_cvtps_epi32( _mm_min_ps( m_ID->color[r + 2].rgba, maxc4 ) );
		const __m128i t3 = _mm_cvtps_epi32( _mm_min_ps( m_ID->color[r + 3].rgba, maxc4 ) );
		const __m128i t4 = _mm_packs_epi32( t0, t1 ), t6 = _mm_packs_epi32( t2, t3 ), t5 = _mm_packus_epi16( t4, t6 );
		const unsigned int* p = (const unsigned int*)reinterpret_cast<const unsigned int*>(&t5);
		m_Buffer[m_RP->addr[r]] = p[0], m_Buffer[m_RP->addr[r + 1]] = p[1];
		m_Buffer[m_RP->addr[r + 2]] = p[2], m_Buffer[m_RP->addr[r + 3]] = p[3];
	}
#endif
}

#endif

// -----------------------------------------------------------
// LineTracer::Run
// Render thread
// -----------------------------------------------------------
void LineTracer::run()
{
	while (1)
	{
		WaitForSingleObject( waitforgo[m_Thread], INFINITE );
		const uint xtiles = Engine::m_Width / PACKETW;
		m_Template = Engine::m_Template;
		while (1)
		{
			if (waiting > 0)
			{
				volatile LONG w = InterlockedDecrement( &waiting );
				if (w >= 0) 
				{
					const uint tx = w % xtiles, ty = w / xtiles;
					RenderTile( tx, ty );
					if (Engine::m_AATreshold < 512) TileAA( tx, ty );
					const uint offset = tx * PACKETW + ty * PACKETH * m_Pitch;
					__m128i* dst = (__m128i*)(m_Dest + offset);
					__m128i* src = (__m128i*)m_Buffer;
					for ( unsigned int y = 0; y < 16; y++ )
					{
						for ( unsigned int x = 0; x < 4; x++ ) _mm_stream_si128( dst + x, src[x] );
						dst += m_Pitch >> 2;
						src += 4;
					}
				}
			}
			else { SetEvent( waitfordone[m_Thread] ); break; }
		}
	}
}

// -----------------------------------------------------------
// LineTracer::runonce1()
// Render tasks - non-threaded - part 1
// -----------------------------------------------------------
void LineTracer::runonce1()
{
	const uint xtiles = Engine::m_Width / PACKETW;
	m_Template = Engine::m_Template;
	while (waiting > 0)
	{
		volatile LONG w = InterlockedDecrement( &waiting );
		if (w >= 0) 
		{
			const uint tx = w % xtiles, ty = w / xtiles;
			RenderTile( tx, ty );
			if (Engine::m_AATreshold < 512) TileAA( tx, ty );
			const uint offset = tx * PACKETW + ty * PACKETH * m_Pitch;
			__m128i* dst = (__m128i*)(m_Dest + offset);
			__m128i* src = (__m128i*)m_Buffer;
			for ( unsigned int y = 0; y < 16; y++ )
			{
				for ( unsigned int x = 0; x < 4; x++ ) _mm_stream_si128( dst + x, src[x] );
				dst += m_Pitch >> 2;
				src += 4;
			}
		}
	}
}

// -----------------------------------------------------------
// Engine::SetupTemplate
// Setup the first ray packet, to be updated incrementally
// -----------------------------------------------------------
void Engine:: SetupTemplate( RayPacket& a_Pos )
{
	uint rayidx = 0;
	for ( uint ty = 0; ty < 2; ty++ ) for ( uint tx = 0; tx < 2; tx++ )
	{
		for ( uint ry = 0; ry < (PACKETH / 4); ry++ ) for ( uint rx = 0; rx < (PACKETW / 4); rx++ )
		{
			const float rayx = tx * (PACKETW / 2) + rx * 2.0f, rayy = ty * (PACKETH / 2) + ry * 2.0f;
			for ( uint py = 0; py < 2; py++ ) for ( uint px = 0; px < 2; px++ )
			{
				const vector3 pos = m_P1 + (rayx + px) * m_DX + (rayy + py) * m_DY;
				a_Pos.SetDirection( rayidx, pos );
				a_Pos.SetOrigin( rayidx, m_Origin );
				a_Pos.addr[rayidx++] = tx * (PACKETW / 2) + rx * 2 + px + 
									  (ty * (PACKETH / 2) + ry * 2 + py) * 16;
			}
		}
	}
	// setup corner rays
	const vector3 pos2 = m_P1 + (PACKETW - 1) * m_DX;
	const vector3 pos3 = m_P1 + (PACKETW - 1) * m_DX + (PACKETH - 1) * m_DY;
	const vector3 pos4 = m_P1 + (PACKETH - 1) * m_DY;
	float* cdx = reinterpret_cast<float*>(&a_Pos.cdx4);
	float* cdy = reinterpret_cast<float*>(&a_Pos.cdy4);
	float* cdz = reinterpret_cast<float*>(&a_Pos.cdz4);
	cdx[0] = m_P1.x, cdy[0] = m_P1.y, cdz[0] = m_P1.z;
	cdx[1] = pos2.x, cdy[1] = pos2.y, cdz[1] = pos2.z;
	cdx[2] = pos3.x, cdy[2] = pos3.y, cdz[2] = pos3.z;
	cdx[3] = pos4.x, cdy[3] = pos4.y, cdz[3] = pos4.z;
}
	
// -----------------------------------------------------------
// Engine::Render
// Render using a camera
// -----------------------------------------------------------
void Engine::Render( Camera* a_Cam )
{
	vector3 pos = a_Cam->GetPosition();
	vector3 target = a_Cam->GetTarget();
	Render( pos, target, a_Cam );
}	

// -----------------------------------------------------------
// Engine::Render
// Render using a camera
// -----------------------------------------------------------
void Engine::Render( const vector3& a_Pos, const vector3& a_X, const vector3& a_Y, const vector3& a_Z )
{
	matrix m;
	m[0] = a_X.x, m[1] = a_X.y, m[2] = a_X.z;
	m[4] = a_Y.x, m[5] = a_Y.y, m[6] = a_Y.z;
	m[8] = a_Z.x, m[9] = a_Z.y, m[10] = a_Z.z;
	Render( a_Pos, m );
}	
	
// -----------------------------------------------------------
// Engine::Render
// Main rendering method
// -----------------------------------------------------------
void Engine::Render( vector3& a_Pos, vector3& a_Target, Camera* a_Cam )
{
	matrix m;
	if (!a_Cam)
	{
		vector3 zaxis = a_Target - a_Pos, up( 0, 1, 0 ); zaxis.Normalize();
		vector3 xaxis = up.Cross( zaxis ); xaxis.Normalize();
		vector3 yaxis = xaxis.Cross( -zaxis ); yaxis.Normalize();
		m[0] = xaxis.x, m[1] = xaxis.y, m[2] = xaxis.z;
		m[4] = yaxis.x, m[5] = yaxis.y, m[6] = yaxis.z;
		m[8] = zaxis.x, m[9] = zaxis.y, m[10] = zaxis.z;
	}
	else
	{
		m = a_Cam->GetMatrix();
	}
	Render( a_Pos, m );
}

void Engine::Render( const vector3& a_Pos, const matrix& a_Mat )
{
	// set eye and screen plane position
	const float xp = 4, yp = ((float)m_Height / (float)m_Width) * xp;
#ifdef LEGACYFLIP
	m_P1 = vector3(  xp,  yp, 5 ), m_P2 = vector3( -xp,  yp, 5 );
	m_P3 = vector3( -xp, -yp, 5 ), m_P4 = vector3(  xp, -yp, 5 );
#else
	m_P1 = vector3( -xp,  yp, 5 ), m_P2 = vector3(  xp,  yp, 5 );
	m_P3 = vector3(  xp, -yp, 5 ), m_P4 = vector3( -xp, -yp, 5 );
#endif
	// calculate camera matrix
	matrix m = a_Mat;
	m.Invert();
	m[3] = a_Pos.x, m[7] = a_Pos.y, m[11] = a_Pos.z;
	// move camera
	m_Origin = vector3( 0, 0, 0 );
	m_Origin = m.Transform( m_Origin );
	m_P1 = m.Transform( m_P1 ), m_P2 = m.Transform( m_P2 );
	m_P3 = m.Transform( m_P3 ),	m_P4 = m.Transform( m_P4 );
	// screen plane deltas
	m_DX = (m_P2 - m_P1) * (1.0f / m_Width);
	m_DY = (m_P4 - m_P1) * (1.0f / m_Height );
	SetupTemplate( m_Template );
	// add jobs
	const uint xtiles = m_Width / PACKETW, ytiles = m_Height / PACKETH;
	waiting = xtiles * ytiles;
	// update light tree
	Scene::GetLightBVH()->Build( Scene::GetLights(), Scene::GetNrLights() );
	// execute tasks
	RTimer.reset();
	Primitive* pr = SceneGraph::GetNode( 0 )->GetPrim( 0 );
	const __m128 ambR4 = _mm_set_ps1( Scene::m_Ambient.r );
	const __m128 ambG4 = _mm_set_ps1( Scene::m_Ambient.g );
	const __m128 ambB4 = _mm_set_ps1( Scene::m_Ambient.b );
	const __m128 fogR4 = _mm_set_ps1( 256.0f * Scene::m_FogColor.r );
	const __m128 fogG4 = _mm_set_ps1( 256.0f * Scene::m_FogColor.g );
	const __m128 fogB4 = _mm_set_ps1( 256.0f * Scene::m_FogColor.b );
	for ( uint r = 0; r < m_Cores; ++r ) 
	{
		LT[r].SetBuffer( m_Final, m_Final, m_BDest, m_Pitch );
		LT[r].SetExtends( Scene::GetExtends() );
		LT[r].SetOrigin( m_Origin );
		LT[r].SetDeltas( m_DX, m_DY );
		LT[r].ResetCounters();
		LT[r].m_Fog = Scene::m_Fog;
		LT[r].m_FogDensity4 = Scene::m_FogDensity4;
		LT[r].m_FogTop4 = Scene::m_FogTop4;
		LT[r].m_AmbientR4 = ambR4;
		LT[r].m_AmbientG4 = ambG4;
		LT[r].m_AmbientB4 = ambB4;
		LT[r].m_FogColorr4 = fogR4;
		LT[r].m_FogColorg4 = fogG4;
		LT[r].m_FogColorb4 = fogB4;
		LT[r].m_Photons = m_Photons;
		LT[r].m_Dome4 = _mm_set1_epi32( (uint)Scene::m_Dome );
		LT[r].m_Dome = Scene::m_Dome;
		LT[r].m_SDScale = Scene::m_SDScale;
	#ifdef PHOTONMAPPING
		LT[r].m_GIDots = m_GIDots;
		LT[r].m_GIVoronoi = m_GIVoronoi;
		LT[r].m_GITicks = 0;
		LT[r].m_SampleDist = PhotonMapper::m_SearchDist;
		LT[r].m_SampleSqDist = PhotonMapper::m_SearchDist * PhotonMapper::m_SearchDist;
		LT[r].m_SampleDot = PhotonMapper::m_SampleDot;
	#endif
		LT[r].m_AATreshold = m_AATreshold;
		LT[r].m_Counter1 = LT[r].m_Counter2 = LT[r].m_Counter3 = 0;
		for ( uint p = 0; p < PACKETSIZE; p++ )
			LT[r].m_IDp.prim[p] = LT[r].m_LID.prim[p] = LT[r].m_IDsec[0].prim[p] = LT[r].m_IDsec[1].prim[p] = pr;
	}
	for ( uint r = 0; r < m_Cores - 1; r++ ) SetEvent( waitforgo[r] );
	LT[m_Cores - 1].runonce1();
	WaitForMultipleObjects( m_Cores - 1, waitfordone, true, INFINITE );
	m_RenderTime = (float)RTimer.elapsed();
	RTimer.reset();
	waiting = (xtiles * ytiles) >> 2;
	uint raysbeforeaa = 0;
	for ( uint r = 0; r < m_Cores; ++r ) raysbeforeaa += LT[r].RaysCast();
	m_AATime = (float)RTimer.elapsed();
	m_RenderTime += m_AATime;
	RTimer.reset();
	m_RenderTime += (float)RTimer.elapsed();
	uint md = 0;
	Engine::m_RaysCast = Engine::m_Intersections = Engine::m_Leafs = Engine::m_NCInts = Engine::m_AARaysCast = 0;
	Engine::m_GITicks = 0;
	Engine::m_Counter1 = Engine::m_Counter2 = Engine::m_Counter3 = 0;
	for ( uint r = 0; r < m_Cores; ++r )
	{
		Engine::m_RaysCast += LT[r].RaysCast();
		Engine::m_Intersections += LT[r].IntCount();
		Engine::m_Leafs    += LT[r].m_Leafs;
		Engine::m_NCInts   += LT[r].m_NCInts;
		Engine::m_GITicks  += LT[r].m_GITicks;
		Engine::m_Counter1 += LT[r].m_Counter1;
		Engine::m_Counter2 += LT[r].m_Counter2;
		Engine::m_Counter3 += LT[r].m_Counter3;
	}
	Engine::m_AARaysCast = Engine::m_RaysCast - raysbeforeaa;
}