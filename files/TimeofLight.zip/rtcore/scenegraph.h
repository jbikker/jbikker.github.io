// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#pragma once

#include "bvh.h"

namespace Raytracer {

static const vector3 gVector(0,-0.2f,0);
class Primitive;
class Vertex;
class Material;
class Node
{
public:
	enum 
	{ 
		STATIC = 0,
		REFITTABLE = 1,
		DYNAMIC = 2,
		SPECIAL = 3
	};
	Node();
	Node( int a_PCount );
	Node( char* a_Obj, vector3 a_Pos, float a_Scale );
	~Node();
	virtual void Add( Primitive* a_Prim );
	virtual void Add( vector3 a_Centre, float a_Radius, Material* a_Mat ) {};
	Primitive* Get( unsigned int a_Idx ) const { return m_Prim[a_Idx]; }
	void Set( unsigned int a_Idx, Primitive* a_Prim ) { m_Prim[a_Idx] = a_Prim; }
	virtual void Load( char* a_Obj, float a_Scale = 1.0f );
	void SetTransform( matrix& a_Mat ) { m_Mat = a_Mat; }
	matrix& GetTransform() { return m_Mat; }
	Primitive* GetOPrim( int a_Idx ) const { return m_OPrim[a_Idx]; }
	Primitive* GetPrim( int a_Idx ) const { return m_Prim[a_Idx]; }
	Primitive** GetPrimArray() const { return m_Prim; }
	int GetPrimCount() { return m_PCount; }
	virtual void Transform();
	void SetMaterial( Material* a_Mat );
	virtual void Break();
	virtual void Break( vector3 a_Direction );
	virtual void SetGravity( bool a_Bool, vector3 a_Vector = gVector );
	void BuildBVH();
	void Refit();
	void NewFormat();
	void Optimize();
	int GetType() const { return m_Type; }
	void SetType( int a_Type ) { m_Type = a_Type; }	
	int GetBVHRoot() const { return m_Builder->GetRootIdx(); }
	void Constructed( bool a_Flag ) { m_Constructed = a_Flag; }
	bool IsConstructed() const { return m_Constructed; }
	BVHBuilder* GetBuilder() const { return m_Builder; }
	void Disable() { m_Active = false; }
	void Enable() { m_Active = true; }
	bool IsActive() const { return m_Active; }
protected:
	Primitive** m_Prim, **m_OPrim;
	Vertex* m_VPool;
	int m_Type;
	int m_PCount;
	matrix m_Mat;
	BVHBuilder* m_Builder;
	bool m_Constructed, m_Active;
};

class Spheres : public Node
{
public:
	Spheres();
	Spheres( int a_Count );
	~Spheres();
	void Add( vector3 a_Centre, float a_Radius, Material* a_Mat );
	void Transform();
	void SetCentre( int a_Idx, const vector3& a_Centre );
	void SetRadius( int a_Idx, const float a_Radius );
	const vector3 GetCentre( int a_Idx ) const;
	const float GetRadius( int a_Idx ) const;
	const float GetSqRadius( int a_Idx ) const;
	const float GetRRadius( int a_Idx ) const;
private:
	Vertex* m_Vert;
	vector3* m_OCentre;
};

// md2 header
typedef struct
{
	int ident;          // magic number: "IDP2"
	int version;        // version: must be 8
	int skinwidth;      // texture width
	int skinheight;     // texture height
	int framesize;      // size in bytes of a frame
	int num_skins;      // number of skins
	int num_vertices;   // number of vertices per frame
	int num_st;         // number of texture coordinates
	int num_tris;       // number of triangles
	int num_glcmds;     // number of opengl commands
	int num_frames;     // number of frames
	int offset_skins;   // offset skin data
	int offset_st;      // offset texture coordinate data
	int offset_tris;    // offset triangle data
	int offset_frames;  // offset frame data
	int offset_glcmds;  // offset OpenGL command data
	int offset_end;     // offset end of file
} MD2Header;

typedef struct
{
	char name[64];		// texture file name
} MD2Skin;

typedef struct
{
	short u, v;
} MD2UV;

typedef struct
{
	unsigned short vertex[3];	// vertex indices of the triangle
	unsigned short uv[3];		// tcoord indices
} MD2Tri;

typedef struct
{
	unsigned char v[3];			// position
	unsigned char normalIndex;	// normal vector index
} MD2Vert;

typedef struct
{
	vector3 scale;			// scale factor
	vector3 translate;		// translation vector
	char name[16];			// frame name
	vector3* verts;			// list of frame's vertices
} MD2Frame;

class Vertex;
class MD2Node : public Node
{
public:
	MD2Node();
	MD2Node( char* a_Obj, vector3 a_Pos, float a_Scale );
	~MD2Node();
	virtual void Load( char* a_Obj, float a_Scale = 1.0f );
	virtual void Transform();
	void SetAnim( char* a_Name );
	void SetAnimPos( float a_Pos ) { m_APos = a_Pos; }
	int FindFirstFrame( char* a_Name );
	int FindLastFrame( char* a_Name );
private:
	MD2Header m_Header;
	MD2Skin* m_Skins;
	MD2UV* m_TCoords;
	MD2Tri* m_Tris;
	MD2Frame* m_Frames;
	Vertex* m_VArray;
	int* m_GLCmds;
	float m_APos;
	int m_First, m_Last;
};

struct MD5BBox { vector3 min, max; };
struct MD5Vertex { Vertex* v; int start, count; };
struct MD5Weight { int joint; float bias; vector3 pos; };
struct MD5Joint { char name[64]; int id, parent; vector3 pos; quat4 orient; };
struct MD5JointInfo { char name[64]; int parent, flags, startindex; };
struct MD5BaseFrameJoint { vector3 pos; quat4 orient; };

struct MD5Anim
{
	char name[64];
	int	framecount, jointcount, framerate;
	MD5Joint** skelframes;
	MD5BBox* bbox;
	MD5Anim* next;
};

struct MD5Mesh
{
	MD5Vertex* Vertices;
	MD5Weight* Weights;
	int	VertCount;
	int	WeightCount;
	Material* Mat;
};

struct MD5BlendAnim
{
	MD5Anim* anim;
	int framecurrent, framenext;
	float lasttime, blend;
};

struct MD5Attachment
{
	int bone;
	Node* obj;
	vector3 offset;
	matrix m;
	MD5Attachment* next;
	Material** m_MatList;
	int m_MatListCount;
};

class MD5Model : public Node
{
public:
	MD5Model();
	~MD5Model();
	void LoadModel( char* a_Filename );
	void LoadModelNAnimations( char* a_Model );
	void AddAnim( char* a_Filename );
	void RemoveAnim( char* a_Name );
	MD5Anim* GetAnimByName( char* a_Name );
	MD5Anim* GetAnimById( int a_Id );
	void PlayAnim( MD5Anim* a_Anim );
	void PlayAnimByName( char* a_Name );
	void PlayAnimById( int a_Id );
	int GetAnimCount() { return m_AnimCount; }
	MD5Anim* GetCurrentAnim() { return m_AnimCurrent.anim; }
	void Transform();
	void Update( float a_DT );
	char* GetName() const { return m_Name; }
	MD5BBox GetBBox() { return m_BBox; }
	MD5Joint* GetJointById( int a_Id ) { return &m_Skeleton[a_Id]; }
	MD5Joint* GetJointByName( char* a_Name );
	int GetJointCount() { return m_JointCount; }
	int GetMeshCount() { return m_MeshCount; }
	MD5Mesh* GetMesh(int a_Id) { return &m_Meshes[a_Id]; }
	Material** GetMatList() { return m_MatList; }
	int GetMatCount() { return m_MatListCount; }
	int GetVertCount() { return m_VertCount; }
	void SetColorSceme( Color &a_Ambient, Color &a_Diffuse, Color &a_Specular );
	void SetReflection( float a_RefMin, float a_RefMax );
	void SetRefraction( float a_Refr, float a_Index );
	void Detach( Node* a_Obj );
	void Attach( Node* a_Obj, char* a_Bone, vector3 a_Offset = vector3( 0, 0, 0 ) );
	void SetScale( vector3 a_Scale) { m_Scale = a_Scale; }
	vector3 GetScale() { return m_Scale; }
private:
	void RebuildMatList();
	void StripQuotes( char* a_Name );
    void BuildFrameSkeleton( const MD5JointInfo* a_JointInfos, const MD5BaseFrameJoint* a_BaseFrame, const float* a_AnimFrameData, MD5Joint* a_SkelFrame );
	void InterpolateSkeletons( const MD5Joint* a_SkelA, const MD5Joint* a_SkelB, const float a_Interp );
	char* m_Name;
	MD5Mesh* m_Meshes;
	Material** m_MatList;
	MD5Joint* m_BaseSkeleton, *m_Skeleton;
	MD5Anim* m_AnimFirst, *m_AnimLast;
	MD5Attachment* m_AttachFirst, *m_AttachLast;
	MD5BlendAnim m_AnimCurrent, m_AnimNext;
	MD5BBox m_BBox;
	vector3 m_Scale;
	int m_AttachmentCount, m_MatListCount, m_AnimCount, m_JointCount, m_MeshCount, m_VertCount;
};

class StaticMesh : public Node
{
public:
	StaticMesh( int a_PCount );
	void Add( Primitive* a_Prim );
	virtual void Transform() {};
};

class Breakable : public Node
{
public:
	Breakable();
	Breakable( char* a_Obj, vector3 a_Pos, float a_Scale );
	Breakable( char* a_Obj, vector3 a_Pos, float a_Scale, vector3 a_Direction);
	~Breakable();
	virtual void Load( char* a_Obj, float a_Scale = 1.0f );
	virtual void Transform();
	void Break();
	void Explode();
	void Reset();
	void Break( vector3 a_Direction );
	void SetGravity( bool a_Bool, vector3 a_Vector = gVector );
private:
	vector3* m_Pos, *m_DPos;	// position and speed (per polygon)
	vector3* m_Rot, *m_DRot;	// rotations and angular velocity (16)
	matrix* m_Trans;			// matrices representing rotation (16)
	bool m_Broken;				// object is broken or not
	vector3 m_BlastDirection;	// where do the polygons move to
	vector3 m_VGravity;			// gravity vector
	bool m_BGravity;			// gravity boolean
};

#ifdef MULTIBEAM
class MultiBeam
{
public:
	MultiBeam( Light* a_Light ) { m_Light = a_Light; }
	void SetDirection( int a_Idx, vector3& a_Dir ) { a_Dir.Normalize(); m_Dir[a_Idx] = a_Dir; }
	vector3& GetDirection( int a_Idx ) { return m_Dir[a_Idx]; }
	void Transform( matrix& a_Mat );
	inline Light* GetLight() { return m_Light; }
private:
	Light* m_Light;
	vector3 m_Dir[MULTIBEAMDIRS];
};
#endif

class SceneGraph
{
public:
	SceneGraph();
	~SceneGraph();
	static void Update();
	static void AddNode( Node* a_Node ) { m_Node[m_NCount++] = a_Node; }
	static void DeleteNode( Node* a_Node );
	// static void Reset() { m_NCount = 0; }
	static Node* GetNode( unsigned int a_Idx ) { return m_Node[a_Idx]; }
	static void Break();
	static void Break( vector3 a_Direction );
	virtual void SetGravity( bool a_Bool, vector3 a_Vector = gVector );
	static int FindBestMatch( BVHNode* A, BVHNode** list, int lsize );
	static void BuildTopBVH();
	static BVHNode* GetSceneRoot() { return m_BVHRoot; }
	static int GetPolyCount();
	static int GetNodeCount() { return m_NCount; }
private:
	static Node** m_Node;
	static unsigned int m_NCount;
	static BVHNode* m_BVHRoot;
	static int m_BVHFirst;
};

} // namespace Raytracer