// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#pragma once

// original code by Nils Desle

#define MAXJOBTHREADS	16
#define MAXJOBS			128

namespace Raytracer {

class Job
{
public:
	virtual void main() = 0;
protected:
	friend class JobThread;
	void RunCodeWrapper();
};

class JobThread
{
public:
	void CreateAndStartThread( unsigned int threadId );
	void WaitForThreadToStop();
	void Go();
protected:
	friend DWORD JobThreadProc( LPVOID lpParameter );
	void BackgroundTask();
	HANDLE m_GoSignal, m_ThreadHandle;
	int m_ThreadID;
};

class JobManager	// singleton class!
{
protected:
	JobManager( unsigned int numThreads );
public:
	~JobManager();
	static void CreateJobManager( unsigned int numThreads );
	static JobManager* GetJobManager() { return m_JobManager; }
	void AddJob2( Job* a_Job );
	unsigned int GetNumThreads() { return m_NumThreads; }
	void RunJobs();
	void ThreadDone( unsigned int n );
protected:
	friend class JobThread;
	Job* GetNextJob();
	Job* FindNextJob();
	static JobManager* m_JobManager;
	Job* m_JobList[MAXJOBS];
	CRITICAL_SECTION m_CS;
	HANDLE m_ThreadDone[MAXJOBTHREADS];
	unsigned int m_NumThreads, m_JobCount;
	JobThread* m_JobThreadList;
};

} // namespace Raytracer

// EOF