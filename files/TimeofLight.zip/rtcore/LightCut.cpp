#include "LightCut.h"

#include "precomp.h"

#undef max

namespace Raytracer {

/*void LightCut::makeVPLs(int& n, VPL** vpl, LightCutNode* node, int depth, VPL* pool, int& npool)
{
	//depth > n? approximate, make new light
	if (depth>9000)
	{
		std::cout << "max depth\n";
		//VPL* newv=new VPL(node->reprlight->position,node->reprlight->normal,node->totlight);
		//vpl[n] = VPL(node->reprlight->position,node->reprlight->normal,node->totlight);
		pool[npool]=VPL(node->reprlight->position,node->reprlight->normal,node->totlight);
		vpl[n]=&pool[npool];
		npool++;
		n++;
		return;
	}

	//leaf? reprlight = correct light
	if (node->left==0)
	{
		std::cout << "leaf\n";
		vpl[n]=node->reprlight;
		n++;
		return;
	}

		std::cout << "children\n";

	//node? go to children
	makeVPLs(n,vpl,node->left,depth+1,pool,npool);
	makeVPLs(n,vpl,node->right,depth+1,pool,npool);
} */

void test()
{
	
}


//roel: tofix memory leaks
void LightCut::build(VPL* vpl, int nvpl)
{
	std::cout << "building lightcuttree (zzz..)\n";

	LightCutNode** nodes = new LightCutNode*[nvpl];

	LightCutNode* newnodes = (LightCutNode*)MALLOC64(sizeof(LightCutNode)*nvpl*2);
	int nnew=0;
	
	for(int i = 0; i < nvpl; i++)
	{
		//nodes[i] = (LightCutNode*)MALLOC64(sizeof(LightCutNode));
		//*nodes[i] = LightCutNode(&vpl[i]);
		//nodes[i]=new LightCutNode(&vpl[i]);
		newnodes[nnew]=LightCutNode(&vpl[i]);
		nodes[i]=&newnodes[nnew];
		nnew++;
	}

	for(int n=nvpl; n>1; n--)
	{

		float bestmetric=std::numeric_limits<float>::max();
		int besti,bestj;


		for(int i = 0; i < n - 1; i++)
		{
			for(int j = i + 1; j < n; j++)
			{
				float newmet=nodes[i]->getNewMetric(*nodes[j]);

				if (newmet<bestmetric)
				{
					bestmetric=newmet;
					besti=i;
					bestj=j;
				}
			}
		}

		//std::cout << "besti: " << besti << ", bestj: " << bestj << ", metr: " << bestmetric << "\n";

		//nodes[besti] = new LightCutNode(nodes[besti],nodes[bestj]);
		//nodes[besti] = (LightCutNode*)MALLOC64(sizeof(LightCutNode));
		//*nodes[besti] = LightCutNode(nodes[besti],nodes[bestj]);

		newnodes[nnew]=LightCutNode(nodes[besti],nodes[bestj]);
		nodes[besti]=&newnodes[nnew];
		nnew++;

		nodes[bestj] = nodes[n-1];
	}

	root = nodes[0];

	std::cout << "got lightcuttree\n";
}


LightCut::LightCut(void)
{
}

LightCut::~LightCut(void)
{
}

}; // namespace Raytracer