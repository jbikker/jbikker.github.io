// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2008 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#include "precomp.h"

using namespace Raytracer;

_declspec(align(16)) 

Texture* MManager::m_TPtr;
Light* MManager::m_LgtPtr;
unsigned int MManager::m_CurPrim, MManager::m_CurLight;
unsigned int MManager::m_CurText, MManager::m_CurMat;
unsigned int MManager::m_BVHIdx, MManager::m_BVHPIdx;
BVHNode* MManager::m_BVHPool;
Primitive* MManager::m_PrimPtr;
Material* MManager::m_MPtr;
LightList* MManager::m_LLPtr;
LNode* MManager::m_LNPtr;
Primitive** MManager::m_BVHPrim;
LBVHNode* LBVHMManager::m_LBVHNPtr;
unsigned int* MManager::m_Pool;
unsigned int** MManager::m_PList;
int MManager::m_Pools, MManager::m_PLeft;
unsigned int** MManager::m_Tiny;

MManager::MManager()
{
	m_MPtr = (Material*)MALLOC64( MAXMATERIAL * sizeof( Material ) );
	m_CurMat = 0;
	m_TPtr = (Texture*)MALLOC64( 512 * sizeof( Texture ) );
	m_CurText = 0;
}

void MManager::Init( unsigned int a_Size )
{
	a_Size += 20; // take care of some boundaries & stuff
	m_LgtPtr = (Light*)MALLOC64( MAXLIGHTS * sizeof( Light ) );
	m_CurLight = 0;
	m_PrimPtr = (Primitive*)MALLOC64( 50000 * sizeof( Primitive ) );
	m_CurPrim = 0;
	m_LLPtr = (LightList*)MALLOC64( 2048 * sizeof( LightList ) );
	for ( unsigned int i = 0; i < 2048; i++ ) m_LLPtr[i].SetNext( &m_LLPtr[i + 1] );
	m_LNPtr = (LNode*)MALLOC64( 2048 * sizeof( LNode ) );
	for ( unsigned int i = 0; i < 2048; i++ ) m_LNPtr[i].SetLeft( &m_LNPtr[i + 1] );
	m_BVHPool = (BVHNode*)MALLOC64( sizeof( BVHNode ) * (a_Size * 2 + 512) );
	m_BVHIdx = 512; // first 512 reserved for scenegraph
	m_BVHPrim = (Primitive**)MALLOC64( sizeof( Primitive* ) * (a_Size + 512) );
	m_BVHPIdx = 0;
	m_PList = new unsigned int*[2048];
	m_Pool = m_PList[0] = new unsigned int[TINYPOOLSIZE];
	m_PLeft = TINYPOOLSIZE;
	m_Pools = 1;
	m_Tiny = new unsigned int*[512];
	for ( int i = 0; i < 512; i++ ) m_Tiny[i] = 0;
}

Texture* MManager::FindTexture( char* a_Name )
{
	for ( unsigned int i = 0; i < m_CurText; i++ ) if (m_TPtr[i].m_Name)
		if (!strcmp( m_TPtr[i].m_Name, a_Name )) return &m_TPtr[i];
	return 0;
}

void MManager::FreeBVHNodes( int nfirst, int nlast, int pfirst, int plast )
{
	int ndelta = (nlast - nfirst) + 1;
	int pdelta = (plast - pfirst) + 1;
	memcpy( &m_BVHPool[nfirst], &m_BVHPool[nlast + 1], ((m_BVHIdx - 1) - nlast) * sizeof( BVHNode ) );
	memcpy( &m_BVHPrim[pfirst], &m_BVHPrim[plast + 1], ((m_BVHPIdx - 1) - plast) * sizeof( Primitive* ) );
	m_BVHIdx -= ndelta;
	m_BVHPIdx -= pdelta;
	memset( &m_BVHPool[m_BVHIdx + 10], 0, ndelta * sizeof( BVHNode ) );
}

Primitive* MManager::NewPrimitive() { return &m_PrimPtr[m_CurPrim++]; }
Light* MManager::NewLight() { return &m_LgtPtr[m_CurLight++]; }
Texture* MManager::NewTexture() { return &m_TPtr[m_CurText++]; }
Material* MManager::NewMaterial() { m_MPtr[m_CurMat].Init(); return &m_MPtr[m_CurMat++]; }

void MManager::DeleteTiny()
{
	for ( int i = 0; i < m_Pools; i++ ) delete m_PList[i];
	m_Pool = m_PList[0] = new unsigned int[TINYPOOLSIZE];
	m_PLeft = TINYPOOLSIZE;
	m_Pools = 1;
	for ( int i = 0; i < 512; i++ ) m_Tiny[i] = 0;
}