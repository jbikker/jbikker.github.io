// --------------------------------------------------------------------------
// Arauna Ray Tracer - (c) 2004-2007 by Jacco Bikker   <><
// You are free to use Arauna for non-commercial purposes;
// for all other projects: mail bikker.j@nhtv.nl
// __________________________________________________________________________

#pragma once

#define PACKETW	16
#define PACKETH 16
#define PACKETSHFT	4

// derived data, do not change
#define PACKETSIZE	(PACKETW * PACKETH)
#define PACKETQ		(PACKETSIZE/4)

#include "common.h"
#include "windows.h"
#include "sthread.h"

namespace Raytracer {

#define DOT128(ax,ay,az,bx,by,bz) _mm_add_ps( _mm_add_ps( _mm_mul_ps( ax, bx ), _mm_mul_ps( ay, by ) ), _mm_mul_ps( az, bz ) )

static __forceinline __m128 safercp( const __m128 v )
{
	const __m128 nr = _mm_rcp_ps( v );
	const __m128 muls = _mm_mul_ps( _mm_mul_ps( nr, nr ), v );
	return _mm_sub_ps( _mm_add_ps( nr, nr ), _mm_andnot_ps( _mm_cmpeq_ps( v, _mm_set_ps1( 0 ) ), muls ) ); 
}

static __forceinline __m128 fastrcp( const __m128 v )
{
	const __m128 n = _mm_rcp_ps( v );
	return _mm_sub_ps( _mm_add_ps( n, n ), _mm_mul_ps( _mm_mul_ps( v, n ), n ) );
}

// -----------------------------------------------------------
// Intersection result container for 256 rays
// -----------------------------------------------------------
class Primitive;
class IData
{
public:
	void SetNormal( const uint idx, const vector3& n )
	{
		N[idx] = n.x, N[idx + 4] = n.y, N[idx + 8] = n.z;
	}
#ifdef PHOTONMAPPING
	void SetPrimNormal( const uint idx, const vector3& n )
	{
		PN[idx] = n.x, PN[idx + 4] = n.y, PN[idx + 8] = n.z;
	}
#endif
	vector3 GetNormal( const uint idx )
	{
		return vector3( N[idx], N[idx + 4], N[idx + 8] );
	}
	__m128 dist4[PACKETQ];
	// union { __m128 dist4[PACKETQ]; float dist[PACKETQ * 4]; };
#ifdef _WIN64
	Primitive* prim[PACKETQ * 4];
	__m128 shadow[PACKETQ];
#else
	union { __m128i prim4[PACKETQ]; __m128 shadow[PACKETQ]; Primitive* prim[PACKETQ * 4]; };
#endif
	union { __m128i addr4[PACKETQ]; unsigned int addr[PACKETQ * 4]; __m128 phcol[128]; __m128 w4[PACKETQ]; float w[PACKETQ * 4]; };
	union { __m128 u4[PACKETQ]; float u[PACKETQ * 4]; int depth[PACKETQ * 4]; };
	union { __m128 v4[PACKETQ]; float v[PACKETQ * 4]; int depth2[PACKETQ * 4]; };
	Color color[PACKETQ * 4];
	Color colip[PACKETQ * 4];
	union { __m128 N4[PACKETQ * 4]; float N[PACKETQ * 4 * 4]; };
#ifdef PHOTONMAPPING
	union { __m128 PN4[PACKETQ * 4]; float PN[PACKETQ * 4 * 4]; };
#endif
	// improve locality by storing data in array of structs instead of current struct of arrays?
	// that will be LOTS of work in the core...
};

// -----------------------------------------------------------
// IData1  class definition
// -----------------------------------------------------------
struct IData1
{
	Primitive* prim;	// 4
	float u, v;			// 8
	float dist;			// 4
	vector3 N;			// 12
#ifndef _WIN32
	unsigned int dummy; // 4, total 32
#endif
};

// -----------------------------------------------------------
// RayPacket class definition
// -----------------------------------------------------------
class RayPacket
{
public:
	RayPacket() {};
	void Normalize( uint r );
	void FindDominantAxis();
	void FindDominantAxisGeneric();
	void BuildPlanesShadow( const vector3& a_Origin );
	void BuildPlanesShadowGeneric( const vector3& a_Origin, RayPacket* a_RP );
	void BuildPlanesGeneric();
	void SetDirection( const uint idx, const vector3& dir ) 
	{ 
		float* dx = reinterpret_cast<float*>(dx4);
		float* dy = reinterpret_cast<float*>(dy4);
		float* dz = reinterpret_cast<float*>(dz4);
		dx[idx] = dir.x, 
		dy[idx] = dir.y, 
		dz[idx] = dir.z; 
	}
	void SetOrigin( const uint idx, const vector3& pos ) 
	{ 
		float* ox = reinterpret_cast<float*>(ox4);
		float* oy = reinterpret_cast<float*>(oy4);
		float* oz = reinterpret_cast<float*>(oz4);
		ox[idx] = pos.x; 
		oy[idx] = pos.y;
		oz[idx] = pos.z;
	}
	void SetOrigin4( const uint idx, const __m128 x4, const __m128 y4, const __m128 z4 )
	{
		ox4[idx] = x4, oy4[idx] = y4, oz4[idx] = z4;
	}
	__forceinline void ScaleDirection4( const int idx, const __m128 s )
	{
		dx4[idx] = _mm_mul_ps( dx4[idx], s );
		dy4[idx] = _mm_mul_ps( dy4[idx], s );
		dz4[idx] = _mm_mul_ps( dz4[idx], s );
	}
	__forceinline void StartAtIntersection( const RayPacket& restrict rp, const IData& restrict id )
	{
		for ( uint r = 0; r < packetq; r++ )
		{
			ox4[r] = _mm_add_ps( rp.ox4[r], _mm_mul_ps( rp.dx4[r], id.dist4[r] ) );
			oy4[r] = _mm_add_ps( rp.oy4[r], _mm_mul_ps( rp.dy4[r], id.dist4[r] ) );
			oz4[r] = _mm_add_ps( rp.oz4[r], _mm_mul_ps( rp.dz4[r], id.dist4[r] ) );
		}
	}
	__forceinline void CalcReciprocal4( const uint idx )
	{
		rdx4[idx] = safercp( dx4[idx] );
		rdy4[idx] = safercp( dy4[idx] );
		rdz4[idx] = safercp( dz4[idx] );
	}
	__forceinline void CalcReciprocals()
	{
		for ( uint r = 0; r < packetq; r++ ) if (_mm_movemask_ps( mask4[r] ))
		{
			rdx4[r] = safercp( dx4[r] );
			rdy4[r] = safercp( dy4[r] );
			rdz4[r] = safercp( dz4[r] );
		}
	}
	__forceinline void MoveOriginAway( const __m128& amount ) 
	{
		for ( uint r = 0; r < packetq; r++ )
		{
			ox4[r] = _mm_add_ps( ox4[r], _mm_mul_ps( dx4[r], amount ) );
			oy4[r] = _mm_add_ps( oy4[r], _mm_mul_ps( dy4[r], amount ) );
			oz4[r] = _mm_add_ps( oz4[r], _mm_mul_ps( dz4[r], amount ) );
		}
	}
#ifndef ALTFIRST
	__forceinline void UpdateSigns()
	{
		const unsigned int* psigns = (unsigned int*)&dx[0];
		for ( uint r = 0; r < packetsize; ++r )
		{
			sign[r] = psigns[r] >> 31;
			sign[r + PACKETSIZE] = psigns[r + PACKETSIZE] >> 31;
			sign[r + PACKETSIZE * 2] = psigns[r + PACKETSIZE * 2] >> 31;
		}
	}
#endif
	__forceinline void UpdateCornerSigns()
	{
		const unsigned int* osigns = (unsigned int*)&nx4;
		unsigned int* signs = reinterpret_cast<unsigned int*>(signs4);
		for ( uint r = 0; r < 4; ++r )
		{
			signs[r + 0] = (osigns[3 - r] >> 31) * 4 + 0;
			signs[r + 4] = (osigns[7 - r] >> 31) * 4 + 1;
			signs[r + 8] = (osigns[11 - r] >> 31) * 4 + 2;
		}
	}
	// data members
	__m128 ox4[PACKETQ], oy4[PACKETQ], oz4[PACKETQ];
	__m128 signs4[3];
	__m128 rdx4[PACKETQ], rdy4[PACKETQ], rdz4[PACKETQ];
	__m128 nx4, ny4, nz4;
	__m128 D4;
	__m128 cdx4, cdy4, cdz4;
#ifndef ALTFIRST
	uint sign[3 * 4 * PACKETQ]; // 48 * PACKETQ bytes
#endif
	uint addr[PACKETSIZE]; // 4 * PACKETSIZE bytes
	__m128 dx4[PACKETQ], dy4[PACKETQ], dz4[PACKETQ];
	__m128 mask4[PACKETQ];
	__m128 submask4[PACKETQ];
	vector3 hn1, hn2;
	uint packetq, packetsize, qoffset, offset;
	sint maxis, maxdir, dummy1, dummy2;
};

// -----------------------------------------------------------
// BVH traversal stack
// -----------------------------------------------------------
struct BVHNode;
struct BVHStack
{
	BVHNode* node;
	uint fidx, first, dummy;
};

// -----------------------------------------------------------
// LineTracer helper thread class definition
// -----------------------------------------------------------
class Texture;
class Light;
class LineTracer : public Thread
{
public:
	LineTracer() :
		one( _mm_set_ps1( 1.0f ) ), 
		two( _mm_set_ps1( 2.0f ) ), 
		zero( _mm_set_ps1( 0.0f ) ), 
		epsilon( _mm_set_ps1( EPSILON ) ), 
		thousand( _mm_set_ps1( MAXINTDIST ) ), 
		small4( _mm_set_ps1( 0.000001f ) ),
		half4( _mm_set_ps1( 0.5f ) ) {}
	struct Pair
	{
		const Primitive* pr; unsigned int rayid;
	};
	// other methods
	void Init( uint thread );
	INLINE void GetColorAtIP();
	INLINE void ApplyLights();
	INLINE void PreparePacket( const uint tx, const uint ty );
	INLINE void FindFirstPrimary( uint& a_First, const BVHNode& restrict a_Node );
	INLINE const uint CheckFirstPrimary( const uint a_First, BVHNode* a_Pair, uint a_FIdx ) const;
	INLINE void FindFirstPrimaryEx( uint& a_First, const BVHNode* a_Node ) const;
	INLINE void FindFirstShadow( uint& a_First, const BVHNode& restrict a_Node );
	INLINE void FindFirstShadowGeneric( uint& a_First, const BVHNode& restrict a_Node );
	INLINE void FindFirstGeneric( uint& a_First, const BVHNode& restrict a_Node );
	INLINE void IntersectPrimary( const uint a_First, const Primitive& restrict a_Prim );
	INLINE void IntersectShadow( const uint a_First, const Primitive& restrict a_Prim );
	INLINE void IntersectShadowGeneric( const uint a_First, const Primitive& restrict a_Prim );
	INLINE void UpdateGenericSubmask( uint& a_First, const BVHNode& restrict a_Node );
	INLINE void IntersectGeneric( const uint a_First, const Primitive& restrict a_Prim );
	INLINE void PrepShadowPacket( const Light& restrict a_Light );
	INLINE void DoShadowRays( const Light& restrict a_Light );
	INLINE void TraceAARays();
	INLINE void TileAA( const uint tx, const uint ty );
	INLINE void RenderTile( const uint tx, const uint ty );
	void DoAlphaBlending( uint a_Depth );
	void DoReflections( uint a_Depth );
	void DoRefractions( uint a_Depth );
	void run();
	void runonce1();
	void runonce2();
	void SetExtends( aabb a_Extends ) 
	{ 
		m_Extends = a_Extends; 
	#ifdef PHOTONMAPPING
		m_ExtP1 = a_Extends.GetP1() * 1.1f;
		m_ExtP2 = a_Extends.GetP2() * 1.1f;
		m_ExtSize = m_ExtP2 - m_ExtP1;
		m_ExtRSize = vector3( PHOTONGRIDX / m_ExtSize.x, PHOTONGRIDY / m_ExtSize.y, PHOTONGRIDZ / m_ExtSize.z );
		m_ExtCSize = vector3( m_ExtSize.x / PHOTONGRIDX, m_ExtSize.y / PHOTONGRIDY, m_ExtSize.z / PHOTONGRIDZ );
		m_ExtRSizex4 = _mm_set_ps1( m_ExtRSize.x );
		m_ExtRSizey4 = _mm_set_ps1( m_ExtRSize.y );
		m_ExtRSizez4 = _mm_set_ps1( m_ExtRSize.z );
		m_ExtP1x4 = _mm_set_ps1( m_ExtP1.x );
		m_ExtP1y4 = _mm_set_ps1( m_ExtP1.y );
		m_ExtP1z4 = _mm_set_ps1( m_ExtP1.z );
	#endif
	}
	void SetBuffer( Pixel* a_Dest, Pixel* a_Final, Pixel* a_BDest, uint a_Pitch ) 
	{
		m_Dest = a_Dest;
		m_Final = a_Final;
		m_BDest = a_BDest;
		m_Pitch = a_Pitch;
	}
	void SetOrigin( vector3 a_Origin ) 
	{ 
		m_Origin = a_Origin; 
		m_Ox4 = _mm_set_ps1( m_Origin.x );
		m_Oy4 = _mm_set_ps1( m_Origin.y );
		m_Oz4 = _mm_set_ps1( m_Origin.z );
	}
	void SetDeltas( vector3 a_DX, vector3 a_DY ) { m_DX = a_DX, m_DY = a_DY; }
	const uint RaysCast() const { return m_Rays; }
	const uint IntCount() const { return m_Ints; }
	const void ResetCounters() { m_Rays = m_Ints = m_NCInts = m_Leafs = 0; }
private:
	const __m128 one, two, zero, epsilon, thousand, small4, half4;
	BVHStack m_Stack[MAXBVHDEPTH]; // TODO: member variables may perform worse than local variables; consider moving
	BVHStack m_LStack[MAXBVHDEPTH];
	__m128 masktable4[16];
	uint m_Offset[16];
	Pixel m_Buffer[256];
public:
	RayPacket m_RPp, m_RPsec[4];
	IData m_IDp, m_IDsec[4];
	RayPacket m_LRP, *m_RP, m_Template;
	IData m_LID, *m_ID;
	sint m_AATreshold;
private:
	vector3 m_Origin, m_LOrigin, m_DX, m_DY;
	__m128 m_Ox4, m_Oy4, m_Oz4;
	uint m_Thread;
	aabb m_Extends;
#ifdef PHOTONMAPPING
	vector3 m_ExtP1, m_ExtP2, m_ExtSize, m_ExtRSize, m_ExtCSize;
	__m128 m_ExtP1x4, m_ExtP1y4, m_ExtP1z4;
	__m128 m_ExtRSizex4, m_ExtRSizey4, m_ExtRSizez4;
public:
	bool m_GIDots, m_GIVoronoi;
	float m_SampleDist, m_SampleSqDist, m_SampleDot;
private:
#endif
	uint m_Rays, m_Ints, m_Depth;
	uint m_RayID;
	Pixel* m_Final, *m_Surf;
	Pixel* m_BDest, *m_Dest;
	uint m_Pitch;
	// fog
public:
	uint m_Leafs, m_NCInts;
	bool m_Fog, m_Photons;
	Primitive* m_Dome;
	float m_SDScale;
	__m128i m_Dome4;
	__m128 m_FogTop4;
	__m128 m_FogDensity4;
	__m128 m_FogColorr4, m_FogColorg4, m_FogColorb4;
	// ambient base color
	__m128 m_AmbientR4, m_AmbientG4, m_AmbientB4;
	uint m_GITicks;
	uint m_Counter1, m_Counter2, m_Counter3;
};

// -----------------------------------------------------------
// Log class definition
// System messages output to file
// -----------------------------------------------------------
class Log
{
public:
	Log( char* a_File );
	static void Write( char* a_Txt, char* a_Data );
	static void Message( char* a_Txt );
	static void Message( char* a_Txt, char* a_Txt2 );
	static void IntValue( char* a_Txt, int a_Data );
	static void FloatValue( char* a_Txt, float a_Data );
	static void CharValue( char* a_Txt, char* a_Data );
	static void Error( char* a_Error, char* a_Param );
private:
	static void RedirectIOToConsole();
	static char* m_File;
};

// -----------------------------------------------------------
// Engine class definition
// Raytracer core
// -----------------------------------------------------------
class Scene;
class Light;
class MManager;
class Camera;
class Material;
class Engine
{
public:
	Engine();
	~Engine();
	static void SetTarget( Pixel* a_Dest, uint a_Width, uint a_Height, uint a_Pitch );
	static void SetupTemplate( RayPacket& a_Pos );
	static void Render( vector3& a_Pos, vector3& a_Target, Camera* a_Cam = 0 );
	static void Render( Camera* a_Cam );
	static void Render( const vector3& a_Pos, const vector3& a_X, const vector3& a_Y, const vector3& a_Z );
	static void Render( const vector3& a_Pos, const matrix& a_Mat );
	static bool IsVisible( const vector3& a_Pos, sint& a_X, sint& a_Y );
	static bool IsVisible( const vector3& a_Pos, const vector3& a_Campos, const vector3& a_Camdir, sint& a_X, sint& a_Y );
	static float Trace( const vector3& a_O, const vector3& a_D, Primitive*& a_Prim, Material** a_SkipList = 0, int a_NumSkip = 0 );
	static void TraceEx( const vector3& a_O, const vector3& a_D, IData1& a_IData );
	static float TracePixel( int x, int y, Primitive*& p );
	static vector3& GetP1() { return m_P1; }
	static vector3& GetP2() { return m_P2; }
	static vector3& GetP3() { return m_P3; }
	static vector3& GetP4() { return m_P4; }
	// renderer data
	static uint m_Width, m_Height, m_Pitch;
	static vector3 m_P1, m_P2, m_P3, m_P4, m_Origin, m_DX, m_DY;
	static RayPacket m_Template;
public:
	// counters
	static uint m_Cores;
	static uint m_RaysCast, m_AARaysCast, m_Intersections, m_Leafs, m_NCInts, m_GITicks;
	static float m_RenderTime, m_AATime, m_SetupTime, m_PostProcTime, m_BuildTime, m_LoopTime, m_PostTime;
	static bool m_ShowPCount, m_Photons, m_HDRBlur;
#ifdef PHOTONMAPPING
	static bool m_GIDots, m_GIVoronoi; 
#endif
	static uint m_Counter1, m_Counter2, m_Counter3;
	static uint m_AATreshold;
};

typedef __int64 int64_t; 

struct wallclock_t 
{ 
	typedef int64_t value_type; 
	static double inv_freq; 
	value_type start; 

	wallclock_t() : start(get()) {} 
	// value_type elapsed() const { return get() - start; }
	double elapsed() { return (double)( get() - start ) * inv_freq; }
	void reset() { start = get(); }

	static value_type get() 
	{ 
		LARGE_INTEGER c; 
		QueryPerformanceCounter(&c); 
		return c.QuadPart; 
	} 

	// returns ms 
	static double to_time(const value_type vt) { return double(vt) * inv_freq; } 

	static void init() 
	{ 
		LARGE_INTEGER f; 
		QueryPerformanceFrequency(&f); 
		inv_freq = 1000./double(f.QuadPart); 
	} 
}; 

}; // namespace Raytracer