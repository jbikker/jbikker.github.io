// --------------------------------------------------------------------------
// Copyright (c) Mark Peters and Bram van de Wetering 2009
// --------------------------------------------------------------------------

#include "LightObjects.h"
#include "core.h"					// main renderer functions
#include "scene.h"					// main scene functions
#include "memory.h"					// for MManager::NewMaterial()
#include "surface.h"				// graphics surface functions
#include "scenegraph.h"				// for SceneGraph::Update()
#include "Config.h"

using namespace Raytracer;

// Light Manager
LightRotater** LightManager::m_Rotaters = NULL;
float LightManager::m_TableLightRot = 0.0f;
float LightManager::m_ArkaCycle = 0.0f;
int LightManager::m_NextRotaterId = 0;

// Table light strips
Light* LightManager::m_RotTableLights[24];
Light* LightManager::m_ArkanoidStrip1[8];
Light* LightManager::m_ArkanoidStrip2[8];

void LightManager::Init(int a_MaxLightRotaters)
{
	// Init light rotators
	m_Rotaters = new LightRotater*[a_MaxLightRotaters];

	// Init spinning table lights
	const float tY = -53.5f, tX = 3.0f, tRad = 110.5f, tStr = 4.0f;
	for( int i=0; i<24; i++ )
	{
		m_RotTableLights[i] = MManager::NewLight();

		const float angle = float( i - 5.0f ) * PI * 2.0f / 96.0f - PI*0.05f;
		const float vecx = sin( angle ) * tRad;
		const float vecz = cos( angle ) * tRad;
		vector3 origin = vector3( vecx + tX, tY, vecz );

		Color col1( 1.0f, 1.0f, 1.0f ), col2( 1.0f, 1.0f, 1.0f );
		m_RotTableLights[i]->Init( 1, "Table Light", origin, col1, col2, tStr );
		Scene::AddLight( m_RotTableLights[i] );
	}

	// Init arkanoid light strip
	const vector3 Pos1( -78.60, -36.92, -11.47 ); const vector3 Pos2( -56.50, -37.44, -39.62 );
	const vector3 Pos3( -2.02, -37.42, -46.41 ); const vector3 Pos4( 30.57, -36.54, -73.46 );
	Color col1( 0.8f, 1.0f, 0.5f );
	for(int i=0; i<8; i++)
	{
		const float factor = float(i)/8.0f;

		m_ArkanoidStrip1[i] = MManager::NewLight();
		vector3 lpos1 = Pos1 + (Pos2-Pos1)*factor;
		m_ArkanoidStrip1[i]->Init(1,"ASL1", lpos1, col1, col1, 2 );
		Scene::AddLight( m_ArkanoidStrip1[i] );

		m_ArkanoidStrip2[i] = MManager::NewLight();
		vector3 lpos2 = Pos3 + (Pos4-Pos3)*factor;
		m_ArkanoidStrip2[i]->Init(1,"ASL3", lpos2, col1, col1, 2 );
		Scene::AddLight( m_ArkanoidStrip2[i] );
	}
}

void LightManager::Tick(float a_DT)
{
	// Handle light rotators
	for (int i=0; i<m_NextRotaterId; ++i) m_Rotaters[i]->Tick(a_DT);

	// Handle spinning table lights
	m_TableLightRot += 2*a_DT;
	if( m_TableLightRot > 2*PI ) m_TableLightRot -= 2*PI;
	for(int i=0; i<24; i++)
	{
		const float factor = 0.5f + 0.5f*sin( float(i)/24.0f*2*PI + m_TableLightRot );
		m_RotTableLights[i]->SetRadius( 2.0f + 4.0f*factor );
	}

	// Handle arkanoid strop
	m_ArkaCycle += 4*a_DT;
	if( m_ArkaCycle > 8.0f ) m_ArkaCycle -= 8.0f;
	const int newI = int( m_ArkaCycle + 0.5f );
	for(int i=0; i<8; i++)
	{
		float oldR = (m_ArkanoidStrip1[i]->GetRadius() - 2.0f) / 4.0f;
		float newR = MAX( 0.0f, oldR - a_DT*2 );
		if(i == newI) newR = MIN( 1.0f, oldR + a_DT*2 );
		Color newCol( 0.1f + newR*0.9f, 0.1f + newR*0.9f, 0.1f + newR*0.9f );
		m_ArkanoidStrip1[i]->SetRadius( newR*4.0f + 2.0f ); 
		m_ArkanoidStrip1[i]->SetDiffuse( newCol );
		m_ArkanoidStrip1[i]->SetSpecular( newCol );
		m_ArkanoidStrip2[7-i]->SetRadius( newR*4.0f + 2.0f );	
		m_ArkanoidStrip2[7-i]->SetDiffuse( newCol );
		m_ArkanoidStrip2[7-i]->SetSpecular( newCol );
	}
}

// Light Rotater
void LightRotater::Init(int a_LightCount, int a_ActiveCount, float a_RotateInterval)
{
	m_Timer = a_RotateInterval;
	m_Current = rand() % a_LightCount;
	m_ActiveCount = a_ActiveCount;
	m_RotateInterval = a_RotateInterval;
	m_LightCount = 0;
	m_Lights = new Light*[a_LightCount];

}

void LightRotater::Tick(float a_DT)
{
	m_Timer += a_DT;
	if (m_Timer >= m_RotateInterval)
	{
		m_Current = ((m_Current + 1) % m_LightCount);
		for (int i=0; i<m_LightCount; ++i) m_Lights[i]->Active(0);
		for (int i=0; i<m_ActiveCount; ++i)
		{
			int l=m_Current+i;
			if (l>=m_LightCount) l-=m_LightCount;
			m_Lights[l]->Active(1);
		}
		m_Timer -= m_RotateInterval;
	}
}