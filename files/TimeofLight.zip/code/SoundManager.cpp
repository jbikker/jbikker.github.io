// --------------------------------------------------------------------------
// Copyright (c) Mark Peters and Bram van de Wetering 2009
// --------------------------------------------------------------------------

#include "SoundManager.h"
#include "Config.h"

namespace Raytracer {

std::map<char*, FSOUND_SAMPLE*> SoundManager::m_SoundMap;

void SoundManager::Init()
{
	// Set up FMOD
	FSOUND_Init(44100, 32, 0);
}

void SoundManager::ShutDown()
{
	// Close fmod
	FSOUND_Close();
}

void SoundManager::Stop(int a_Channel)
{
	FSOUND_StopSound( a_Channel );
}

void SoundManager::StopAllSounds()
{
	FSOUND_StopSound( FSOUND_ALL );
}

SoundManagerSound SoundManager::Play( char* a_FileName, int a_Channel )
{
	SoundManagerSound s;
	s.Channel = a_Channel;
	s.Handle = NULL;
	if (FSOUND_IsPlaying(a_Channel)) return s;

	std::map<char*, FSOUND_SAMPLE*>::iterator it = m_SoundMap.find(a_FileName);
	if (it != m_SoundMap.end())
	{
		s.Handle = it->second;
	}
	else
	{
		s.Handle = FSOUND_Sample_Load( FSOUND_FREE, a_FileName , FSOUND_2D , 0 , 0 );
		m_SoundMap.insert(std::map<char*, FSOUND_SAMPLE*>::value_type(a_FileName,s.Handle));
	}
	s.Channel = FSOUND_PlaySound(a_Channel, s.Handle);
	FSOUND_SetVolume(s.Channel, Config::S_soundVol);
	return s;
}

SoundManagerSound SoundManager::PlayLooped(char* a_FileName, int a_Channel)
{
	SoundManagerSound s = Play( a_FileName, a_Channel );
	FSOUND_SetLoopMode( a_Channel, FSOUND_LOOP_NORMAL );
	return s;
}

void SoundManager::SetVolume( int a_Vol, int a_Channel )
{
	FSOUND_SetVolume( a_Channel, a_Vol );
}

void SoundManager::SetAllSoundVolume()
{
	FSOUND_SetVolume(FSOUND_ALL, Config::S_soundVol);
	FSOUND_SetVolume(CHANNEL_MUSIC, Config::S_musicVol);
	SoundManager::SetVolume(0, CHANNEL_BALLROLL);
	SoundManager::SetVolume(0, CHANNEL_GEARS);
}

}; // namespace Raytracer