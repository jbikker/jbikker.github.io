// --------------------------------------------------------------------------
// Copyright (c) Mark Peters and Bram van der Wetering 2009
// --------------------------------------------------------------------------

#ifndef I_MENUITEMS_H
#define I_MENUITEMS_H

#include "string.h"
#include "Config.h"

#define S_TILE_W	16
#define L_TILE_W	16
#define C_TILE_W	16
#define B_TILE_W	16

namespace Raytracer {

class Surface;

void InitTiles();
void WindowDraw(Surface* a_Target, int a_Width, int a_Height);

class SlidingItem
{
public:
	SlidingItem() : m_X(0), m_Y(Config::S_scrHeight + 32), m_TY(0), m_Active(false), m_Slide(true) {}

	void setStatic( float a_Y ){ m_Slide = false; m_Y = a_Y; }
	void setStatic( float a_X, float a_Y ){  m_Slide = false; m_Y = a_Y; m_X = a_X; }
	void setActive(bool a_Active){ m_Active = a_Active; }
	void setPos( float a_X, float a_Y ){ m_X = a_X, m_TY = a_Y; }
	void jumpToTarget(){ m_Y = m_TY; }
	void jumpToStart(){ m_Y = Config::S_scrHeight + 32; }
	float GetX(){ return m_X; }
	float GetY(){ return m_Y; }
	void Tick( float a_DT );
	bool InPlace(){ return m_InPlace; }

protected:
	float m_X, m_Y, m_TY;
	bool m_Active, m_InPlace, m_Slide;
};

class CheckBox : public SlidingItem
{
public:
	CheckBox(bool& a_Bool, char* a_Info) : m_Bool(&a_Bool){ m_Info = new char[strlen(a_Info)+1]; strcpy(m_Info, a_Info); }
	~CheckBox(){}

	void Tick( float a_DT );
	void Draw( Surface* a_Target );
private:
	bool* m_Bool;
	char* m_Info;
};

class Button : public SlidingItem
{
public:
	Button(Surface* a_Image, int a_Height) : m_Image(a_Image), m_Anim(0), m_Height(a_Height), m_Clicked(false) {}
	~Button(){}

	bool isClicked(){ return(m_Active && m_InPlace && m_Clicked); }
	void Tick( float a_DT );
	void Draw( Surface* a_Target );

private:
	Surface* m_Image;
	float m_Anim;
	int m_Height;
	bool m_Clicked;
	bool m_MouseOver;
};

class Slider : public SlidingItem
{
public:
	Slider(int a_Len, int a_States, int& a_Int, char* a_Info) : m_Len(a_Len), m_Int(&a_Int)
	{
		m_States = (a_States>2) ? a_States : 2;
		m_Texts = new char*[m_States];
		stateX = new int[m_States];
		const float xD = float(m_Len)/float(m_States-1);
		for(int i=0; i<m_States; ++i){ stateX[i] = int(xD*i+(S_TILE_W>>1)); m_Texts[i]=0; }
		m_Info = new char[strlen(a_Info)+1]; strcpy(m_Info, a_Info);
	}
	~Slider(){ for(int i=0; i<m_States; i++){ delete m_Texts[i]; } delete m_Texts; delete m_Info; }

	void SetState(int a_Index, char* a_Text)
	{
		if(a_Index < 0) a_Index = m_States-1;
		if(a_Index > m_States) return;
		m_Texts[a_Index] = new char[strlen(a_Text)];
		strcpy(m_Texts[a_Index],a_Text);
	}

	void Tick( float a_DT );
	void Draw( Surface* a_Target);

private:
	int m_Len, m_States;
	int* m_Int, *stateX;
	char* m_Info;
	char** m_Texts;
};

class SliderBar : public SlidingItem
{
public:
	SliderBar(int a_Len, int& a_Int, char* a_Info) : m_Len(a_Len), m_Int(&a_Int), m_Changed(false)
	{
		m_Info = new char[strlen(a_Info)+1]; strcpy(m_Info, a_Info);
	}
	~SliderBar(){ delete m_Info; }

	void Tick( float a_DT );
	void Draw( Surface* a_Target);
	bool Changed(){return m_Changed;}

private:
	int m_Len, *m_Int;
	char* m_Info;
	bool m_Changed;
};

class SelectList : public SlidingItem
{
public:
	SelectList(int a_Width, int a_Items, int& a_Int, char* a_Info) : m_Width(a_Width), m_Int(&a_Int)
	{
		m_Items = (a_Items>0) ? a_Items : 0;
		m_Texts = new char*[m_Items];
		m_Info = new char[strlen(a_Info)]; strcpy(m_Info, a_Info);
	}
	~SelectList(){ for(int i=0; i<m_Items; i++){ delete m_Texts[i]; } delete m_Texts; delete m_Info; }
	
	void SetState(int a_Index, char* a_Text)
	{
		if(a_Index < 0 || a_Index > m_Items) return;
		m_Texts[a_Index] = new char[strlen(a_Text)+1];
		strcpy(m_Texts[a_Index],a_Text);
	}

	void Tick( float a_DT );
	void Draw( Surface* a_Target );

private:
	int m_Width, m_Items;
	int* m_Int;
	char* m_Info;
	char** m_Texts;
};

class FloatingText : public SlidingItem
{
public:
	FloatingText(char* a_Text){ m_Info = new char[strlen(a_Text)+1]; strcpy(m_Info, a_Text); }
	~FloatingText(){ delete m_Info; }
	void Tick( float a_DT ){ SlidingItem::Tick( a_DT ); }
	void Draw( Surface* a_Target );
private:
	char* m_Info;
};

class AskWindow
{
public:
	AskWindow(char* a_Line1, char* a_Line2, float a_TarW, float a_TarH );
	~AskWindow(){ delete m_Line1; delete m_Line2; delete m_Yes; delete m_No; }

	void Tick( float a_DT );
	void Enter();
	void Exit();
	void Draw( Surface* a_Target);
	int GetAns(){ return m_Ans; }
private:
	float m_WinW, m_WinH, m_TarW, m_TarH, m_YesX, m_NoX;
	int m_Ans;
	FloatingText* m_Line1, *m_Line2;
	Button* m_Yes, *m_No;
};

} // namespace Raytracer

#endif
