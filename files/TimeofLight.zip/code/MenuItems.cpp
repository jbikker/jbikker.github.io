// --------------------------------------------------------------------------
// Copyright (c) Mark Peters and Bram van der Wetering 2009
// --------------------------------------------------------------------------

#include "MenuItems.h"
#include "Surface.h"
#include "Drawing2D.h"
#include "SoundManager.h"

namespace Raytracer {

Surface* sliderTiles[10];
Surface* listTiles[3];
Surface* checkBoxTiles[4];
Surface* windowTiles[9];
Surface* barTiles[5];
Surface* buttonImgYes, *buttonImgNo;

void InitTiles()
{
	buttonImgYes = new Surface("images/Menu Images/Button_Yes.tga");
	buttonImgNo = new Surface("images/Menu Images/Button_No.tga");

	int srcWidth, tileHeight; Pixel* origin;

	Surface* sliderTileset = new Surface("images/Menu Images/Slider_Tileset.tga");
	srcWidth = sliderTileset->GetWidth();
	tileHeight = sliderTileset->GetHeight()>>1;
	origin = sliderTileset->GetBuffer();
	for(int i=0; i<10; ++i)
	{
		sliderTiles[i] = new Surface(S_TILE_W,tileHeight);
		Pixel* dst = sliderTiles[i]->GetBuffer();
		Pixel* src = origin + i*S_TILE_W; if(i>6) src += srcWidth*(tileHeight-1);
		for(int y=0; y<tileHeight; ++y){ memcpy(dst,src,S_TILE_W*sizeof(Pixel)); dst += S_TILE_W; src += srcWidth; }
	}
	delete sliderTileset;

	Surface* listTileset = new Surface("images/Menu Images/List_Tileset.tga");
	srcWidth = listTileset->GetWidth();
	tileHeight = listTileset->GetHeight();
	origin = listTileset->GetBuffer();
	for(int i=0; i<3; ++i)
	{
		listTiles[i] = new Surface(L_TILE_W,tileHeight);
		Pixel* dst = listTiles[i]->GetBuffer();
		Pixel* src = origin + i*L_TILE_W;
		for(int y=0; y<tileHeight; ++y){ memcpy(dst,src,L_TILE_W*sizeof(Pixel)); dst += L_TILE_W; src += srcWidth; }
	}
	delete listTileset;

	Surface* windowTileset = new Surface("images/Menu Images/Window_Tileset.tga");
	srcWidth = windowTileset->GetWidth();
	origin = windowTileset->GetBuffer();
	for(int i=0; i<9; i++)
	{
		windowTiles[i] = new Surface(W_TILE_W,W_TILE_H);
		Pixel* dst = windowTiles[i]->GetBuffer();
		Pixel* src = origin + (i%3)*W_TILE_W + (i/3)*W_TILE_H*srcWidth;
		for(int y=0; y<W_TILE_H; ++y){ memcpy(dst,src,W_TILE_W*sizeof(Pixel)); dst += W_TILE_W; src += srcWidth; }
	}
	delete windowTileset;

	Surface* checkBoxTileset = new Surface("images/Menu Images/Checkbox_Tileset.tga");
	srcWidth = checkBoxTileset->GetWidth();
	tileHeight = checkBoxTileset->GetHeight();
	origin = checkBoxTileset->GetBuffer();
	for(int i=0; i<4; ++i)
	{
		checkBoxTiles[i] = new Surface(L_TILE_W,tileHeight);
		Pixel* dst = checkBoxTiles[i]->GetBuffer();
		Pixel* src = origin + i*C_TILE_W;
		for(int y=0; y<tileHeight; ++y){ memcpy(dst,src,C_TILE_W*sizeof(Pixel)); dst += C_TILE_W; src += srcWidth; }
	}
	delete checkBoxTileset;

	Surface* barTileset = new Surface("images/Menu Images/Bar_Tileset.tga");
	srcWidth = barTileset->GetWidth();
	tileHeight = barTileset->GetHeight();
	origin = checkBoxTileset->GetBuffer();
	for(int i=0; i<5; ++i)
	{
		barTiles[i] = new Surface(B_TILE_W,tileHeight);
		Pixel* dst = barTiles[i]->GetBuffer();
		Pixel* src = origin + i*B_TILE_W;
		for(int y=0; y<tileHeight; ++y){ memcpy(dst,src,C_TILE_W*sizeof(Pixel)); dst += B_TILE_W; src += srcWidth; }
	}
	delete barTileset;
}

void SlidingItem::Tick( float a_DT )
{
	if(!m_Slide){ m_InPlace = true; return; }

	const float targetY = m_Active ? m_TY : Config::S_scrHeight + 32;
	m_InPlace = ( abs(targetY-m_Y) < 2.0f);

	if(!m_InPlace)
	{
		float dY = (targetY - m_Y) * 0.1f;
		m_Y += dY;

		if(m_Y > targetY+0.08f) m_Y -= 0.08f;
		else if(m_Y < targetY-0.08f) m_Y += 0.08f;
		else m_Y = targetY;
	}
}

void SliderBar::Tick( float a_DT )
{
	// Handle Sliding
	SlidingItem::Tick( a_DT );

	// Determine mouse over
	if( m_InPlace && m_Active )
	{
		const int xI = int(m_X), yI = int(m_Y);
		bool mouseOver = (Config::Mouse_X > xI-16) && (Config::Mouse_Y > yI);
		mouseOver = (Config::Mouse_X < xI+m_Len+16) && (Config::Mouse_Y < yI+barTiles[0]->GetHeight()) && mouseOver;
		m_Changed = (Config::Mouse_Down[0] && mouseOver);
		if(m_Changed) *m_Int = MIN(256,MAX(0, ((Config::Mouse_X - int(m_X))*256)/m_Len ));
	}
}

void SliderBar::Draw( Surface* a_Target)
{
	int a_X=int(m_X), a_Y=int(m_Y);

	// Draw Infotext
	const int parts = (strlen(m_Info)*6)/C_TILE_W;
	DrawTransp(a_X-C_TILE_W, a_Y, a_Target, barTiles[2]);
	DrawTransp(a_X-C_TILE_W*(parts+2), a_Y, a_Target, barTiles[0]);
	for(int i=0; i<parts; ++i) DrawTransp(a_X-C_TILE_W*(i+2), a_Y, a_Target, barTiles[1]);
	PrintSafe(a_Target, m_Info, a_X-C_TILE_W*(parts+1)-(S_TILE_W>>1), a_Y+4, 0xffffff);

	// Draw Bar
	const int partW = m_Len % C_TILE_W;
	for(int i=0; i<(m_Len/C_TILE_W); ++i) DrawTransp(a_X + i*C_TILE_W, a_Y, a_Target, barTiles[3]);
	DrawPartial(a_X + m_Len-partW, a_Y, partW, barTiles[0]->GetHeight(), a_Target, barTiles[3]);
	DrawTransp(a_X + m_Len, a_Y, a_Target, barTiles[4]);

	// Draw Bar Fill
	const int barLen = ((*m_Int) * m_Len)/256;
	BarSafe(a_Target, a_X, a_Y+5, a_X + barLen, a_Y+7, 0xbbbb66 );
	BarSafe(a_Target, a_X, a_Y+8, a_X + barLen, a_Y+11, 0x666644 );
}

void CheckBox::Tick( float a_DT )
{
	// Handle Sliding
	SlidingItem::Tick( a_DT );

	// Determine mouse over
	if( m_InPlace && m_Active )
	{
		const int xI = int(m_X), yI = int(m_Y);
		bool mouseOver = (Config::Mouse_X > xI) && (Config::Mouse_Y > yI);
		mouseOver = (Config::Mouse_X < xI+C_TILE_W) && (Config::Mouse_Y < yI+checkBoxTiles[0]->GetHeight()) && mouseOver;
		if(Config::Mouse_Click[0] && mouseOver) *m_Bool = !(*m_Bool); 
	}
}

void CheckBox::Draw( Surface* a_Target )
{
	const int a_X = int(m_X), a_Y = int(m_Y);

	// Draw Checkbox
	DrawTransp(a_X, a_Y, a_Target, checkBoxTiles[(*m_Bool)?1:0]);

	// Draw Infotext
	const int parts = (strlen(m_Info)*6)/C_TILE_W;
	DrawTransp(a_X+C_TILE_W*(parts+2), a_Y, a_Target, checkBoxTiles[3]);
	for(int i=0; i<parts+1; ++i) DrawTransp(a_X + C_TILE_W*(i+1), a_Y, a_Target, checkBoxTiles[2]);
	PrintSafe(a_Target, m_Info, a_X+(C_TILE_W>>1)+C_TILE_W, a_Y+6, 0xffffff);
}

void Button::Tick( float a_DT )
{
	// Handle Sliding
	SlidingItem::Tick( a_DT );

	// Determine mouse over
	bool oldMouseOver = m_MouseOver; 
	if( m_InPlace && m_Active )
	{
		const int xI = int(m_X)-(m_Image->GetWidth()>>1), yI = int(m_Y);
		m_MouseOver = (Config::Mouse_X > xI) && (Config::Mouse_Y > yI);
		m_MouseOver = (Config::Mouse_X < xI+m_Image->GetWidth()) && (Config::Mouse_Y < yI+m_Height) && m_MouseOver;
		if( (!oldMouseOver) && m_MouseOver ) SoundManager::Play( "Sound/Menu/softclick.wav" );
	}
	else m_MouseOver = false;

	// Handle mouse over animation
	const int maxFrame = m_Image->GetHeight()/m_Height-1;
	m_Anim += m_MouseOver ? (a_DT * 64.0f) : (a_DT * -64.0f);
	if(m_Anim > float(maxFrame)) m_Anim = float(maxFrame);
	else if(m_Anim < 0) m_Anim = 0;

	// Set clicked trigger
	m_Clicked = (m_MouseOver && Config::Mouse_Click[0]) ? true : false;
	if( m_Clicked ) SoundManager::Play( "Sound/Menu/toneSample_004.wav" );
}

void Button::Draw( Surface* a_Target )
{
	if(m_Y > Config::S_scrHeight) return;
	DrawFrame(int(m_X)-(m_Image->GetWidth()>>1), int(m_Y), a_Target, m_Image, m_Height, int(m_Anim));
}

void Slider::Tick( float a_DT )
{
	// Handle Sliding
	SlidingItem::Tick( a_DT );

	// Determine mouse over
	bool mouseOver = (Config::Mouse_X >= m_X - m_Len) && (Config::Mouse_X <= m_X + m_Len + S_TILE_W*2);
	mouseOver = (Config::Mouse_Y >= m_Y) && (Config::Mouse_Y <= m_Y+sliderTiles[0]->GetHeight()) && mouseOver;

	// Recalc value on mouseclick
	if(mouseOver && Config::Mouse_Down[0])
	{
		*m_Int = 0;
		for(int i=0; i<m_States-1; ++i){ if(Config::Mouse_X > (m_X+(stateX[i]+stateX[i+1])/2)) (*m_Int)++; }
	}
}

void Slider::Draw( Raytracer::Surface *a_Target )
{
	const int a_X = int(m_X), a_Y = int(m_Y);

	// Draw Infotext
	const int parts = (strlen(m_Info)*6)/S_TILE_W;
	DrawTransp(a_X-(S_TILE_W<<1), a_Y, a_Target, sliderTiles[9]);
	DrawTransp(a_X-(S_TILE_W*(parts+3)), a_Y, a_Target, sliderTiles[7]);
	for(int i=0; i<parts; ++i) DrawTransp(a_X-(S_TILE_W*(i+3)), a_Y, a_Target, sliderTiles[8]);
	PrintSafe(a_Target, m_Info, a_X-S_TILE_W*(parts+2)-(S_TILE_W>>1), a_Y+4, 0xffffff);

	// Draw sliderbar ends
	DrawTransp(a_X-S_TILE_W, a_Y, a_Target, sliderTiles[0]);
	DrawTransp(a_X+S_TILE_W+m_Len, a_Y, a_Target, sliderTiles[6]);

	// Draw lightbar
	for(int i=0; i<m_Len; i += S_TILE_W) 
		DrawTransp(a_X+i,a_Y,a_Target,sliderTiles[(i+(S_TILE_W>>1)>stateX[*m_Int])?4:1]);

	// Draw states
	for(int i=0; i<m_States; i++)
	{
		if(m_Texts[i]) PrintSafe(a_Target, m_Texts[i], a_X+stateX[i]-strlen(m_Texts[i])*3, a_Y-8, 0xffffff);
		if(i==*m_Int) DrawTransp(a_X+stateX[i]-(S_TILE_W>>1), a_Y, a_Target, sliderTiles[3]);
		else DrawTransp(a_X+stateX[i]-(S_TILE_W>>1), a_Y, a_Target, sliderTiles[(i>*m_Int)?5:2]); 
	}
}

void SelectList::Tick( float a_DT )
{
	// Handle Sliding
	SlidingItem::Tick( a_DT );

	const int tileH = listTiles[0]->GetHeight();
	for(int i=0; i<m_Items; ++i)
	{
		// Handle input
		bool mouseOver = (Config::Mouse_X >= m_X+(L_TILE_W>>1)) && (Config::Mouse_X <= m_X+m_Width-(L_TILE_W>>1));
		mouseOver = (Config::Mouse_Y >= int(m_Y)+tileH+i*10) && (Config::Mouse_Y <= int(m_Y)+tileH*2+i*10) && mouseOver;
		if(mouseOver && Config::Mouse_Click[0]) *m_Int = i;
	}
}

void SelectList::Draw( Surface* a_Target)
{
	const int a_X = int(m_X), a_Y = int(m_Y);

	// Fade item rect
	const int tileH = listTiles[0]->GetHeight();
	DrawFCol(a_Target, a_X, a_Y+(tileH>>1), m_Width, m_Items*10+(tileH>>1), 0);
	
	for(int i=0; i<m_Items; ++i)
	{
		// Drawing the List
		if(i == *m_Int)
		DrawFCol(a_Target, a_X, a_Y+tileH+10*i, m_Width, 10, 0xDCDC8C);
		if(m_Texts[i]) PrintSafe(a_Target, m_Texts[i], a_X+L_TILE_W, a_Y+tileH+10*i+3,0xffffff);
	}

	// Draw Info Bar
	const int partW = m_Width % W_TILE_W, iLen = strlen(m_Info)*6;
	DrawTransp(a_X - L_TILE_W, a_Y, a_Target, listTiles[0]);
	DrawTransp(a_X + m_Width, a_Y, a_Target, listTiles[2]);
	for(int i=0; i<(m_Width/L_TILE_W); ++i) DrawTransp(a_X + i*L_TILE_W, a_Y, a_Target, listTiles[1]);
	DrawPartial(a_X + m_Width-partW, a_Y, partW, tileH, a_Target, listTiles[1]);
	if(m_Info) PrintSafe(a_Target, m_Info, a_X + (m_Width>>1)-(iLen>>1), a_Y + 6, 0xffffff);
}

void WindowDraw(Surface* a_Target, int a_Width, int a_Height)
{
	const int m_X = (Config::S_scrWidth>>1) - (a_Width>>1);
	const int m_Y = (Config::S_scrHeight>>1) - (a_Height>>1);

	// Fade Background
	DrawFade(a_Target, 96, m_X-(W_TILE_W>>1), m_Y-(W_TILE_H>>1), a_Width+W_TILE_W, a_Height+W_TILE_H);

	// Copy Horizontal Bars
	for(int i=0; i<(a_Width/W_TILE_W); ++i)
	{
		DrawTransp(m_X + i*W_TILE_W, m_Y - W_TILE_H, a_Target, windowTiles[1]);
		DrawTransp(m_X + i*W_TILE_W, m_Y + a_Height, a_Target, windowTiles[7]);
	}
	const int partW = a_Width % W_TILE_W;
	DrawPartial(m_X + a_Width-partW, m_Y - W_TILE_H, partW, W_TILE_H, a_Target, windowTiles[1]);
	DrawPartial(m_X + a_Width-partW, m_Y + a_Height, partW, W_TILE_H, a_Target, windowTiles[7]);
	
	// Copy Vertical Bars
	for(int i=0; i<(a_Height/W_TILE_H); ++i)
	{
		DrawTransp(m_X - W_TILE_W, m_Y + i*W_TILE_H, a_Target, windowTiles[3]);
		DrawTransp(m_X + a_Width, m_Y + i*W_TILE_H, a_Target, windowTiles[5]);
	}
	const int partH = a_Height % W_TILE_H;
	DrawPartial(m_X - W_TILE_W, m_Y + a_Height-partH, W_TILE_H, partH, a_Target, windowTiles[3]);
	DrawPartial(m_X + a_Width, m_Y + a_Height-partH, W_TILE_H, partH, a_Target, windowTiles[5]);

	// Copy Corners
	DrawTransp(m_X - W_TILE_W, m_Y - W_TILE_H, a_Target, windowTiles[0]);
	DrawTransp(m_X + a_Width, m_Y - W_TILE_H, a_Target, windowTiles[2]);
	DrawTransp(m_X - W_TILE_W, m_Y + a_Height, a_Target, windowTiles[6]);
	DrawTransp(m_X + a_Width, m_Y + a_Height, a_Target, windowTiles[8]);
}

void FloatingText::Draw( Surface* a_Target )
{
	int len = 3*strlen(m_Info);
	PrintSafe( a_Target, m_Info, m_X-len, m_Y, 0xffffff ); 
}

AskWindow::AskWindow(char* a_Line1, char* a_Line2, float a_TarW, float a_TarH ) : 
	m_Ans(0), m_TarW(a_TarW), m_TarH(a_TarH)
{
	float centerX = Config::S_scrWidth>>1, centerY = Config::S_scrHeight>>1;
	m_Line1 = new FloatingText(a_Line1); m_Line1->setPos(centerX, centerY-12); m_Line1->setActive(true);
	m_Line2 = new FloatingText(a_Line2); m_Line2->setPos(centerX, centerY+4); m_Line2->setActive(true);

	m_Yes = new Button( buttonImgYes, 24 ); m_Yes->setActive( false );
	m_No = new Button( buttonImgNo, 24 ); m_No->setActive( false );
}

void AskWindow::Enter()
{
	float centerX = Config::S_scrWidth>>1, centerY = Config::S_scrHeight>>1;
	m_WinW = m_WinH = m_YesX = m_NoX = m_Ans = 0;
	m_Line1->jumpToStart(), m_Line2->jumpToStart();
	m_Yes->setStatic( centerX, centerY+4 ); m_Yes->setActive( true );
	m_No->setStatic( centerX, centerY+4 ); m_No->setActive( true );
}

void AskWindow::Exit()
{
	m_Yes->setActive( false );
	m_No->setActive( false );
}

void AskWindow::Tick( float a_DT )
{
	m_Line1->Tick( a_DT ), m_Line2->Tick( a_DT );

	m_WinW -= (m_WinW - m_TarW) * 0.15f;
	m_WinH -= (m_WinH - m_TarH) * 0.15f;

	if(m_WinW > 64)
	{
		m_YesX = (Config::S_scrWidth>>1)-(m_WinW*0.5f)+32;
		m_NoX = (Config::S_scrWidth>>1)+(m_WinW*0.5f)-32;
	}
	else
	{
		m_YesX = (Config::S_scrWidth>>1);
		m_NoX = (Config::S_scrWidth>>1);
	}
	float buttonY = (Config::S_scrHeight>>1)+(m_WinH*0.5f)+4;

	m_Yes->setStatic( m_YesX, buttonY ); m_Yes->Tick( a_DT );
	m_No->setStatic( m_NoX, buttonY ); m_No->Tick( a_DT );

	if( m_Yes->isClicked() ) m_Ans = 'y';
	if( m_No->isClicked() ) m_Ans = 'n';
}

void AskWindow::Draw( Surface* a_Target)
{
	WindowDraw(a_Target, int(m_WinW), int(m_WinH));

	m_Line1->Draw( a_Target ), m_Line2->Draw( a_Target );
	m_Yes->Draw( a_Target ), m_No->Draw( a_Target );
}

} // namespace Raytracer