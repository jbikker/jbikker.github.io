// --------------------------------------------------------------------------
// Copyright (c) Mark Peters and Bram van de Wetering 2009
// --------------------------------------------------------------------------

#pragma once

namespace Raytracer {

#include "config.h"

#define CAM_ORIGINPOS vector3( 0.0f, 0.0f, 150.0f )
#define CAM_ORIGINROT vector3( -25, 180, 0 )

#define CAM_CANNONPOS vector3( 35.0f, -35.0f, 84.0f )
#define CAM_CANNONROT vector3( 6, 188, 0 )

#define CAM_ARKAPOS vector3( -31.58f, -10.07f, -23.75f )
#define CAM_ARKAROT vector3( -25, 180, 0 )

#define CAM_LISLANDPOS vector3( 124.74f, -21.07f, 31.10f ) //vector3( 106, -32, 36 )
#define CAM_LISLANDROT vector3( -25.50f, 117.50f, 0.00f ) //( -25, 188, 0 )

#define BALLDIST_NEAR	35
#define BALLDIST_FAR	65

class GameCam
{
public:
	enum CamMode{ CAM_FREE, CAM_GAME, CAM_CANNON, CAM_ARKANOID, CAM_LEFT_ISLAND, CAM_RAILS };
	static void Tick( float a_DT );
	static void Init();

	static void SetZoom( bool a_State ){ m_Zoom = a_State; }
	static void SetPos( vector3 a_Pos ){ m_Campos = a_Pos; }
	static void SetTarget( vector3 a_Target ){ m_Target = a_Target; }
	static void SetRotation( vector3 a_Rotation ){ m_Camrot = a_Rotation; }
	static void Tilt(){ m_Tilt += 1.0f; }

	static vector3 GetPos(){ return m_Campos; }
	static vector3 GetTarget(){ return m_Target; }
	static vector3 GetRotation(){ return m_Camrot; }

	static void SetCamMode( CamMode a_CamMode ){ m_CamMode = a_CamMode; }
	static CamMode GetCamMode(){ return m_CamMode; }
private:
	static bool m_Zoom;
	static CamMode m_CamMode;
	static vector3 m_Campos;
	static vector3 m_Target;
	static vector3 m_Camrot;
	static float m_ZoomFactor, m_FollowFactor, m_Tilt;
};

class Surface;
class ChargeCylinder;
class Light;
class Flipper;
class ScoreMeter;
class Cannon;
class Paddle;
class Life;
class World
{
public:
	static void Init();
	static void NewGame();
	static void ExitGame();

	static void Tick( float a_DT );

	static void PostRender();
	static void IncLeftIslandBallCounter(int ballid){ m_LeftIslandBallCounter[ballid]++;}
	static void IncRailBallCounter(int ballid){ m_RailBallCounter[ballid]++;}
	static void ResetRailBallBuffer(int ballid){ m_RailBallBuffer[ballid] = 0.0f;}
	static void IncreaseLoopingCounter(int ballid){ m_LoopingTimer[ballid] += 0.01f;}
	static void IncTrampolineCounter(int ballid){ m_BallTrampolineCounter[ballid]++;}

	static void IncLives(int a_Inc){m_Lives += a_Inc;}
	static int GetLives(){return m_Lives;}

	static bool GetTilted(){return (m_TiltTimer >= 0.2f);}

	static unsigned int GetScore(){return m_Score;}
	static void IncScore(unsigned int a_Score);

	static Surface* GetSurface( ){return m_Surface;}
	static void SetSurface(Surface* a_Surface){m_Surface = a_Surface;}

	static void KeyPress( );
private:
	static bool m_Loaded;
	static float m_Rot;
	static float m_TimeLeft;
	static float m_TiltTimer;
	static unsigned int m_Score;
	static ScoreMeter* m_ScoreMeter;

	static Surface* m_Surface;
	static Cannon* m_Cannon;

	static Paddle* m_Paddle;
	static Flipper* m_LFlippers[LFLIPPERS];
	static Flipper* m_RFlippers[RFLIPPERS];
	static Life* m_Lifes[3];

	static vector3 m_ShootLast;
	static vector3 m_ShootPos;
	static int m_Lives;
	static int m_LeftIslandBallCounter[MAXBALLCOUNT];
	static int m_RailBallCounter[MAXBALLCOUNT];
	static int m_BallTrampolineCounter[MAXBALLCOUNT];
	static float m_RailBallBuffer[MAXBALLCOUNT];
	static float m_LoopingTimer[MAXBALLCOUNT];
};

}; // namespace Raytracer
