// --------------------------------------------------------------------------
// Copyright (c) Mark Peters and Bram van de Wetering 2009
// --------------------------------------------------------------------------

#include "Balls.h"
#include "Entities.h"
#include "GameObjects.h"
#include "core.h"					// main renderer functions
#include "scene.h"					// main scene functions
#include "memory.h"					// for MManager::NewMaterial()
#include "surface.h"				// graphics surface functions
#include "scenegraph.h"				// for SceneGraph::Update()
#include "SoundManager.h"
#include "World.h"
#include "Surface.h"

using namespace Raytracer;

// -----------------------------------------------------------
// BallThread Class
// -----------------------------------------------------------
static volatile long rayindex = 0;
static HANDLE waitforgo[4];
static HANDLE waitfordone[4];
_declspec(align(16)) static BallThread BT[4];
const int RAYPRECISION2 = RAYPRECISION*RAYPRECISION;

void BallThread::Init( unsigned int a_Thread )
{
	m_Thread = a_Thread;
	SetThreadIdealProcessor( handle(), m_Thread );
}
void BallThread::run()
{
	while (1)
	{
		WaitForSingleObject( waitforgo[m_Thread], INFINITE );
		while (1)
		{
			if (rayindex > 0)
			{
				volatile LONG rid = InterlockedDecrement( &rayindex );
				if (rid >= 0) 
				{
					vector3 pos = m_Ball->GetPos();
					vector3 vel = m_Ball->GetVelocity();
					vector3 ray = BallManager::RayDirs[RAYPRECISION2-rid];
					float rad = m_Ball->GetRadius();				
					Primitive* prim = 0;
					float dist = Engine::Trace(pos, ray, prim, BallManager::GetMatList(), BallManager::GetMatCount() );
					if (dist < rad)
					{
						float l = vel.Length()*m_Friction;
						float raddist = rad-dist;

						// reflect and update ball position
						const vector3 n = prim->GetNormal();
						const vector3 r = n.Dot(ray) * n;
						pos -= r*raddist;
						m_Ball->SetPos(pos);

						// add a reflecting velocity to the ball
						float m = raddist/rad;
						//totalmass += m/RAYPRECISION2;
						//vel *= (1.0f-m/RAYPRECISION2*Config::B_Slowdown);
						vel -= r * (l+m_Bouncyness) * m;

						// active collision triggers
						if (prim)
						{
							Entity* e=EntityManager::GetEntityByMaterial(prim->GetMaterial());
							//prim->m_Material->SetDiffuse(Color(Rand(1.0f), Rand(1.0f), Rand(1.0f)));
							Flipper* flipper = 0;
							vector3 distance;
							float length;
							if (e)
							{
								e->SetHitFlag(m_Ball, prim->m_Material, prim->GetNormal());
								switch (e->GetType())
								{
								case Entity::HITTARGET:
								case Entity::MUSICBOX:
								case Entity::BOARD:
								case Entity::FLIPPER:
									break;

								case Entity::MUSHROOM:
									length = vel.Length();
									vel += 0.15f * length * r * raddist;
									vel -= 70.0f * r;
									m_Ball->SetChargeFlag();
									break;

								case Entity::BUMPER:
									if (prim->m_Material == e->GetMaterialByName("Ref_kickerMaterial"))
									{
										vel -= 90.0f * r;
										vel -= 90.0f * n;
									}
									break;

								case Entity::PUSHER:
									vel -= (75.0f+Rand(100.0f)) * n;
									break;

								case Entity::BREAKOUT:
									vel *= 0.5f;
									vel -= 25.0f * n;
									break;

								case Entity::PADDLE:
									distance = vector3(n.x, 0, n.z);
									distance.Normalize();
									length = vel.Length(); vel.Normalize(); vel *= min(length,30.0f);
									vel -= 80.0f * distance;
									SoundManager::Play( "Sound/Ingame/padhit.ogg", CHANNEL_EVENT_2 );
									break;
								//default:
									//Log::Message("UNKNOWN");
								}
							}
						}
					}
					//vel *= (1.0f-totalmass);
					m_Ball->SetVelocity(vel);
					m_Ball->SetPos(pos);
				}
			}
			else 
			{ 
				SetEvent( waitfordone[m_Thread] ); 
				break; 
			}
		}
	}
}


// -----------------------------------------------------------
// Ball Class
// -----------------------------------------------------------
Ball::Ball()
{
	m_Active = false;
	m_Material = MManager::NewMaterial();
	m_Light = MManager::NewLight();
	vector3 pos(0.0f,0.0f,0.0f);
	Color diff(1.0f,1.0f,1.0f);
	Color spec(0.5f,0.5f,0.5f);
	m_Light->Init(0,"Sun",pos,diff,spec,0);
	Scene::AddLight(m_Light);
}

void Ball::Init(vector3 a_Pos, vector3 a_InitVelocity)
{
	m_Pos = a_Pos;
	m_Velocity = a_InitVelocity;
	m_Active = true;
	m_DeleteFlag = false;
	m_Charge = 0.5f;

	((Spheres*)(BallManager::GetNode()))->SetCentre(m_SphereId, m_Pos);
	m_Light->SetPos(m_Pos);
}

void Ball::CleanUp()
{
	m_Charge = 0.0f;
	m_Active = false;
	m_Pos = vector3(-1000,m_SphereId*5,-1000);
	((Spheres*)(BallManager::GetNode()))->SetCentre(m_SphereId, m_Pos);
	m_Light->SetShadows(false);
	m_Light->SetRadius(0);
	m_Light->SetPos(m_Pos);
}

void Ball::SetLightPos(vector3 a_Pos)
{
	m_Light->SetPos(a_Pos);
}
void Ball::SetRadius(float a_Radius)
{
	((Spheres*)(BallManager::GetNode()))->SetRadius(m_SphereId, a_Radius);
}
float Ball::GetRadius()
{
	return ((Spheres*)(BallManager::GetNode()))->GetRadius(m_SphereId);
}

void Ball::AddTiltForce()
{
	if (!m_Active) return;
	m_Velocity += vector3(25.0f-Rand(50),0,25.0f-Rand(50));
}

void Ball::StepTick(float a_DT)
{
	if (!m_Active) return;

	// Gravity
	m_Velocity -= BallManager::GetGravityNormal() * m_Gravity * a_DT;

	// Truncate to max force
	if (m_Velocity.SqrLength() > Config::B_MaxSpeed * Config::B_MaxSpeed)
	{
		m_Velocity.Normalize();
		m_Velocity *= Config::B_MaxSpeed;
	}

	// Update Position
	m_Pos += m_Velocity * a_DT;

	// Ball to Ball Collision
	for (int i=0; i<BallManager::GetActiveBallCount(); ++i)
	{
		Ball* other = BallManager::GetBallById(i);
		int myid = GetSphereId();
		if (other->GetSphereId() != myid)
		{
			// Check whether there actually was a collision
			float rad = GetRadius() + other->GetRadius();
			vector3 vdist = m_Pos - other->GetPos();
			float dist = vdist.Length();
			if (dist > 0.0f && dist < rad) 
			{
				// normalize vdist
				vdist = vdist / dist;

				// move the balls away from eachother
				float overlap = rad - dist;
				vector3 mtd = vdist * overlap;
				m_Pos += mtd * 0.5f;
				other->SetPos(other->GetPos() - mtd * 0.5f);

				// Remove some speed for collisions (not 100% elastic)
				float fric = overlap / rad * 0.6f;
				this->ScaleVelocity(1.0f - fric * GetRadius());
				other->ScaleVelocity(1.0f - fric * other->GetRadius());

				// Get the components of the velocity vectors which are parallel to the collision.    
				// The perpendicular component remains the same for both fish    
				float aci = m_Velocity.Dot(vdist);
				float bci = other->GetVelocity().Dot(vdist);
							
				// Replace the collision velocity components with the new ones   
				this->AddVelocity((bci - aci) * vdist);
				other->AddVelocity((aci - bci) * vdist);
			}
		}
	}

	// Multithreaded collision
	int cores = Engine::m_Cores;
	if (cores > 4) cores = 4;
	rayindex = RAYPRECISION2-1;
	for (int i=0; i<cores; ++i)
	{
		BT[i].m_Ball = this;
		BT[i].m_Friction = m_Friction;
		BT[i].m_Bouncyness = m_Bouncyness;
		SetEvent( waitforgo[i] );
	}
	WaitForMultipleObjects( cores, waitfordone, true, INFINITE );

	// Update Charge
	if (m_ChargeFlag) m_Charge += 0.2f;
	if (m_Charge > 1.0f) m_Charge = 1.0f;
	m_ChargeFlag = false;

	// Update Lights
	Color ChargeColorDif = Color( 1.00f, 1.00f, 1.00f );
	Color ChargeColorSpec = Color( 0.30f, 0.30, 0.30f );
	vector3 pos = m_Pos + vector3(0, GetRadius(), 0);
	m_Light->SetShadows(Config::S_lightingQuality >= 1);
	m_Light->SetRadius(40.0f+m_Charge*20.0f);
	m_Light->SetDiffuse(ChargeColorDif);
	m_Light->SetSpecular(ChargeColorSpec);
}



void Ball::Tick(float a_DT)
{
	// Update Material
	m_Material->SetAmbient( Color( 0.25f + 0.25f * m_Charge, 0.25f + 0.25f * m_Charge, 0.25f ) );
	m_Material->SetDiffuse( Color( 0.25f + 0.25f * m_Charge, 0.25f + 0.25f * m_Charge, 0.25f ) );
	m_Material->SetSpecular( Color( 0.05f + 0.05f * m_Charge, 0.05f + 0.05f * m_Charge, 0.05f ) );
	m_Material->SetEmissive( Color( 0.25f + 0.25f * m_Charge, 0.25f + 0.25f * m_Charge, 0.25f ) );
	if (Config::S_reflections > 0)
	{
		m_Material->SetMinReflection(0.1f);
		m_Material->SetMaxReflection(1.5f);
		//if (Config::S_reflections > 3) m_Material->SetRefraction(0.25f*m_Charge);
	}
	else
	{
		m_Material->SetMinReflection(0.0f);
		m_Material->SetMaxReflection(0.0f);
	}

	// Delete ball
	if (m_Pos.y < -100 || m_Pos.y > 250)
	{
		World::IncLives(-1);
		BallManager::DeleteBall(m_SphereId);
	}

	//// play sound
	//if( m_LastVel.Length() - m_Velocity.Length() > (m_Velocity.Length() * 0.4f) ) SoundManager::Play( "Sound/Ingame/little_thump.wav" );
	
	// update velocity
	m_LastVel = m_Velocity;
}

void Ball::PostRender()
{
	World::GetSurface()->Box(-m_Pos.x-GetRadius()+ 128, m_Pos.z-GetRadius() + 128, -m_Pos.x+GetRadius() + 128, m_Pos.z+GetRadius() + 128, 0xffff00);
}

// -----------------------------------------------------------
// BallManager Class
// -----------------------------------------------------------
Node* BallManager::m_Node;
Ball** BallManager::m_Balls;
int BallManager::m_MaxBalls = 0;
int BallManager::m_NextBallId = 0;
vector3 BallManager::RayDirs[RAYPRECISION2];
Material** BallManager::m_MatList=0;
vector3 BallManager::m_GravityNormal;

void BallManager::Init(int a_MaxBalls)
{
	m_MaxBalls = a_MaxBalls;

	// Gravity
	matrix m;
	m.RotateX(TABLEPITCHANGLE);
	m_GravityNormal = m.Transform(vector3(0,1,0));

	// Create Spheres
	m_Node = new Spheres(m_MaxBalls);
	m_Balls = new Ball*[m_MaxBalls];
	m_MatList = new Material*[m_MaxBalls];
	for (int i=0; i<m_MaxBalls; i++)
	{
		// Create some dummy spheres far outside map
		m_Balls[i] = new Ball();
		m_Balls[i]->SetSphereId(i);
		m_MatList[i] = m_Balls[i]->GetMaterial();
		m_MatList[i]->SetShadow(false);
		m_Node->Add(vector3(-1000,i*1,-1000), 0.1f, m_MatList[i]);
	}
	SceneGraph::AddNode( m_Node );

	// Precalculate rays
	float p = 360/RAYPRECISION*PI/180;
	for (int y=RAYPRECISION-1; y>=0; y--)
	{
		for (int x=RAYPRECISION-1; x>=0; x--)
		{
			RayDirs[y*RAYPRECISION+x] = vector3(cos(x*p),cos(y*p),sin(x*p));
			RayDirs[y*RAYPRECISION+x].Normalize();
		}
	}

	// Multithreading
	int cores = Engine::m_Cores;
	if (cores > 4) cores = 4;
	for (int i = 0; i < cores; ++i )
	{
		// events
		waitforgo[i] = CreateEvent( NULL, FALSE, FALSE, NULL );
		waitfordone[i] = CreateEvent( NULL, FALSE, FALSE, NULL );
		BT[i].Init(i);
		BT[i].start();
	}
}

void BallManager::Destroy()
{
	for (unsigned int i = 0; i < Engine::m_Cores; ++i )
	{
		BT[i].kill();
	}
}

int BallManager::AddBall(vector3 a_Pos, vector3 a_Velocity, float a_Radius)
{
	if (m_NextBallId < m_MaxBalls)
	{
		m_Balls[m_NextBallId]->SetRadius(a_Radius);
		m_Balls[m_NextBallId]->Init(a_Pos, a_Velocity);
		++m_NextBallId;
	}
	return m_NextBallId-1;
}

void BallManager::DeleteBall(int a_ID)
{
	// Delete Ball
	m_NextBallId--;

	// Swop the deleted ball with the last ball
	if ( a_ID != m_NextBallId ) 
	{
		Ball* ball = m_Balls[a_ID];
		m_Balls[a_ID] = m_Balls[m_NextBallId];
		m_Balls[a_ID]->SetSphereId(a_ID);
		m_Balls[m_NextBallId] = ball;
		m_Balls[m_NextBallId]->SetSphereId(m_NextBallId);
	}

	// Delete the ball
	m_Balls[m_NextBallId]->CleanUp();
	if (GameCam::GetCamMode() != GameCam::CAM_FREE) GameCam::SetCamMode(GameCam::CAM_GAME);

	//ball->SetActive(false);
	//((Spheres*)(m_Node))->SetCentre(ball->GetSphereId(), vector3(1000-int(ball->GetSphereId()/1000)*0.5f,1000-int(ball->GetSphereId()%1000)*0.5f,1000-int(ball->GetSphereId()/1000)*0.5f));
}

void BallManager::Tick(float a_DT)
{
	for (int i=0; i<m_NextBallId; ++i)
	{
		m_Balls[i]->Tick(a_DT);
	}
}

void BallManager::PostRender()
{
	for (int i=0; i<m_NextBallId; ++i)
	{
		m_Balls[i]->PostRender();
	}
}


void BallManager::StepTick(float a_DT)
{
	// Update Balls
	for (int i=0; i<m_NextBallId; ++i)
	{
		m_Balls[i]->StepTick(a_DT);
	}

	// Delete Balls
	for (int i=0; i<m_NextBallId; ++i)
	{
		if (m_Balls[i]->GetDeleteFlag())
		{
			DeleteBall(i);
			break;
		}
	}
}

void BallManager::UpdateBallPositions()
{
	for (int i=0; i<m_NextBallId; ++i)
	{
		m_Balls[i]->SetLightPos(m_Balls[i]->GetPos());
		((Spheres*)(m_Node))->SetCentre(i, m_Balls[i]->GetPos());
	}
}
void BallManager::AddTiltForce()
{
	for (int i=0; i<m_NextBallId; ++i)
	{
		m_Balls[i]->AddTiltForce();
	}
}


void BallManager::ResetPhysics(float a_DT)
{
	for (int i=0; i<m_NextBallId; ++i)
	{
		float r = m_Balls[i]->GetRadius();
		r += a_DT*2.0f; if (r > BALLSIZE) r = BALLSIZE;
		m_Balls[i]->SetRadius(r);

		m_Balls[i]->SetPhysics(Config::B_Gravity,Config::B_Friction,Config::B_Bouncyness);
	}
}

