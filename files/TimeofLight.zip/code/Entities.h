// --------------------------------------------------------------------------
// Copyright (c) Mark Peters and Bram van de Wetering 2009
// --------------------------------------------------------------------------

#ifndef I_ENTITY_H
#define I_ENTITY_H

#include "common.h"
#include "common_math.h"
#include "Balls.h"

namespace Raytracer {

class Node;
class Entity;
class Material;
class Light;

class EntityManager
{
public:
	static void Init(int a_MaxEntities);
	static void StepTick(float a_DT);
	static void PostRender();
	static void Tick(float a_DT);
	static void RunHits(float a_DT);
	static void UpdateQuality();
	static void ResetEntities();
	static int AddEntity(Entity* a_Entity);
	static void DeleteEntity(int a_ID);
	static Entity* GetEntityById(int a_ID){ return m_Entities[a_ID];}
	static Entity* GetEntityByMaterial(const Material* a_Mat);
	static int GetActiveEntityCount(){return m_NextEntityId;}
	static int GetMaxEntities(){return m_MaxEntities;}
private:
	static Entity** m_Entities;
	static int m_NextEntityId;
	static int m_MaxEntities;
};

class Entity
{
public:
	enum eType { UNKNOWN, BOARD, FLIPPER, MUSHROOM, BUMPER, PUSHER, HITTARGET, CANNON, MUSICBOX, ROTATOR, PADDLE, BREAKOUT };

	Entity();

	virtual void Init(char* a_Model, matrix a_Transform, float a_Scale){}
	virtual void StepTick(float a_DT){}
	virtual void Tick(float a_DT){}
	virtual void Reset(){}
	virtual void Hit(float a_DT){}
	virtual void PostRender(){}

	virtual void UpdateQuality(){}
	virtual bool ContainsMaterial(const Material* a_Mat);

	void BuildMatList();
	Material* GetMaterialByName(char* a_Name);

	virtual eType GetType(){return UNKNOWN;}

	bool GetHitFlag(){return m_HitFlag;}
	void SetHitFlag(Ball* a_Ball, Material* a_Mat, vector3 a_Normal){int id = a_Ball->GetSphereId(); m_HitFlag = true; m_HitBall[id] = a_Ball; m_HitMaterial[id] = a_Mat;  m_HitNormal[id] = a_Normal;}
	void ResetHits(){ m_HitFlag = false; for (int i=0; i<MAXBALLCOUNT; ++i) { m_HitBall[i] = NULL; m_HitMaterial[i] = NULL; }}

	void SetId(unsigned int a_Id){m_Id = a_Id;}
	int GetId(){return m_Id;}

	vector3 GetPos(){return m_Pos;}
	void SetPos(vector3 a_Pos){m_Pos = a_Pos;}

	Node* GetNode(){return m_Node;}
protected:
	vector3 m_Pos;

	Material** m_MatList;
	int m_MatCount;
	Node* m_Node;

	bool m_HitFlag;
	Ball* m_HitBall[MAXBALLCOUNT];
	Material* m_HitMaterial[MAXBALLCOUNT];
	vector3 m_HitNormal[MAXBALLCOUNT];
private:
	int m_Id;
};

}; // namespace Raytracer
#endif

