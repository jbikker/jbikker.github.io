// --------------------------------------------------------------------------
// Copyright (c) Mark Peters and Bram van de Wetering 2009
// --------------------------------------------------------------------------

extern "C" { 
#include "glew.h" 
}
#include "gl.h"
#include "Config.h"

#include "common.h"
#include "common_math.h"
#include "core.h"

namespace Raytracer {

//====== Option Settings ======
bool Config::Active = true;
int Config::WindowWidth = 640, Config::WindowHeight = 480;
int Config::ViewportWidth = 640, Config::ViewportHeight = 480;
bool Config::ReCreateWindow = false;

int Config::S_scrWidth = 640;
int Config::S_scrHeight = 480;
bool Config::S_fullscreen = false;
bool Config::S_fixRatio = true;

int Config::S_lightingQuality = 0;
int Config::S_reflections = 0;
int Config::S_antiAliasing = 2;

int Config::S_soundVol = 100;
int Config::S_musicVol = 100;

//====== User Input ======
bool Config::Key_Down[256];
bool Config::Key_Press[256];
bool Config::Mouse_Down[3];
bool Config::Mouse_Click[3];
int Config::Mouse_X = 0, Config::Mouse_Y = 0;
int Config::Mouse_PrevX = 0, Config::Mouse_PrevY = 0;

//====== High Scores ======
unsigned int Config::HighScores[10];
char Config::HighNames[10][12];

//====== Misc ======
bool Config::ShowStats = false;
bool Config::exitApp = false;
bool Config::RenderScene = false;
bool Config::fromOptions = false;
bool Config::newHighscore = false;

float Config::SceneUpdateCost = 0;
float Config::PhysicsCosts = 0;
vector3 Config::CamRot;
float Config::B_MaxSpeed = 350;
float Config::B_Gravity = 350; //350
float Config::B_Friction = 0.25f;
float Config::B_Bouncyness = 20.0f;
float Config::B_Slowdown = 0.0f;
float Config::B_TimeStep = 0.001f;

// --------------------------------------------------------------------------
// Option settings
// --------------------------------------------------------------------------

void Config::F_LoadSettings()
{
	FILE* f = fopen( "config.txt", "r" );
	if (f)
	{
		Log::Message( "loading global settings file (config.txt)..." );
		int fullscreen, fixratio;
		char line[256];
		while (!feof( f ))
		{
			fgets( line, 255, f );
			if (strncmp(line, "scrwidth", 8)==0) sscanf( line + 9, "%i", &Config::S_scrWidth );
			if (strncmp(line, "scrheight", 9)==0) sscanf( line + 10, "%i", &Config::S_scrHeight );
			if (strncmp(line, "fullscreen", 10)==0) sscanf( line + 11, "%i", &fullscreen );
			if (strncmp(line, "fixratio", 8)==0) sscanf( line + 8, "%i", &fixratio );

			if (strncmp(line, "lighting", 8)==0) sscanf( line + 9, "%i", &Config::S_lightingQuality );
			if (strncmp(line, "reflections", 11)==0) sscanf( line + 12, "%i", &Config::S_reflections );
			if (strncmp(line, "anti alias", 10)==0) sscanf( line + 11, "%i", &Config::S_antiAliasing );

			if (strncmp(line, "sound vol", 9)==0) sscanf( line + 10, "%i", &Config::S_soundVol );
			if (strncmp(line, "music vol", 9)==0) sscanf( line + 10, "%i", &Config::S_musicVol );
		}
		fclose( f );

		Config::S_fullscreen = (fullscreen==0)?false:true;
		Config::S_fixRatio = (fixratio==0)?false:true;
		Engine::m_AATreshold = Config::S_antiAliasing;

		Config::WindowWidth = Config::S_scrWidth;
		Config::WindowHeight = Config::S_scrHeight;
	}
	else F_GenerateSettings();
}

void Config::F_GenerateSettings()
{
	Log::Message( "Generating global settings file (config.txt)..." );
	FILE* f = fopen( "config.txt", "w" ); if(!f) return;
	fprintf(f, "scrwidth %i\n", S_scrWidth);
	fprintf(f, "scrheight %i\n", S_scrHeight);
	fprintf(f, "fullscreen %i\n", S_fullscreen);
	fprintf(f, "fixratio %i\n", S_fixRatio);

	fprintf(f, "lighting %i\n", S_lightingQuality);
	fprintf(f, "reflections %i\n", S_reflections);
	fprintf(f, "anti alias %i\n", S_antiAliasing);

	fprintf(f, "sound vol %i\n", S_soundVol);
	fprintf(f, "music vol %i\n", S_musicVol);
	fclose(f);
}

// --------------------------------------------------------------------------
// Input update loop
// --------------------------------------------------------------------------

void Config::F_UpdateInput()
{	
	Mouse_Click[0] = Mouse_Click[1] = Mouse_Click[2] = false;
	memset(&Key_Press[0], 0, sizeof(bool) * 256);
	Mouse_PrevX = Mouse_X;
	Mouse_PrevY = Mouse_Y;
}

// --------------------------------------------------------------------------
// High Score functions
// --------------------------------------------------------------------------

struct ScoreData{ int HighScores[10]; char Names[10][12]; };

void SetDefaultScore( ScoreData& data, int Pos, char* Name, unsigned int Score )
{
	memset(&data.Names[Pos][0],0,12);
	strcpy(&data.Names[Pos][0], Name);
	data.HighScores[Pos] = Score;
}
void Encrypt( ScoreData& data )
{
	for(int n=0; n<10; n++) for(int c=0; c<12; c++) data.Names[n][c] ^= ~(c|(n*3));
}

void Config::F_GenerateScores()
{
	Log::Message( "Generating highscore file (highscores.dat)..." );
	FILE* f = fopen( "highscores.dat", "w" ); if(!f) return;
	ScoreData saveData;
	// === Default Highscores ===========================

	SetDefaultScore(saveData, 0, "created by",		25000*10+rand() % 25000);
	SetDefaultScore(saveData, 1, "bram",			25000*9+rand() % 25000);
	SetDefaultScore(saveData, 2, "mark",			25000*8+rand() % 25000);
	SetDefaultScore(saveData, 3, "jan",				25000*7+rand() % 25000);
	SetDefaultScore(saveData, 4, "valentin",		25000*6+rand() % 25000);
	SetDefaultScore(saveData, 5, "wytze",			25000*5+rand() % 25000);
	SetDefaultScore(saveData, 6, "irina",			25000*4+rand() % 25000);
	SetDefaultScore(saveData, 7, "marc",			25000*3+rand() % 25000);
	SetDefaultScore(saveData, 8, "produced by",		25000*2+rand() % 25000);
	SetDefaultScore(saveData, 9, "dot studios",		25000*1+rand() % 25000);

	// ==================================================
	Encrypt( saveData );
	fwrite(&saveData, sizeof(ScoreData), 1, f);
	fclose(f);
}

void Config::F_LoadScores()
{
	Log::Message( "loading highscore file (highscores.dat)..." );
	FILE* f = fopen( "highscores.dat", "r" );
	ScoreData loadData;
	if (f)
	{
		fread(&loadData,sizeof(loadData),1,f);
		Encrypt( loadData );
		for(int i=0; i<10; i++)
		{
			HighScores[i] = loadData.HighScores[i];
			memcpy(&HighNames[i][0], &loadData.Names[i][0],12);
		}
	}
	else{ F_GenerateScores(); F_LoadScores(); }
}

void Config::F_SaveScores()
{
	Log::Message( "saving highscore file (highscores.dat)..." );
	FILE* f = fopen( "highscores.dat", "w" ); if(!f) return;
	ScoreData saveData;
	for(int i=0; i<10; i++)
	{
		saveData.HighScores[i] = HighScores[i];
		memcpy(&saveData.Names[i][0], &HighNames[i][0],12);
	}
	Encrypt( saveData );
	fwrite(&saveData, sizeof(ScoreData), 1, f);
	fclose(f);
}

// --------------------------------------------------------------------------
// Window resize
// --------------------------------------------------------------------------

void Config::ResizeGLWindow(int width, int height)
{
	if(width==0) width = 1;		WindowWidth = ViewportWidth = width;
	if(height==0) height = 1;	WindowHeight = ViewportHeight = height;

	// fix ratio
	if(Config::S_fixRatio)
	{
		if(ViewportWidth < 4 || ViewportHeight < 3) ViewportWidth = 4, ViewportHeight = 3;
		else ViewportWidth -= ViewportWidth%4, ViewportHeight -= ViewportHeight %3;
		if((ViewportWidth*3) != (ViewportHeight<<2))
		if((ViewportWidth*3) > (ViewportHeight<<2))
			ViewportWidth = (ViewportHeight<<2)/3;
		else
			ViewportHeight = (ViewportWidth*3)>>2;
	}
	int xoffset = (WindowWidth-ViewportWidth)>>1;
	int yoffset = (WindowHeight-ViewportHeight)>>1;

	glViewport( xoffset, yoffset, ViewportWidth, ViewportHeight );
	glMatrixMode( GL_PROJECTION );
	glLoadIdentity();
 	glOrtho( 0, 1, 0, 1, -1, 1 );
	glMatrixMode( GL_MODELVIEW );
	glLoadIdentity();

	char t[256];
	sprintf(t, "ResizeGLWindow width: %i, height: %i", width, height);
	Log::Message(t); 
}

}; // namespace Raytracer