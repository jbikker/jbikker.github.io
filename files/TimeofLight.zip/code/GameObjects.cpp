// --------------------------------------------------------------------------
// Copyright (c) Mark Peters and Bram van de Wetering 2009
// --------------------------------------------------------------------------

#include "GameObjects.h"
#include "Balls.h"
#include "core.h"
#include "scene.h"
#include "memory.h"
#include "surface.h"
#include "scenegraph.h"
#include "SoundManager.h"
#include "Config.h"
#include "World.h"
#include "ScoreMultiplier.h"
#include "Surface.h"

using namespace Raytracer;

// intersects a 2d line, y=-1 parrelel, y=0 = no hit, y=1 = intersect
vector3 LinesIntersection(vector3 s1, vector3 e1, vector3 s2, vector3 e2)
{
	float x1=s1.x;	float y1=s1.z;
	float x2=e1.x;	float y2=e1.z;
	float x3=s2.x;	float y3=s2.z;
	float x4=e2.x;	float y4=e2.z;  
	float denominator = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4); 
	if (denominator == 0)  return vector3(0,-1,0);  
	float pre = (x1*y2 - y1*x2), post = (x3*y4 - y3*x4);  
	float x = ( pre * (x3 - x4) - (x1 - x2) * post ) / denominator; 
	float y = ( pre * (y3 - y4) - (y1 - y2) * post ) / denominator;  
	if ( x < min(x1, x2) || x > max(x1, x2) || x < min(x3, x4) || x > max(x3, x4) ) return vector3(0,0,0);  
    if ( y < min(y1, y2) || y > max(y1, y2) || y < min(y3, y4) || y > max(y3, y4) ) return vector3(0,0,0);
	return vector3(x,1,y);
}

// Board
void Board::Init(char* a_Model, matrix a_Transform, float a_Scale)
{
	// Init
	m_Origin = a_Transform;
	m_Pos = a_Transform.GetTranslation();

	// load model
	m_Node = new Node(a_Model, m_Pos, a_Scale);
	m_Node->SetTransform(a_Transform);
	SceneGraph::AddNode(m_Node);

	m_LightCount = 0;
	Color diff(1.0f,1.0f,1.0f);
	Color spec(1.0f,1.0f,1.0f);
	vector3 pos;

	// TopLeft Center Island
	pos = vector3(34, -30, -56);
	m_Lights[m_LightCount] = MManager::NewLight();
	m_Lights[m_LightCount]->Init(1,"Sun",pos,diff,spec,60);
	Scene::AddLight(m_Lights[m_LightCount++]);

	// Top Bottom Light
	pos = vector3(-48,-60.0f,-53);
	m_Lights[m_LightCount] = MManager::NewLight();
	m_Lights[m_LightCount]->Init(1,"Sun",pos,diff,spec,20);
	Scene::AddLight(m_Lights[m_LightCount++]);

	// Hit targets left
	pos = vector3(71.62f, -35.93f, -62.34f);
	m_Lights[m_LightCount] = MManager::NewLight();
	m_Lights[m_LightCount]->Init(1,"Sun",pos,diff,spec,50);
	Scene::AddLight(m_Lights[m_LightCount++]);

	// Center Bottom Light
	pos = vector3(0.0f,-60.0f,0.0f);
	m_Lights[m_LightCount] = MManager::NewLight();
	m_Lights[m_LightCount]->Init(1,"Sun",pos,diff,spec,50);
	Scene::AddLight(m_Lights[m_LightCount++]);

	// Charge Cylinder Left
	pos = vector3(41.65f, -40, 32.67f);
	m_Lights[m_LightCount] = MManager::NewLight();
	m_Lights[m_LightCount]->Init(1,"Sun",pos,diff,spec,30);
	Scene::AddLight(m_Lights[m_LightCount++]);

	// Center Top Light
	pos = vector3(0.0f,-35.0f,0.0f);
	m_Lights[m_LightCount] = MManager::NewLight();
	m_Lights[m_LightCount]->Init(1,"Sun",pos,diff,spec,40);
	Scene::AddLight(m_Lights[m_LightCount++]);

	// Right Island
	pos = vector3(-77, -30, 15);
	m_Lights[m_LightCount] = MManager::NewLight();
	m_Lights[m_LightCount]->Init(1,"Sun",pos,diff,spec,50);
	Scene::AddLight(m_Lights[m_LightCount++]);

	// Top Island
	pos = vector3(-33, -20.0f, -79);
	m_Lights[m_LightCount] = MManager::NewLight();
	m_Lights[m_LightCount]->Init(1,"Sun",pos,diff,spec,50);
	Scene::AddLight(m_Lights[m_LightCount++]);

	// Material List
	BuildMatList();
	m_Node->Transform();
}
void Board::UpdateQuality()
{
	for (int i=5; i<m_LightCount; ++i) m_Lights[i]->SetShadows(Config::S_lightingQuality > 0);
	Material* mat;

	// Table
	mat = GetMaterialByName("Ref_material2");
	if (Config::S_reflections >= 3)
	{
		mat->SetMinReflection(0.5f);
		mat->SetMaxReflection(1.0f);
	}
	else
	{
		mat->SetMinReflection(0.0f);
		mat->SetMaxReflection(0.0f);
	}

	// Rails
	mat = GetMaterialByName("Ref_railsMaterial");
	if (Config::S_reflections >= 4)
	{
		mat->SetRefraction(0.75f);
		mat->SetRefrIndex(1.1f);
		mat->SetMinReflection(0.3f);
		mat->SetMaxReflection(1.5f);
	}
	else
	{
		mat->SetRefraction(0.0f);
		mat->SetRefrIndex(1.1f);
		mat->SetMinReflection(0.0f);
		mat->SetMaxReflection(0.0f);
	}
	mat = GetMaterialByName("Ref_loopingMaterial");
	mat->SetRefraction(0.75f);
	mat->SetRefrIndex(1.2f);
	if (Config::S_reflections >= 4)
	{
		mat->SetRefraction(0.75f);
		mat->SetRefrIndex(1.1f);
		mat->SetMinReflection(0.3f);
		mat->SetMaxReflection(1.5f);
	}
	else
	{
		mat->SetRefraction(0.0f);
		mat->SetRefrIndex(1.1f);
		mat->SetMinReflection(0.0f);
		mat->SetMaxReflection(0.0f);
	}

	// Glass
	mat = GetMaterialByName("Ref_glassCirkelMaterial");
	mat->SetRefraction(0.75f);
	mat->SetRefrIndex(1.2f);
	if (Config::S_reflections >= 1)
	{
		mat->SetMinReflection(0.8f);
		mat->SetMaxReflection(1.5f);
	}
}

void Board::Hit(float a_DT)
{
	for (int i=0; i<MAXBALLCOUNT; ++i)
	{
		if (m_HitMaterial[i])
		{
			if (m_HitMaterial[i] == GetMaterialByName("Ref_loopingMaterial"))
			{
				World::IncScore(SCORE_LOOPING_TRAVEL);
				World::IncRailBallCounter(i);
				m_HitBall[i]->SetPhysics(50,0.99f,20.0f);
			}

			if (m_HitMaterial[i] == GetMaterialByName("trampoline"))
			{
				World::IncTrampolineCounter(i);
			} 
			else if (m_HitMaterial[i] == GetMaterialByName("breakout"))
			{
				float r = m_HitBall[i]->GetRadius();
				r -= a_DT*3.0f; if (r < ARKANOID_BALLSIZE) r = ARKANOID_BALLSIZE;
				m_HitBall[i]->SetRadius(r);	
			} 
			else if (m_HitMaterial[i] == GetMaterialByName("leftIsland"))
			{
				World::IncLeftIslandBallCounter(i);
			}
			else if (m_HitMaterial[i] == GetMaterialByName("Ref_railsMaterial"))
			{
				World::IncRailBallCounter(i);
			}
		}
	}

}

// ShinyPatch
void ShinyPatch::Init(char* a_Model, matrix a_Transform, float a_Scale)
{
	// Init
	m_Origin = a_Transform;
	m_Pos = a_Transform.GetTranslation();

	// load model
	m_Node = new Node(a_Model, m_Pos, a_Scale);
	m_Node->SetTransform(a_Transform);
	SceneGraph::AddNode(m_Node);

	// Material List
	BuildMatList();
	m_Node->Transform();
}
void ShinyPatch::UpdateQuality()
{
	Material* mat;
	if (Config::S_reflections >= 1)
	{
		mat = GetMaterialByName("shinyPatchesSideSG");
		mat->SetMinReflection(0.8f);
		mat->SetMaxReflection(1.5f);

		mat = GetMaterialByName("shinyPatchesCenterSG");
		mat->SetMinReflection(0.8f);
		mat->SetMaxReflection(1.5f);
	}
	else
	{
		mat = GetMaterialByName("shinyPatchesSideSG");
		mat->SetMinReflection(0.0f);
		mat->SetMaxReflection(0.0f);

		mat = GetMaterialByName("shinyPatchesCenterSG");
		mat->SetMinReflection(0.0f);
		mat->SetMaxReflection(0.0f);
	}
}
void ShinyPatch::Hit(float a_DT)
{
}

// Rotater
void Rotater::Init(char* a_Model, matrix a_Transform, float a_Scale)
{
	// Init
	m_Origin = a_Transform;
	m_Pos = a_Transform.GetTranslation();
	m_RotSpeedMax = 0.0f;

	// load model
	m_Node = new Node(a_Model, m_Pos, a_Scale);
	m_Node->SetTransform(a_Transform);
	m_Node->SetType(Node::REFITTABLE);
	SceneGraph::AddNode(m_Node);

	// Material List
	BuildMatList();
}
void Rotater::UpdateQuality()
{
	Material* mat;
		
	mat = GetMaterialByName("sidePlates");
	if (mat)
	{
		if (Config::S_reflections >= 2)
		{
			mat->SetMinReflection(0.3f);
			mat->SetMaxReflection(1.5f);
		}
		else
		{
			mat->SetMinReflection(0.0f);
			mat->SetMaxReflection(0.0f);
		}
	}

	mat = GetMaterialByName("leftWheel2:sidePlates");
	if (mat)
	{
		if (Config::S_reflections >= 2)
		{
			mat->SetMinReflection(0.3f);
			mat->SetMaxReflection(1.5f);
		}
		else
		{
			mat->SetMinReflection(0.0f);
			mat->SetMaxReflection(0.0f);
		}
	}

	mat = GetMaterialByName("initialShadingGroup");
	if (mat)
	{
		if (Config::S_reflections >= 2)
		{
			mat->SetMinReflection(0.3f);
			mat->SetMaxReflection(1.5f);
		}
		else
		{
			mat->SetMinReflection(0.0f);
			mat->SetMaxReflection(0.0f);
		}
	}
}

void Rotater::Hit(float a_DT)
{
	World::IncScore(m_Score);
	const int randsound = rand() % 3;
	if( abs(m_RotSpeedBooster) < abs(m_RotSpeedMax * 0.8f) )
	{
		if( randsound == 0 ) SoundManager::Play("Sound/Ingame/winding1.wav", CHANNEL_EVENT_1 );
		if( randsound == 1 ) SoundManager::Play("Sound/Ingame/winding2.wav", CHANNEL_EVENT_2 );
		if( randsound == 2 ) SoundManager::Play("Sound/Ingame/winding3.wav", CHANNEL_EVENT_3 );
	}
	m_RotSpeedBooster = m_RotSpeedMax;
}

void Rotater::StepTick(float a_DT)
{
	if (m_RotSpeedBooster > 0.0f)
	{
		m_RotSpeedBooster -= a_DT*60.0f;
		if (m_RotSpeedBooster < 0.0f) m_RotSpeedBooster = 0.0f;
	}

	if (m_RotSpeedBooster < 0.0f)
	{
		m_RotSpeedBooster += a_DT*60.0f;
		if (m_RotSpeedBooster > 0.0f) m_RotSpeedBooster = 0.0f;
	}

	m_Rot += a_DT * m_RotSpeed + a_DT*m_RotSpeedBooster;
	if (m_Rot < 0) m_Rot += 360;
	if (m_Rot > 360) m_Rot -= 360;
	matrix m=m_Origin;
	matrix m2;
	m2.RotateY(m_Rot);
	m.Concatenate(m2);
	m_Node->SetTransform(m);
}


void Rotater::Tick(float a_DT)
{
	m_Node->Transform();
}
// Dial
void Dial::Init(char* a_Model, matrix a_Transform, float a_Scale)
{
	// Init
	m_Origin = a_Transform;
	m_Pos = a_Transform.GetTranslation();

	// load model
	m_Node = new Node(a_Model, m_Pos, a_Scale);
	m_Node->SetTransform(a_Transform);
	m_Node->SetType(Node::REFITTABLE);
	SceneGraph::AddNode(m_Node);

	// Material List
	BuildMatList();
}
void Dial::UpdateQuality()
{
	Material* mat = GetMaterialByName("dial_01");
	if (mat)
	{
		if (Config::S_reflections >= 3)
		{
			mat->SetMinReflection(0.5f);
			mat->SetMaxReflection(1.0f);
		}
		else
		{
			mat->SetMinReflection(0.0f);
			mat->SetMaxReflection(0.0f);
		}
	}
}

void Dial::Hit(float a_DT)
{
//	SoundManager::Play("sound/metalrolling.wad",CHANNEL_BALLROLL);
}

void Dial::StepTick(float a_DT)
{
	m_Rot += 10.0f*a_DT; if (m_Rot > 360.0f) m_Rot -= 360.0f;
	matrix m=m_Origin;
	matrix m2;
	m2.RotateY(m_Rot);
	m.Concatenate(m2);
	m_Node->SetTransform(m);
}

void Dial::Tick(float a_DT)
{
	m_Node->Transform();
}
// MusicBox
void MusicBox::Init(char* a_Model, matrix a_Transform, float a_Scale)
{
	// Init
	m_Origin = a_Transform;
	m_Pos = a_Transform.GetTranslation();

	// load model
	m_Node = new Node(a_Model, m_Pos, a_Scale);
	m_Node->SetTransform(a_Transform);
	SceneGraph::AddNode(m_Node);

	// add light
	vector3 l[6];
	l[0] = vector3(-16,11, 0);
	l[1] = vector3(-16,10,-4);
	l[2] = vector3(-16,10, 4);
	l[3] = vector3(-16,14, 0);
	l[4] = vector3(-16,13,-4);
	l[5] = vector3(-16,13, 4);
	for (int i=0; i<6; ++i)
	{
		m_Lights[i] = MManager::NewLight();
		Color diff(0.3f,0.7f,0.3f);
		Color spec(0.2f,0.3f,0.2f);
		vector3 pos = m_Origin.Transform(l[i]);
		m_Lights[i]->Init(0,"MusicBox",pos,diff,spec,5);
		Scene::AddLight(m_Lights[i]);
	}
	m_Lights[6] = MManager::NewLight();
	Color diff(1.0f,1.0f,1.0f);
	Color spec(0.5f,0.5f,0.5f);
	vector3 pos = vector3(2,45,10);
	pos = m_Origin.Transform(pos);
	m_Lights[6]->Init(0,"MusicBox",pos,diff,spec,65);
	Scene::AddLight(m_Lights[6]);

	// Material List
	BuildMatList();
	m_Node->Transform();
}
void MusicBox::UpdateQuality()
{
	Material* mat;
	mat = GetMaterialByName("glass");
	if (mat)
	{
		mat->SetRefraction(0.9f);
		mat->SetRefrIndex(1.2f);
		if (Config::S_reflections >= 3)
		{
			mat->SetMinReflection(0.2f);
			mat->SetMaxReflection(1.5f);
		}
		else
		{
			mat->SetMinReflection(0.0f);
			mat->SetMaxReflection(0.0f);
		}
	}
	mat = GetMaterialByName("goo");
	if (mat)
	{
		mat->SetRefraction(0.8f);
		mat->SetRefrIndex(1.0f);
	}
}
void MusicBox::Hit(float a_DT)
{
	for (int i=0; i<MAXBALLCOUNT; ++i)
	{
		if (m_HitMaterial[i])
		{
			if (m_HitMaterial[i] == GetMaterialByName("innertube_shader") || m_HitMaterial[i] == GetMaterialByName("outertube_shader"))
			{
				float r = m_HitBall[i]->GetRadius();
				r -= a_DT*4.0f; if (r < ARKANOID_BALLSIZE) r = ARKANOID_BALLSIZE;
				m_HitBall[i]->SetRadius(r);
				SoundManager::Play( "Sound/Ingame/musicbox.ogg", CHANNEL_MUSICBOX );
			} 
		}
	}
}
void MusicBox::Tick(float a_DT)
{
	for (int i=0; i<6; ++i) m_Lights[i]->SetRadius(15.0f+Rand(5.0f));
}
// Flipper
void Flipper::Init(char* a_Model, matrix a_Transform, float a_Scale)
{
	// Init
	m_Origin = a_Transform;
	m_Pos = a_Transform.GetTranslation();
	m_CurRot = 0.0f;
	m_Flipping = false;
	m_Status = Flipper::IDLE;

	// load model
	m_Node = new Node(a_Model, m_Pos, a_Scale);
	m_Node->SetType(Node::REFITTABLE);
	m_Node->SetTransform(a_Transform);
	SceneGraph::AddNode(m_Node);

	// Create Light
	vector3 pos = m_Pos + vector3(0,7,0);
	m_Light = MManager::NewLight();
	Color diff(1.0f,1.0f,1.0f);
	Color spec(0.5f,0.5f,0.5f);
	m_Light->Init(0,"Flipper",pos,diff,spec,15);
	Scene::AddLight(m_Light);

	// Material List
	BuildMatList();
}

float Flipper::GetSpeed()
{
	if (m_CurRot <= 0.0f || m_CurRot >= 45.0f || m_Status != Flipper::UP) 
		return 0.0f;
	else
		return 1.0f;
}

void Flipper::Reset()
{
	m_CurRot = 0.0f;
	m_Flipping = false;
	m_Status = Flipper::IDLE;
}

bool Flipper::Flip(bool a_Flipping)
{ 
	if (m_Flipping != a_Flipping && a_Flipping) SoundManager::Play("Sound/Ingame/flipper.wad",CHANNEL_FLIPPER + m_CurRot);
	m_Flipping = a_Flipping; 
	if (a_Flipping && m_Status!=Flipper::UP) m_Status = Flipper::UP;
	if (m_Status==Flipper::UP && m_CurRot < 45.0f) return true; 
	if (m_Status==Flipper::UP && m_CurRot == 45.0f && !m_Flipping) return true; 
	if (m_Status==Flipper::DOWN) return true; 
	return false;
}
void Flipper::StepTick(float a_DT)
{
	switch (m_Status)
	{
	case IDLE: 
		break;

	case UP: 
		m_CurRot += a_DT*750.0f; 
		if (m_CurRot > 45.0f) 
		{
			m_CurRot = 45.0f;
			if (!m_Flipping) m_Status = Flipper::DOWN;
		}
		break;

	case DOWN: 
		m_CurRot -= a_DT*750.0f; 
		if (m_Flipping) m_Status = Flipper::UP;
		if (m_CurRot < 0.0f)
		{
			m_Status = Flipper::IDLE;
			m_CurRot = 0.0f;
		}
		break;
	}

	matrix m=m_Origin;
	matrix m2;
	m2.RotateY(m_RotateDir ? m_CurRot : -m_CurRot);
	m.Concatenate(m2);
	m_Node->SetTransform(m);

	if (GetSpeed() > 0.0f)
	{
		// Use Line Intersection for ball physics
		vector3 start = vector3(0,0, (m_RotateDir) ? -1.5f : 1.5f); start = m.Transform( start );
		vector3 end = vector3(-14,0, (m_RotateDir) ? -1.5f : 1.5f); end = m.Transform( end );
		vector3 line; if (m_RotateDir) line = end-start; else line = start-end; 
		vector3 perp = vector3(-line.z, 0, line.x);
		vector3 n = perp; n.Normalize();
		for (int i=0; i<BallManager::GetActiveBallCount(); ++i)
		{
			vector3 result;
			Ball* ball=BallManager::GetBallById(i);

			// left line
			result = LinesIntersection(start, end, ball->GetPos() - 2.0f*vector3(ball->GetRadius(),0,ball->GetRadius()), ball->GetPos() + vector3(ball->GetRadius(),0,ball->GetRadius()*1.5f));
			if (result.y > 0)
			{
				vector3 distance = m_Pos - ball->GetPos();
				float length = distance.SqrLength();
				ball->SetVelocity( (10.0f+length) * n * 50.0f);
				ball->SetPos( vector3(result.x, ball->GetPos().y, result.z-ball->GetRadius()) );
				continue;
			}

			// right line
			result = LinesIntersection(start, end, ball->GetPos() - 2.0f*vector3(-ball->GetRadius(),0,ball->GetRadius()), ball->GetPos() + vector3(-ball->GetRadius(),0,ball->GetRadius()*1.5f));
			if (result.y > 0)
			{
				vector3 distance = m_Pos - ball->GetPos();
				float length = distance.SqrLength();
				ball->SetVelocity( (10.0f+length) * n * 50.0f);
				ball->SetPos( vector3(result.x, ball->GetPos().y, result.z-ball->GetRadius()) );
				continue;
			}

			// straight down
			result = LinesIntersection(start, end, ball->GetPos() - vector3(0,0,2.0f*ball->GetRadius()), ball->GetPos() + vector3(0,0,ball->GetRadius()*2));
			if (result.y > 0)
			{
				vector3 distance = m_Pos - ball->GetPos();
				float length = distance.SqrLength();
				ball->SetVelocity( (10.0f+length) * n * 50.0f);
				ball->SetPos( vector3(result.x, ball->GetPos().y, result.z-ball->GetRadius()) );
				continue;
			}
		}
	}
}

void Flipper::Tick(float a_DT)
{
	m_Node->Transform();
}
void Flipper::UpdateQuality()
{
	//Material* mat;
	//mat = GetMaterialByName("shinyFlipperSG");
	//if (mat)
	//{
	//	if (Config::S_reflections >= 2)
	//	{
	//		mat->SetMinReflection(0.3f);
	//		mat->SetMaxReflection(1.3f);
	//		mat->SetRefraction(0.5f);
	//		mat->SetRefrIndex(1.2f);
	//	}
	//	else
	//	{
	//		mat->SetRefraction(0.0f);
	//	}
	//}
}

void Flipper::PostRender()
{
	matrix m=m_Origin;
	matrix m2;
	m2.RotateY(m_RotateDir ? m_CurRot : -m_CurRot);
	m.Concatenate(m2);
	m_Node->SetTransform(m);

	vector3 start = vector3(0,0, (m_RotateDir) ? -1.5f : 1.5f); start = m.Transform( start );
	vector3 end = vector3(-14,0, (m_RotateDir) ? -1.5f : 1.5f); end = m.Transform( end );
	World::GetSurface()->Line(-start.x + 128, start.z + 128, -end.x + 128, end.z + 128, 0xff0000);

	vector3 line; if (m_RotateDir) line = end-start; else line = start-end; 
	vector3 perp = vector3(-line.z, 0, line.x);
	vector3 dir = perp; dir.Normalize();

	vector3 sds = start + (end-start) * 0.5f;
	vector3 sde = sds + dir * 5.0f;

	World::GetSurface()->Line(-sds.x + 128, sds.z + 128, -sde.x + 128, sde.z + 128, 0xffffff);

	for (int i=0; i<BallManager::GetActiveBallCount(); ++i)
	{
		Ball* ball=BallManager::GetBallById(i);
		//vector3 dir2 = ball->GetVelocity(); dir2.y = 1; 
		//dir2.Normalize();
		//dir2 *= ball->GetRadius()*2;
		vector3 dir2 = vector3(0,0,ball->GetRadius()*3);

		World::GetSurface()->Line(-ball->GetPos().x+128, ball->GetPos().z+128, -(ball->GetPos().x+dir2.x)+128, ball->GetPos().z+dir2.z+128, 0x00ff00);

		vector3 result = LinesIntersection(start, end, ball->GetPos(), ball->GetPos() + dir2);
		if (result.y > 0) World::GetSurface()->Box(-(result.x-2)+128, result.z-2+128, -(result.x+2)+128, result.z+2+128, 0x0000ff);

		//if (result.y > 0) World::GetSurface()->Line(-result.x+128, result.z+128, -(result.x+dir.x*100)+128, result.z+dir.z*100+128, 0x0000ff);
	}
}


// Mushroom
void Mushroom::Init(char* a_Model, matrix a_Transform, float a_Scale)
{
	// Init
	m_Rotate = Rand(360.0f);
	m_Origin = a_Transform;
	m_Pos = a_Transform.GetTranslation();
	m_ColorStart = vector3(1.0f, 1.0f, 1.0f);
	m_ColorEnd = vector3(1.0f, 0.0f, 0.0f);
	m_HitTimer = 0.0f;
	m_BounceForce = 10.0f;

	// load model
	m_Node = new Node(a_Model, m_Pos, a_Scale);
	m_Node->SetTransform(a_Transform);
	m_Node->SetType(Node::REFITTABLE);
	SceneGraph::AddNode(m_Node);

	// add light
	vector3 pos = m_Pos + vector3(0,4,0);
	m_Light = MManager::NewLight();
	Color diff(1.0f,1.0f,1.0f);
	Color spec(0.5f,0.5f,0.5f);
	m_Light->Init(0,"StaticLight",pos,diff,spec,10);
	Scene::AddLight(m_Light);

	// Material List
	BuildMatList();
}
void Mushroom::UpdateQuality()
{
	m_LightMat = GetMaterialByName("mushroomLights");
	Material* mat = GetMaterialByName("mushroomMetal");
	if (Config::S_reflections >= 2)
	{
		mat->SetMinReflection(0.5f);
		mat->SetMaxReflection(1.5f);
	}
	else
	{
		mat->SetMinReflection(0.0f);
		mat->SetMaxReflection(0.0f);
	}
}

void Mushroom::Tick(float a_DT)
{
	m_Rotate += a_DT*10.0f;
	m_HitTimer -= a_DT*0.5f;
	if (m_HitTimer < 0.0f) m_HitTimer = 0.0f;
	float hit = 1.0f-m_HitTimer;

	float r = m_ColorStart.x * m_HitTimer + m_ColorEnd.x * hit;
	float g = m_ColorStart.y * m_HitTimer + m_ColorEnd.y * hit;
	float b = m_ColorStart.z * m_HitTimer + m_ColorEnd.z * hit;

	m_LightMat->SetAmbient ( Color( r * 1.0f, g * 1.0f, b * 1.0f ) );
	m_LightMat->SetDiffuse ( Color( r * 0.9f, g * 0.9f, b * 0.9f ) );
	m_LightMat->SetSpecular( Color( r * 0.3f, g * 0.3f, b * 0.3f ) );

	if (Config::S_reflections >= 4)
	{
		m_LightMat->SetRefraction(m_HitTimer*0.5f);
		m_LightMat->SetRefrIndex(1.5f);
	}
	else
	{
		m_LightMat->SetRefraction(0.0f);
	}

	m_Light->SetShadows(Config::S_lightingQuality >= 3);
	m_Light->SetRadius(20.0f+m_HitTimer*100.0f);

	matrix m=m_Origin;
	matrix m2;
	m2.RotateY(m_Rotate);
	m.Concatenate(m2);
	m_Node->SetTransform(m);
	m_Node->Transform();
}


void Mushroom::Hit(float a_DT)
{
	m_HitTimer = 1.0f;
	World::IncScore(1112);

	const int randsound = (rand() >> 6) % 3;
	if( randsound == 0 ) SoundManager::Play( "Sound/Ingame/mushroom_hit1.ogg", CHANNEL_EVENT_1 );
	if( randsound == 1 ) SoundManager::Play( "Sound/Ingame/mushroom_hit2.ogg", CHANNEL_EVENT_2 );
	if( randsound == 2 ) SoundManager::Play( "Sound/Ingame/mushroom_hit3.ogg", CHANNEL_EVENT_3 );
}
// Charge Cylinder
void ChargeCylinder::Init(char* a_Model, matrix a_Transform, float a_Scale)
{
	// Init
	m_Origin = a_Transform;
	m_Pos = a_Transform.GetTranslation();

	// load model
	m_Node = new Node(a_Model, m_Pos, a_Scale);
	m_Node->SetTransform(a_Transform);
	SceneGraph::AddNode(m_Node);

	// Create Light
	m_Charge = 0.0f;
	for (int i=0; i<5; i++)
	{
		vector3 pos = m_Pos + vector3(0,7.5f+(float)i*1.25f,1);
		m_Light[i] = MManager::NewLight();
		Color diff1(0.0f,0.7f,0.0f);
		Color spec1(0.0f,0.3f,0.0f);
		m_Light[i]->Init(4,"ChargeCylinder1",pos,diff1,spec1,0);
		Scene::AddLight(m_Light[i]);
	}

	//m_Light[1] = MManager::NewLight();
	//Color diff2(0.5f,0.5f,0.0f);
	//Color spec2(0.3f,0.3f,0.0f);
	//m_Light[1]->Init(5,"ChargeCylinder2",pos,diff2,spec2,20);
	//Scene::AddLight(m_Light[1]);

	// Material List
	BuildMatList();
	m_Node->Transform();
}


void ChargeCylinder::Reset()
{
	m_Charge = 0.0f;
	m_Opened = false;
	Hit(0.0f);
}
void ChargeCylinder::UpdateQuality()
{
	Material* mat = GetMaterialByName("glassCylinderSG");
	mat->SetRefraction(0.7f);
	mat->SetRefrIndex(1.1f);
	if (Config::S_reflections >= 1)
	{
		mat->SetMinReflection(0.7f);
		mat->SetMaxReflection(1.5f);
	}
	else
	{
		mat->SetMinReflection(0.0f);
		mat->SetMaxReflection(0.0f);
	}

	mat = GetMaterialByName("liquidGooSG");
	mat->SetRefraction(0.8f);
	mat->SetRefrIndex(1.0f);
}
void ChargeCylinder::Hit(float a_DT)
{
	for (int i=0; i<MAXBALLCOUNT; ++i)
	{
		if (m_HitBall[i] && m_HitMaterial[i] == GetMaterialByName("baseMetalSG2SG"))
		{
			if (m_HitBall[i]->GetCharge() < (a_DT*0.2f) || m_Opened)
			{
				vector3 v = vector3(0,0,75);
				v = m_Origin.Transform(v);
				m_HitBall[i]->SetVelocity(v + vector3(0,75,0));
			}
			else
			{
				m_Charge += m_HitBall[i]->GetCharge()*a_DT*2.0f;
				m_HitBall[i]->SetCharge(m_HitBall[i]->GetCharge()-a_DT*0.2f);
				if (m_Charge >= 5.0f)
				{
					m_Charge = 5.0f; 
					m_Opened = true;
					SoundManager::Play("sound/Ingame/creaking.wad", CHANNEL_CANNONROT);
					ScoreMultiplier::IncMultiplier(2); 
					m_CountDown = 120.0f;
				}
				else
				{
					GameCam::SetZoom(true);
					SoundManager::Play("sound/Ingame/heart.wad", CHANNEL_EVENT_1);
				}
			}
		}
	}
}
void ChargeCylinder::Tick(float a_DT)
{
	for (int i=1; i<5; i++)
	{
		float value = Rand(0.3f);
		Color diff(value,0.7f-value,0.0f);
		m_Light[i]->SetDiffuse(diff);
	}
	if (m_CountDown > 0.0f) m_CountDown -= a_DT;
	if (m_Opened && m_CountDown <= 0.0f) 
	{ 
		ScoreMultiplier::IncMultiplier(-2); 
		Reset();
	}
	for (int i=0; i<5; ++i) m_Light[i]->SetRadius((m_Charge-i)*4.0f);

	//if (m_HitBall) m_HitBall->AddVelocity(vector3(-500,-2500,500));
	//if (m_Animator > 1.0f){ m_Animator = 1.0f; dir *= -1; }
	//if (m_Animator < 0.0f){ m_Animator = 0.0f; dir *= -1; }

	//m_Light[0]->SetRadius(m_Animator);
	//vector3 newpos;
	//newpos = m_Pos + vector3(0,m_Animator,1);
	//m_Light[0]->SetPos(newpos);
	//newpos = m_Pos + vector3(0,sinf(m_Animator)*4.0f+8.5f,1);
	//m_Light[0]->SetPos(newpos);
	//newpos = m_Pos + vector3(0,sinf((1.0f-m_Animator))*4.0f+8.5f,1);
	//m_Light[1]->SetPos(newpos);

	//Material* mat = GetMaterialByName("liquidGooSG");
	//mat->SetUVScale(m_UVScale, mat->GetVScale());
}


// Bumper
void Bumper::Init(char* a_Model, matrix a_Transform, float a_Scale)
{
	// Init
	m_Origin = a_Transform;
	m_Pos = a_Transform.GetTranslation();
	m_ColorStart = vector3(1.0f, 1.0f, 0.0f);
	m_ColorEnd = vector3(1.0f, 0.0f, 0.0f);
	m_HitTimer = 0.0f;
	m_BounceForce = 10.0f;

	// load model
	m_Node = new Node(a_Model, m_Pos, a_Scale);
	m_Node->SetTransform(a_Transform);
	SceneGraph::AddNode(m_Node);

	// add light
	vector3 lpos = vector3(0,5.0f,-5);
	vector3 pos = m_Origin.Transform(lpos);
	m_Light = MManager::NewLight();
	Color diff(1.0f,0.0f,0.0f);
	Color spec(0.5f,0.0f,0.0f);
	m_Light->Init(0,"StaticLight",pos,diff,spec,30);
	Scene::AddLight(m_Light);

	vector3 ambpos = vector3(0,15.0f,-5);
	pos = m_Origin.Transform(ambpos);
	m_AmbientLight = MManager::NewLight();
	Color diff2(1.0f,1.0f,0.5f);
	Color spec2(0.5f,0.5f,0.3f);
	m_AmbientLight->Init(0,"AmbientStaticLight",pos,diff2,spec2,30);
	Scene::AddLight(m_AmbientLight);

	// Material List
	BuildMatList();
	m_Node->Transform();
}
void Bumper::UpdateQuality()
{
	m_LightMat = GetMaterialByName("Ref_kickerMaterial");
	if (Config::S_reflections >= 1)
	{
		//m_LightMat->SetRefraction(0.5f);
		//m_LightMat->SetRefrIndex(1.0f);
		m_LightMat->SetMinReflection(0.5f);
		m_LightMat->SetMaxReflection(1.5f);
	}
	else
	{
		//m_LightMat->SetRefraction(0.0f);
		//m_LightMat->SetRefrIndex(1.0f);
		m_LightMat->SetMinReflection(0.0f);
		m_LightMat->SetMaxReflection(0.0f);
	}

	Material* mat = GetMaterialByName("Ref_material");
	if (Config::S_reflections >= 4)
	{
		m_LightMat->SetMinReflection(0.5f);
		m_LightMat->SetMaxReflection(1.5f);
	}
	else
	{
		m_LightMat->SetMinReflection(0.0f);
		m_LightMat->SetMaxReflection(0.0f);
	}
}
void Bumper::Tick(float a_DT)
{
	m_HitTimer -= a_DT*0.5f;
	if (m_HitTimer < 0.0f) m_HitTimer = 0.0f;
	float hit = 1.0f-m_HitTimer;

	float r = m_ColorStart.x * m_HitTimer + m_ColorEnd.x * hit;
	float g = m_ColorStart.y * m_HitTimer + m_ColorEnd.y * hit;
	float b = m_ColorStart.z * m_HitTimer + m_ColorEnd.z * hit;

	Color a = Color( r * 1.0f, g * 1.0f, b * 1.0f );
	Color d = Color( r * 0.8f, g * 0.8f, b * 0.8f );
	Color s = Color( r * 0.3f, g * 0.3f, b * 0.3f );

	m_LightMat->SetAmbient ( a );
	m_LightMat->SetDiffuse ( d );
	m_LightMat->SetSpecular( s );

	m_Light->SetDiffuse( d );
	m_Light->SetSpecular( s );
	m_Light->SetShadows(Config::S_lightingQuality>1);
	m_Light->SetRadius(m_HitTimer*150.0f);
	m_Light->Active(m_Light->GetRadius() > 0.0f);
}


void Bumper::Hit(float a_DT)
{
	m_HitTimer = 1.0f;
	World::IncScore(331);
	SoundManager::Play( "Sound/Ingame/bumperhit.ogg", CHANNEL_EVENT_1 + rand() % 3 );
}
// Hit Target
void HitTarget::Init(char* a_Model, matrix a_Transform, float a_Scale)
{
	// Init
	m_Owner = NULL;
	m_Origin = a_Transform;
	m_Pos = a_Transform.GetTranslation();
	m_ColorStart = vector3(1.0f, 1.0f, 0.5f);
	m_ColorEnd = vector3(1.0f, 0.5f, 0.5f);
	m_Active = false;

	// load model
	m_Node = new Node(a_Model, m_Pos, a_Scale);
	m_Node->SetTransform(a_Transform);
	SceneGraph::AddNode(m_Node);

	// Material List
	BuildMatList();
	m_Node->Transform();
}
void HitTarget::SetOwner(HitTargetBucket* a_Owner)
{
	m_Owner = a_Owner; 
	m_Owner->AddTarget(this);
}
void HitTarget::UpdateQuality()
{
	m_LightMat = GetMaterialByName("targetFrontSG");
	//if (Config::S_reflections >= 1)
	//{
	//	m_LightMat->SetMinReflection(0.2f);
	//	m_LightMat->SetMaxReflection(1.5f);
	//}
	//else
	//{
	//	m_LightMat->SetMinReflection(0.0f);
	//	m_LightMat->SetMaxReflection(0.0f);
	//}
}
void HitTarget::Tick(float a_DT)
{
	if (m_Owner) m_Owner->Update();
	if (m_Active) 
	{
		m_LightMat->SetAmbient ( Color( 1.0f, 0.0f, 0.0f ) );
		m_LightMat->SetDiffuse ( Color( 0.9f, 0.0f, 0.0f ) );
		m_LightMat->SetSpecular( Color( 0.3f, 0.0f, 0.0f ) );
	}
	else
	{
		m_LightMat->SetAmbient ( Color( 1.0f, 1.0f, 0.0f ) );
		m_LightMat->SetDiffuse ( Color( 0.9f, 0.9f, 0.0f ) );
		m_LightMat->SetSpecular( Color( 0.3f, 0.3f, 0.0f ) );
	}
}
void HitTarget::Hit(float a_DT)
{
	if (!m_Active) World::IncScore(3117);
	m_Active = true;
	SoundManager::Play("sound/Ingame/little_thump.wav",CHANNEL_EVENT_3);
}
// Hit Target Bucket
void HitTargetBucket::Init(char* a_Model, matrix a_Transform, float a_Scale)
{
	m_CountDown = 0.0f;
	m_Pos = a_Transform.GetTranslation();
	m_NextTarget = 0;
	m_Active = false;
}
void HitTargetBucket::Update()
{
	bool active = true;
	for (int i=0; i<m_NextTarget; ++i)
	{
		if (!m_Targets[i]->GetActive())
		{
			active = false; 
			break;
		}
	}
	if (!m_Active && active) {  
		World::IncScore(12818); 
		ScoreMultiplier::IncMultiplier(1); 
		m_CountDown = 60.0f;
	}
	m_Active = active;
}
void HitTargetBucket::Tick(float a_DT)
{
	if (m_CountDown > 0.0f) m_CountDown -= a_DT;
	if (m_Active && m_CountDown <= 0.0f) 
	{ 
		ScoreMultiplier::IncMultiplier(-1); 
		m_Active = false;
		for (int i=0; i<m_NextTarget; ++i) m_Targets[i]->Reset();
	}
}
// ScoreMeter
void ScoreMeter::Init(char* a_Model, float a_Scale)
{
	lightstr = 3.3f;

	// load model
	for (int i=0; i<SCORECYLINDERS; ++i)
	{
		const float scl = 2.0f;
		matrix m;
		m_Cpos[i] = vector3( 0, 1.1f * scl, 2.0f * scl ) + vector3( 0.1f * (float(i-5)+0.5f) * scl, 0, 0 );
		m_Lpos[i] = m_Cpos[i] + vector3( 0, -0.8f * scl, 0.4f * scl - (2.0f * scl) );

		//// add light
		//m_Light[i] = MManager::NewLight();
		//Color diff(1.0f,1.0f,1.0f);
		//Color spec(0.5f,0.5f,0.5f);
		//vector3 p(0,0,0);
		//m_Light[i]->Init(0,"ScoreLight", p, diff, spec, lightstr );
		//Scene::AddLight(m_Light[i]);

		// add cylinder
		m_Node[i] = new Node(a_Model, m.GetTranslation(), a_Scale);
		m_Node[i]->SetType(Node::REFITTABLE);
		m_Node[i]->SetTransform(m);
		for (int j=0; j<m_Node[i]->GetPrimCount(); ++j)
		{
			m_Node[i]->GetPrim(j)->m_Material->SetAmbient(Color(7.5f, 7.5f, 7.5f));
			m_Node[i]->GetPrim(j)->m_Material->SetDiffuse(Color(0.0f, 0.0f, 0.0f));
			m_Node[i]->GetPrim(j)->m_Material->SetSpecular(Color(0.0f, 0.0f, 0.0f));
		}

		SceneGraph::AddNode(m_Node[i]);
	}
}

void ScoreMeter::Tick( float a_DT )
{
	float step = a_DT * 100.0f;
	int oscore = World::GetScore();
	int nscore = World::GetScore();

	// Build matrix
	const vector3 campos = GameCam::GetPos();
	const vector3 camtar = GameCam::GetTarget();

	matrix camm;
	vector3 zaxis = camtar - campos, up( 0, 1, 0 ); zaxis.Normalize();
	vector3 xaxis = up.Cross( zaxis ); xaxis.Normalize();
	vector3 yaxis = xaxis.Cross( -zaxis ); yaxis.Normalize();
	camm[0] = xaxis.x, camm[1] = xaxis.y, camm[2] = xaxis.z;
	camm[4] = yaxis.x, camm[5] = yaxis.y, camm[6] = yaxis.z;
	camm[8] = zaxis.x, camm[9] = zaxis.y, camm[10] = zaxis.z;
	camm.SetTranslation( vector3(0,0,0) );

	camm.Invert();

	for (int i=SCORECYLINDERS-1; i>=0; --i)
	{
		nscore /= 10;
		int rotx = oscore - nscore * 10;
		oscore /= 10;
		float rot = 360 - rotx * 36.0f;

		if( fabs( m_Rot[i] - float(rot) ) > step )
		{
			if(m_Rot[i] > rot) m_Rot[i] -= step; else m_Rot[i] += step;
		}
		else m_Rot[i] = rot;

		vector3 cPos = m_Cpos[i];
		vector3 lPos = m_Lpos[i];

		vector3 cTrn = camm.Transform(cPos);
		vector3 lTrn = camm.Transform(lPos);

		cTrn += campos;
		lTrn += campos;

		matrix m = camm, n; n.RotateX( m_Rot[i] );
		m.Concatenate( n );
		m.SetTranslation( cTrn );
		m_Node[i]->SetTransform( m );
		//m_Light[i]->SetRadius( lightstr );
		//m_Light[i]->SetPos( lTrn );
		m_Node[i]->Transform();
	}
}

// Paddle
void Paddle::Init(char* a_Model, matrix a_Transform, float a_Scale)
{
	// Init
	m_Origin = a_Transform;
	m_Pos = a_Transform.GetTranslation();

	// load model
	m_Node = new Node(a_Model, m_Pos, a_Scale);
	m_Node->SetType(Node::REFITTABLE);
	m_Node->SetTransform(a_Transform);
	SceneGraph::AddNode(m_Node);

	// add light
	for (int i=0; i<3; ++i)
	{
		m_Light[i] = MManager::NewLight();
		Color diff(1.0f,1.0f,1.0f);
		Color spec(0.3f,0.3f,0.3f);
		m_Light[i]->Init(0,"Paddle",m_Pos,diff,spec,10);
		Scene::AddLight(m_Light[i]);
	}

	// Material List
	BuildMatList();
}
void Paddle::UpdateQuality()
{
	Material* mat = GetMaterialByName("flippersSG");
	if (Config::S_reflections >= 2)
	{
		mat->SetMinReflection(0.7f);
		mat->SetMaxReflection(1.5f);
	}
	else
	{
		mat->SetMinReflection(0.0f);
		mat->SetMaxReflection(0.0f);
	}
}
void Paddle::StepTick(float a_DT)
{
	switch (m_Status)
	{
	case IDLE: 
		m_Light[0]->Active(0);
		m_Light[1]->Active(0);
		break;

	case LEFT: 
		m_Light[0]->Active(1);
		m_Light[1]->Active(0);
		m_Rot += a_DT*30.0f; 
		if (m_Rot > 17) m_Rot = 17.0f;
		break;

	case RIGHT: 
		m_Light[0]->Active(0);
		m_Light[1]->Active(1);
		m_Rot -= a_DT*30.0f; 
		if (m_Rot < -12) m_Rot = -12.0f;
		break;
	}

	// offset
	vector3 offset = vector3(1.0f, 0, 0);
	matrix m2;
	m2.RotateY(-3.5f);
	offset = m2.Transform(offset);

	// model pos
	matrix m=m_Origin;
	m.Translate(offset * m_Rot);
	m_Node->SetTransform(m);

	// light pos
	vector3 p1 = m_Origin.GetTranslation() + offset * (m_Rot+4) + vector3(0,3,0); m_Light[0]->SetPos(p1);
	vector3 p2 = m_Origin.GetTranslation() + offset * (m_Rot-4) + vector3(0,3,0); m_Light[1]->SetPos(p2);
	vector3 p3 = m_Origin.GetTranslation() + offset * m_Rot + vector3(0,5,0); m_Light[2]->SetPos(p3);
}

void Paddle::Tick(float a_DT)
{
	m_Node->Transform();
}
void Paddle::Reset()
{
	m_Status = IDLE;
	m_Rot = 0.0f;
}


// Cannon
void CannonBase::Init(char* a_Model, matrix a_Transform, float a_Scale)
{
	// Init
	m_Owner = NULL;
	m_Origin = a_Transform;
	m_Pos = a_Transform.GetTranslation();

	// load model
	m_Node = new Node(a_Model, m_Pos, a_Scale);
	m_Node->SetType(Node::REFITTABLE);
	m_Node->SetTransform(a_Transform);
	SceneGraph::AddNode(m_Node);

	// Material List
	BuildMatList();
}

void CannonBase::UpdateQuality()
{
	Material* mat;
	mat = GetMaterialByName("reflectiveStandaard_shader");
	if (mat)
	{
		if (Config::S_reflections >= 4)
		{
			mat->SetMinReflection(0.2f);
			mat->SetMaxReflection(1.5f);
		}
		else
		{
			mat->SetMinReflection(0.0f);
			mat->SetMaxReflection(0.0f);
		}
	}
	mat = GetMaterialByName("reflective_shader");
	if (mat)
	{
		if (Config::S_reflections >= 4)
		{
			mat->SetMinReflection(0.2f);
			mat->SetMaxReflection(1.5f);
		}
		else
		{
			mat->SetMinReflection(0.0f);
			mat->SetMaxReflection(0.0f);
		}
	}
}

void CannonBase::Tick(float a_DT)
{
	matrix m=m_Origin;
	matrix m2;
	m2.RotateY(m_Owner->GetResetRot() + m_Owner->GetRotY());
	m.Concatenate(m2);
	m_Node->SetTransform(m);
	m_Node->Transform();

	m_RotLast = m_Rot;
	m_Rot = m_Owner->GetRotY();
	m_RotatedLast = m_Rotated;
	m_Rotated = ( m_RotLast != m_Rot );

	if( m_Rotated ) SoundManager::Play( "Sound/Ingame/cannonrotate.ogg", CHANNEL_CANNONROT ); else SoundManager::Stop( CHANNEL_CANNONROT );
	if( m_RotatedLast && (!m_Rotated) ) SoundManager::Play( "Sound/Ingame/cannonrotate_end.ogg" );
}

void CannonLoop::Init(char* a_Model, matrix a_Transform, float a_Scale)
{
	// Init
	m_Owner = NULL;
	m_Origin = a_Transform;
	m_Pos = a_Transform.GetTranslation();

	// load model
	m_Node = new Node(a_Model, m_Pos, a_Scale);
	m_Node->SetType(Node::REFITTABLE);
	m_Node->SetTransform(a_Transform);
	SceneGraph::AddNode(m_Node);

	// add light
	for (int i=0; i<6; ++i)
	{
		m_Lights[i] = MManager::NewLight();
		Color diff(0.3f,0.7f,0.3f);
		Color spec(0.2f,0.3f,0.2f);
		m_Lights[i]->Init(0,"Cannon",m_Pos,diff,spec,5);
		Scene::AddLight(m_Lights[i]);
	}

	// Material List
	BuildMatList();
}

void CannonLoop::UpdateQuality()
{
	Material* mat;
	mat = GetMaterialByName("lighttubes_shader");
	if (mat)
	{
		mat->SetRefraction(0.9f);
		mat->SetRefrIndex(1.2f);
		if (Config::S_reflections >= 3)
		{
			mat->SetMinReflection(0.2f);
			mat->SetMaxReflection(1.5f);
		}
		else
		{
			mat->SetMinReflection(0.0f);
			mat->SetMaxReflection(0.0f);
		}
	}
	mat = GetMaterialByName("initialShadingGroup");
	mat->SetRefraction(0.8f);
	mat->SetRefrIndex(1.0f);
}

void CannonLoop::Hit(float a_DT)
{
	for (int i=0; i<MAXBALLCOUNT; ++i)
	{
		if (m_HitBall[i] && m_HitMaterial[i] == GetMaterialByName("hitMaterialSG"))
		{
			if (m_Owner->GetStatus() == Cannon::IDLE)
			{
				m_Owner->SetStatus(Cannon::UP);
				World::IncScore(1112);
			}
			else if (m_Owner->GetFire())
			{
				m_HitBall[i]->AddVelocity(-m_HitNormal[i]*1000);
			}
		}
	}
}

void CannonLoop::StepTick(float a_DT)
{
	switch (m_Owner->GetStatus())
	{
	case Cannon::IDLE: 
		m_Owner->SetLaunchTimer();
		m_Owner->SetFire(false);
		if (m_Owner->GetRotY() > 50.0f*a_DT) m_Owner->RotateY(-50.0f*a_DT); else m_Owner->RotateY(-m_Owner->GetRotY());
		break;
	case Cannon::UP: 
		if ( GameCam::GetCamMode() == GameCam::CAM_GAME && BallManager::GetActiveBallCount() <= 1 ) GameCam::SetCamMode( GameCam::CAM_CANNON );
		m_Owner->RotateX(20.0f*a_DT); 
		if (m_Owner->GetRotY() > -90)
		{
			m_Owner->SetLaunchTimer();
			m_Owner->RotateY(-30.0f*a_DT);
		}
		else
			m_Owner->Rotate(30.0f*a_DT);
		if (m_Owner->GetRotX() > 30.0f)
		if (!m_Owner->UpdateLaunchTimer(a_DT))
		{
			m_Owner->SetFire(true);
			m_Owner->SetStatus(Cannon::DOWN);
			SoundManager::Play( "Sound/Ingame/cannonshot.ogg" );
		}
		break;
	case Cannon::DOWN: 
		if( GameCam::GetCamMode() == GameCam::CAM_CANNON ) GameCam::SetCamMode( GameCam::CAM_GAME );
		m_Owner->ClampY();
		m_Owner->RotateX(15.0f*-a_DT);
		break;
	}
	matrix m=m_Origin;
	matrix m2, m3;
	m3.RotateX(m_Owner->GetRotX());
	m2.RotateY(m_Owner->GetResetRot() + m_Owner->GetRotY());
	m.Concatenate(m2);
	m.Concatenate(m3);
	m_Node->SetTransform(m);

	// lights
	vector3 l[6];
	l[0] = vector3(5,5,2);
	l[1] = vector3(5,5,-1.5f);
	l[2] = vector3(5,5,-5);
	l[3] = vector3(-5,5,2);
	l[4] = vector3(-5,5,-1.5f);
	l[5] = vector3(-5,5,-5);
	for (int i=0; i<6; ++i)
	{
		l[i] = m.Transform(l[i]);
		m_Lights[i]->SetPos(l[i]);	
		m_Lights[i]->SetRadius(15.0f+Rand(7.0f));
	}
}

void CannonLoop::Tick(float a_DT)
{
	m_Node->Transform();
}
void Cannon::Init(matrix a_Transform, float a_Scale)
{
	m_Base = new CannonBase();
	m_Base->Init("meshes/cannonStandard.obj",a_Transform,a_Scale);
	m_Base->SetOwner(this);

	m_Loop = new CannonLoop();
	m_Loop->Init("meshes/cannon.obj",a_Transform,a_Scale);
	m_Loop->SetOwner(this);

	Reset();
}

void Cannon::Reset()
{
	m_RotX = 1;
	m_RotY = 0;
	m_Fire = false;
	m_Status = IDLE;
}

void Cannon::Rotate( float a_Dist )
{
	m_RotY += m_Rot*a_Dist; 
	if (m_RotY < -150) m_RotY = -150; 
	if (m_RotY > -90) m_RotY = -90;
}

void Cannon::RotateX(float a_Degrees)
{
	m_RotX += a_Degrees; 
	if (m_RotX < 1)
	{
		m_RotX = 1; 
		m_Status = IDLE;
	} 
	if (m_RotX > 31.0f)
	{
		m_RotX = 31.0f;
	}
}

void Cannon::AddRotate( int a_Rot )
{
	m_Rot += a_Rot;
}


// BreakoutGrid
void BreakoutBrick::Init(char* a_Model, matrix a_Transform, float a_Scale)
{
	// Init
	m_Owner = NULL;
	m_Origin = a_Transform;
	m_Pos = a_Transform.GetTranslation();

	// load model
	m_Node = new Node(a_Model, m_Pos, a_Scale);
	m_Node->SetTransform(a_Transform);
	SceneGraph::AddNode(m_Node);

	// Material List
	BuildMatList();
	m_Node->Transform();
}
void BreakoutBrick::UpdateQuality()
{
	Material* mat = GetMaterialByName("teslaCoil");
	if (Config::S_reflections >= 4)
	{
		mat->SetMinReflection(0.5f);
		mat->SetMaxReflection(1.5f);
	}
	else
	{
		mat->SetMinReflection(0.0f);
		mat->SetMaxReflection(0.0f);
	}
}
void BreakoutBrick::Tick(float a_DT)
{
	if (m_Owner) m_Owner->Update();
}
void BreakoutBrick::Hit(float a_DT)
{
	m_Node->Disable();
	World::IncScore(3117);
	SoundManager::Play( "Sound/Ingame/screwdown.wav", CHANNEL_EVENT_1 + rand() % 3 );
}
void BreakoutBrick::Reset()
{ 
	m_Node->Enable(); 
}
bool BreakoutBrick::GetActive()
{ 
	return m_Node->IsActive(); 
}
void BreakoutGrid::Init(char* a_Model, matrix a_Transform, float a_Scale)
{
	// init variables
	m_CountDown = 0.0f;
	m_Pos = a_Transform.GetTranslation();
	m_NextTarget = 0;
	m_Active = false;
	m_Origin = a_Transform;

	// load models in a Pattern
	const float Pattern[110] = {
		0,0,0,0,0,0,0,0,0,0,0,
		0,0,0,0,0,0,0,0,0,0,0,
		0,0,1,0,0,0,0,0,1,0,0,
		1,0,0,1,0,0,0,1,0,0,1,
		1,0,1,1,1,1,1,1,1,0,1,
		1,1,1,0,1,1,1,0,1,1,1,
		0,1,1,1,1,1,1,1,1,1,0,
		0,0,1,1,1,1,1,1,1,0,0,
		0,0,1,0,0,0,0,0,1,0,0,
		0,1,0,0,0,0,0,0,0,1,0,
	};
	for (int y=0; y<10; ++y)
	for (int x=0; x<11; ++x)
	{
		int idx = y*11+x;
		if (Pattern[idx] > 0)
		{
			matrix m = m_Origin;
			m.Translate(vector3(x*3.0f, 3.5f, y*3.0f));
			m_Targets[m_NextTarget] = new BreakoutBrick();
			m_Targets[m_NextTarget]->Init(a_Model,m,1.0f);
			m_Targets[m_NextTarget]->SetOwner(this);
			m_NextTarget++;
		}
	}
}

void BreakoutGrid::Reset()
{
	m_MultiActive = false;
	m_MultiCountDown = 0.0f;
	m_Active = true;
	for (int i=0; i<m_NextTarget; ++i) m_Targets[i]->Reset();
}
void BreakoutGrid::Update()
{
	bool active = false;
	for (int i=0; i<m_NextTarget; ++i)
	{
		if (m_Targets[i]->GetActive())
		{
			active = true; 
			break;
		}
	}
	if (!active && m_Active)
	{
		ScoreMultiplier::IncMultiplier(2);
		m_MultiCountDown = 120.0f;
		m_MultiActive = true;

		World::IncScore(9818); 

		m_CountDown = 5.0f;
		m_Active = false;
	}
}
void BreakoutGrid::Tick(float a_DT)
{
	if (m_CountDown > 0.0f) m_CountDown -= a_DT;
	if (m_CountDown <= 0.0f && !m_Active)
	{
		m_Active = true;
		for (int i=0; i<m_NextTarget; ++i) m_Targets[i]->Reset();
	}
	if (m_MultiCountDown > 0.0f) m_MultiCountDown -= a_DT;
	if (m_MultiCountDown <= 0.0f && m_MultiActive)
	{
		ScoreMultiplier::IncMultiplier(-2); 
		m_MultiActive = false;
	}
}
// Life
void Life::Init(char* a_Model, matrix a_Transform, float a_Scale)
{
	// Init
	m_Origin = a_Transform;
	m_Pos = a_Transform.GetTranslation();

	// load model
	m_Node = new Node(a_Model, m_Pos, a_Scale);
	m_Node->SetTransform(a_Transform);
	SceneGraph::AddNode(m_Node);

	// Light
	m_Light = MManager::NewLight();
	Color diff(0.3f,0.7f,0.3f);
	Color spec(0.2f,0.3f,0.2f);
	m_Light->Init(0,"Life",m_Pos,diff,spec,5);
	Scene::AddLight(m_Light);

	// Material List
	BuildMatList();
	m_Node->Transform();
}
void Life::UpdateQuality()
{
	Material* mat;
	mat = GetMaterialByName("glass");
	if (mat)
	{
		mat->SetRefraction(0.7f);
		mat->SetRefrIndex(1.2f);
		if (Config::S_reflections >= 3)
		{
			mat->SetMinReflection(0.2f);
			mat->SetMaxReflection(1.5f);
		}
		else
		{
			mat->SetMinReflection(0.0f);
			mat->SetMaxReflection(0.0f);
		}
	}
	mat = GetMaterialByName("goo");
	mat->SetRefraction(0.8f);
	mat->SetRefrIndex(1.0f);
}
void Life::Tick(float a_DT)
{
	vector3 l = vector3(0,1,0);
	l = m_Origin.Transform(l);
	m_Light->SetPos(l);	
	m_Light->SetRadius(20.0f+Rand(2.0f));
}
void Life::SetActive(bool a_Active)
{
	m_Light->Active(a_Active);
}