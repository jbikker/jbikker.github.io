// --------------------------------------------------------------------------
// Copyright (c) Mark Peters and Bram van de Wetering 2009
// --------------------------------------------------------------------------

#ifndef I_POSTGAME_H
#define I_POSTGAME_H

namespace Raytracer {

// Main Menu Fases
enum
{
	PG_NULL			= 0,
	PG_GAMEOUT		= (1 << 1),
	PG_POSTIN		= (1 << 2),
	PG_NOSCORE		= (1 << 3),
	PG_HIGHSCORE	= (1 << 4),
	PG_TOMAIN		= (1 << 5)
};

class Surface;
class PostGame
{
public:
	static void Init();
	static void Enter(unsigned int a_EndScore, Surface* a_BG );
	static void Exit();

	static int EvaluateScore();

	static void Tick( float a_DT );
	static void Draw( Surface* a_Target, Surface* a_Cursor );
	static inline bool IsDone(){ return m_Done; }

private:
	static inline void SetFase( int a_Fase );
	static inline bool InFase(int a_Fase ){ return m_Fase == a_Fase; }

	static int m_Fase, m_Idx;
	static Surface* m_NoScore, *m_HighBG;
	static Surface* m_ScoreButton, *m_EnterName;
	static Surface* m_BG;
	static unsigned int m_FinalScore;
	static float m_Fade, m_Timer, m_ScrollX, m_ScrollY;
	static bool m_Done;
	static char m_NewScore[12];
	static int m_CursorPos;
	static float m_BoxFluc;
};

} // namespace Raytracer

#endif
