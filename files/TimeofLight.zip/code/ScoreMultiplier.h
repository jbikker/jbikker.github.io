// --------------------------------------------------------------------------
// Copyright (c) Mark Peters and Bram van de Wetering 2009
// --------------------------------------------------------------------------

#ifndef I_SCORE_MULTIPLIER_H
#define I_SCORE_MULTIPLIER_H

#include "common.h"
#include "common_math.h"
#include "Entities.h"
#include "LightObjects.h"

namespace Raytracer {

class ScoreMultiplier
{
public:
	static void Init();
	static void Update(float a_DT);
	static int GetMultiplier(){return m_Multiplier;}
	static void IncMultiplier(int a_Amount){m_Multiplier += a_Amount;}
	static void SetMultiplier(int a_Multiplier){m_Multiplier = a_Multiplier;}
private:
	static int m_Multiplier;
	static float m_Timer;
	static Light* m_Light[MULTIPLIERS];
//	static LightRotater* m_LightRotater;
};


}; // namespace Raytracer
#endif

