// --------------------------------------------------------------------------
// Copyright (c) Mark Peters and Bram van de Wetering 2009
// --------------------------------------------------------------------------

#ifndef I_GAME_OBJECTS_H
#define I_GAME_OBJECTS_H

#include "common.h"
#include "common_math.h"
#include "Entities.h"

namespace Raytracer {

class Board : public Entity
{
public:
	void Init(char* a_Model, matrix a_Transform, float a_Scale);
	void Reset(){}
	void UpdateQuality();
	void Hit(float a_DT);

	Entity::eType GetType(){return Entity::BOARD;}
private:
	matrix m_Origin;
	int m_LightCount;
	Light* m_Lights[16];
};
class ShinyPatch : public Entity
{
public:
	void Init(char* a_Model, matrix a_Transform, float a_Scale);
	void Reset(){}
	void UpdateQuality();
	void Hit(float a_DT);

	Entity::eType GetType(){return Entity::BOARD;}
private:
	matrix m_Origin;
};
class Dial : public Entity
{
public:
	void Init(char* a_Model, matrix a_Transform, float a_Scale);
	void Reset(){m_Rot = 130.0f;}
	void UpdateQuality();
	void Hit(float a_DT);
	void StepTick(float a_DT);
	void Tick(float a_DT);

	Entity::eType GetType(){return Entity::ROTATOR;}
private:
	matrix m_Origin;
	float m_Rot;
};

class Rotater : public Entity
{
public:
	void Init(char* a_Model, matrix a_Transform, float a_Scale);
	void Reset(){m_Rot = Rand(360.0f);}
	void UpdateQuality();
	void Hit(float a_DT);
	void StepTick(float a_DT);
	void Tick(float a_DT);

	void SetScore(float a_Score){m_Score = a_Score;}
	void SetRotateSpeedOnHit(float a_Speed){m_RotSpeedMax = a_Speed;}
	void SetRotateSpeed(float a_Speed){m_RotSpeed = a_Speed;}

	Entity::eType GetType(){return Entity::ROTATOR;}
private:
	matrix m_Origin;
	float m_Rot;
	float m_RotSpeed;
	float m_RotSpeedMax;
	float m_RotSpeedBooster;
	float m_Score;
};

class MusicBox : public Entity
{
public:
	void Init(char* a_Model, matrix a_Transform, float a_Scale);
	void Reset(){}
	void UpdateQuality();
	void Hit(float a_DT);
	void Tick(float a_DT);

	Entity::eType GetType(){return Entity::MUSICBOX;}
private:
	matrix m_Origin;
	Light* m_Lights[7];
};
class Flipper : public Entity
{
public:
	enum Status { IDLE, UP, DOWN };

	void Init(char* a_Model, matrix a_Transform, float a_Scale);
	void UpdateQuality();
	void StepTick(float a_DT);
	void Tick(float a_DT);
	void PostRender();

	bool Flip(bool a_Flipping);
	void Reset();

	void SetRotateDir(bool a_RotateDir){m_RotateDir = a_RotateDir;}

	bool Flipping(){return m_Flipping;}
	float GetRot(){return m_CurRot;}
	float GetSpeed();

	Entity::eType GetType(){return Entity::FLIPPER;}

private:
	matrix m_Origin;
	Light* m_Light;

	bool m_RotateDir;
	float m_CurRot;
	Status m_Status;
	bool m_Flipping;
};
class Mushroom : public Entity
{
public:
	void Init(char* a_Model, matrix a_Transform, float a_Scale);
	void UpdateQuality();
	void Tick(float a_DT);
	void Hit(float a_DT);
	void Reset(){m_HitTimer = 0.0f;}

	void SetColorStart(vector3 a_Color){m_ColorStart = a_Color;}
	void SetColorEnd(vector3 a_Color){m_ColorEnd = a_Color;}
	void SetBounceForce(float a_Force){m_BounceForce = a_Force;}

	Entity::eType GetType(){return Entity::MUSHROOM;}

private:
	Light* m_Light;
	Material* m_LightMat;
	matrix m_Origin;
	float m_HitTimer;

	float m_Rotate;
	float m_BounceForce;
	vector3 m_ColorStart;
	vector3 m_ColorEnd;
};

class ChargeCylinder : public Entity
{
public:
	void Init(char* a_Model, matrix a_Transform, float a_Scale);
	void UpdateQuality();
	void Tick(float a_DT);
	void Hit(float a_DT);
	void Reset();

	float GetCharge(){return m_Charge;}
	void AddCharge(float a_Amount){ m_Charge += a_Amount; }
	bool HasCharge(){return m_Charge > 0.0f; }

	Entity::eType GetType(){return Entity::BOARD;}

private:
	matrix m_Origin;
	Light* m_Light[5];
	float m_Charge;
	bool m_Opened;
	float m_CountDown;
};

class Bumper : public Entity
{
public:
	void Init(char* a_Model, matrix a_Transform, float a_Scale);
	void UpdateQuality();
	void Tick(float a_DT);
	void Hit(float a_DT);
	void Reset(){m_HitTimer = 0.0f;}
	void SetColorStart(vector3 a_Color){m_ColorStart = a_Color;}
	void SetColorEnd(vector3 a_Color){m_ColorEnd = a_Color;}
	void SetBounceForce(float a_Force){m_BounceForce = a_Force;}

	Entity::eType GetType(){return Entity::BUMPER;}

private:
	Material* m_LightMat;
	matrix m_Origin;
	float m_HitTimer;
	float m_BounceForce;
	vector3 m_ColorStart;
	vector3 m_ColorEnd;
	Light* m_Light;
	Light* m_AmbientLight;
};
class HitTargetBucket;
class HitTarget : public Entity
{
public:
	void Init(char* a_Model, matrix a_Transform, float a_Scale);
	void SetOwner(HitTargetBucket* a_Owner);
	void UpdateQuality();
	void Tick(float a_DT);
	void Hit(float a_DT);
	void Reset(){m_Active = false;}
	void SetColorStart(vector3 a_Color){m_ColorStart = a_Color;}
	void SetColorEnd(vector3 a_Color){m_ColorEnd = a_Color;}
	bool GetActive(){return m_Active;}

	Entity::eType GetType(){return Entity::HITTARGET;}

private:
	HitTargetBucket* m_Owner;
	Material* m_LightMat;
	matrix m_Origin;
	bool m_Active;
	vector3 m_ColorStart;
	vector3 m_ColorEnd;
};

class HitTargetBucket : public Entity
{
public:
	virtual void Init(char* a_Model, matrix a_Transform, float a_Scale);
	virtual void Reset(){m_Active = false;}
	virtual void Update();
	virtual void Tick(float a_DT);
	void AddTarget(HitTarget* a_Target){m_Targets[m_NextTarget++] = a_Target;}
protected:
	HitTarget* m_Targets[16];
	int m_NextTarget;
	bool m_Active;
	float m_CountDown;
};

class ScoreMeter
{
public:
	void Init(char* a_Model, float a_Scale);
	void Tick(float a_DT);
private:
	Node* m_Node[SCORECYLINDERS];
	float m_Rot[SCORECYLINDERS];
	Light* m_Light[SCORECYLINDERS];
	vector3 m_Cpos[SCORECYLINDERS];
	vector3 m_Lpos[SCORECYLINDERS];
	float lightstr;
};
class Paddle : public Entity
{
public:
	enum Status { IDLE, LEFT, RIGHT };

	void Init(char* a_Model, matrix a_Transform, float a_Scale);
	void UpdateQuality();
	void StepTick(float a_DT);
	void Tick(float a_DT);

	void SetStatus(Status a_Status){m_Status = a_Status;}
	void Reset();

	Entity::eType GetType(){return Entity::PADDLE;}

private:
	matrix m_Origin;
	Light* m_Light[3];
	Status m_Status;
	float m_Rot;
};
// Cannon
class CannonBase;
class CannonLoop;
class Cannon
{
public:
	enum Status { IDLE, UP, DOWN };

	void Init(matrix a_Transform, float a_Scale);
	void Reset();

	float GetResetRot(){return m_ResetRot;}
	void SetResetRot(float a_Rot){m_ResetRot = a_Rot;}

	void SetStatus(Status a_Status){m_Status = a_Status;}
	Status GetStatus(){return m_Status;}

	void SetLaunchTimer(){m_LaunchTimer = 5.0f;}
	bool UpdateLaunchTimer(float a_Time){ m_LaunchTimer -= a_Time; return m_LaunchTimer > 0.0f;}
	void SetFire(bool a_Fire){m_Fire = a_Fire;}
	bool GetFire(){return m_Fire;}
	void SetRotate(int a_Rot){m_Rot = a_Rot; }
	void AddRotate(int a_Rot);
	void RotateX(float a_Degrees);
	void Rotate(float a_Dist);
	void RotateY(float a_Degrees){m_RotY += a_Degrees;}
	void ClampY(){ if (m_RotY > 360) m_RotY -= 360; if (m_RotY < 0) m_RotY += 360; }
	float GetRotX(){return m_RotX; }
	float GetRotY(){return m_RotY; }
	Entity::eType GetType(){return Entity::CANNON;}
private:
	matrix m_Origin;
	CannonBase* m_Base;
	CannonLoop* m_Loop;
	float m_RotX;
	float m_RotY;
	float m_ResetRot;
	int m_Rot;
	bool m_Fire;
	float m_LaunchTimer;
	Status m_Status;
};

class CannonBase : public Entity
{
public:
	void Init(char* a_Model, matrix a_Transform, float a_Scale);
	void Reset(){m_Owner->Reset();}
	void UpdateQuality();
	void Tick(float a_DT);

	void SetOwner(Cannon* a_Owner){m_Owner = a_Owner;}
	Entity::eType GetType(){return Entity::CANNON;}
private:
	matrix m_Origin;
	Cannon* m_Owner;
	float m_Rot, m_RotLast;
	bool m_Rotated, m_RotatedLast;
};
class CannonLoop : public Entity
{
public:
	void Init(char* a_Model, matrix a_Transform, float a_Scale);
	void UpdateQuality();
	void StepTick(float a_DT);
	void Tick(float a_DT);
	void Hit(float a_DT);

	void SetOwner(Cannon* a_Owner){m_Owner = a_Owner;}
	Entity::eType GetType(){return Entity::CANNON;}
private:
	matrix m_Origin;
	Cannon* m_Owner;
	Light* m_Lights[6];
};

// Breakout Grid
class BreakoutGrid;
class BreakoutBrick : public Entity
{
public:
	void Init(char* a_Model, matrix a_Transform, float a_Scale);
	void SetOwner(BreakoutGrid* a_Owner){m_Owner = a_Owner; }
	void UpdateQuality();
	void Tick(float a_DT);
	void Hit(float a_DT);
	void Reset();
	bool GetActive();

	Entity::eType GetType(){return Entity::BREAKOUT;}

private:
	BreakoutGrid* m_Owner;
	Material* m_LightMat;
	matrix m_Origin;
};
class BreakoutGrid : public Entity
{
public:
	void Init(char* a_Model, matrix a_Transform, float a_Scale);
	void Reset();
	void Update();
	void Tick(float a_DT);
protected:
	BreakoutBrick* m_Targets[64];
	int m_NextTarget;
	float m_CountDown;
	float m_MultiCountDown;
	bool m_Active;
	bool m_MultiActive;
	matrix m_Origin;
};

class Life : public Entity
{
public:
	void Init(char* a_Model, matrix a_Transform, float a_Scale);
	void Reset(){}
	void UpdateQuality();
	void Hit(float a_DT){}
	void Tick(float a_DT);

	void SetActive(bool a_Active);

	Entity::eType GetType(){return Entity::BOARD;}
private:
	matrix m_Origin;
	Light* m_Light;
};

}; // namespace Raytracer
#endif

