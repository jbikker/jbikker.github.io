// --------------------------------------------------------------------------
// Copyright (c) Mark Peters and Bram van der Wetering 2009
// --------------------------------------------------------------------------

#include "MainMenu.h"
#include "Config.h"
#include "Surface.h"
#include "Drawing2D.h"
#include "MenuItems.h"
#include "Core.h"
#include "SoundManager.h"
#include "Entities.h"
#include "World.h"

namespace Raytracer {

// Option Settings
const int resW[] = { 640, 800, 1024, 1280 };
const int resH[] = { 480, 600, 768, 960 }; 
struct
{
	int LightQ, Refl, AA, Res;
	int Svol, Mvol;
	bool Fullscr, FixRatio;
} opts;

// --------------------------------------------------------------------------
// Main Menu Buttons
// --------------------------------------------------------------------------

Surface* buttonImg, *buttonBack, *buttonBackSealed;
Surface* buttonNewGame, *buttonOptions, *buttonHighScores, *buttonQuitGame, *buttonApply;

Font* Font_HighScores;

Button* Button_NewGame;
Button* Button_Options;
Button* Button_Hiscore;
Button* Button_QuitGme;

Button* Button_Back;
Button* Button_Apply;

Slider* Slider_LOD;
Slider* Slider_LIT;
Slider* Slider_AAS;

SlidingItem* ScoreSliders[10];

CheckBox* CheckBox_Fullscr;
CheckBox* CheckBox_FixRatio;

SelectList* List_RES;

SliderBar* SliderBar_SoundVol;
SliderBar* SliderBar_MusicVol;

// --------------------------------------------------------------------------
// Main Functions
// --------------------------------------------------------------------------

// MainMenu Member Data
Surface* MainMenu::m_BG = 0;
Surface* MainMenu::m_Title = 0;
Surface* MainMenu::m_LoadingScr = 0;
Surface* MainMenu::m_Splash1 = 0;
Surface* MainMenu::m_Splash2 = 0;
int MainMenu::m_Fase = MM_NULL, MainMenu::m_Splash = 0;
float MainMenu::m_BGx = 0, MainMenu::m_BGy = 0, MainMenu::m_Rot = 0;
float MainMenu::m_Fade = 0.0f, MainMenu::m_LineAlpha = 0;
float MainMenu::m_WinW = 0, MainMenu::m_WinH = 0;
float MainMenu::m_TarW = 0, MainMenu::m_TarH = 0;
float MainMenu::m_Timer = 0.0f;
bool MainMenu::m_NewGame = false;
bool MainMenu::m_LoadingDone = false;
bool MainMenu::m_SplashDone = false;

void MMSetPositions()
{
	const float centerX = float(Config::S_scrWidth>>1);
	const float centerY = float(Config::S_scrHeight>>1);

	Button_NewGame->setPos(centerX, centerY-64);
	Button_Options->setPos(centerX, centerY-32);
	Button_Hiscore->setPos(centerX, centerY);
	Button_QuitGme->setPos(centerX, centerY+32);

	Button_Back->setPos(centerX, 0);
	Button_Apply->setPos(centerX, centerY+80);

	SliderBar_SoundVol->setPos(centerX-16, centerY+24);
	SliderBar_MusicVol->setPos(centerX-16, centerY+40);

	Slider_LOD->setPos( centerX, centerY-112 );
	Slider_LIT->setPos( centerX, centerY-96 );
	Slider_AAS->setPos( centerX, centerY-80 );
	List_RES->setPos( centerX, centerY-48 );

	CheckBox_Fullscr->setPos(centerX-160, centerY-48);
	CheckBox_FixRatio->setPos(centerX-160, centerY-32);

	for(int i=0; i<10; i++)
	ScoreSliders[i]->setPos(centerX-(416.0f*0.5f)+32.0f, centerY-(272.0f*0.5f)+float(i*24)+16.0f);
}

void MMResetPositions()
{
	Button_NewGame->jumpToStart(); Button_Options->jumpToStart();
	Button_Hiscore->jumpToStart(); Button_QuitGme->jumpToStart();

	Button_Back->jumpToStart();	Button_Apply->jumpToStart();

	SliderBar_SoundVol->jumpToStart();
	SliderBar_MusicVol->jumpToStart();

	Slider_LOD->jumpToStart();
	Slider_LIT->jumpToStart();
	Slider_AAS->jumpToStart();
	List_RES->jumpToStart();

	CheckBox_Fullscr->jumpToStart();
	CheckBox_FixRatio->jumpToStart();

	for(int i=0; i<10; i++) ScoreSliders[i]->jumpToStart();
}

void MainMenu::Init()
{
	// Load option settings
	LoadSettings();

	// Load high scores
	Config::F_LoadScores();

	// Load images
	m_Title = new Surface("images/Menu Images/MainMenu_Title.tga");
	m_BG = new Surface("images/Menu Images/MainMenu_BG.tga");
	m_LoadingScr = new Surface("images/Menu Images/loadingscreen.tga");
	
	buttonBack = new Surface("images/Menu Images/Button_Back.tga");
	buttonBackSealed = new Surface("images/Menu Images/Button_Back_Sealed.tga");
	Font_HighScores = new Font("images/Menu Images/Font_HighScores.tga","abcdefghijklmnopqrstuvwxyz0123456789");

	buttonNewGame = new Surface("images/Menu Images/Button_NewGame.tga");
	buttonOptions = new Surface("images/Menu Images/Button_Options.tga");
	buttonHighScores = new Surface("images/Menu Images/Button_HighScores.tga");
	buttonQuitGame = new Surface("images/Menu Images/Button_QuitGame.tga");
	buttonApply  = new Surface("images/Menu Images/Button_Apply.tga");

	// Initialize the tilesets
	InitTiles();

	// Create buttons, sliders and misc
	Button_NewGame = new Button(buttonNewGame,32);
	Button_Options = new Button(buttonOptions,32);
	Button_Hiscore = new Button(buttonHighScores,32);
	Button_QuitGme = new Button(buttonQuitGame,32);

	Button_Back = new Button(buttonBack,24);
	Button_Apply = new Button(buttonApply,32);

	Slider_LOD = new Slider(128, 5, opts.LightQ, "Lighting Quality");
	Slider_LIT = new Slider(128, 5, opts.Refl, "Material Quality");
	Slider_AAS = new Slider(128, 9, opts.AA, "Anti Aliasing");
	Slider_LOD->SetState(0,"Min"); Slider_LOD->SetState(-1,"Max");

	List_RES = new SelectList(144, 4, opts.Res, "Select Resolution");

	CheckBox_Fullscr = new CheckBox(opts.Fullscr, "Full Screen");
	CheckBox_FixRatio = new CheckBox(opts.FixRatio, "Fix Window Ratio");

	SliderBar_SoundVol = new SliderBar( 96, opts.Svol, "Sound Volume" );
	SliderBar_MusicVol = new SliderBar( 96, opts.Mvol, "Music Volume" );

	List_RES->SetState(0, " 640 x 480");
	List_RES->SetState(1, " 800 x 600");
	List_RES->SetState(2, "1024 x 768");
	List_RES->SetState(3, "1280 x 960");

	for(int i=0; i<10; i++) ScoreSliders[i] = new SlidingItem();

	MMSetPositions();
}

void MainMenu::Resize()
{
	MMSetPositions();

	// insta-jump to correct positions
	Slider_LOD->jumpToTarget();	Slider_LIT->jumpToTarget();
	Slider_AAS->jumpToTarget();	Slider_LOD->jumpToTarget();
	SliderBar_SoundVol->jumpToTarget();	SliderBar_MusicVol->jumpToTarget();
	CheckBox_Fullscr->jumpToTarget(); 
	CheckBox_FixRatio->jumpToTarget(); 
	List_RES->jumpToTarget();
	Button_Apply->jumpToTarget();

	// hide main buttons
	Button_NewGame->jumpToStart();
	Button_Options->jumpToStart();
	Button_Hiscore->jumpToStart();
	Button_QuitGme->jumpToStart();

	for(int i=0; i<10; i++) ScoreSliders[i]->jumpToStart();
}

void MainMenu::Enter()
{
	if (Config::newHighscore) 
	{ 
		SetFase(MM_HIGH); 
		Config::newHighscore = false; 
	}
	else
	{
		SetFase(MM_MAIN);
	}
	m_NewGame = m_LoadingDone = false;
	m_Fade = 0.0f;
	m_WinW = 0;
	m_WinH = 0;
	MMResetPositions();
}

void MainMenu::SplashEnter()
{
	m_Fade = 0.0f;
	m_WinW = 0;
	m_WinH = 0;
	m_Splash = 0;

	m_Splash1 = new Surface("images/Menu Images/splash_arauna.tga");
	m_Splash2 = new Surface("images/Menu Images/splash_dotstudios.tga");
}

void MainMenu::SetFase( int a_Fase )
{
	m_Fase = a_Fase;
	const bool inOpts = InFase(MM_OPTS), inMain = InFase(MM_MAIN), inHigh = InFase(MM_HIGH);

	Button_NewGame->setActive(inMain),	Button_Options->setActive(inMain);
	Button_Hiscore->setActive(inMain),	Button_QuitGme->setActive(inMain);

	Slider_LOD->setActive(inOpts); Slider_LIT->setActive(inOpts);
	Slider_AAS->setActive(inOpts); List_RES->setActive(inOpts);

	CheckBox_Fullscr->setActive(inOpts);
	CheckBox_FixRatio->setActive(inOpts);

	SliderBar_SoundVol->setActive(inOpts);
	SliderBar_MusicVol->setActive(inOpts);

	Button_Apply->setActive(inOpts);

	for(int i=0; i<10; i++) ScoreSliders[i]->setActive(inHigh);

	if(inOpts) LoadSettings();
	if(InFase(MM_OPTS) || InFase(MM_HIGH))
	{
		Button_Back->setActive(true);
		m_TarW = 416.0f, m_TarH = 272.0f;
		if(InFase(MM_HIGH)) m_LineAlpha = 0;
	}
	else
	{
		Button_Back->setActive(false);
		if(InFase(MM_GAME) || InFase(MM_LOAD) || InFase(MM_LEND) )
		{
			m_TarW = 0.0f, m_TarH = 0.0f;
			m_Timer = 0.0f;
		}
		else
		{
			m_TarW = 192.0f, m_TarH = 192.0f;
		}
	}
}

void MainMenu::Exit()
{
	SetFase(MM_NULL);
}

void MainMenu::SplashExit()
{
	delete m_Splash1; m_Splash1 = NULL;
	delete m_Splash2; m_Splash2 = NULL;
}

void MainMenu::LoadSettings()
{
	opts.LightQ = Config::S_lightingQuality;
	opts.Refl = Config::S_reflections;
	opts.AA = Config::S_antiAliasing;
	for(int i=0; i<4; i++) if(Config::S_scrWidth == resW[i]) opts.Res = i;
	opts.Svol = Config::S_soundVol;
	opts.Mvol = Config::S_musicVol;
	opts.Fullscr = Config::S_fullscreen;
	opts.FixRatio = Config::S_fixRatio;
	Engine::m_AATreshold = 512-Config::S_antiAliasing*64;
	SoundManager::SetAllSoundVolume();
}

void MainMenu::SaveSettings()
{
	// Save To file
	Log::Message( "Saving option settings (config.txt)..." );
	FILE* f = fopen( "config.txt", "w" ); if(!f) return;
	fprintf(f, "scrwidth %i\n", resW[opts.Res] );
	fprintf(f, "scrheight %i\n", resH[opts.Res] );
	fprintf(f, "fullscreen %i\n", (opts.Fullscr)?1:0);
	fprintf(f, "fixratio %i\n", (opts.FixRatio)?1:0);

	fprintf(f, "lighting %i\n", opts.LightQ );
	fprintf(f, "reflections %i\n", opts.Refl );
	fprintf(f, "anti alias %i\n", opts.AA );

	fprintf(f, "sound vol %i\n", opts.Svol );
	fprintf(f, "music vol %i\n", opts.Mvol );
	fclose(f);

	// Recreate window changes
	if (opts.Fullscr != Config::S_fullscreen) Config::ReCreateWindow = true;
	if (resW[opts.Res] != Config::S_scrWidth || resH[opts.Res] != Config::S_scrHeight) Config::ReCreateWindow = true;
	if ((Config::WindowWidth != Config::S_scrWidth) || (Config::WindowHeight != Config::S_scrHeight)) Config::ReCreateWindow = true;

	// Save To Config
	Config::S_lightingQuality = opts.LightQ;
	Config::S_reflections = opts.Refl;
	Config::S_antiAliasing = opts.AA;
	Config::S_fixRatio = opts.FixRatio;

	Config::S_soundVol = opts.Svol;
	Config::S_musicVol = opts.Mvol;

	Config::S_fullscreen = opts.Fullscr;
	Config::S_fixRatio = opts.FixRatio;

	// Update
	SoundManager::SetAllSoundVolume();
	EntityManager::UpdateQuality();
	Engine::m_AATreshold = 512-Config::S_antiAliasing*64;
}

// --------------------------------------------------------------------------
// Main Loop
// --------------------------------------------------------------------------
	
void MainMenu::SplashTick( float a_DT )
{
	// Apply fade
	if( (m_Splash == 1) || (m_Splash == 3) )
	{
		if(m_Fade > 0.0f){ m_Fade -= a_DT * 64.0f; if(m_Fade < 0.0f) m_Fade = 0.0f; }
	}
	else
	{
		if(m_Fade < 256.0f){ m_Fade += a_DT * 64.0f; if(m_Fade > 256.0f) m_Fade = 256.0f; }
	}

	// Skip splashes
	if( Config::Key_Press[VK_RETURN] || Config::Key_Press[VK_SPACE] || Config::Key_Press[VK_ESCAPE] || Config::Mouse_Click[0] ) m_SplashDone = true; 

	// Shift fases
	if( (m_Splash == 3) && (m_Fade <= 0.0f) ) m_SplashDone = true; 
	if( (m_Splash == 2) && (m_Fade >= 256.0f) ) m_Splash++;
	if( (m_Splash == 1) && (m_Fade <= 0.0f) ) m_Splash++;
	if( (m_Splash == 0) && (m_Fade >= 256.0f) ) m_Splash++;
	
	// Prevent extreme FPS
	Sleep(5);
}

void MainMenu::Tick( float a_DT )
{
	// Handle buttons
	Button_NewGame->Tick( a_DT ); if(Button_NewGame->isClicked()){ SetFase(MM_LOAD); }
	Button_Options->Tick( a_DT ); if(Button_Options->isClicked()){ SetFase(MM_OPTS); } 
	Button_Hiscore->Tick( a_DT ); if(Button_Hiscore->isClicked()){ SetFase(MM_HIGH); } 
	Button_QuitGme->Tick( a_DT ); if(Button_QuitGme->isClicked()){ Config::exitApp = true; }		

	Button_Back->Tick( a_DT ); if( Button_Back->isClicked() ){ SetFase(MM_MAIN); }
	Button_Apply->Tick( a_DT ); if( Button_Apply->isClicked() ){ SaveSettings(); }

	if(SliderBar_SoundVol->Changed() || SliderBar_MusicVol->Changed()) 
	{
		Config::S_soundVol = opts.Svol;
		Config::S_musicVol = opts.Mvol;
		SoundManager::SetAllSoundVolume();
	}

	// Handle option thingies
	Slider_LOD->Tick( a_DT );
	Slider_LIT->Tick( a_DT );
	Slider_AAS->Tick( a_DT );
	List_RES->Tick( a_DT );

	CheckBox_Fullscr->Tick( a_DT );
	CheckBox_FixRatio->Tick( a_DT );

	SliderBar_SoundVol->Tick( a_DT );
	SliderBar_MusicVol->Tick( a_DT );

	for(int i=0; i<10; i++) ScoreSliders[i]->Tick( a_DT );
	if( InFase(MM_HIGH) )
	{ 
		if(m_LineAlpha < 1.0f) m_LineAlpha += a_DT*2.0f; 
	}
	else
	{ 
		if(m_LineAlpha > 0.0f) m_LineAlpha -= a_DT*2.0f; 
	}

	// Apply fade
	if( InFase(MM_LOAD) || InFase(MM_GAME) )
	{
		if(m_Fade > 0.0f){ m_Fade -= a_DT * 512.0f; if(m_Fade < 0.0f) m_Fade = 0.0f; }
	}
	else
	{
		if(m_Fade < 256.0f){ m_Fade += a_DT * 256.0f; if(m_Fade > 256.0f) m_Fade = 256.0f; }
	}

	// Resize Window
	m_WinW -= (m_WinW - m_TarW) * 0.15f;
	m_WinH -= (m_WinH - m_TarH) * 0.15f;
	Button_Back->setStatic( float(Config::S_scrHeight>>1) + (m_WinH*0.5f) + 4 );

	// Exit Menu
	if( InFase(MM_GAME) && (m_Fade <= 0.0f) ){ m_NewGame = true; }

	// Handle loading screen
	if( m_LoadingDone ){ SetFase(MM_GAME); m_LoadingDone = false; }
	if( InFase(MM_LEND) && (m_Fade >= 256.0f) ){ World::Init(); m_LoadingDone = true; }
	if( InFase(MM_LOAD) && (m_Fade <= 0.0f) ){ SetFase(MM_LEND); }

	// Prevent extreme FPS
	Sleep(5);
}

// --------------------------------------------------------------------------
// Drawing Loop
// --------------------------------------------------------------------------

void MainMenu::SplashDraw( Surface* a_Target )
{
	a_Target->Clear(0);

	// Draw splash image
	Surface* splashIMG = m_Splash1;
	if( m_Splash > 1 ) splashIMG = m_Splash2;

	const int dw = splashIMG->GetWidth(), dh = splashIMG->GetHeight();
	const int dx = (Config::S_scrWidth>>1) - (dw>>1);
	const int dy = (Config::S_scrHeight>>1) - (dh>>1);
	splashIMG->CopyTo( a_Target, dx, dy );

	// Apply Fade
	int fade = MIN( int(m_Fade * 2.0f), 255 );
	if( fade < 255 ) DrawFade(a_Target, fade, dx, dy, dw, dh );
}

void MainMenu::Draw( Surface* a_Target, Surface* a_Cursor )
{ 
	// Draw Loading screen
	if( InFase(MM_LEND) || InFase(MM_GAME) )
	{
		// Draw loading img
		const int dx = (Config::S_scrWidth>>1) - (m_LoadingScr->GetWidth()>>1);
		const int dy = (Config::S_scrHeight>>1) - (m_LoadingScr->GetHeight()>>1);
		m_LoadingScr->CopyTo( a_Target, dx, dy );

		// Apply Fade
		if( m_Fade != 256.0f) DrawFade(a_Target, int(m_Fade), 0, 0, Config::S_scrWidth, Config::S_scrHeight);

		return;
	}

	// Draw Moving Background
	m_Rot += 0.005f, m_BGx += sin(m_Rot*0.6f), m_BGy += cos(m_Rot)*0.6f;
	if(m_BGx < 0) m_BGx += 512; if(m_BGx > 512) m_BGx -= 512;
	if(m_BGy < 0) m_BGy += 512; if(m_BGy > 512) m_BGy -= 512;
	DrawTiled( int(m_BGx), int(m_BGy), a_Target, m_BG );

	WindowDraw(a_Target, int(m_WinW), int(m_WinH));
	DrawHighScores( a_Target );
	
	// Draw Buttons
	if(InFase(MM_OPTS) || InFase(MM_HIGH)) Button_Back->Draw( a_Target );
	else if(!InFase(MM_GAME))
		DrawTransp( int(Button_Back->GetX())-64, int(Button_Back->GetY()), a_Target, buttonBackSealed );

	Button_Apply->Draw( a_Target );

	Button_NewGame->Draw( a_Target ); Button_Options->Draw( a_Target );
	Button_Hiscore->Draw( a_Target ); Button_QuitGme->Draw( a_Target );

	Slider_LOD->Draw( a_Target ); Slider_LIT->Draw( a_Target );
	Slider_AAS->Draw( a_Target ); List_RES->Draw( a_Target );

	CheckBox_Fullscr->Draw( a_Target );
	CheckBox_FixRatio->Draw( a_Target );

	SliderBar_SoundVol->Draw( a_Target );
	SliderBar_MusicVol->Draw( a_Target );

	int topY = (Config::S_scrHeight>>1)-m_Title->GetHeight()-192;
	int bottomY = (Config::S_scrHeight>>1)-(int(m_WinH)>>1);
	int titleY = ((topY+bottomY)>>1);
	DrawTransp((Config::S_scrWidth>>1)-(m_Title->GetWidth()>>1), titleY, a_Target, m_Title);

	// Draw bottom text
	char* cr1 = "Created by Mark Peters, Bram van de Wetering, Wytze van Balkom,";
	char* cr2 = "Jan Zavadil, Valentin Vockel, Irina Tomova and Marc Goliszec.";
	char* cr3 = "(c) 2009 Dot Studio's. All rights reserved, Time of Light is the exclusive copyright of Dot Studios.";
	a_Target->Print( cr1, 8, a_Target->GetHeight()-24, 0xaa7755 );
	a_Target->Print( cr2, 8, a_Target->GetHeight()-18, 0xaa7755 );
	a_Target->Print( cr3, 8, a_Target->GetHeight()-12, 0xaa7755 );

	DrawMouse( a_Target, a_Cursor );

	// Apply Fade
	if( m_Fade != 256.0f) DrawFade(a_Target, int(m_Fade), 0, 0, Config::S_scrWidth, Config::S_scrHeight);
}

void MainMenu::DrawHighScores( Surface* a_Target )
{
	char c[32];
	for(int i=0; i<10; i++)
	{
		if(ScoreSliders[i]->GetY() < float(Config::S_scrHeight-16))
		{
			int lineY = (Config::S_scrHeight>>1)-(272>>1)+i*24+16;
			int posx = int(ScoreSliders[i]->GetX()), posy = int(ScoreSliders[i]->GetY());
			int ialpha = int(m_LineAlpha*256.0f);
			if(ialpha) 
			{
				GradientLine( a_Target, posx, lineY+14, posx+176, 0x3f340f, 0x7f683b, ialpha );
				GradientLine( a_Target, posx + 176, lineY+14, posx + 352, 0x7f683b, 0x3f340f, ialpha );
			}
			sprintf(c,"%i",i+1);
			Font_HighScores->Print( a_Target, c, posx + 16 - Font_HighScores->Width(c), posy );
			memcpy(c,&Config::HighNames[i][0],12); c[12]=0;
			Font_HighScores->Print( a_Target, c, posx + 32, posy );
			sprintf(c,"%i",Config::HighScores[i]);
			Font_HighScores->Print( a_Target, c, posx + 352 - Font_HighScores->Width(c), posy );
		}
	}
}

}; // namespace Raytracer