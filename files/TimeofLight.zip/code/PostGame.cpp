// --------------------------------------------------------------------------
// Copyright (c) Mark Peters and Bram van de Wetering 2009
// --------------------------------------------------------------------------

#include "Windows.h"
#include "Config.h"
#include "Surface.h"
#include "Drawing2D.h"
#include "MenuItems.h"
#include "PostGame.h"
#include "Windows.h"
#include "stdlib.h"

namespace Raytracer {

SlidingItem* ScoreButton, *EnterNameButton;
extern Font* Font_HighScores;

// PostGame Member Data
int PostGame::m_Fase = PG_NULL;
int PostGame::m_Idx = 0;
unsigned int PostGame::m_FinalScore = 0;
Surface* PostGame::m_HighBG;
Surface* PostGame::m_ScoreButton, *PostGame::m_EnterName;
Surface* PostGame::m_BG;
float PostGame::m_ScrollX = 0, PostGame::m_ScrollY = 0;
float PostGame::m_Fade = 0, PostGame::m_Timer = 0;
bool PostGame::m_Done = false;
char PostGame::m_NewScore[12];
int PostGame::m_CursorPos = 0;
float PostGame::m_BoxFluc = 0.0f;

void PostGame::SetFase(int a_Fase)
{
	m_Fase = a_Fase;

	ScoreButton->setActive( m_Fase != PG_TOMAIN );
	EnterNameButton->setActive( (m_Fase != PG_TOMAIN) && (m_Idx!=-1) );
}

int PostGame::EvaluateScore()
{
	int idx = -1;
	for(int i=9; i>=0; i--)
	{
		if(Config::HighScores[i] < m_FinalScore) idx = i;
	}
	return idx;
}

void PostGame::Init()
{
	m_HighBG = new Surface("images/Menu Images/HighScore_BG.tga");
	m_ScoreButton = new Surface("images/Menu Images/FinalScore.tga");
	m_EnterName = new Surface("images/Menu Images/EnterName.tga");

	ScoreButton = new SlidingItem();
	EnterNameButton = new SlidingItem();
}

void PostGame::Enter(unsigned int a_EndScore, Surface* a_BG )
{
	for(int i=0; i<12; i++) m_NewScore[i] = ' ';
	m_CursorPos = 0;
	m_FinalScore = a_EndScore;
	m_Done = false;
	m_Idx = EvaluateScore();
	SetFase(PG_GAMEOUT);
	m_Fade = 256.0f;
	m_BG = new Surface( a_BG->GetWidth(), a_BG->GetHeight() );
	a_BG->CopyTo( m_BG, 0, 0 );
	m_BoxFluc = 0.0f;

	ScoreButton->jumpToStart();
	EnterNameButton->jumpToStart();

	const float centreX = float((Config::S_scrWidth>>1)-(m_ScoreButton->GetWidth()>>1));
	ScoreButton->setPos( centreX, 64.0f );
	EnterNameButton->setPos( centreX, 320.0f );

	Config::newHighscore = true;
}

void PostGame::Exit()
{
	delete m_BG;
}

void PostGame::Tick( float a_DT )
{
	if( !InFase(PG_GAMEOUT) && ( (!InFase(PG_POSTIN)) || m_Fade > 128.0f ) )
	{
		ScoreButton->Tick( a_DT );
		EnterNameButton->Tick( a_DT );
	}

	// Enter name
	if( InFase(PG_HIGHSCORE) && EnterNameButton->InPlace() )
	{
		const int boxX = int(EnterNameButton->GetX()) + 126, boxY = int(EnterNameButton->GetY()) + 44;
		if( Config::Mouse_X >= boxX && Config::Mouse_X <= boxX + 240 )
		if( Config::Mouse_Y >= boxY && Config::Mouse_Y <= boxY + 32 )
		if( Config::Mouse_Down[0] )
		{
			m_CursorPos = MIN(11,MAX(0, (Config::Mouse_X - boxX)/20 ));
			m_BoxFluc = 256.0f;
		}
		if( Config::Key_Press[VK_LEFT] && m_CursorPos > 0){ m_CursorPos--; m_BoxFluc = 256.0f; }
		if( Config::Key_Press[VK_RIGHT] && m_CursorPos < 11){ m_CursorPos++; m_BoxFluc = 256.0f; }

		const int t = 'a'-'A';
		for( int i='A'; i<='Z'; i++ ) if(Config::Key_Press[i]){ m_NewScore[m_CursorPos++] = i+t; m_BoxFluc = 256.0f; }
		for( int i='0'; i<='9'; i++ ) if(Config::Key_Press[i]){ m_NewScore[m_CursorPos++] = i; m_BoxFluc = 256.0f; }
		if( Config::Key_Press[VK_SPACE] ){ m_NewScore[m_CursorPos++] = ' '; m_BoxFluc = 256.0f; }
		if( Config::Key_Press[VK_DELETE] ){ m_NewScore[m_CursorPos] = ' '; m_BoxFluc = 256.0f; }
		if( Config::Key_Press[VK_BACK] )
		{ 
			m_CursorPos--; if(m_CursorPos < 0) m_CursorPos = 11;
			m_NewScore[m_CursorPos] = ' '; 
			m_BoxFluc = 256.0f; 
		}
		if( m_CursorPos < 0 ) m_CursorPos = 11;
		if( m_CursorPos > 11 ) m_CursorPos = 0;

		m_BoxFluc += a_DT * 512.0f; if( m_BoxFluc > 512.0f ) m_BoxFluc -= 512.0f;
	}

	// Return to menu (and save score)
	if( (InFase(PG_NOSCORE) || InFase(PG_HIGHSCORE)) && Config::Key_Press[VK_RETURN] )
	{
		if(m_Idx != -1)
		{
			for(int i=9; i>m_Idx; i--) 
			{
				memcpy( &Config::HighNames[i][0], &Config::HighNames[i-1][0], 12 );
				Config::HighScores[i] = Config::HighScores[i-1];
			}
			memcpy( &Config::HighNames[m_Idx][0], &m_NewScore[0], 12 );
			Config::HighScores[m_Idx] = m_FinalScore;
		}
		Config::F_SaveScores();
		SetFase(PG_TOMAIN);
	}

	// Apply fade
	if(InFase(PG_GAMEOUT) || InFase(PG_TOMAIN))
	{
		if(m_Fade > 0.0f){ m_Fade -= a_DT * 256.0f; if(m_Fade < 0.0f) m_Fade = 0.0f; }
	}
	else
	{
		if(m_Fade < 256.0f){ m_Fade += a_DT * 128.0f; if(m_Fade > 256.0f) m_Fade = 256.0f; }
	}

	// Fase transitions
	if(InFase(PG_GAMEOUT) && m_Fade < 1.0f) SetFase(PG_POSTIN);
	if(InFase(PG_TOMAIN) && m_Fade < 1.0f) m_Done = true;
	if(InFase(PG_POSTIN) && m_Fade > 255.0f)
	{
		if(m_Idx == -1) SetFase(PG_NOSCORE); else SetFase(PG_HIGHSCORE);
	}

	// Prevent extreme FPS
	Sleep(5);
}

void PostGame::Draw( Surface* a_Target, Surface* a_Cursor )
{
	if(InFase(PG_GAMEOUT))
	{
		// Draw old game screencapture
		m_BG->CopyTo( a_Target, 0, 0 );
	}
	else
	{
		// Draw Moving Background
		m_ScrollX -= 0.2f, m_ScrollY -= 0.3f;
		if(m_ScrollX > 512.0f) m_ScrollX -= 512.0f;
		if(m_ScrollY > 512.0f) m_ScrollY -= 512.0f;
		DrawTiled( int(m_ScrollX), int(m_ScrollY), a_Target, m_HighBG );
	}

	// Draw Enter name button
	const int buttonX = int(EnterNameButton->GetX()), buttonY = int(EnterNameButton->GetY());
	DrawTransp( buttonX, buttonY, a_Target, m_EnterName );
	if(InFase(PG_HIGHSCORE))
	{
		
		const int boxX = buttonX + 126 + m_CursorPos * 20;
		int ifluc = (m_BoxFluc >= 256.0f) ? int(512-m_BoxFluc) : int(m_BoxFluc);
		ifluc = MAX(0,MIN(255,ifluc));
		Pixel boxCol = (ifluc << 16) + (ifluc << 8) + ifluc;
		a_Target->Box( boxX, buttonY + 44, boxX + 19, buttonY + 44 + 31, boxCol );

		char c[] = { 0,0 };
		for(int i=0; i<12; i++)
		{
			c[0] = m_NewScore[i];
			const int fx = buttonX + i*20 + 136 - (Font_HighScores->Width(c)>>1);
			if(c[0] != ' ') Font_HighScores->Print( a_Target, c, fx, buttonY + 44 + 8, true );
		}
	}
	
	// Draw final score button
	DrawTransp( ScoreButton->GetX(), ScoreButton->GetY(), a_Target, m_ScoreButton );
	if(ScoreButton->GetY()+128 < Config::S_scrHeight-16)
	{
		char scoretxt[32];
		sprintf(scoretxt, "%i", m_FinalScore);
		Font_HighScores->Centre( a_Target, scoretxt, ScoreButton->GetY()+128 );
	}

	DrawMouse( a_Target, a_Cursor );

	// Apply Fade
	if( m_Fade < 256.0f) DrawFade(a_Target, int(m_Fade), 0, 0, Config::S_scrWidth, Config::S_scrHeight);
}

};