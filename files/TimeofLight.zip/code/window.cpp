// --------------------------------------------------------------------------
// Copyright (c) Mark Peters and Bram van de Wetering 2009
// --------------------------------------------------------------------------

extern "C" { 
#include "glew.h" 
}
#include "gl.h"
#include "Config.h"
#include "surface.h"
#include "windows.h"
#include "Game.h"
#include "core.h"
#include "scene.h"
#include "MainMenu.h"
#include "EscapeMenu.h"
#include "World.h"

using namespace Raytracer;

static bool initialized = false;
static char appname[] = APP_NAME;
static float looptime = 0.1f;
static wallclock_t LTimer;

Surface* surface = 0;
Game* game = 0;

HDC hDC=NULL;
HGLRC hRC=NULL;
HWND hWnd=NULL;
HINSTANCE hInstance=NULL;

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	int xoffset, yoffset;
	switch (uMsg)
	{
		case WM_ACTIVATE: Config::Active = !HIWORD(wParam);	return 0;
		case WM_SYSCOMMAND:
		{
			switch (wParam)
			{
				case SC_SCREENSAVE:
				case SC_MONITORPOWER:
					return 0;
			}
			break;
		}

		case WM_CLOSE:
		case WM_QUIT: 
			Config::exitApp = 1;
			return 0;
		case WM_LBUTTONDOWN:
			Config::Mouse_Down[0] = Raytracer::Config::Mouse_Click[0] = true;
			return 0;
		case WM_LBUTTONUP:
			Config::Mouse_Down[0] = false;
			return 0;
		case WM_MBUTTONDOWN:
			Config::Mouse_Down[1] = Raytracer::Config::Mouse_Click[1] = true;
			return 0;
		case WM_MBUTTONUP:
			Config::Mouse_Down[1]= false;
			return 0;
		case WM_RBUTTONDOWN:
			Config::Mouse_Down[2] = Raytracer::Config::Mouse_Click[2] = true;
			return 0;
		case WM_RBUTTONUP:
			Config::Mouse_Down[2]= false;
			return 0;
		case WM_MOUSEMOVE:
			xoffset = (Config::WindowWidth>>1) - (Config::ViewportWidth>>1);
			yoffset = (Config::WindowHeight>>1) - (Config::ViewportHeight>>1);
			Config::Mouse_X = Config::S_scrWidth * (LOWORD(lParam)-xoffset) / Config::ViewportWidth;
			Config::Mouse_Y = Config::S_scrHeight * (HIWORD(lParam)-yoffset) / Config::ViewportHeight;
			return 0;
		case WM_KEYDOWN:
			Config::Key_Down[wParam] = Raytracer::Config::Key_Press[wParam] = true;
			return 0;
		case WM_KEYUP:
			Config::Key_Down[wParam] = false;
			return 0;
		case WM_SIZE:
			Config::ResizeGLWindow(LOWORD(lParam),HIWORD(lParam));
			return 0;
		case WM_SETCURSOR:
			if (Config::S_fullscreen){ SetCursor(NULL); return 0; }
			break;
	}

	// Pass All Unhandled Messages To DefWindowProc
	return DefWindowProc(hWnd,uMsg,wParam,lParam);
}

bool init()
{
	Log::Message("Initializing..."); 

	// Set Opengl Settings
	glEnable( GL_TEXTURE_2D );
	glShadeModel( GL_SMOOTH );
	glClearColor( 0.0f, 0.0f, 0.0f, 0.0f );
	glClear( GL_COLOR_BUFFER_BIT );
	glHint( GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST );
	glBlendFunc(GL_SRC_ALPHA,GL_ONE);

	// Create a Surface
	surface = new Surface( Config::S_scrWidth, Config::S_scrHeight );
	surface->InitCharset();
	game->SetTarget(surface);
	Engine::SetTarget( surface->GetBuffer(), Config::S_scrWidth, Config::S_scrHeight, Config::S_scrWidth );

	// Convert surface to opengl texture
	glGenTextures( 1, game->GetScreenTexId() );
	if (glGetError()) return false;
	glBindTexture( GL_TEXTURE_2D, *game->GetScreenTexId() );
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); 
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, Config::S_scrWidth, Config::S_scrHeight, 0, GL_BGRA, GL_UNSIGNED_BYTE, surface->GetBuffer());
	if (glGetError()) return false;

	return true;
}
void KillGLWindow()
{
	Log::Message("Destroying Window..."); 
	if (glIsTexture(*game->GetScreenTexId())) glDeleteTextures(1, game->GetScreenTexId());
	if (Config::S_fullscreen) ChangeDisplaySettings(NULL,0);
	if (hRC)
	{
		wglMakeCurrent(NULL,NULL);
		wglDeleteContext(hRC);
	}
	if (hDC) ReleaseDC(hWnd,hDC);
	if (hWnd) DestroyWindow(hWnd);
	if (hInstance) UnregisterClass(appname,hInstance);
	hRC=NULL;
	hDC=NULL;
	hWnd=NULL;
	hInstance=NULL;
}
bool CreateGLWindow(int bits)
{
	Config::F_LoadSettings();

	Log::Message("Creating Window..."); 
	hInstance = GetModuleHandle(NULL);
	WNDCLASS wc;
	wc.style = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
	wc.lpfnWndProc = (WNDPROC) WndProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = LoadIcon(NULL, IDI_WINLOGO);
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = NULL;
	wc.lpszMenuName = NULL;
	wc.lpszClassName = appname;

	if (!RegisterClass(&wc)){ 
		Log::Message("Failed To Register The Window Class.");	
		return false; 
	}
	
	if (Config::S_fullscreen)
	{
		DEVMODE dmScreenSettings;
		memset(&dmScreenSettings,0,sizeof(dmScreenSettings));
		dmScreenSettings.dmSize=sizeof(dmScreenSettings);
		dmScreenSettings.dmPelsWidth = Config::WindowWidth;
		dmScreenSettings.dmPelsHeight = Config::WindowHeight;
		dmScreenSettings.dmBitsPerPel = bits;	
		dmScreenSettings.dmFields=DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT;
		if (ChangeDisplaySettings(&dmScreenSettings,CDS_FULLSCREEN)!=DISP_CHANGE_SUCCESSFUL)
		{
			char t[256];
			sprintf(t, "Failed to set to fullscreen (width: %i, height: %i), continuing windowed.", dmScreenSettings.dmPelsWidth, dmScreenSettings.dmPelsHeight);
			Log::Message(t);	
			Config::S_fullscreen = false;
		}
	}
	else
	{
		ChangeDisplaySettings(NULL,0);
	}

	DWORD dwExStyle, dwStyle;
	if (Config::S_fullscreen)
	{
		dwExStyle=WS_EX_APPWINDOW;
		dwStyle=WS_POPUP;
	}
	else
	{
		dwExStyle=WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;
		dwStyle= WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_OVERLAPPEDWINDOW; //WS_SYSMENU
	}

	RECT WindowRect;
	WindowRect.left=(long)0;
	WindowRect.right=(long)Config::WindowWidth;
	WindowRect.top=(long)0;
	WindowRect.bottom=(long)Config::WindowHeight;
	AdjustWindowRectEx(&WindowRect, dwStyle, FALSE, dwExStyle);

	int winX = (Config::S_fullscreen) ? 0 : (GetSystemMetrics(SM_CXSCREEN)>>1)-(Config::S_scrWidth>>1);
	int winY = (Config::S_fullscreen) ? 0 : (GetSystemMetrics(SM_CYSCREEN)>>1)-(Config::S_scrHeight>>1);
	if (!(hWnd=CreateWindowEx( dwExStyle, appname, appname, dwStyle | WS_CLIPSIBLINGS |	WS_CLIPCHILDREN, winX, winY, WindowRect.right-WindowRect.left, WindowRect.bottom-WindowRect.top, NULL, NULL, hInstance,NULL)))
	{
		Log::Message("Failed to create Window.");	
		KillGLWindow();
		return false;
	}

	if (!(hDC=GetDC(hWnd)))
	{
		Log::Message("Failed to create Device Context.");	
		KillGLWindow();
		return false;
	}

	unsigned int PixelFormat;
	static PIXELFORMATDESCRIPTOR pfd={ sizeof(PIXELFORMATDESCRIPTOR), 1, PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL |	PFD_DOUBLEBUFFER, PFD_TYPE_RGBA, bits, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16, 0, 0,	PFD_MAIN_PLANE,	0, 0, 0, 0};
	if (!(PixelFormat=ChoosePixelFormat(hDC,&pfd)))
	{
		Log::Message("Failed to find suitable Pixelformat.");	
		KillGLWindow();
		return false;
	}

	if(!SetPixelFormat(hDC,PixelFormat,&pfd))
	{
		Log::Message("Failed to set Pixelformat.");	
		KillGLWindow();
		return false;
	}

	if (!(hRC=wglCreateContext(hDC)))
	{
		Log::Message("Failed to create Rendering Context.");	
		KillGLWindow();
		return false;
	}

	if(!wglMakeCurrent(hDC,hRC))
	{
		Log::Message("Failed to activate Rendering Context.");	
		KillGLWindow();
		return false;
	}

	if (!init())
	{
		Log::Message("Failed to initialize.");	
		KillGLWindow();	
		return false;
	}

	ShowWindow(hWnd,SW_SHOW);
	SetForegroundWindow(hWnd);
	SetFocus(hWnd);

	if (!initialized)
	{
		initialized = true;
	}
	else
	{
		MainMenu::Resize();
		EscapeMenu::Resize();	
	}

	Log::Message("Window Setup Complete..."); 
	return true;
}

int APIENTRY WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow )
{  
	game = new Game();
	if (!Scene::InitScene()) return 1;
	if (!CreateGLWindow(32)) return 1;	
	game->Init();
	World::SetSurface(surface);

	MSG	msg;
	LTimer.init();
	while (!Config::exitApp)
	{
		if (PeekMessage(&msg,NULL,0,0,PM_REMOVE))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else
		{
			// Update
			LTimer.reset();
			looptime = Engine::m_LoopTime / 1000;
			if (looptime < 0.01f) looptime = 0.01f;
			if (looptime > 0.50f) looptime = 0.50f;
			game->Tick( looptime );

			// Run Arauna Render
			if (Config::RenderScene)
			{
				vector3 pos = Scene::GetCamera()->GetPosition();
				vector3 tar = Scene::GetCamera()->GetTarget();
				Engine::Render( pos, tar, 0 );
			}

			// Run Post Render
			game->PostRender( looptime );

			// Reset Input
			Config::F_UpdateInput();

			// Render the OpenGL Quad
			game->OpenGLRender();
			SwapBuffers(hDC);

			// Get the new timings
			Engine::m_LoopTime = (float)LTimer.elapsed();
		
			// If recreate flag is set recreate window
			if (Config::ReCreateWindow)
			{
				Config::ReCreateWindow = false;
				KillGLWindow();
				if (!CreateGLWindow(32)) return 1;
			}
		}
	}

	// Shutdown
	ShowCursor(TRUE);
	game->ShutDown();
	KillGLWindow();
	ExitProcess( 0 );
	return 0;
}