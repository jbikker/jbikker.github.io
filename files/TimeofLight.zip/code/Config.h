// --------------------------------------------------------------------------
// Copyright (c) Mark Peters and Bram van de Wetering 2009
// --------------------------------------------------------------------------

#ifndef I_CONFIG_H
#define I_CONFIG_H

// --------------------------------------------------------------------------
// Global Variables & Game Settings
// --------------------------------------------------------------------------

#define APP_NAME	"TimeofLight"
#define RAYPRECISION 10
#define MAXSCENELIGHTS 256
#define MAXBALLCOUNT 3
#define LFLIPPERS 3
#define RFLIPPERS 1
#define TABLEPITCHANGLE 5
#define CAMSPEED 200
#define SCORECYLINDERS 10
#define MULTIPLIERS 10

#define BALLSIZE 2.3f
#define ARKANOID_BALLSIZE 1.5f

// Score List
#define SCORE_MUSHROOM_HIT			1515
#define SCORE_BUMPER_HIT			1666
#define SCORE_KEY_HIT				1701
#define SCORE_ARKANOID_HIT			 555
#define SCORE_CANNON_FIRE			3012

#define SCORE_LOOPING_TRAVEL		   2
#define SCORE_RAIL_TRAVEL			   1


namespace Raytracer {

class vector3;
struct Config
{
//====== Option Settings ======
	static bool Active, ReCreateWindow;
	static int WindowWidth, WindowHeight;
	static int ViewportWidth, ViewportHeight;

	static int S_scrWidth, S_scrHeight;	
	static bool S_fullscreen, S_fixRatio;

	static int S_lightingQuality;
	static int S_reflections;
	static int S_antiAliasing;

	static int S_soundVol, S_musicVol;

	static void F_LoadSettings();
	static void F_GenerateSettings();

//====== User Input ======
	static bool Key_Down[256], Key_Press[256];
	static bool Mouse_Down[3], Mouse_Click[3];
	static int Mouse_X, Mouse_Y;
	static int Mouse_PrevX, Mouse_PrevY;

	static void F_UpdateInput();

//====== High Scores ======
	static unsigned int HighScores[10];
	static char HighNames[10][12];

	static void F_LoadScores();
	static void F_SaveScores();
	static void F_GenerateScores();
	
//====== Balls ======
	static float B_MaxSpeed;
	static float B_Gravity;
	static float B_Friction;
	static float B_Bouncyness;
	static float B_Slowdown;
	static float B_TimeStep;

//====== Misc ======
	static void ResizeGLWindow(int width, int height);

	static bool ShowStats;
	static bool RenderScene;
	static bool exitApp;
	static bool fromOptions;
	static bool newHighscore;

	static float SceneUpdateCost;
	static float PhysicsCosts;
	static vector3 CamRot;
};

}; // namespace Raytracer

#endif