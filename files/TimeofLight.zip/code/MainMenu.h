// --------------------------------------------------------------------------
// Copyright (c) Mark Peters and Bram van der Wetering 2009
// --------------------------------------------------------------------------

#ifndef I_MAINMENU_H
#define I_MAINMENU_H

namespace Raytracer {

// Main Menu Fases
enum
{
	MM_NULL	= 0,
	MM_MAIN	= (1 << 1),
	MM_OPTS	= (1 << 2),
	MM_HIGH	= (1 << 3),
	MM_LOAD = (1 << 4),
	MM_LEND = (1 << 5),
	MM_GAME	= (1 << 6)
};

class Surface;
class MainMenu
{
public:
	static void Init();
	static void Resize();
	static void Enter();
	static void Exit();

	static void Tick( float a_DT );
	static void Draw( Surface* a_Target, Surface* a_Cursor );
	static void LoadSettings();
	static void SaveSettings();

	static void SplashEnter();
	static void SplashTick( float a_DT );
	static void SplashDraw( Surface* a_Target );
	static void SplashExit();

	static inline bool NewGame(){ return m_NewGame; }
	static inline bool SplashDone(){ return m_SplashDone; }

private:
	static inline void SetFase( int a_Fase );
	static inline bool InFase(int a_Fase ){ return m_Fase == a_Fase; }
	static void DrawHighScores( Surface* a_Target);

	static Surface* m_BG, *m_Title, *m_LoadingScr;
	static Surface* m_Splash1, *m_Splash2;
	static int m_Fase, m_Splash;
	static float m_BGx, m_BGy, m_Rot;
	static float m_Fade, m_Timer, m_LineAlpha;
	static bool m_NewGame, m_LoadingDone, m_SplashDone;

	static float m_WinW, m_WinH, m_TarW, m_TarH;
};

} // namespace Raytracer

#endif
