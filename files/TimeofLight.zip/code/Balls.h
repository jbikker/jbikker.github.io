// --------------------------------------------------------------------------
// Copyright (c) Mark Peters and Bram van de Wetering 2009
// --------------------------------------------------------------------------

#ifndef I_BALLS_H
#define I_BALLS_H

#include "config.h"
#include "common.h"
#include "common_math.h"
#include "sthread.h"

namespace Raytracer {

class Node;
class Ball;
class Material;
class Light;

class BallManager
{
public:
	static void Init(int a_MaxBalls);
	static void Destroy();
	static void StepTick(float a_DT);
	static void Tick(float a_DT);
	static void PostRender();
	static vector3 GetGravityNormal(){return m_GravityNormal;}
	static int AddBall(vector3 a_Pos, vector3 a_Velocity, float a_Radius);
	static void DeleteBall(int a_ID);
	static void AddTiltForce();
	static void UpdateBallPositions();
	static Ball* GetBallById(int a_ID){ return m_Balls[a_ID];}
	static int GetActiveBallCount(){return m_NextBallId;}
	static int GetMaxBalls(){return m_MaxBalls;}
	static Node* GetNode(){return m_Node;}
	static vector3 RayDirs[RAYPRECISION*RAYPRECISION];
	static int GetMatCount(){return m_MaxBalls;}
	static Material** GetMatList(){return m_MatList;}
	static void ResetPhysics(float a_DT);
private:
	static Node* m_Node;
	static Ball** m_Balls;
	static int m_NextBallId;
	static int m_MaxBalls;
	static Material** m_MatList;
	static vector3 m_GravityNormal;
};

class BallThread : public Thread
{
public:
	void Init( unsigned int a_Thread );
	void run();

	Ball* m_Ball;
	unsigned int m_Thread;
	float m_Friction;
	float m_Bouncyness;
};


class Ball
{
public:
	Ball();
	void Init(vector3 a_Pos, vector3 a_InitVelocity);
	void StepTick(float a_DT);
	void Tick(float a_DT);
	void PostRender();
	void AddTiltForce();
	void SetActive(bool a_Active){m_Active = a_Active;}

	void SetCharge(float a_Charge){m_Charge = a_Charge;}
	float GetCharge(){return m_Charge;}

	void SetRadius(float a_Radius);
	float GetRadius();

	Material* GetMaterial(){return m_Material;}

	void SetChargeFlag(){m_ChargeFlag = true;}

	void SetDeleteFlag(bool a_Flag){m_DeleteFlag = a_Flag;}
	bool GetDeleteFlag(){return m_DeleteFlag;}
	void CleanUp();

	void SetSphereId(unsigned int a_SphereId){m_SphereId = a_SphereId;}
	int GetSphereId(){return m_SphereId;}

	void SetLightPos(vector3 a_Pos);

	void SetPos(vector3 a_Pos){m_Pos = a_Pos;}
	vector3 GetPos(){return m_Pos;}

	void AddVelocity(vector3 a_velocity){m_Velocity += a_velocity;}
	void SetVelocity(vector3 a_Velocity){m_Velocity = a_Velocity;}
	void ScaleVelocity(float a_Scaler){m_Velocity *= a_Scaler;}
	vector3 GetVelocity(){return m_Velocity;}

	void SetPhysics(float a_Gravity, float a_Friction, float a_Bouncyness){m_Gravity = a_Gravity; m_Friction = a_Friction; m_Bouncyness = a_Bouncyness;}
private:
	int m_SphereId;
	float m_Charge;
	bool m_Active;
	float m_Gravity;
	float m_Friction;
	float m_Bouncyness;
	vector3 m_Pos;
	vector3 m_Velocity, m_LastVel;
	Material* m_Material;
	Light* m_Light;
	bool m_DeleteFlag;
	bool m_ChargeFlag;
};

}; // namespace Raytracer
#endif

