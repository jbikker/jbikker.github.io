// --------------------------------------------------------------------------
// Copyright (c) Mark Peters and Bram van de Wetering 2009
// --------------------------------------------------------------------------

#include "GameObjects.h"
#include "Balls.h"
#include "core.h"					// main renderer functions
#include "scene.h"					// main scene functions
#include "memory.h"					// for MManager::NewMaterial()
#include "surface.h"				// graphics surface functions
#include "scenegraph.h"				// for SceneGraph::Update()
#include "SoundManager.h"
#include "Config.h"
#include "World.h"
#include "ScoreMultiplier.h"

using namespace Raytracer;

int ScoreMultiplier::m_Multiplier = 0;
float ScoreMultiplier::m_Timer = 0.0f;
Light* ScoreMultiplier::m_Light[MULTIPLIERS];
//LightRotater* ScoreMultiplier::m_LightRotater;

void ScoreMultiplier::Init()
{
	matrix fm;
	fm.Translate(vector3(0, -47, 0));

	// Create Lights
	//m_LightRotater = new LightRotater();
	//m_LightRotater->Init(MULTIPLIERS, 1, 0.1f);
	for (int i=0; i<MULTIPLIERS; ++i)
	{
		vector3 pos;
		switch (i)
		{
		case 0: pos = vector3(  0.46f,-50,-22.21f); break;
		case 1: pos = vector3(-11.36f,-50,-21.65f); break;
		case 2: pos = vector3(-26.05f,-50,-12.13f); break;
		case 3: pos = vector3(-32.26f,-50,6.48f); break;
		case 4: pos = vector3(-26.96f,-50,25.51f); break;
		case 5: pos = vector3(-6.89f,-50,34.83f); break;
		case 6: pos = vector3(19.86f,-50,26.29f); break;
		case 7: pos = vector3(23.42f,-50,4.42f); break;
		case 8: pos = vector3(23.73f,-50,-5.94f); break;
		case 9: pos = vector3(13.57f,-50,-16.45f); break;
		}
		m_Light[i] = MManager::NewLight();
		Color diff(1.0f,0.0f,0.0f);
		Color spec(0.5f,0.0f,0.0f);
		m_Light[i]->Init(0,"ScoreMultiplier",pos,diff,spec,15);
		Scene::AddLight(m_Light[i]);
		//m_LightRotater->AddLight(m_Light[i]);
	}
}

void ScoreMultiplier::Update(float a_DT)
{
	//m_LightRotater->Tick(a_DT);
	for (int i=0; i<MULTIPLIERS; ++i)
	{
		if (m_Multiplier > i)
		{
			Color diff(1.0f,1.0f,0.0f);
			Color spec(0.5f,0.5f,0.0f);
			m_Light[i]->SetDiffuse(diff);
			m_Light[i]->SetSpecular(spec);
			m_Light[i]->SetRadius(10);
		}
		else
		{
			Color diff(1.0f,0.0f,0.0f);
			Color spec(0.5f,0.0f,0.0f);
			m_Light[i]->SetDiffuse(diff);
			m_Light[i]->SetSpecular(spec);
			m_Light[i]->SetRadius(5);
		}
	}
}