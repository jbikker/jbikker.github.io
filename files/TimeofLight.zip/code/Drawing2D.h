// --------------------------------------------------------------------------
// Copyright (c) Mark Peters and Bram van de Wetering 2009
// --------------------------------------------------------------------------

#ifndef I_DRAWING2D_H
#define I_DRAWING2D_H

#include "Surface.h"

namespace Raytracer {

#define W_TILE_W	24
#define W_TILE_H	24

class Surface;

inline Pixel BlendColors( const Pixel& idst, const Pixel& isrc, unsigned int alpha )
{
	Pixel RG = (0xff00ff & ((idst & 0xff00ff) + ((((isrc & 0xff00ff) - (idst & 0xff00ff)) * alpha)>>8)));
	Pixel B = (0x00ff00 & ((idst & 0x00ff00) + ((((isrc & 0x00ff00) - (idst & 0x00ff00)) * alpha)>>8)));
	return RG|B;
}

void ResizeIMG(Surface* a_Target, Surface* a_Origin);
void DrawFade(Surface* a_Dest, unsigned int a_Scale, int a_X, int a_Y, int a_Width, int a_Height);
void DrawFCol(Surface* a_Dest, int a_X, int a_Y, int a_Width, int a_Height, Pixel a_Col);
void DrawFrame(int a_X, int a_Y, Surface* a_Target, Surface* a_Image, int a_Height, int a_Frame);
void DrawTransp(int a_X, int a_Y, Surface* a_Target, Surface* a_Image);
void DrawPartial(int a_X, int a_Y, int a_Width, int a_Height, Surface* a_Target, Surface* a_Image);
void DrawTiled(int a_X, int a_Y, Surface* a_Target, Surface* a_Image);
void PrintSafe(Surface* a_Target, char* a_String, int a_X, int a_Y, Pixel a_Col);
void BarSafe(Surface* a_Target, int a_X1, int a_Y1, int a_X2, int a_Y2, Pixel a_Col);
void Sephia(Surface* a_Target, Surface* a_Src);
void DrawPauseScreen(Surface* a_Target);
void DrawMouse(Surface* a_Target, Surface* a_Cursor);
void GradientLine(Surface* a_Target, int a_X, int a_Y, int a_X2, Pixel a_Col1, Pixel a_Col2, int alpha);

} // namespace Raytracer

#endif
