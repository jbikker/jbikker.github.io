// --------------------------------------------------------------------------
// Copyright (c) Mark Peters and Bram van de Wetering 2009
// --------------------------------------------------------------------------

#ifndef _SOUND_MANAGER_H_
#define _SOUND_MANAGER_H_

#include <map>
#include "../FMOD/fmod.h"

namespace Raytracer {

#define CHANNEL_FREE		-1
#define CHANNEL_MUSIC		4
#define CHANNEL_SPEECH		5
#define CHANNEL_BALLROLL	6
#define CHANNEL_BALLTICK	7
#define CHANNEL_FLIPPER		8 // Uses also channel 9
#define CHANNEL_CANNONROT	10
#define CHANNEL_GEARS		11
#define CHANNEL_MUSICBOX	12
#define CHANNEL_EVENT_1		13
#define CHANNEL_EVENT_2		14
#define CHANNEL_EVENT_3		15


struct SoundManagerSound
{ 
	int Channel;
	FSOUND_SAMPLE* Handle;
};

class SoundManager
{
public:
	static void Init();
	static void ShutDown();

	static SoundManagerSound Play( char* a_FileName, int a_Channel = CHANNEL_FREE );
	static SoundManagerSound PlayLooped( char* a_FileName, int a_Channel = CHANNEL_FREE );
	static void Stop( int a_Channel = CHANNEL_FREE );
	static void StopAllSounds();
	static void SetVolume( int a_Vol, int a_Channel );
	static void SetAllSoundVolume();
private:
	static std::map<char*, FSOUND_SAMPLE*> m_SoundMap;
};

}; // namespace Raytracer


#endif