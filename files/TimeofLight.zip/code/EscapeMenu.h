#ifndef I_ESCAPEMENU_H
#define I_ESCAPEMENU_H

namespace Raytracer {


// Escape Menu Fases
enum
{
	EM_NULL	= 0,
	EM_MAIN	= (1 << 1),
	EM_OPTS = (1 << 2),
	EM_TOMM	= (1 << 3),
	EM_QUIT	= (1 << 4)
};

class Surface;
class EscapeMenu
{
public:
	static void Init();
	static void Enter( Surface* a_BG );
	static void Exit();

	static void Resize();

	static void Tick( float a_DT );
	static void Draw( Surface* a_Target, Surface* a_Cursor );
	static void LoadSettings();
	static void SaveSettings();

	static inline bool Resume(){ return m_Resume; }
	static inline bool ToMenu(){ return m_ToMenu; }

private:
	static inline void SetFase( int a_Fase );
	static inline bool InFase(int a_Fase ){ return m_Fase == a_Fase; }
	
	static Surface* m_Background;
	static int m_Fase;
	static float m_Fade, m_Timer;
	static bool m_Resume, m_ToMenu, m_Ask1, m_Ask2;

	static float m_WinW, m_WinH, m_TarW, m_TarH;
};

} // namespace Raytracer

#endif
