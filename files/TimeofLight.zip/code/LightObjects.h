// --------------------------------------------------------------------------
// Copyright (c) Mark Peters and Bram van de Wetering 2009
// --------------------------------------------------------------------------

#ifndef I_LIGHT_OBJECTS_H
#define I_LIGHT_OBJECTS_H

#include "common.h"
#include "common_math.h"

namespace Raytracer {

class Light;
class LightRotater;
class LightManager
{
public:
	static void Init( int a_MaxLightRotaters );
	static void Tick( float a_DT );
	static void AddLightRotater(LightRotater* a_Rotater){ m_Rotaters[m_NextRotaterId++] = a_Rotater; }
private:
	static LightRotater** m_Rotaters;
	static int m_NextRotaterId;

	static Light* m_RotTableLights[24];
	static Light* m_ArkanoidStrip1[8];
	static Light* m_ArkanoidStrip2[8];

	static float m_TableLightRot;
	static float m_ArkaCycle;
};

class LightRotater
{
public:
	void Init(int a_LightCount, int a_ActiveCount, float a_RotateInterval);
	void Tick(float a_DT);
	void AddLight(Light* a_Light){ m_Lights[m_LightCount++] = a_Light; }
private:
	Light** m_Lights;
	float m_RotateInterval;
	float m_Timer;
	int m_Current;
	int m_LightCount;
	int m_ActiveCount;
};

}; // namespace Raytracer
#endif

