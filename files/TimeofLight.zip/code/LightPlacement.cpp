#include "core.h"
#include "common_math.h"
#include "scenegraph.h"
#include "Game.h"
#include "scene.h"
#include "surface.h"
#include "Config.h"
#include "scene.h"					// main scene functions
#include "memory.h"					// for MManager::NewMaterial()
#include "surface.h"				// graphics surface functions
#include "scenegraph.h"				// for SceneGraph::Update()
#include "LightPlacement.h"

namespace Raytracer {

FILE* LightFile;
Spheres* PosNode;
bool GroupActive = false;
int CycleLights = 0;

void LightPlacement::Init()
{
	// Create some dummy spheres far outside map
	PosNode = new Spheres(2);
	Material* mat = MManager::NewMaterial();
	Color ambient( 1.0f, 1.0f, 1.0f );
	mat->Init(); mat->SetAmbient( ambient );
	for(int i=0; i<2; i++) PosNode->Add( vector3(-1000,-1000 + i*10,-1000), 1.0f, mat );
	SceneGraph::AddNode( PosNode );
}

vector3 LightPlacement::TraceMouse()
{
	Primitive* prim;
	float x = Config::Mouse_X, y = Config::Mouse_Y;
	float width = (float)Engine::m_Width, height = (float)Engine::m_Height;
	vector3 p4 = Engine::m_P4, p1 = Engine::m_P1, p2 = Engine::m_P2;
	const vector3 Target = p1 + ((p2 - p1) * ((float)x / width)) + ((p4 - p1) * ((float)y / height));
	const vector3 Origin = Engine::m_Origin, Dir = (Target - Origin).Normalized();
	float dist = Engine::TracePixel( Config::Mouse_X, Config::Mouse_Y, prim );

	if( !prim ) return vector3(0,0,0);
	const vector3 poi = Origin + ( Dir * dist ) + ( -1.8f * Dir );
	return poi;
}

void LightPlacement::Message( char* a_Msg )
{
	LightFile = fopen( "lights.txt", "a" );
	if(!LightFile) return;
	fputs( a_Msg, LightFile );
	fflush( LightFile );
	fclose( LightFile );
	Log::Message( a_Msg );
}

void LightPlacement::Tick()
{
	// Draw lightpos
	vector3 Pos = TraceMouse();
	if((Pos.x != 0) || (Pos.y != 0) || (Pos.z != 0)) PosNode->SetCentre(0,Pos);

	char c[256];
	if( Config::Key_Press['O'] )
	{
		sprintf(c, "L %.2f %.2f %.2f", Pos.x, Pos.y, Pos.z );
		Message( c ); 
	}
}

}; // namespace Raytracer