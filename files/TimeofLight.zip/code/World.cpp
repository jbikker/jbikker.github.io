// --------------------------------------------------------------------------
// Copyright (c) Mark Peters and Bram van de Wetering 2009
// --------------------------------------------------------------------------

#include "core.h"
#include "common_math.h"
#include "scenegraph.h"
#include "Game.h"
#include "scene.h"
#include "surface.h"
#include "Config.h"
#include "Balls.h"
#include "core.h"	
#include "scene.h"	
#include "memory.h"	
#include "surface.h"
#include "scenegraph.h"
#include "GameObjects.h"
#include "World.h"
#include "Entities.h"
#include "Balls.h"
#include "MainMenu.h"
#include "SoundManager.h"
#include "LightObjects.h"
#include "ScoreMultiplier.h"

namespace Raytracer {

vector3 World::m_ShootLast;
vector3 World::m_ShootPos;
float World::m_Rot = 0;
float World::m_TimeLeft = 0;
float World::m_TiltTimer = 0;
unsigned int World::m_Score = 0;
bool World::m_Loaded = false;
ScoreMeter* World::m_ScoreMeter = 0;

Surface* World::m_Surface = 0;
Paddle* World::m_Paddle = 0;
Cannon* World::m_Cannon = 0;
Life* World::m_Lifes[3];

Flipper* World::m_LFlippers[LFLIPPERS];
Flipper* World::m_RFlippers[RFLIPPERS];
int World::m_Lives = 0;
int World::m_LeftIslandBallCounter[MAXBALLCOUNT];
float World::m_RailBallBuffer[MAXBALLCOUNT];
int World::m_RailBallCounter[MAXBALLCOUNT];
float World::m_LoopingTimer[MAXBALLCOUNT];
int World::m_BallTrampolineCounter[MAXBALLCOUNT];


void World::Init()
{
	if (m_Loaded) return;
	m_Loaded = true;
	matrix fm, fm2;
	Rotater* rt;

	// Initialize Managers
	EntityManager::Init(MAXSCENENODES-1);
	BallManager::Init(MAXBALLCOUNT);
	LightManager::Init(1024);
	ScoreMultiplier::Init();

	//// Load Skydome
	//Scene::m_SDScale = 512.0f;
	//Scene::m_Dome = MManager::NewPrimitive();
	//Material* dm = MManager::NewMaterial();
	//Color black( 0, 0, 0 );
	//Color white( 1, 1, 1 );
	//dm->SetDiffuse( black );
	//dm->SetSpecular( black );
	//dm->SetAmbient( white );
	//dm->SetEmissive( black );
	//dm->SetMinReflection( 0 );
	//dm->SetMaxReflection( 0 );
	//dm->SetRefraction( 0 );
	//Texture* t = MManager::NewTexture();
	//t->Init( "textures/skydome.hdr");
	//dm->SetTexture( t );
	//Scene::m_Dome->SetMaterial( dm );
	//Vertex* v1 = new Vertex(); v1->SetPos( vector3( -SKYDOMERADIUS, -SKYDOMERADIUS, -SKYDOMERADIUS ) );
	//Vertex* v2 = new Vertex(); v2->SetPos( vector3( SKYDOMERADIUS, SKYDOMERADIUS, SKYDOMERADIUS ) );
	//Vertex* v3 = new Vertex(); v3->SetPos( vector3( -SKYDOMERADIUS, SKYDOMERADIUS, SKYDOMERADIUS ) );
	//Scene::m_Dome->SetVertex( 0, v1 );
	//Scene::m_Dome->SetVertex( 1, v2 );
	//Scene::m_Dome->SetVertex( 2, v3 );	
	//Scene::m_Dome->m_N = vector3( 0, 0, 0 );
	//Scene::m_Dome->m_T = vector3( SKYDOMERADIUS, SKYDOMERADIUS * SKYDOMERADIUS, 1.0f / SKYDOMERADIUS );

	// Load the SkyBox
	rt = new Rotater();
	rt->Init("meshes/skybox_new.obj", fm, 10.0f);
	rt->SetRotateSpeed(20.0f);
	for (int i=0; i<rt->GetNode()->GetPrimCount(); ++i)	rt->GetNode()->GetPrim(i)->m_Material->SetAmbient(Color(2.5f, 2.5f, 2.5f));

	// Load Table
	Board* Table = new Board();
	fm.SetTranslation(vector3(0,-50,0));
	Table->Init("meshes/table.obj", fm, 10.0f);

	// Shiny Patches
	ShinyPatch* ShinyPatches = new ShinyPatch();
	fm.SetTranslation(vector3(0,-50,0));
	ShinyPatches->Init("meshes/shinyPatches.obj", fm, 10.0f);

	// Lifes
	m_Lifes[0] = new Life();
	fm.SetTranslation(vector3(47, -48, 91));
	m_Lifes[0]->Init("meshes/lifeCilinder.obj", fm, 10.0f);

	m_Lifes[1] = new Life();
	fm.SetTranslation(vector3(39, -48, 94));
	m_Lifes[1]->Init("meshes/lifeCilinder.obj", fm, 10.0f);

	m_Lifes[2] = new Life();
	fm.SetTranslation(vector3(28, -48, 97));
	m_Lifes[2]->Init("meshes/lifeCilinder.obj", fm, 10.0f);

	// BreakoutGrid
	BreakoutGrid* bgo = new BreakoutGrid();
	fm.SetTranslation(vector3(-45,-40.5f,-90));
	bgo->Init("meshes/coilBumper.obj", fm, 10.0f);

	// Paddle
	m_Paddle = new Paddle();
	fm.SetTranslation(vector3(-36, -36.5f, -43.8f));
	m_Paddle->Init("meshes/paddle.obj", fm, 10.0f);

	// Load Dial
	Dial* d = new Dial();
	fm.SetTranslation(vector3(0,-52.5f,0));
	d->Init("meshes/newdial.obj", fm, 12.0f);

	// Load Rotating Objects
	rt = new Rotater();
	fm.SetTranslation(vector3(-74, -46, -1));
	rt->Init("meshes/key.obj", fm, 10.0f);
	rt->SetRotateSpeed(-15.0f);
	rt->SetRotateSpeedOnHit(-500.0f);
	rt->SetScore(SCORE_KEY_HIT);

	rt = new Rotater();
	fm.SetTranslation(vector3(-63, -46, 33));
	rt->Init("meshes/key.obj", fm, 10.0f);
	rt->SetRotateSpeed(-15.0f);
	rt->SetRotateSpeedOnHit(-500.0f);
	rt->SetScore(SCORE_KEY_HIT);

	rt = new Rotater();
	fm.SetTranslation(vector3(-89, -46, 18));
	rt->Init("meshes/key.obj", fm, 10.0f);
	rt->SetRotateSpeed(15.0f);
	rt->SetRotateSpeedOnHit(500.0f);
	rt->SetScore(SCORE_KEY_HIT);

	// Gears Top Left
	rt = new Rotater();
	fm.RotateY(30);
	fm.SetTranslation(vector3(34, -52.9f, -57));
	rt->Init("meshes/leftWheel1.obj", fm, 10.0f);
	rt->SetRotateSpeed( 40.0f);

	rt = new Rotater();
	fm.SetTranslation(vector3(46.5f, -52.9f, -37));
	rt->Init("meshes/leftWheel2.obj", fm, 10.0f);
	rt->SetRotateSpeed(-80.0f);

	// Gears Center
	rt = new Rotater();
	fm.RotateY(5.0f);
	fm.SetTranslation(vector3(0, -70, 0));
	rt->Init("meshes/big_center_gear1.obj", fm, 5.0f);
	rt->SetRotateSpeed( 20.0f);

	rt = new Rotater();
	fm.SetTranslation(vector3(-17, -70, 16));
	rt->Init("meshes/big_center_gear2.obj", fm, 5.0f);
	rt->SetRotateSpeed(-20.0f);

	// Gears Top
	rt = new Rotater();
	fm.SetTranslation(vector3(-50.34f, -53, -61.95f));
	rt->Init("meshes/big_center_gear1.obj", fm, 5.0f);
	rt->SetRotateSpeed( 20.0f);

	//rt = new Rotater();
	//fm.SetTranslation(vector3(-36.31f, -53, -42.54f));
	//rt->Init("meshes/big_center_gear2.obj", fm, 5.0f);
	//rt->SetRotateSpeed(-20.0f);

	// Load MusicBox
	MusicBox* MB = new MusicBox();
	fm.RotateY(-40);
	fm.SetTranslation(vector3(12, -30, -80));
	MB->Init("meshes/lpPlayer.obj", fm, 20.0f);

	// Load Charge cylinder
	ChargeCylinder* cc;

	cc = new ChargeCylinder();
	fm.RotateY(30);
	fm.SetTranslation(vector3(45, -52.3f, 6));
	cc->Init("meshes/newchargeCylinder.obj", fm, 2.2f);

	cc = new ChargeCylinder();
	fm.RotateY(350);
	fm.SetTranslation(vector3(5, -52, -45));
	cc->Init("meshes/newchargeCylinder.obj", fm, 2.2f);

	// mushrooms
	Mushroom* st;
	st = new Mushroom();
	fm.SetTranslation(vector3(-35, -52.5f,-20));
	st->Init("meshes/mushroom.obj", fm, 15.0f);

	st = new Mushroom();
	fm.SetTranslation(vector3(-52, -52.5f,-18));
	st->Init("meshes/mushroom.obj", fm, 15.0f);

	st = new Mushroom();
	fm.SetTranslation(vector3(-47, -52.5f, 2));
	st->Init("meshes/mushroom.obj", fm, 15.0f);

	// Top Island
	st = new Mushroom();
	fm.SetTranslation(vector3(-59.36f, -37, -44.45f));
	st->Init("meshes/mushroom.obj", fm, 15.0f);


	st = new Mushroom();
	fm.SetTranslation(vector3(-83.14f, -37, -55.73f));
	st->Init("meshes/mushroom.obj", fm, 15.0f);

	st = new Mushroom();
	fm.SetTranslation(vector3(-79.36f, -37, -30.99f));
	st->Init("meshes/mushroom.obj", fm, 15.0f);

	// Left Island
	st = new Mushroom();
	fm.SetTranslation(vector3(91.11f, -52.5f, -45.61f));
	st->Init("meshes/mushroom.obj", fm, 15.0f);

	st = new Mushroom();
	fm.SetTranslation(vector3(65, -52.5f, -19.25f));
	st->Init("meshes/mushroom.obj", fm, 15.0f);

	st = new Mushroom();
	fm.SetTranslation(vector3(91.95f, -52.5f, -8.15f));
	st->Init("meshes/mushroom.obj", fm, 15.0f);

	// bumpers
	Bumper* bp;

	// main bumpers
	bp = new Bumper();
	fm.RotateY(190);
	fm.SetTranslation(vector3(25, -52, 65.5f));
	bp->Init("meshes/kicker.obj", fm, 22.0f);

	bp = new Bumper();
	fm.RotateY(-60);
	fm.SetTranslation(vector3(-25, -52, 72.5f));
	bp->Init("meshes/kicker.obj", fm, 22.0f);

	// cannon
	m_Cannon = new Cannon();
	fm.RotateY(130);
	fm.SetTranslation(vector3(61.78f, -36, 55.84f));
	m_Cannon->Init(fm, 7.0f);
	m_Cannon->SetResetRot(160.0f);

	// Targets
	HitTarget* ht;

	// Left Center
	HitTargetBucket* htb = new HitTargetBucket();
	fm.SetTranslation(vector3(33, -52, 20));
	htb->Init("", fm, 0);

	ht = new HitTarget();
	fm.RotateY(180);
	fm.SetTranslation(vector3(49.8f, -53, 26));
	ht->Init("meshes/target.obj", fm, 20.0f);
	ht->SetOwner(htb);

	ht = new HitTarget();
	fm.RotateY(180);
	fm.SetTranslation(vector3(49.7f, -53, 30));
	ht->Init("meshes/target.obj", fm, 20.0f);
	ht->SetOwner(htb);

	ht = new HitTarget();
	fm.RotateY(180);
	fm.SetTranslation(vector3(49.6f, -53, 34));
	ht->Init("meshes/target.obj", fm, 20.0f);
	ht->SetOwner(htb);

	ht = new HitTarget();
	fm.RotateY(180);
	fm.SetTranslation(vector3(49.5, -53, 38));
	ht->Init("meshes/target.obj", fm, 20.0f);
	ht->SetOwner(htb);

	// Targets - right island
	HitTargetBucket* htb2 = new HitTargetBucket();
	fm.SetTranslation(vector3(33, -52, 20));
	htb2->Init("", fm, 0);

	const vector3 begpos( -67.14f, -49.00f, -20.30f );
	const vector3 endpos( -93.21f, -48.00f, -36.78f );
	for(int i=0; i<6; i++)
	{
		vector3 pos = begpos + (endpos-begpos)*float(i)/6.0f;
		ht = new HitTarget();
		fm.RotateY(125);
		fm.SetTranslation(pos);
		ht->Init("meshes/target.obj", fm, 20.0f);
		ht->SetOwner(htb2);
	}

	// Targets - left island
	HitTargetBucket* htb3 = new HitTargetBucket();
	fm.SetTranslation(vector3(33, -52, 20));
	htb3->Init("", fm, 0);

	const vector3 begpos2( 77.11f, -52.0f, -67.02f );
	const vector3 endpos2( 59.79f, -52.5f, -58.77f );
	for(int i=0; i<4; i++)
	{
		vector3 pos = begpos2 + (endpos2-begpos2)*float(i)/4.0f;
		ht = new HitTarget();
		fm.RotateY(60);
		fm.SetTranslation(pos);
		ht->Init("meshes/target.obj", fm, 20.0f);
		ht->SetOwner(htb3);
	}

	// Create da flipper
	for (int i=0; i<LFLIPPERS; ++i)
	{
		m_LFlippers[i] = new Flipper();
		m_LFlippers[i]->SetRotateDir(true);
	}
	for (int i=0; i<RFLIPPERS; ++i)
	{
		m_RFlippers[i] = new Flipper();
		m_RFlippers[i]->SetRotateDir(false);
	}

	//  Set Flippers
	fm.RotateY(-30);
	fm.SetTranslation(vector3( 16, -52, 93));
	m_LFlippers[0]->Init("meshes/flipperLeft.obj",fm,25.0f);
	
	fm.RotateY(-40);
	fm.SetTranslation(vector3(100, -52, 16));
	m_LFlippers[1]->Init("meshes/flipperLeft.obj",fm,20.0f);

	fm.RotateY(-80);
	fm.SetTranslation(vector3(-47.80f, -52, 48.85f));
	m_LFlippers[2]->Init("meshes/flipperLeft.obj",fm,20.0f);

	fm.RotateY(180+30);
	fm.SetTranslation(vector3(-20, -52, 93));
	m_RFlippers[0]->Init("meshes/flipper.obj",fm,25.0f);

	// Add scoremeter
	fm.RotateY(180);
	fm2.RotateX(224);
	fm.Concatenate(fm2);
	fm.SetTranslation(vector3(0,-45,120));
	m_ScoreMeter = new ScoreMeter();
	m_ScoreMeter->Init( "meshes/scorecylinder.obj", 0.2f );

	// do evil GI stuff
	SceneGraph::Update();
	Scene::UpdateSceneExtends();
}


void World::IncScore(unsigned int a_Score)
{
	m_Score += (a_Score << ScoreMultiplier::GetMultiplier());
}
void World::NewGame()
{
	Scene::SetAmbient(Color(0.15f,0.15f,0.15f));

	SoundManager::PlayLooped( "Sound/Ingame/ball_rolling_edit.ogg", CHANNEL_BALLROLL );
	SoundManager::PlayLooped( "Sound/Ingame/clockgears.ogg", CHANNEL_GEARS );
	SoundManager::SetVolume(0, CHANNEL_BALLROLL);
	SoundManager::SetVolume(0, CHANNEL_GEARS);

	EntityManager::UpdateQuality();

	// set initial camera position and target
	Config::CamRot = vector3(-25,180,0);
	Scene::GetCamera()->SetPosition( vector3( 0, 0, 125 ) );
	Scene::GetCamera()->SetTarget( vector3( -1.0, 0, 0.0 ) );

	// Reset all entities
	ScoreMultiplier::SetMultiplier(0);
	EntityManager::ResetEntities();

	// Reset Variables
	m_Lives = 3;
	m_Score = 0;
	for (int i=0; i<MAXBALLCOUNT; ++i)
	{
		m_LeftIslandBallCounter[i] = 0;
		m_RailBallBuffer[i] = 0;
		m_RailBallCounter[i] = 0;
		m_BallTrampolineCounter[i] = 0;
		m_LoopingTimer[i] = 0;
	}

	// Reset Camera
	GameCam::Init();
	m_TimeLeft = 0.0f;
}

void World::ExitGame()
{
	while (BallManager::GetActiveBallCount() > 0) BallManager::DeleteBall(0);
	m_Lives = 0;
}

void World::Tick( float a_DT )
{
	GameCam::SetZoom(false);

	// Physics and entity updates
	BallManager::ResetPhysics( a_DT );
	wallclock_t elap; elap.reset();
	m_TimeLeft += a_DT;
	while (m_TimeLeft >= Config::B_TimeStep)
	{
		EntityManager::StepTick(Config::B_TimeStep);
		BallManager::StepTick(Config::B_TimeStep);
		EntityManager::RunHits(Config::B_TimeStep);
		m_TimeLeft -= Config::B_TimeStep;
	}
	
	// Ball rolling sound
	float mindist = 65536.0f; int ballID = -1;
	const float minbound = 5.0f, maxbound = 200.0f;
	for(int i=0; i<BallManager::GetActiveBallCount(); i++)
	{
		vector3 vdist = BallManager::GetBallById(i)->GetPos() - GameCam::GetPos();
		if( vdist.SqrLength() < mindist*mindist ){ mindist = vdist.Length(); ballID=i; }
	}
	float volumef = 1.0f - ( mindist - minbound ) / ( maxbound - minbound );
	if( ballID != -1 )
	{
		vector3 vspeed = BallManager::GetBallById(ballID)->GetVelocity();
		volumef *= vector3(vspeed.x, 0, vspeed.z).Length() * 0.01f;
	}
	int volumei = MIN( 255, MAX( 0, volumef * 255.0f ) );
	SoundManager::SetVolume( volumei, CHANNEL_BALLROLL );

	// Clock gear sound
	vector3 vgeardist = vector3(0, -50, 2) - GameCam::GetPos();
	const float dist = vgeardist.Length();
	const float gminbound = 20.0f, gmaxbound = 100.0f;
	volumef = 1.0f - ( dist - gminbound ) / ( gmaxbound - minbound );
	volumei = MIN( 255, MAX( 0, volumef * 255.0f ) );
	SoundManager::SetVolume(volumei, CHANNEL_GEARS);

	// Tilt
	m_TiltTimer -= a_DT*0.5f;
	if (m_TiltTimer < 0.0f) m_TiltTimer = 0.0f;

	// Update World
	GameCam::Tick(a_DT);
	m_ScoreMeter->Tick( a_DT );

	ScoreMultiplier::Update( a_DT );
	EntityManager::Tick( a_DT );
	BallManager::Tick( a_DT );
	LightManager::Tick( a_DT );

	// Update Life Cylinders
	for (int i=0; i<3; ++i)	m_Lifes[i]->SetActive(i<m_Lives);

	// Update Ball
	BallManager::UpdateBallPositions();
	if (BallManager::GetActiveBallCount() > 0)
	{
		if (GameCam::GetCamMode()==GameCam::CAM_GAME || GameCam::GetCamMode()==GameCam::CAM_LEFT_ISLAND)
		{
			GameCam::SetCamMode(GameCam::CAM_LEFT_ISLAND);
			for (int i=0; i<BallManager::GetActiveBallCount(); ++i)
			{
				if (m_LeftIslandBallCounter[i] == 0) GameCam::SetCamMode(GameCam::CAM_GAME);
				m_LeftIslandBallCounter[i] = 0;
			}
		}
		if (GameCam::GetCamMode()==GameCam::CAM_GAME || GameCam::GetCamMode()==GameCam::CAM_RAILS)
		{
			GameCam::SetCamMode(GameCam::GameCam::CAM_RAILS);
			for (int i=0; i<BallManager::GetActiveBallCount(); ++i)
			{
				m_RailBallBuffer[i] -= a_DT; 
				if (m_RailBallBuffer[i] <= 0.0f) GameCam::SetCamMode(GameCam::CAM_GAME);
				if (m_RailBallCounter[i] > 0) m_RailBallBuffer[i] += a_DT*3.0f;
				if (m_RailBallBuffer[i] < -0.25f) m_RailBallBuffer[i] = -0.25f;
				if (m_RailBallBuffer[i] > 0.25f) m_RailBallBuffer[i] = 0.25f;
				m_RailBallCounter[i] = 0;
			}
		}
		for (int i=0; i<BallManager::GetActiveBallCount(); ++i)
		{
			if (m_BallTrampolineCounter[i] > 0) 
			{
				m_LoopingTimer[i] += a_DT;
				if (m_LoopingTimer[i] > 0.5f)
				{
					m_LoopingTimer[i] = 0.0f;
					BallManager::GetBallById(i)->SetPos(vector3(77.55f, -50, 36.93f));
					BallManager::GetBallById(i)->SetVelocity(vector3(0,10000,0));			
				}
			} 
			m_BallTrampolineCounter[i] = 0;
		}						
		if (GameCam::GetCamMode()==GameCam::CAM_GAME || GameCam::GetCamMode()==GameCam::CAM_ARKANOID)
		{
			GameCam::SetCamMode(GameCam::CAM_ARKANOID);
			for (int i=0; i<BallManager::GetActiveBallCount(); ++i)
			{
				Ball* ball = BallManager::GetBallById(i);
				if (ball->GetRadius() >= BALLSIZE) GameCam::SetCamMode(GameCam::CAM_GAME);
			}
		}
	}
	Config::PhysicsCosts = (float)elap.elapsed();

	elap.reset();
	SceneGraph::Update();
	Config::SceneUpdateCost = (float)elap.elapsed();

	Scene::GetCamera()->SetPosition(GameCam::GetPos());
	Scene::GetCamera()->SetTarget(GameCam::GetTarget());
}	

void World::PostRender()
{
	//EntityManager::PostRender();
	//BallManager::PostRender();
}

void World::KeyPress( )
{
	//// Balls
	//if (Config::Key_Press['1']) Config::B_Gravity += 10.0f;
	//if (Config::Key_Press['2']) Config::B_Gravity -= 10.0f;
	//if (Config::Key_Press['3']) Config::B_Friction += 0.05f;
	//if (Config::Key_Press['4']) Config::B_Friction -= 0.05f;
	//if (Config::Key_Press['5']) Config::B_MaxSpeed += 10.0f;
	//if (Config::Key_Press['6']) Config::B_MaxSpeed -= 10.0f;
	//if (Config::Key_Press['7']) Config::B_Bouncyness += 5.0f;
	//if (Config::Key_Press['8']) Config::B_Bouncyness -= 5.0f;
	//if (Config::Key_Press['9']) Config::B_Slowdown += 0.05f;
	//if (Config::Key_Press['0']) Config::B_Slowdown -= 0.05f;

	// Tilt
	if (Config::Key_Press[VK_SPACE]) 
	{
		if (m_TiltTimer < 2.0f) 
		{
			GameCam::Tilt();
			BallManager::AddTiltForce();
			m_TiltTimer += 0.75f;
			if (m_TiltTimer > 2.5f) m_TiltTimer = 2.5f;
		}
		if (m_TiltTimer >= 2.0f) SoundManager::Play("Sound/Ingame/tilt.wad",CHANNEL_SPEECH);
	}
	
	if (Config::Key_Press[VK_RETURN])
	{ 
		if (BallManager::GetActiveBallCount() < m_Lives)
		{
			BallManager::AddBall(vector3(0, -40.0f, 0),vector3(0,50,0),BALLSIZE);
			SoundManager::Play( "Sound/Ingame/ball_bell.ogg",CHANNEL_EVENT_1 );
			SoundManager::Play( "Sound/Ingame/ball_spawn.wav",CHANNEL_EVENT_1 );
			if( BallManager::GetActiveBallCount() > 1 )
				SoundManager::Play( "Sound/Ingame/Multiball.wad", CHANNEL_SPEECH );
		}
	}

	// Flippers
	if (!GetTilted())
	{
		bool flipleft = GetAsyncKeyState(VK_LCONTROL) || GetAsyncKeyState(VK_LSHIFT) || GetAsyncKeyState('Z');
		bool flipright = GetAsyncKeyState(VK_RCONTROL) || GetAsyncKeyState(VK_RSHIFT) || GetAsyncKeyState('M');
		
		for (int i=0; i<LFLIPPERS; ++i) m_LFlippers[i]->Flip(flipleft);
		for (int i=0; i<RFLIPPERS; ++i)	m_RFlippers[i]->Flip(flipright);

		m_Paddle->SetStatus(Paddle::IDLE);
		if (flipleft && (!flipright)) m_Paddle->SetStatus(Paddle::LEFT);
		if ((!flipleft) && flipright) m_Paddle->SetStatus(Paddle::RIGHT);

		m_Cannon->SetRotate(0);
		if (flipleft) m_Cannon->AddRotate(1);
		if (flipright) m_Cannon->AddRotate(-1);
	}

	// Cam Modes
	if (Config::Key_Press[VK_F2]) GameCam::SetCamMode(GameCam::CAM_FREE);
	if (Config::Key_Press[VK_F3]) GameCam::SetCamMode(GameCam::CAM_GAME);
	//if (Config::Key_Press[VK_F7])
	//{
	//	GameCam::SetCamMode( GameCam::CAM_RAILS );
	//	//vector3 pos = Scene::GetCamera()->GetPosition();
	//	//vector3 vel = Scene::GetCamera()->GetTarget()-pos;
	//	//BallManager::AddBall(pos,vel*1000,BALLSIZE);	
	//}

	//// Misc
	//if (Config::Key_Press['Y']) if (BallManager::GetActiveBallCount() > 0) BallManager::DeleteBall(0);
	////if (Config::Key_Press['C'])
	////{
	////	vector3 pos = Scene::GetCamera()->GetPosition();
	////	char t[128];
	////	sprintf(t,"CamPos: %2.2ff, %2.2ff, %2.2ff", pos.x, pos.y, pos.z);
	////	Log::Message(t);
	////}

	//if (Config::Key_Down['X'])
	//{
	//	vector3 pos = BallManager::GetBallById(0)->GetPos();
	//	char t[128];
	//	sprintf(t,"BalPos: %2.2ff, %2.2ff, %2.2ff", pos.x, pos.y, pos.z);
	//	Log::Message(t);
	//}

	//if (Config::Key_Press[VK_F5])
	//{
	//	m_ShootLast = Scene::GetCamera()->GetPosition();
	//	m_ShootPos = Scene::GetCamera()->GetTarget()-m_ShootLast;
	//}
	//if (Config::Key_Press[VK_F6])
	//{
	//	BallManager::AddBall(m_ShootLast,m_ShootPos*1000,BALLSIZE);	
	//}
	//if (Config::Key_Press[VK_F7])
	//{
	//	BallManager::AddBall(m_ShootLast,vector3(0,0,0),BALLSIZE);	
	//}
}


// ====================================================

bool GameCam::m_Zoom = false;
float GameCam::m_ZoomFactor = 0.0f, GameCam::m_FollowFactor = 0.0f, GameCam::m_Tilt = 0.0f;
vector3 GameCam::m_Campos;
vector3 GameCam::m_Target;
vector3 GameCam::m_Camrot;
GameCam::CamMode GameCam::m_CamMode = GameCam::CAM_GAME;

void GameCam::Init()
{
	m_Campos = CAM_ORIGINPOS;
	m_Camrot = CAM_ORIGINROT;
	m_Target = CAM_ORIGINPOS + vector3( 0.0f, 0.0f, 1.0f );
}

void GameCam::Tick( float a_DT )
{
	// Camera
	matrix m, m2;
	if(m_CamMode != CAM_FREE )
	{
		if( BallManager::GetActiveBallCount() <= 0 || BallManager::GetActiveBallCount() > 1 || m_CamMode == CAM_CANNON || m_CamMode == CAM_ARKANOID || m_CamMode == CAM_LEFT_ISLAND || m_CamMode == CAM_RAILS )
		{
			vector3 rotvec = CAM_ORIGINROT, posvec = CAM_ORIGINPOS;
			if( m_CamMode == CAM_CANNON ){ rotvec = CAM_CANNONROT; posvec = CAM_CANNONPOS; }
			if( m_CamMode == CAM_ARKANOID ){ rotvec = CAM_ARKAROT; posvec = CAM_ARKAPOS; }
			if( m_CamMode == CAM_LEFT_ISLAND ){ rotvec = CAM_LISLANDROT; posvec = CAM_LISLANDPOS; }
			if( m_CamMode == CAM_RAILS && BallManager::GetActiveBallCount() > 0 )
			{
				const vector3 ballpos = BallManager::GetBallById(0)->GetPos();
				const vector3 balldir = BallManager::GetBallById(0)->GetVelocity().Normalized();
				posvec = ballpos - balldir * 50.0f + vector3(0, 35.0f, 0);
				m_Target = ballpos;
			}

			const vector3 tPos = posvec - m_Campos;
			m.RotateY( rotvec.y );
			m2.RotateX( rotvec.x );
			m.Concatenate( m2 );
			const vector3 tTar = posvec + vector3( m[2] * 10.0f, m[6] * 10.0f, m[10] * 10.0f ) - m_Target;

			m_Campos += tPos * a_DT * 4.0f;
			if( m_CamMode != CAM_RAILS ) m_Target += tTar * a_DT * 4.0f;

			m_FollowFactor = 0.0f;
		}
		else
		{
			const float mindist = BALLDIST_NEAR, maxdist = BALLDIST_FAR;
			
			const vector3 origin = CAM_ORIGINPOS;
			const vector3 ballpos = BallManager::GetBallById(0)->GetPos();
			const float ballspeed = BallManager::GetBallById(0)->GetVelocity().Length();

			// Change zoom
			if(m_Zoom)
			{
				m_ZoomFactor += a_DT * 2.0f * (ballspeed / Config::B_MaxSpeed);
			}
			else 
			{
				m_ZoomFactor -= a_DT * 4.0f * (ballspeed / Config::B_MaxSpeed);
			}

			// Clamp zoom
			if(m_ZoomFactor > 1.0f) m_ZoomFactor = 1.0f;
			if(m_ZoomFactor < 0.0f) m_ZoomFactor = 0.0f;

			// Apply zoom
			vector3 vdist = origin - ballpos; vdist.Normalize();
			const float zoomcos = -cos( m_ZoomFactor * PI ) * 0.5f + 0.5f;
			const vector3 tarBallPos = ballpos + vdist * ( mindist + (maxdist-mindist)*(1.0f-zoomcos) );

			if( m_FollowFactor < 1.0f )
			{
				// Interpolate origin and ball folowing cam
				m.RotateY( 180 );
				m2.RotateX( -25 );
				m.Concatenate( m2 );
				m_Campos = (tarBallPos * m_FollowFactor) + (origin * (1.0f - m_FollowFactor) );
				const vector3 tTar = m_Campos + vector3( m[2] * 10.0f, m[6] * 10.0f, m[10] * 10.0f );

				m_FollowFactor += a_DT;
				m_Target = (BallManager::GetBallById(0)->GetPos() * m_FollowFactor) + (tTar * (1.0f - m_FollowFactor) );
			}
			else
			{ 
				// set to ball following cam
				m_FollowFactor = 1.0f;
				m_Target = BallManager::GetBallById(0)->GetPos();
				m_Campos = tarBallPos;
			}
		}

		// Apply tilt force
		if( m_Tilt > 0 )
		{
			m_Tilt -= a_DT * 4.0f;
			if( m_Tilt < 0 ) m_Tilt = 0;
			vector3 tiltvec = m_Target - m_Campos;
			const float yforce = sin(m_Tilt * 32.0f) * m_Tilt;
			m.Identity();
			m.RotateX( yforce * 4.0f );
			vector3 resvec = m.Transform( tiltvec );
			m_Target = m_Campos + resvec;
		}
	}
	else if (m_CamMode == CAM_FREE)
	{
		// If right mouse key is pressed then rotate camera
		if (Config::Mouse_Down[2])
		{
			int diffx = max( min( Config::Mouse_X-Config::Mouse_PrevX, 50), -50 );
			int diffy = max( min( Config::Mouse_Y-Config::Mouse_PrevY, 50), -50 );
			m_Camrot.x -= float(diffy) * 0.5f;
			m_Camrot.y -= float(diffx) * 0.5f;
			if (m_Camrot.y < 0)		m_Camrot.y += 360;
			if (m_Camrot.y > 360)	m_Camrot.y -= 360;
			if (m_Camrot.x < -85)	m_Camrot.x = -85;
			if (m_Camrot.x > 85)	m_Camrot.x = 85;
		}

		// setup a matrix for the camera
		m.RotateY( m_Camrot.y );
		m2.RotateX( m_Camrot.x );
		m.Concatenate( m2 );

		// handle key movement
		float speed = 30.0f * a_DT;
		if (Config::Key_Down[VK_SHIFT]) speed *= 3.0f;
		if (Config::Key_Down['W']) m_Campos += speed * vector3( m[2], m[6], m[10] );
		if (Config::Key_Down['A']) m_Campos -= speed * vector3( m[0], m[4], m[8] );
		if (Config::Key_Down['D']) m_Campos += speed * vector3( m[0], m[4], m[8] );
		if (Config::Key_Down['S']) m_Campos -= speed * vector3( m[2], m[6], m[10] );
		if (Config::Key_Down['Q']) m_Campos -= speed * vector3( m[1], m[5], m[9] );
		if (Config::Key_Down['E']) m_Campos += speed * vector3( m[1], m[5], m[9] );

		// store position and orientation in the camera object
		m_Target = m_Campos + vector3( m[2], m[6], m[10] );
	}
}


};