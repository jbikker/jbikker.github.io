// --------------------------------------------------------------------------
// Copyright (c) Mark Peters and Bram van de Wetering 2009
// --------------------------------------------------------------------------

#include "Entities.h"
#include "core.h"					// main renderer functions
#include "scene.h"					// main scene functions
#include "memory.h"					// for MManager::NewMaterial()
#include "surface.h"				// graphics surface functions
#include "scenegraph.h"				// for SceneGraph::Update()

using namespace Raytracer;

// -----------------------------------------------------------
// EntityManager Class
// -----------------------------------------------------------
Entity** EntityManager::m_Entities;
int EntityManager::m_MaxEntities = 0;
int EntityManager::m_NextEntityId = 0;

void EntityManager::Init(int a_MaxEntities)
{
	m_MaxEntities = a_MaxEntities;
	m_Entities = new Entity*[m_MaxEntities];
	m_NextEntityId = 0;
}

int EntityManager::AddEntity(Entity* a_Entity)
{
	if (m_NextEntityId < m_MaxEntities)
	{
		m_Entities[m_NextEntityId] = a_Entity;
		m_Entities[m_NextEntityId]->SetId(m_NextEntityId);
		m_NextEntityId++;
	}
	return m_NextEntityId-1;
}

void EntityManager::DeleteEntity(int a_ID)
{
	--m_NextEntityId;
	if ( a_ID != m_NextEntityId ) 
	{
		Entity* ent = m_Entities[a_ID];
		m_Entities[a_ID] = m_Entities[m_NextEntityId];
		m_Entities[m_NextEntityId] = ent;
	}
}

void EntityManager::Tick(float a_DT)
{
	for (int i=0; i<m_NextEntityId; ++i)
	{
		m_Entities[i]->Tick(a_DT);
	}
}

void EntityManager::StepTick(float a_DT)
{
	for (int i=0; i<m_NextEntityId; ++i)
	{
		m_Entities[i]->StepTick(a_DT);
	}
}

void EntityManager::RunHits(float a_DT)
{
	for (int i=0; i<m_NextEntityId; ++i)
	{
		if (m_Entities[i]->GetHitFlag()) m_Entities[i]->Hit(a_DT);
		m_Entities[i]->ResetHits();
	}
}

void EntityManager::UpdateQuality()
{
	for (int i=0; i<m_NextEntityId; ++i)
	{
		m_Entities[i]->UpdateQuality();
	}
}

void EntityManager::PostRender()
{
	for (int i=0; i<m_NextEntityId; ++i)
	{
		m_Entities[i]->PostRender();
	}
}

void EntityManager::ResetEntities()
{
	for (int i=0; i<m_NextEntityId; ++i)
	{
		m_Entities[i]->Reset();
	}
}

Entity* EntityManager::GetEntityByMaterial(const Material* a_Mat)
{
	for (int i=0; i<m_NextEntityId; ++i)
	{
		if (m_Entities[i]->ContainsMaterial(a_Mat))
		{
			return m_Entities[i];
		}
	}
	return NULL;
}

Entity::Entity()
{
	EntityManager::AddEntity(this);
	m_MatCount = 0;
	m_MatList = 0;
}

bool Entity::ContainsMaterial(const Material* a_Mat)
{
	for (int i=0; i<m_MatCount; ++i)
	{
		if (m_MatList[i] == a_Mat)
		{
			return true;
		}
	}
	return false;
}

void Entity::BuildMatList()
{
	m_MatCount = 0;
	m_MatList = new Material*[32];
	for (int i=0; i<m_Node->GetPrimCount(); ++i)
	{
		Material* mat=m_Node->GetPrim(i)->m_Material;
		bool valid=true;
		for (int j=0; j<m_MatCount; j++)
		{
			if (m_MatList[j]==mat) valid = false;
		}
		if (valid)
		{
			char t[128];
			sprintf(t, "%s%i_%i", mat->GetName(), GetId(), m_MatCount );
			Log::Message(mat->GetName());
			mat->SetName(t);
			m_MatList[m_MatCount] = mat;
			m_MatCount++;
		}
	}
}

Material* Entity::GetMaterialByName(char* a_Name)
{
	char t[64];
	for (int i=0; i<m_MatCount; ++i)
	{
		sprintf(t, "%s%i_%i", a_Name, GetId(), i );
		if (!strcmp(m_MatList[i]->GetName(),t))
		{
			return m_MatList[i];
		}
	}
	//sprintf(t, "Material not found: %s", a_Name);
	//Log::Message(t);
	return NULL;
}