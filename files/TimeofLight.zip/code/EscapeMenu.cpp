#include "EscapeMenu.h"
#include "Config.h"
#include "Surface.h"
#include "Drawing2D.h"
#include "MenuItems.h"
#include "Core.h"
#include "SoundManager.h"
#include "Entities.h"

namespace Raytracer {

struct
{
	int LightQ, Refl, AA;
	int Svol, Mvol;
} escopts;

// --------------------------------------------------------------------------
// Escape Menu Buttons
// --------------------------------------------------------------------------

extern Surface* buttonBack, *buttonBackSealed, *buttonImg;
extern Surface* buttonOptions, *buttonQuitGame, *buttonApply;
Surface* buttonResume, *buttonToMenu;

Button* Button_Esc_Resume;
Button* Button_Esc_Options;
Button* Button_Esc_ToMenu;
Button* Button_Esc_QuitGame;

Button* Button_Esc_Yes;
Button* Button_Esc_No;

Button* Button_Esc_Back;
Button* Button_Esc_Apply;

Slider* Slider_Esc_LOD;
Slider* Slider_Esc_LIT;
Slider* Slider_Esc_AAS;

SliderBar* SliderBar_Esc_SoundVol;
SliderBar* SliderBar_Esc_MusicVol;

AskWindow* AskWindow_ToMain;
AskWindow* AskWindow_Quit;

// MainMenu Member Data
Surface* EscapeMenu::m_Background = 0;
int EscapeMenu::m_Fase = EM_NULL;
float EscapeMenu::m_Fade = 0.0f;
float EscapeMenu::m_WinW = 16, EscapeMenu::m_WinH = 16;
float EscapeMenu::m_TarW = 16, EscapeMenu::m_TarH = 16;
float EscapeMenu::m_Timer = 0.0f;
bool EscapeMenu::m_Resume = false;
bool EscapeMenu::m_ToMenu = false;
bool EscapeMenu::m_Ask1 = false;
bool EscapeMenu::m_Ask2 = false;

// --------------------------------------------------------------------------
// Main Functions
// --------------------------------------------------------------------------

void EMSetPositions()
{
	const int centerX = (Config::S_scrWidth>>1);
	const int centerY = (Config::S_scrHeight>>1);

	Button_Esc_Resume->setPos(centerX, centerY-64);
	Button_Esc_Options->setPos(centerX, centerY-32);
	Button_Esc_ToMenu->setPos(centerX, centerY);
	Button_Esc_QuitGame->setPos(centerX, centerY+32);

	Button_Esc_Back->setPos(centerX, 0);
	Button_Esc_Apply->setPos(centerX, centerY+48);

	SliderBar_Esc_SoundVol->setPos(centerX-8, centerY);
	SliderBar_Esc_MusicVol->setPos(centerX-8, centerY-16);

	Slider_Esc_LOD->setPos( centerX-8, centerY-80 );
	Slider_Esc_LIT->setPos( centerX-8, centerY-64 );
	Slider_Esc_AAS->setPos( centerX-8, centerY-48 );
}

void EMResetPositions()
{
	Button_Esc_Resume->jumpToStart(); Button_Esc_Options->jumpToStart();
	Button_Esc_ToMenu->jumpToStart(); Button_Esc_QuitGame->jumpToStart();

	Button_Esc_Back->jumpToStart();	Button_Esc_Apply->jumpToStart();

	SliderBar_Esc_SoundVol->jumpToStart();
	SliderBar_Esc_MusicVol->jumpToStart();

	Slider_Esc_LOD->jumpToStart();
	Slider_Esc_LIT->jumpToStart();
	Slider_Esc_AAS->jumpToStart();
}

void EscapeMenu::Init()
{
	// Create background image
	m_Background = new Surface(Config::S_scrWidth, Config::S_scrHeight);

	buttonResume = new Surface("images/Menu Images/Button_Resume.tga");
	buttonToMenu = new Surface("images/Menu Images/Button_ToMenu.tga");

	// Create buttons, sliders and misc
	Button_Esc_Resume = new Button(buttonResume,32);
	Button_Esc_Options = new Button(buttonOptions,32);
	Button_Esc_ToMenu = new Button(buttonToMenu,32);
	Button_Esc_QuitGame = new Button(buttonQuitGame,32);

	Button_Esc_Back = new Button(buttonBack,24);
	Button_Esc_Apply = new Button(buttonApply,32);

	Slider_Esc_LOD = new Slider(128, 5, escopts.LightQ, "Lighting Quality");
	Slider_Esc_LIT = new Slider(128, 5, escopts.Refl, "Material Quality");
	Slider_Esc_AAS = new Slider(128, 9, escopts.AA, "Anti Aliasing");
	Slider_Esc_LOD->SetState(0,"Min"); Slider_Esc_LOD->SetState(-1,"Max");

	SliderBar_Esc_SoundVol = new SliderBar( 96, escopts.Svol, "Sound Volume" );
	SliderBar_Esc_MusicVol = new SliderBar( 96, escopts.Mvol, "Music Volume" );

	AskWindow_ToMain = new AskWindow(	"Are you sure you want to go to the main menu?",
										"The current game will not be saved", 288, 32 );
	AskWindow_Quit = new AskWindow(		"Are you sure you want to quit to desktop?",
										"The current game will not be saved", 288, 32 );
	EMSetPositions();
}

void EscapeMenu::Resize()
{
	// Resize background image to new resolution
	Surface* temp = new Surface(m_Background->GetWidth(), m_Background->GetHeight());
	ResizeIMG(temp, m_Background);
	delete m_Background;
	m_Background = new Surface(Config::S_scrWidth, Config::S_scrHeight);
	ResizeIMG(m_Background, temp);
	delete temp;

	// Reset positions
	EMSetPositions();

	// Recreate Ask popups
	delete AskWindow_ToMain;
	delete AskWindow_Quit;
	AskWindow_ToMain = new AskWindow(	"Are you sure you want to go to the main menu?",
										"The current game will not be saved", 288, 32 );
	AskWindow_Quit = new AskWindow(		"Are you sure you want to quit to desktop?",
										"The current game will not be saved", 288, 32 );
}

void EscapeMenu::Enter( Surface* a_BG )
{
	m_Resume = m_ToMenu = m_Ask1 = m_Ask2 = false;
	m_WinW = 0, m_WinH = 0;
	SetFase(EM_MAIN);
	m_Fade = 256.0f;
	Sephia(m_Background, a_BG);
	EMResetPositions();
	m_Timer = 0;
}

void EscapeMenu::SetFase( int a_Fase )
{
	if( a_Fase == m_Fase ) return;
	m_Fase = a_Fase;
	const bool inOpts = InFase(EM_OPTS), inMain = InFase(EM_MAIN);

	Button_Esc_Resume->setActive(inMain),	Button_Esc_ToMenu->setActive(inMain);
	Button_Esc_Options->setActive(inMain),	Button_Esc_QuitGame->setActive(inMain);

	Slider_Esc_LOD->setActive(inOpts);
	Slider_Esc_LIT->setActive(inOpts);
	Slider_Esc_AAS->setActive(inOpts);

	SliderBar_Esc_SoundVol->setActive(inOpts);
	SliderBar_Esc_MusicVol->setActive(inOpts);

	Button_Esc_Apply->setActive(inOpts);
	Button_Esc_Back->setActive(inOpts);

	if(InFase(EM_OPTS))
	{
		LoadSettings();
		m_TarW = 320.0f, m_TarH = 208.0f;
	}
	if(InFase(EM_TOMM)){ m_TarW = 0, m_TarH = 0; }
	if(InFase(EM_MAIN)){ m_TarW = 192.0f, m_TarH = 144.0f; }
}

void EscapeMenu::Exit()
{
	SetFase(EM_NULL);
	AskWindow_ToMain->Exit();
	AskWindow_Quit->Exit();
}

void EscapeMenu::LoadSettings()
{
	escopts.LightQ = Config::S_lightingQuality;
	escopts.Refl = Config::S_reflections;
	escopts.AA = Config::S_antiAliasing;
	escopts.Svol = Config::S_soundVol;
	escopts.Mvol = Config::S_musicVol;
}

void EscapeMenu::SaveSettings()
{
	// Save To Config
	Config::S_lightingQuality = escopts.LightQ;
	Config::S_reflections = escopts.Refl;
	Config::S_antiAliasing = escopts.AA;

	Config::S_soundVol = escopts.Svol;
	Config::S_musicVol = escopts.Mvol;

	// Save To file
	Log::Message( "Saving option settings (config.txt)..." );
	FILE* f = fopen( "config.txt", "w" ); if(!f) return;
	fprintf(f, "scrwidth %i\n", Config::S_scrWidth );
	fprintf(f, "scrheight %i\n", Config::S_scrHeight );
	fprintf(f, "fullscreen %i\n", (Config::S_fullscreen)?1:0);
	fprintf(f, "fixratio %i\n", (Config::S_fixRatio)?1:0);

	fprintf(f, "lighting %i\n", escopts.LightQ );
	fprintf(f, "reflections %i\n", escopts.Refl );
	fprintf(f, "anti alias %i\n", escopts.AA );

	fprintf(f, "sound vol %i\n", escopts.Svol );
	fprintf(f, "music vol %i\n", escopts.Mvol );
	fclose(f);

	// Update
	SoundManager::SetAllSoundVolume();
	EntityManager::UpdateQuality();
	Engine::m_AATreshold = 512-Config::S_antiAliasing*64;
}

// --------------------------------------------------------------------------
// Main Loop
// --------------------------------------------------------------------------

void EscapeMenu::Tick( float a_DT )
{
	if(m_Ask1)
	{
		AskWindow_ToMain->Tick( a_DT );
		if(AskWindow_ToMain->GetAns() == 'y'){ AskWindow_ToMain->Exit(); SetFase(EM_TOMM); m_Ask1 = false; }
		if(AskWindow_ToMain->GetAns() == 'n'){ AskWindow_ToMain->Exit(); m_Ask1 = false; }
	}
	else if(m_Ask2)
	{ 
		AskWindow_Quit->Tick( a_DT );
		if(AskWindow_Quit->GetAns() == 'y'){ Config::exitApp = true; }
		if(AskWindow_Quit->GetAns() == 'n'){ AskWindow_Quit->Exit(); m_Ask2 = false; }
	}
	else
	{
		// Handle buttons
		Button_Esc_Resume->Tick( a_DT ), Button_Esc_Options->Tick( a_DT );
		Button_Esc_ToMenu->Tick( a_DT ), Button_Esc_QuitGame->Tick( a_DT );

		if(Button_Esc_Resume->isClicked()){ m_Resume = true; }
		if(Button_Esc_Options->isClicked()){ SetFase(EM_OPTS); } 
		if(Button_Esc_ToMenu->isClicked()){ AskWindow_ToMain->Enter(); m_Ask1 = true; } 
		if(Button_Esc_QuitGame->isClicked()){ AskWindow_Quit->Enter(); m_Ask2 = true; }
	}
	
	Button_Esc_Back->Tick( a_DT ); if( Button_Esc_Back->isClicked() ){ SetFase(EM_MAIN); }
	Button_Esc_Apply->Tick( a_DT ); if( Button_Esc_Apply->isClicked() ){ SaveSettings(); }

	if(SliderBar_Esc_SoundVol->Changed() || SliderBar_Esc_MusicVol->Changed()) 
	{
		Config::S_soundVol = escopts.Svol;
		Config::S_musicVol = escopts.Mvol;
		SoundManager::SetAllSoundVolume();
	}

	// Handle option thingies
	Slider_Esc_LOD->Tick( a_DT );
	Slider_Esc_LIT->Tick( a_DT );
	Slider_Esc_AAS->Tick( a_DT );

	SliderBar_Esc_SoundVol->Tick( a_DT );
	SliderBar_Esc_MusicVol->Tick( a_DT );

	// Apply fade
	if( !InFase(EM_TOMM) )
	{
		if(m_Fade < 256.0f){ m_Fade += a_DT * 256.0f; if(m_Fade > 256.0f) m_Fade = 256.0f; }
	}
	else
	{
		if(m_Fade > 0.0f){ m_Fade -= a_DT * 512.0f; if(m_Fade < 0.0f) m_Fade = 0.0f; }
	}

	// Resize Window
	m_WinW -= (m_WinW - m_TarW) * 0.15f;
	m_WinH -= (m_WinH - m_TarH) * 0.15f;
	Button_Esc_Back->setStatic( float(Config::S_scrHeight>>1) + (m_WinH*0.5f) + 4 );

	// Exit Menu
	if(InFase(EM_TOMM)){ m_Timer += a_DT; if(m_Timer > 0.5f) m_ToMenu = true; }

	// Prevent extreme FPS
	Sleep(3);
}

// --------------------------------------------------------------------------
// Drawing Loop
// --------------------------------------------------------------------------

void EscapeMenu::Draw( Surface* a_Target, Surface* a_Cursor )
{
	m_Background->CopyTo(a_Target,0,0);

	// If the menu is in any of the MAIN fases
	WindowDraw(a_Target, int(m_WinW), int(m_WinH));
	
	// Draw Buttons
	if(InFase(EM_OPTS)) Button_Esc_Back->Draw( a_Target );
	else if(!InFase(EM_TOMM)) 
		DrawTransp( int(Button_Esc_Back->GetX())-64, int(Button_Esc_Back->GetY()), a_Target, buttonBackSealed );
	
	Button_Esc_Apply->Draw( a_Target );

	Button_Esc_Resume->Draw( a_Target ); Button_Esc_Options->Draw( a_Target );
	Button_Esc_ToMenu->Draw( a_Target ); Button_Esc_QuitGame->Draw( a_Target );

	Slider_Esc_LOD->Draw( a_Target );
	Slider_Esc_LIT->Draw( a_Target );
	Slider_Esc_AAS->Draw( a_Target );

	SliderBar_Esc_SoundVol->Draw( a_Target );
	SliderBar_Esc_MusicVol->Draw( a_Target );

	if(m_Ask1) AskWindow_ToMain->Draw( a_Target );
	if(m_Ask2) AskWindow_Quit->Draw( a_Target );

	DrawMouse( a_Target, a_Cursor );

	// Apply Fade
	if( m_Fade != 256.0f) DrawFade(a_Target, int(m_Fade), 0, 0, Config::S_scrWidth, Config::S_scrHeight);
}
	
} // namespace Raytracer