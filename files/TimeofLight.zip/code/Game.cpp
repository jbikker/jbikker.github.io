// --------------------------------------------------------------------------
// Copyright (c) Mark Peters and Bram van de Wetering 2009
// --------------------------------------------------------------------------

extern "C" { 
#include "glew.h" 
}
#include "gl.h"
#include "MainMenu.h"
#include "core.h"
#include "common_math.h"
#include "scenegraph.h"
#include "Game.h"
#include "scene.h"
#include "surface.h"
#include "Config.h"
#include "Balls.h"
#include "core.h"					// main renderer functions
#include "scene.h"					// main scene functions
#include "memory.h"					// for MManager::NewMaterial()
#include "surface.h"				// graphics surface functions
#include "scenegraph.h"				// for SceneGraph::Update()
#include "GameObjects.h"
#include "World.h"
#include "SoundManager.h"
#include "EscapeMenu.h"
#include "PostGame.h"
#include "Drawing2D.h"

namespace Raytracer {

void Game::Init()
{
	SoundManager::Init();
	PostGame::Init();
	m_MouseImg = new Surface("images/Menu Images/mouse.tga");

	// Enter menu state
	m_State = NOTHING;
	SetState( SPLASH );
}

void Game::SetState( state newState )
{
	if(m_State == newState) return;

	// Exiting off old states
	if(m_State == MAINMENU) MainMenu::Exit();
	if(m_State == ESCMENU) EscapeMenu::Exit();
	if(m_State == INGAME) Config::RenderScene = false;
	if(m_State == POSTGAME) PostGame::Exit();
	if(m_State == SPLASH)
	{
		MainMenu::SplashExit(); 
		MainMenu::Init();
		EscapeMenu::Init();
	}

	// Entering new states
	if(newState == SPLASH) MainMenu::SplashEnter();
	if(newState == MAINMENU) MainMenu::Enter();
	if(newState == ESCMENU) EscapeMenu::Enter( m_Backbuffer );
	if(newState == INGAME) Config::RenderScene = true;
	if(newState == PAUSED) DrawPauseScreen(m_Backbuffer);
	if(newState == POSTGAME) PostGame::Enter( World::GetScore(), m_Backbuffer );

	// World access
	if ((newState == POSTGAME) || (newState == MAINMENU))
	{ 
		World::ExitGame();
		SoundManager::StopAllSounds();
		SoundManager::PlayLooped( "Sound/Menu/menu_music.wad", CHANNEL_MUSIC );
	}
	if ((newState == INGAME) && (m_State == MAINMENU))
	{
		SoundManager::StopAllSounds();
		SoundManager::PlayLooped( "Sound/Ingame/ingame_music.wad", CHANNEL_MUSIC );
		World::Init(); World::NewGame();
	}

	m_State = newState;
}

void Game::Tick( float a_DT  )
{
	if(InState(INGAME)) 
	{
		if (World::GetLives() <= 0) 
		{ 
			SetState(POSTGAME); 
			return; 
		}
		World::Tick( a_DT );
		World::KeyPress();
	}
}

void Game::ShutDown()
{
	SoundManager::ShutDown();
}

void Game::PostRender( float a_DT  )
{
	if (Config::Key_Press[VK_F1]) Config::ShowStats = !Config::ShowStats;
	if (Config::Key_Press['P'])
	{
		if(InState(PAUSED)) SetState(INGAME);
		else if(InState(INGAME)) SetState(PAUSED);
	}
	if(Config::Key_Press[VK_ESCAPE])
	{
		if(InState(ESCMENU)) SetState(INGAME);
		else if(InState(INGAME)) SetState(ESCMENU);
	}

	if (InState(SPLASH)) 
	{
		MainMenu::SplashTick( a_DT );
		MainMenu::SplashDraw( m_Backbuffer );
		if(MainMenu::SplashDone()) SetState(MAINMENU);
	}

	if (InState(MAINMENU)) 
	{
		MainMenu::Tick( a_DT );
		MainMenu::Draw( m_Backbuffer, m_MouseImg );
		if(MainMenu::NewGame()) SetState(INGAME);
	}

	if (InState(ESCMENU))
	{
		EscapeMenu::Tick( a_DT );
		EscapeMenu::Draw( m_Backbuffer, m_MouseImg );
		if(EscapeMenu::Resume()) SetState(INGAME);
		if(EscapeMenu::ToMenu()) SetState(MAINMENU);
	}

	// Post game / New High Score
	if(InState(POSTGAME))
	{
		PostGame::Tick( a_DT );
		PostGame::Draw( m_Backbuffer, m_MouseImg );
		if(PostGame::IsDone()) SetState(MAINMENU);
	}

	if (Config::ShowStats) ShowStats();
	if (InState(INGAME)) World::PostRender();
}

void Game::OpenGLRender()
{
	glBindTexture( GL_TEXTURE_2D, m_ScreenTexId );
	glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, Config::S_scrWidth, Config::S_scrHeight, GL_BGRA, GL_UNSIGNED_BYTE, m_Backbuffer->GetBuffer());
	glBegin( GL_QUADS );
	if (Config::S_fullscreen)
	{
		glTexCoord2f( 0.0f, 0.0f ); glVertex2f( -1.0f,  1.0f );
		glTexCoord2f( 1.0f, 0.0f ); glVertex2f(  1.0f,  1.0f );
		glTexCoord2f( 1.0f, 1.0f ); glVertex2f(  1.0f, -1.0f );
		glTexCoord2f( 0.0f, 1.0f ); glVertex2f( -1.0f, -1.0f );
	}
	else
	{
		glTexCoord2f( 0.0f, 0.0f ); glVertex2f( 0.0f, 1.0f );
		glTexCoord2f( 1.0f, 0.0f ); glVertex2f( 1.0f, 1.0f );
		glTexCoord2f( 1.0f, 1.0f ); glVertex2f( 1.0f, 0.0f );
		glTexCoord2f( 0.0f, 1.0f ); glVertex2f( 0.0f, 0.0f );
	}
	glEnd();
	glBindTexture( GL_TEXTURE_2D, 0 );	
}

void Game::ShowStats()
{
	const int SCRWIDTH = Config::S_scrWidth;
	const int SCRHEIGHT = Config::S_scrHeight;
	char line[256];
	int ypos = 16, xpos = 10;
	m_Backbuffer->Print( "timings", xpos, ypos, 0x77ff77 ); ypos += 10;
	m_Backbuffer->Line( 7.0f, (float)ypos, 90.0f, (float)ypos, 0x55ff55 ); ypos += 4;
	sprintf( line, "physics    %05.01fms", Config::PhysicsCosts );
	m_Backbuffer->Print( line, xpos, ypos, 0x99ff99 ); ypos += 8;
	sprintf( line, "tracing    %05.01fms", Engine::m_RenderTime );
	m_Backbuffer->Print( line, xpos, ypos, 0x99ff99 ); ypos += 8;
	sprintf( line, "scene      %05.01fms", Config::SceneUpdateCost );
	m_Backbuffer->Print( line, xpos, ypos, 0x99ff99 ); ypos += 8;
	sprintf( line, "engine     %05.01fms", abs(Engine::m_LoopTime - Config::PhysicsCosts - Engine::m_RenderTime - Config::SceneUpdateCost) );
	m_Backbuffer->Print( line, xpos, ypos, 0x99ff99 ); ypos += 8;
	sprintf( line, "loop total %05.01fms", Engine::m_LoopTime );
	m_Backbuffer->Print( line, xpos, ypos, 0x99ff99 ); ypos += 8;
	ypos += 10;
	m_Backbuffer->Print( "counters", xpos, ypos, 0x77ff77 ); ypos += 10;
	m_Backbuffer->Line( 7.0f, (float)ypos, 90.0f, (float)ypos, 0x55ff55 ); ypos += 4;
	int pcount = SceneGraph::GetPolyCount();
	sprintf( line, "cpu cores  %i", Engine::m_Cores );
	m_Backbuffer->Print( line, xpos, ypos, 0x99ff99 ); ypos += 8;
	sprintf( line, "polygons   %i", pcount );
	m_Backbuffer->Print( line, xpos, ypos, 0x99ff99 ); ypos += 8;
	sprintf( line, "lights     %i", Scene::GetNrLights() );
	m_Backbuffer->Print( line, xpos, ypos, 0x99ff99 ); ypos += 8;
	sprintf( line, "display    %ix%i", SCRWIDTH, SCRHEIGHT );
	m_Backbuffer->Print( line, xpos, ypos, 0x99ff99 ); ypos += 8;
	sprintf( line, "rays cast  %i", Engine::m_RaysCast );
	m_Backbuffer->Print( line, xpos, ypos, 0x99ff99 ); ypos += 8;
	sprintf( line, "aa         %i", Engine::m_AATreshold );
	m_Backbuffer->Print( line, xpos, ypos, 0x99ff99 ); ypos += 8;
	ypos += 10;
	m_Backbuffer->Print( "derivatives", xpos, ypos, 0x77ff77 ); ypos += 10;
	m_Backbuffer->Line( 7.0f, (float)ypos, 90.0f, (float)ypos, 0x55ff55 ); ypos += 4;
	sprintf( line, "framerate  %05.02ffps", 1000.0f / Engine::m_LoopTime );
	m_Backbuffer->Print( line, xpos, ypos, 0x99ff99 ); ypos += 8;
	float rps = Engine::m_RaysCast / (Engine::m_RenderTime * 1000);
	sprintf( line, "rays/s     %06.03fM", rps );
	m_Backbuffer->Print( line, xpos, ypos, 0x99ff99 ); ypos += 8;
	sprintf( line, "ray/pixel  %06.03f", (float)Engine::m_RaysCast / float(SCRWIDTH * SCRHEIGHT) );
	m_Backbuffer->Print( line, xpos, ypos, 0x99ff99 ); ypos += 8;
	ypos += 10;

	//m_Backbuffer->Print( "ball info", xpos, ypos, 0x77ff77 ); ypos += 10;
	//m_Backbuffer->Line( 7.0f, (float)ypos, 90.0f, (float)ypos, 0x55ff55 ); ypos += 4;
	//sprintf( line, "gravity    %05.02f", Config::B_Gravity );
	//m_Backbuffer->Print( line, xpos, ypos, 0x99ff99 ); ypos += 8;
	//sprintf( line, "friction   %05.02f", Config::B_Friction );
	//m_Backbuffer->Print( line, xpos, ypos, 0x99ff99 ); ypos += 8;
	//sprintf( line, "max speed  %05.02f", Config::B_MaxSpeed );
	//m_Backbuffer->Print( line, xpos, ypos, 0x99ff99 ); ypos += 8;
	//sprintf( line, "bouncyness %05.02f", Config::B_Bouncyness );
	//m_Backbuffer->Print( line, xpos, ypos, 0x99ff99 ); ypos += 8;
	//sprintf( line, "slowdown   %05.02f", Config::B_Slowdown );
	//m_Backbuffer->Print( line, xpos, ypos, 0x99ff99 ); ypos += 8;
	//ypos += 10;

	m_Backbuffer->Print( "game info", xpos, ypos, 0x77ff77 ); ypos += 10;
	m_Backbuffer->Line( 7.0f, (float)ypos, 90.0f, (float)ypos, 0x55ff55 ); ypos += 4;
	vector3 campos = Scene::GetCamera()->GetPosition();
	sprintf( line, "cam pos      %05.02f %05.02f %05.02f", campos.x, campos.y, campos.z );
	m_Backbuffer->Print( line, xpos, ypos, 0x99ff99 ); ypos += 8;
	vector3 target = Scene::GetCamera()->GetTarget();
	sprintf( line, "cam aim      %05.02f %05.02f %05.02f", target.x, target.y, target.z );
	m_Backbuffer->Print( line, xpos, ypos, 0x99ff99 ); ypos += 8;
}

}; // namespace Raytracer