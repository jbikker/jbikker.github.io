#ifndef I_LIGHTPLACEMENT_H
#define I_LIGHTPLACEMENT_H

// --------------------------------------------------------------------------
// Global Variables & Game Settings
// --------------------------------------------------------------------------

namespace Raytracer {

class LightPlacement
{
public:
	static void Init();
	static void Tick();
	static void Message( char* a_Msg );
	static vector3 TraceMouse();
};

}; // namespace Raytracer

#endif