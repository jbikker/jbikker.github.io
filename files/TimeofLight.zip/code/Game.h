// --------------------------------------------------------------------------
// Copyright (c) Mark Peters and Bram van de Wetering 2009
// --------------------------------------------------------------------------

#pragma once

namespace Raytracer {

enum state
{
	NOTHING,
	MAINMENU,
	INGAME,
	PAUSED,
	ESCMENU,
	POSTGAME,
	SPLASH
};

class Surface;
class Game
{
public:
	void Init();
	void Tick( float a_DT  );
	void PostRender(float a_DT  );

	void OpenGLRender();

	void ShowStats();
	void ShutDown();
	
	void SetState(state newState);
	bool InState(state a_State){ return (m_State == a_State); }

	void SetTarget(Surface* a_Target){m_Backbuffer = a_Target;}
	unsigned int* GetScreenTexId(){return &m_ScreenTexId;}
private:
	Surface* m_Backbuffer;
	Surface* m_MouseImg;
	state m_State;
	unsigned int m_ScreenTexId;
};

} // namespace Raytracer