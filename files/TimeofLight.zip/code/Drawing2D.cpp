// --------------------------------------------------------------------------
// Copyright (c) Mark Peters and Bram van de Wetering 2009
// --------------------------------------------------------------------------

#include "Drawing2D.h"
#include "Config.h"
#include "string.h"

namespace Raytracer {

void ResizeIMG(Surface* a_Dest, Surface* a_Image)
{
	Pixel* src = a_Image->GetBuffer(), *dst = a_Dest->GetBuffer();
	int u, v, srcWidth = a_Image->GetWidth(), srcHeight = a_Image->GetHeight();
	int dstWidth = a_Dest->GetWidth(), dstHeight = a_Dest->GetHeight();
	int dx = (srcWidth << 10) / dstWidth, dy = (srcHeight << 10) / dstHeight;
	if((srcWidth == dstWidth) && (srcHeight == dstHeight)){ a_Image->CopyTo(a_Dest,0,0); return; }

	for ( v = 0; v < dstHeight; ++v )
	{
		for ( u = 0; u < dstWidth; ++u )
		{
			int su = u * dx, sv = v * dy;
			Pixel* s = src + (su >> 10) + (sv >> 10) * srcWidth;
			int ufrac = su & 1023, vfrac = sv & 1023;
			int w4 = (ufrac * vfrac) >> 12;
			int w3 = ((1023 - ufrac) * vfrac) >> 12;
			int w2 = (ufrac * (1023 - vfrac)) >> 12;
			int w1 = ((1023 - ufrac) * (1023 - vfrac)) >> 12;
			int x2 = ((su + dx) > ((srcWidth - 1) << 10))?0:1;
			int y2 = ((sv + dy) > ((srcHeight - 1) << 10))?0:1;
			Pixel p1 = *s, p2 = *(s + x2), p3 = *(s + srcWidth * y2), p4 = *(s + srcWidth * y2 + x2);
			unsigned int r = (((p1 & REDMASK) * w1 + (p2 & REDMASK) * w2 + (p3 & REDMASK) * w3 + (p4 & REDMASK) * w4) >> 8) & REDMASK;
			unsigned int g = (((p1 & GREENMASK) * w1 + (p2 & GREENMASK) * w2 + (p3 & GREENMASK) * w3 + (p4 & GREENMASK) * w4) >> 8) & GREENMASK;
			unsigned int b = (((p1 & BLUEMASK) * w1 + (p2 & BLUEMASK) * w2 + (p3 & BLUEMASK) * w3 + (p4 & BLUEMASK) * w4) >> 8) & BLUEMASK;
			*(dst + u + v * dstWidth) = (Pixel)(r + g + b);
		}
	}
}

void DrawFade(Surface* a_Dest, unsigned int a_Scale, int a_X, int a_Y, int a_Width, int a_Height)
{
	Pixel* dst = a_Dest->GetBuffer();
	const int srcwidth = a_Width, srcheight = a_Height;
	const int dstwidth = a_Dest->GetWidth(), dstheight = a_Dest->GetHeight();
	int rectwidth = srcwidth, rectheight = srcheight;

	if ((rectwidth + a_X) > dstwidth) rectwidth = dstwidth - a_X;
	if ((rectheight + a_Y) > dstheight) rectheight = dstheight - a_Y;
	if (a_X < 0) rectwidth += a_X, a_X =0;
	if (a_Y < 0) rectheight += a_Y, a_Y = 0;
	if ((rectwidth > 0) && (rectheight > 0))
	{
		dst += a_X + dstwidth * a_Y;
		for ( int y = 0; y<rectheight; ++y )
		{
			for( int x = 0; x<rectwidth; ++x)
			{ 
				const Pixel c = (((a_Scale * (dst[x] & 0xff00ff))>>8) & 0xff00ff) + (((a_Scale * (dst[x] & 0xff00))>>8) & 0xff00);
				dst[x] = c;
			}
			dst += dstwidth;
		}
	}
}

void DrawFCol(Surface* a_Dest, int a_X, int a_Y, int a_Width, int a_Height, Pixel a_Col)
{
	Pixel* dst = a_Dest->GetBuffer();
	const int srcwidth = a_Width, srcheight = a_Height;
	const int dstwidth = a_Dest->GetWidth(), dstheight = a_Dest->GetHeight();
	int rectwidth = srcwidth, rectheight = srcheight;

	if ((rectwidth + a_X) > dstwidth) rectwidth = dstwidth - a_X;
	if ((rectheight + a_Y) > dstheight) rectheight = dstheight - a_Y;
	if (a_X < 0) rectwidth += a_X, a_X =0;
	if (a_Y < 0) rectheight += a_Y, a_Y = 0;
	if ((rectwidth > 0) && (rectheight > 0))
	{
		dst += a_X + dstwidth * a_Y;
		for ( int y = 0; y<rectheight; ++y )
		{
			for( int x = 0; x<rectwidth; ++x)
			{ 
				const Pixel c = ((dst[x]>>1) & 0x7f7f7f) + ((a_Col>>1) & 0x7f7f7f);
				dst[x] = c;
			}
			dst += dstwidth;
		}
	}
}

void DrawFrame(int a_X, int a_Y, Surface* a_Target, Surface* a_Image, int a_Height, int a_Frame)
{
	Pixel* dst = a_Target->GetBuffer(), *src = a_Image->GetBuffer() + a_Frame*a_Height*a_Image->GetWidth();
	const int srcwidth = a_Image->GetWidth(), srcheight = a_Height;
	const int dstwidth = a_Target->GetWidth(), dstheight = a_Target->GetHeight();
	int rectwidth = srcwidth, rectheight = srcheight;

	if ((rectwidth + a_X) > dstwidth) rectwidth = dstwidth - a_X;
	if ((rectheight + a_Y) > dstheight) rectheight = dstheight - a_Y;
	if (a_X < 0) src -= a_X, rectwidth += a_X, a_X =0;
	if (a_Y < 0) src -= a_Y * srcwidth, rectheight += a_Y, a_Y = 0;
	if ((rectwidth > 0) && (rectheight > 0))
	{
		dst += a_X + dstwidth * a_Y;
		for ( int y = 0; y < rectheight; ++y )
		{
			for( int x = 0; x < rectwidth; ++x){ if(src[x] & 0xffffff) dst[x] = src[x]; }
			dst += dstwidth, src += srcwidth;
		}
	}
}

void DrawTransp(int a_X, int a_Y, Surface* a_Target, Surface* a_Image)
{
	Pixel* dst = a_Target->GetBuffer(), *src = a_Image->GetBuffer();
	const int srcwidth = a_Image->GetWidth(), srcheight = a_Image->GetHeight();
	const int dstwidth = a_Target->GetWidth(), dstheight = a_Target->GetHeight();
	int rectwidth = srcwidth, rectheight = srcheight;

	if ((rectwidth + a_X) > dstwidth) rectwidth = dstwidth - a_X;
	if ((rectheight + a_Y) > dstheight) rectheight = dstheight - a_Y;
	if (a_X < 0) src -= a_X, rectwidth += a_X, a_X =0;
	if (a_Y < 0) src -= a_Y * srcwidth, rectheight += a_Y, a_Y = 0;
	if ((rectwidth > 0) && (rectheight > 0))
	{
		dst += a_X + dstwidth * a_Y;
		for ( int y = 0; y < rectheight; ++y )
		{
			for( int x = 0; x < rectwidth; ++x){ if(src[x] & 0xffffff) dst[x] = src[x]; }
			dst += dstwidth, src += srcwidth;
		}
	}
}

void DrawPartial(int a_X, int a_Y, int a_Width, int a_Height, Surface* a_Target, Surface* a_Image)
{
	Pixel* dst = a_Target->GetBuffer(), *src = a_Image->GetBuffer();
	const int srcwidth = a_Image->GetWidth();
	const int dstwidth = a_Target->GetWidth(), dstheight = a_Target->GetHeight();
	int rectwidth = a_Width, rectheight = a_Height;

	if ((rectwidth + a_X) > dstwidth) rectwidth = dstwidth - a_X;
	if ((rectheight + a_Y) > dstheight) rectheight = dstheight - a_Y;
	if (a_X < 0) src -= a_X, rectwidth += a_X, a_X =0;
	if (a_Y < 0) src -= a_Y * srcwidth, rectheight += a_Y, a_Y = 0;
	if ((rectwidth > 0) && (rectheight > 0))
	{
		dst += a_X + dstwidth * a_Y;
		for ( int y = 0; y < rectheight; ++y )
		{
			for( int x = 0; x < rectwidth; ++x){ if(src[x] & 0xffffff) dst[x] = src[x]; }
			dst += dstwidth, src += srcwidth;
		}
	}
}

void DrawTiled(int a_X, int a_Y, Surface* a_Target, Surface* a_Image)
{
	Pixel* dst = a_Target->GetBuffer(), *osrc = a_Image->GetBuffer();
	int dstW = a_Target->GetWidth(), dstH = a_Target->GetHeight(), dstP = a_Target->GetPitch();
	int srcW = a_Image->GetWidth(), srcH = a_Image->GetHeight(), srcP = a_Image->GetPitch();
	while(a_X < 0) a_X += srcW;	while(a_Y < 0) a_Y += srcH;
	Pixel* src = osrc + a_Y*srcP;
	int oX = a_X;
	
	for(int y=0; y<dstH; y++)
	{
		int x=0, a_X=oX;
		while(x<dstW)
		{
			int width = MIN(srcW-a_X,dstW-x);
			memcpy(&dst[x],&src[a_X],width*sizeof(Pixel));
			x+=width; a_X=0;
		}
		src += srcP, dst += dstP;
		if(++a_Y == srcH){ a_Y=0; src = osrc; }
	}
}

void PrintSafe(Surface* a_Target, char* a_String, int a_X, int a_Y, Pixel a_Col)
{
	if(a_X < 0 || a_X > Config::S_scrWidth-strlen(a_String)*6) return;
	if(a_Y < 0 || a_Y > Config::S_scrHeight-8) return;
	a_Target->Print(a_String, a_X, a_Y, a_Col);
}

void BarSafe(Surface* a_Target, int a_X1, int a_Y1, int a_X2, int a_Y2, Pixel a_Col)
{
	if(a_X1 < 0) a_X1 = 0; if(a_X2 > Config::S_scrWidth-1) a_X2 = Config::S_scrWidth-1;
	if(a_Y1 < 0) a_Y1 = 0; if(a_Y2 > Config::S_scrHeight-1) a_Y2 = Config::S_scrHeight-1;
	if(a_X1 < a_X2 && a_Y1 < a_Y2) a_Target->Bar(a_X1, a_Y1, a_X2, a_Y2, a_Col);
}

void Sephia(Surface* a_Target, Surface* a_Src)
{
	Pixel* dst = a_Target->GetBuffer();
	Pixel* src = a_Src->GetBuffer();
	int dstW = a_Target->GetWidth(), dstH = a_Target->GetHeight();
	for(int y=0; y<dstH; ++y)
	{
		for(int x=0; x<dstW; ++x)
		{
			int cval = (((src[x] & REDMASK) >> 16) + ((src[x] & GREENMASK) >> 8) + (src[x] & BLUEMASK))/3;
			dst[x] = (((0xC80064*cval)>>8)&0xff00ff) + (((0x8000*cval)>>8)&0xff00);
		}
		src += a_Src->GetPitch();
		dst += a_Target->GetPitch();
	}
}

void DrawPauseScreen(Surface* a_Target)
{
	Sephia(a_Target, a_Target);
	int centerY = (Config::S_scrHeight>>1), pitch = a_Target->GetPitch();
	Pixel* dst1 = a_Target->GetBuffer() + (centerY-18)*pitch, *dst3 = dst1+pitch;
	Pixel* dst2 = a_Target->GetBuffer() + (centerY-6)*pitch, *dst4 = dst2+pitch;
	for(int i=0; i<pitch; ++i)
	{ 
		int dist = MAX(0,255-512*abs((pitch>>1)-i)/pitch);
		dst1[i] = dst2[i] = (dist<<16)+(dist<<8)+dist;
		dst3[i] = dst4[i] = ((dist<<14)&REDMASK)+((dist<<6)&GREENMASK+(dist>>2));
	}
	a_Target->Print("Paused",(Config::S_scrWidth>>1)-strlen("Paused")*3,centerY-14,0xffffff);
}

void DrawMouse(Surface* a_Target, Surface* a_Cursor)
{
	Pixel* dst = a_Target->GetBuffer();
	const int dstW = a_Target->GetWidth(), dstH = a_Target->GetHeight();

	int startX = MAX(0, Config::Mouse_X-96);
	int endX = MIN(dstW,Config::Mouse_X+96);
	int startY = MAX(0, Config::Mouse_Y-96);
	int endY = MIN(dstH,Config::Mouse_Y+96);
	dst += startY*dstW;
	
	for(int y=startY; y<endY; y++)
	{
		int dy = (Config::Mouse_Y - y);
		for(int x=startX; x<endX; x++)
		{
			int dx = (Config::Mouse_X - x);
			int sqrdist = dx*dx+dy*dy;
			if(sqrdist < 8192)
			{
				int str = (16384-sqrdist)>>5;
				if(sqrdist < 256) str += 256-sqrdist;
				int r = (dst[x]&REDMASK)>>16;
				int g = (dst[x]&GREENMASK)>>8;
				int b = (dst[x]&BLUEMASK);

				r = (r*str)>>8;
				g = (g*str)>>8;
				b = (b*str)>>8;

				r += MAX(r-64-(str>>1),0);
				g += MAX(g-64-(str>>1),0);
				b += MAX(b-64-(str>>1),0);

				r = (r&255)|(255*(r>>8));
				g = (g&255)|(255*(g>>8));
				b = (b&255)|(255*(b>>8));

				dst[x] = (r<<16)|(g<<8)|b;
			}
		}
		dst += dstW;
	}
	if (Config::S_fullscreen) DrawTransp(Config::Mouse_X, Config::Mouse_Y, a_Target, a_Cursor);
}

void GradientLine(Surface* a_Target, int a_X, int a_Y, int a_X2, Pixel a_Col1, Pixel a_Col2, int alpha)
{
	if(a_X > a_X2){ int tmp=a_X; a_X=a_X2; a_X2=tmp; Pixel tmpc=a_Col1, a_Col2=a_Col1, a_Col1=tmpc; }
	Pixel* dst = a_Target->GetBuffer() + a_Y*a_Target->GetPitch() + a_X;
	int Q16_step = (1<<16)/(a_X2-a_X);
	for(int i=0; i<(a_X2-a_X); i++) 
	{
		Pixel lcol = BlendColors(a_Col1, a_Col2, (Q16_step*i)>>8);
		dst[i] = BlendColors(dst[i], lcol, alpha);
	}
}

} // namespace Raytracer